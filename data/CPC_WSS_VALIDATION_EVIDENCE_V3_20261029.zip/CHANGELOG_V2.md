# V2 change record — 29 October 2026

The human author authorized preparation of a Zenodo draft, CC BY 4.0 for data/
documentation and MIT for software, and confirmed Aditya Nur Cahyo as the sole
dataset creator. File-level mixed-licence mapping and exact licence texts were
added. Collection README/licence status were updated. Original V1 is preserved.

All 9,804 original evidence payloads retain their exact hashes. No case, verdict,
oracle, outcome, negative result, source code or counterexample was changed.
Original freeze manifests remain exact; 38 omitted internal files remain listed.
The subset is inspectable but not an unmodified sealed-runner replay package.
No test, HMAC, validator, join, scoring, native action or experiment was run.
No DOI, live deposit, public repository update or final publication is claimed.

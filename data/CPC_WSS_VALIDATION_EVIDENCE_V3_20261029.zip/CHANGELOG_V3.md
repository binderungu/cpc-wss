# Distribution V3 — 29 October 2026

The author chose to skip Zenodo and continue the existing GitHub route.
This distribution updates host/version metadata to tag `repository-evidence-v2-20261029`. All9,804
original evidence payloads and the agreed per-file CC BY 4.0/MIT map are retained.
V2 remains in the local preservation archive. No research code, oracle,
decision, metric, counterexample or negative result changed. No test or study
was run. A DOI and journal policy approval are not asserted.

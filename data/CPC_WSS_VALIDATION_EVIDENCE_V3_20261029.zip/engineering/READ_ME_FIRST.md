# Existing join engineering evidence — no new execution
The unchanged receipt attempt004-sealed_UNITTEST.json records a 1.11.0 engineering suite. Exactly 21 test_wss_join.JoinTests method records are the subset cited here. The original whole-suite receipt is retained for context and must not be presented as a new 1.12.0 result.

All receipt-bound test files and tested-source payloads are hash-checked during curation. JOIN_EVIDENCE_BINDING.json lists the 21 method records and nine byte-identical join dependency modules in current 1.12.0. Package __init__.py/version differs. Identical dependency bytes support reuse of that historical evidence only within its tested scope; they do not establish every branch/current module is qualified or that a new 1.12.0 test occurred.

The copied fixture/test/source files are archival evidence, not a test launch request. The regression fixtures include synthetic signing values and generate synthetic local state if executed; they must not be used as production credentials. No test is run in this task. No source is patched.

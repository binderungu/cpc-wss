from dataclasses import replace,fields
import itertools
import json
import os
from pathlib import Path
import subprocess
import stat
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from wss_bridge import baselines as b
from wss_bridge.cpc_adapter import AdmissionContext
from wss_bridge.join import JoinPolicy,mapping_from_analysis
from wss_bridge.outcomes import ExternalRow,typed_value
from wss_bridge.primitives import ContractError,plain_json
from wp07_fixtures import flow,followup,encode,external_mapping
from wp06_fixtures import re_sign_outcome


def common(f,*,inputs=None,external=None,context=None,auxiliary=None,native=None,exposures=None):
    ref=f['entry'].input_ref
    inputs=(b.RawInput(ref,(f['root']/'WP07_CHAIN.json').read_bytes()),) if inputs is None else tuple(inputs)
    return b.CommonEvidence('fixture:wp08-common',inputs,f['adapter'].context if context is None else context,
        b.capture_native(f['controller'],f['analysis']) if native is None else native,
        {item.input_ref:f['exposure_raw'] for item in inputs} if exposures is None else exposures,
        (f['external'],) if external is None else tuple(external),JoinPolicy.from_recipe(f['recipe']),
        {**{'producer:'+str(path.relative_to(f['root']/'producer')):path.read_bytes()
            for path in sorted((f['root']/'producer').rglob('*')) if stat.S_ISREG(path.lstat().st_mode)},
         'source-response-recipe':f['recipe'].raw} if auxiliary is None else auxiliary)


def evaluate(c,method='B2'):
    return b.evaluate_full(c,method=method,cohort_ref='fixture:cohort',snapshot_ref='fixture:analysis')


class BaselineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.f=flow();cls.c=common(cls.f)

    def test_actual_positive_all_full_arms_match_and_b1_abstains(self):
        result=b.run_comparison(self.c,cohort_ref='fixture:cohort',snapshot_ref='fixture:analysis')
        for method in ('B0','B2'):
            with self.subTest(method=method):
                self.assertEqual(result['comparisons'][method]['status'],'MATCH')
                self.assertEqual(result['arms'][method]['results'][0]['result']['disposition'],'ADMIT')
                self.assertEqual(result['arms'][method]['join']['core_ledger'][0]['primary_reason'],'JOINED')
                self.assertEqual(result['arms'][method]['join']['core_ledger'][0]['value'],2)
                self.assertEqual(result['arms'][method]['access_receipt'],result['arms']['CPC_REFERENCE']['access_receipt'])
        self.assertEqual(result['B1']['ledger'][0]['cardinality_observation'],'REPORTED_SINGLETON')
        self.assertEqual(result['B1']['attributed_joined'],0)
        self.assertEqual(result['B1']['ledger'][0]['decision'],'ABSTAIN')
        self.assertEqual(result['arms']['B0']['native_sop_rows'][0]['selected_source']['status'],'VERIFIED_LOCAL_BYTES')
        (Path(os.environ['WSS_TEST_ARTIFACT_ROOT'])/'WP08_POSITIVE_COMPARISON.json').write_bytes(encode(result))
        (Path(os.environ['WSS_TEST_ARTIFACT_ROOT'])/'WP08_COMMON_INPUT_SNAPSHOT.json').write_bytes(encode({
            'receipt':self.c.receipt,'native':self.c.native,'inputs':[{'input_ref':r.input_ref,'raw_hex':r.raw.hex()} for r in self.c.inputs],
            'exposures':{k:v.hex() for k,v in self.c.exposures.items()},'external':[r.descriptor for r in self.c.external_rows],
            'auxiliary':{k:v.hex() for k,v in self.c.auxiliary.items()},
            'key_material':'not exported; new synthetic QA fixture keys are defined in preserved tests/wp05_fixtures.py'}))

    def test_actual_rules_equal_reference_on_semantic_wire_and_cardinality_negatives(self):
        chain=json.loads(self.c.inputs[0].raw);p,_,_=self.c.context.arguments()
        data=[('positive',self.c.inputs[0].raw,'ADMIT'),
              ('purpose',encode(re_sign_outcome(chain,p,purpose='fixture:unapproved')),'REJECT'),
              ('missing-outcome',encode({**chain,'records':chain['records'][:-1]}),'QUARANTINE'),
              ('wire',b'not json','ERROR_INPUT'),('utf8',b'\xff','ERROR_INPUT')]
        inputs=tuple(b.RawInput('fixture:'+name,raw) for name,raw,_ in data)
        c=common(self.f,inputs=inputs)
        ref=evaluate(c,'CPC_REFERENCE');alt=evaluate(c)
        self.assertEqual([r['result']['disposition'] for r in alt['results']],[want for _,_,want in data])
        self.assertEqual(b.compare_full(ref,alt)['status'],'MATCH')
        self.assertEqual(alt['join']['counts']['received_core'],5)
        (Path(os.environ['WSS_TEST_ARTIFACT_ROOT'])/'WP08_NEGATIVE_PARITY.json').write_bytes(encode({'reference':ref,'B2':alt,'comparison':b.compare_full(ref,alt)}))

    def test_invalid_operator_config_preserves_actual_not_evaluated_bucket(self):
        for ctx in [AdmissionContext({},self.c.context.key_registry,self.c.context.validation_time),
                    AdmissionContext(self.c.context.profile,None,None)]:
            with self.subTest(context=ctx.digest):
                c=replace(self.c,context=ctx);ref=evaluate(c,'CPC_REFERENCE');alt=evaluate(c)
                self.assertEqual(alt['results'][0]['result']['disposition'],'ERROR_CONFIG')
                self.assertEqual(alt['join']['counts']['core_buckets']['NOT_EVALUATED_CONFIG'],1)
                self.assertEqual(b.compare_full(ref,alt)['status'],'MATCH')

    def test_baselines_do_not_call_CPC_api(self):
        with patch.object(b,'_dependency',side_effect=AssertionError('baseline may not call CPC')) as api:
            for method in ('B0','B2'):
                self.assertEqual(evaluate(self.c,method)['results'][0]['result']['disposition'],'ADMIT')
            api.assert_not_called()

    def test_byte_keys_lossless_transport_and_binary_keys_unresolved(self):
        actual=b._rules_dependency();seen=[]
        def observe(raw,profile,keys,now,**kwargs):
            seen.append(keys)
            return actual.validate_raw(raw,profile,keys,now,**kwargs)
        with patch.object(b,'_rules_dependency',return_value=SimpleNamespace(validate_raw=observe)):
            self.assertEqual(evaluate(self.c)['status'],'EVALUATED')
        for key,value in self.c.context.key_registry.items():
            self.assertEqual(seen[0][key].encode(),value if type(value) is bytes else value.encode())
        p,k,t=self.c.context.arguments();k[next(iter(k))]=b'\xff'
        result=evaluate(replace(self.c,context=AdmissionContext(p,k,t)))
        self.assertEqual(result['status'],'INCOMPLETE_EVALUATION');self.assertIsNone(result['results'][0]['result'])

    def test_full_budget_fingerprints_every_component_and_freezes_caller_data(self):
        native=plain_json(self.c.native);exposures=dict(self.c.exposures);aux={'capture':b'before'}
        c=common(self.f,native=native,exposures=exposures,auxiliary=aux)
        before=c.digest;native['current_head']='changed';exposures.clear();aux['capture']=b'after'
        self.assertEqual(c.digest,before);self.assertEqual(c.auxiliary['capture'],b'before')
        with self.assertRaises(TypeError):c.native['view']['attempts']['forbidden']='changed'
        variants=[replace(c,auxiliary={'capture':b'other'}),replace(c,exposures={}),
                  replace(c,inputs=(b.RawInput(c.inputs[0].input_ref,b'other'),)),
                  replace(c,external_rows=()),replace(c,policy=replace(c.policy,rubric_version='different')),
                  replace(c,native={**plain_json(c.native),'current_head':'fixture:new-head'})]
        for other in variants:
            with self.subTest(digest=other.digest):self.assertNotEqual(c.digest,other.digest)
        altered=replace(c.external_rows[0],measure_state='INVALID')
        self.assertEqual(altered.descriptor,c.external_rows[0].descriptor)
        self.assertNotEqual(c.digest,replace(c,external_rows=(altered,)).digest)

    def test_keys_not_exposed_in_access_or_failure_receipts(self):
        with patch.object(b,'_rules_dependency',side_effect=RuntimeError('private-secret')):
            result=evaluate(self.c)
        data=encode(result)
        self.assertNotIn(b'private-secret',data)
        for key in self.c.context.key_registry.values():
            self.assertNotIn(key if type(key) is bytes else key.encode(),data)

    def test_mutating_engine_inputs_is_unresolved_and_common_context_unchanged(self):
        p,k,t=self.c.context.arguments()
        def mutate(raw,profile,keys,now,**kwargs):
            profile['profile_state']='changed';return {}
        with patch.object(b,'_rules_dependency',return_value=SimpleNamespace(validate_raw=mutate)):
            result=evaluate(self.c)
        self.assertEqual(result['status'],'INCOMPLETE_EVALUATION')
        self.assertEqual(self.c.context.arguments(),(p,k,t))

    def test_exception_and_malformed_results_are_unresolved_not_fake_verdicts(self):
        valid=plain_json(evaluate(self.c)['results'][0]['result'])
        for bad in [{},None,{**valid,'input_ref':'fixture:wrong'},
                    {**valid,'input_sha256':'sha256:'+'0'*64},
                    {**valid,'diagnostics':[1]},{**valid,'extra':'forbidden'}]:
            with self.subTest(kind=repr(bad)[:50]):
                with patch.object(b,'_rules_dependency',return_value=SimpleNamespace(validate_raw=lambda *a,**k:bad)):
                    result=evaluate(self.c)
                self.assertEqual(result['join']['counts']['unresolved_core'],1)
                self.assertIsNone(result['results'][0]['result'])
                self.assertEqual(sum(result['join']['counts']['core_buckets'].values()),0)
        with patch.object(b,'_rules_dependency',return_value=SimpleNamespace(validate_raw=lambda *a,**k:(_ for _ in ()).throw(RuntimeError('secret')))):
            self.assertEqual(evaluate(self.c)['status'],'INCOMPLETE_EVALUATION')

    def test_native_mapping_failure_keeps_actual_core_and_marks_incomplete(self):
        with patch.object(b,'frozen_mapping',side_effect=RuntimeError('source unavailable')):
            result=evaluate(self.c)
        self.assertEqual(result['results'][0]['result']['disposition'],'ADMIT')
        self.assertEqual(result['join']['counts']['admitted_mapping']['PENDING'],1)
        self.assertEqual(result['status'],'INCOMPLETE_EVALUATION')
        self.assertEqual(b.compare_full(result,result)['status'],'INCOMPLETE_EVALUATION')

    def test_matching_unresolved_never_becomes_parity_pass(self):
        with patch.object(b,'_rules_dependency',side_effect=OSError('missing reference')):
            result=evaluate(self.c)
        self.assertEqual(b.compare_full(result,result)['status'],'INCOMPLETE_EVALUATION')
        self.assertFalse(result['join']['complete_for_declared_snapshot'])

    def test_disagreement_is_diagnosis_and_diagnostics_are_separate(self):
        reference=plain_json(evaluate(self.c,'CPC_REFERENCE'));alternative=plain_json(evaluate(self.c))
        changed=json.loads(encode(alternative));changed['results'][0]['result']['admitted_record']['purpose']='fixture:changed'
        result=b.compare_full(reference,changed)
        self.assertEqual(result['status'],'MISMATCH_REQUIRES_DIAGNOSIS')
        self.assertEqual(result['normalized_export_differences'],(self.c.inputs[0].input_ref,))
        wording=json.loads(encode(alternative));wording['results'][0]['result']['diagnostics']=[{'code':'different wording'}]
        result=b.compare_full(reference,wording)
        self.assertEqual(result['status'],'MATCH');self.assertEqual(len(result['diagnostic_wording_differences']),1)
        altered=json.loads(encode(alternative));altered['join']['core_ledger'][0]['value']=4
        self.assertEqual(b.compare_full(reference,altered)['status'],'MISMATCH_REQUIRES_DIAGNOSIS')

    def test_unequal_budget_or_input_scope_cannot_be_compared(self):
        reference=plain_json(evaluate(self.c,'CPC_REFERENCE'))
        for change in [{'common_evidence_digest':'other'}, {'results':[]},
                       {'access_receipt':{}}, {'results':reference['results']*2}]:
            with self.subTest(change=list(change)),self.assertRaises(ContractError):
                b.compare_full(reference,{**reference,**change})
        altered=json.loads(encode(reference));altered['results'][0]['raw_digest']='other'
        with self.assertRaises(ContractError):b.compare_full(reference,altered)

    def test_shared_mapping_matches_WP07_positive_missing_exposure_and_conflict(self):
        for raw in [self.f['exposure_raw'],None,b'bad']:
            with self.subTest(raw='missing' if raw is None else len(raw)):
                a=mapping_from_analysis(self.f['controller'],self.f['analysis'],self.f['entry'],raw)
                c=b.frozen_mapping(self.c.native,self.f['entry'],raw)
                self.assertEqual(c,a)

    def test_actual_native_reasoned_holds_and_failed_retry_equal_reference(self):
        receipts=[]
        for extra,want in [('failed-retry','JOINED'),('unknown-retry','NATIVE_MAPPING_HOLD'),('second-publication','NATIVE_MAPPING_HOLD')]:
            with self.subTest(extra=extra):
                f=flow(extra=extra);c=common(f)
                self.assertEqual(b.frozen_mapping(c.native,f['entry'],f['exposure_raw']),mapping_from_analysis(f['controller'],f['analysis'],f['entry'],f['exposure_raw']))
                result=b.run_comparison(c,cohort_ref='fixture:holds',snapshot_ref='fixture:analysis')
                self.assertEqual(result['comparisons']['B2']['status'],'MATCH')
                self.assertEqual(result['arms']['B2']['join']['core_ledger'][0]['primary_reason'],want)
                receipts.append(result)
        (Path(os.environ['WSS_TEST_ARTIFACT_ROOT'])/'WP08_NATIVE_SHAPED_HOLDS.json').write_bytes(encode(receipts))

    def test_captured_late_history_preserves_old_bundle_and_old_join(self):
        f=flow();old=common(f);old_bytes=encode(evaluate(old))
        followup(f['controller'],f['attempt'],b'explains and checks the rule',log_id=103,watermark=102)
        revised=f['controller'].analysis_snapshot(reason='WP08_LATE_REVISION')
        historical=replace(old,native=b.capture_native(f['controller'],f['analysis']))
        self.assertEqual(encode(evaluate(old)),old_bytes)
        self.assertFalse(evaluate(historical)['join']['complete_for_declared_snapshot'])
        current=common({**f,'analysis':revised})
        self.assertEqual(b.frozen_mapping(current.native,f['entry'],f['exposure_raw']),mapping_from_analysis(f['controller'],revised,f['entry'],f['exposure_raw']))
        # A later source revision is not a score-valid rescue or a new outcome.
        self.assertEqual(evaluate(current)['join']['core_ledger'][0]['value'],2)

    def test_external_and_admission_duplicates_count_before_filters_in_all_arms(self):
        invalid=external_mapping(self.f['outcome'],value=True)
        c=replace(self.c,external_rows=(self.f['external'],ExternalRow.from_mapping(invalid)))
        self.assertEqual(evaluate(c)['join']['core_ledger'][0]['primary_reason'],'EXTERNAL_COMPOSITE_AMBIGUOUS')
        c=replace(self.c,inputs=(self.c.inputs[0],b.RawInput('fixture:duplicate',self.c.inputs[0].raw)),
                  exposures={**self.c.exposures,'fixture:duplicate':self.f['exposure_raw']})
        for method in ('CPC_REFERENCE','B0','B2'):
            with self.subTest(method=method):
                result=evaluate(c,method)
                self.assertEqual(result['join']['counts']['core_buckets']['ADMIT'],2)
                self.assertEqual(result['join']['core_ledger'][0]['primary_reason'],'ADMISSION_COMPOSITE_AMBIGUOUS')

    def test_b1_closed_slice_and_singleton_cannot_claim_validated_attribution(self):
        core,external=b.project_b1(self.c)
        self.assertEqual({f.name for f in fields(b.AblationRow)},{'pair_key','reported_label','scalar_descriptor'})
        self.assertEqual(core[0].pair_key,external[0].pair_key)
        self.assertEqual(external[0].scalar_descriptor,{'type':'int','decimal':'2'})
        serialized=encode({'core':[r.__getstate__() for r in core],'external':[r.__getstate__() for r in external]})
        for forbidden in [b'experiment_id',b'unit_token',b'composite',b'profile',b'rubric',b'lineage_ref',b'prompt']:
            self.assertNotIn(forbidden,serialized)
        with self.assertRaises(TypeError):b.AblationRow('pair:x','hint',typed_value(2),profile={})
        with self.assertRaises(ContractError):b.AblationRow('pair:x','hint',{'type':'object','items':[]})
        with self.assertRaises(ContractError):b.evaluate_b1([self.c],[],cohort_ref='fixture:c',snapshot_ref='fixture:s')

    def test_b1_preserves_duplicates_missing_and_uninterpretable_rows(self):
        row=b.AblationRow('pair:x','hint',typed_value(None));bad=b.AblationRow(None,None,typed_value(None))
        result=b.evaluate_b1([row,row,bad],[row,row,bad],cohort_ref='fixture:c',snapshot_ref='fixture:s')
        self.assertEqual(result['received_core'],3);self.assertEqual(result['received_external'],3)
        self.assertEqual(result['ledger'][0]['cardinality_observation'],'CORE_KEY_AMBIGUOUS')
        self.assertEqual(result['ledger'][2]['cardinality_observation'],'KEY_UNINTERPRETABLE')
        self.assertEqual(result['abstained'],3);self.assertEqual(result['attributed_joined'],0)
        result=b.evaluate_b1([row],[],cohort_ref='fixture:c',snapshot_ref='fixture:s')
        self.assertEqual(result['ledger'][0]['cardinality_observation'],'EXTERNAL_MISSING')

    def test_b1_projection_uses_rejected_raw_inputs_not_only_admitted(self):
        chain=json.loads(self.c.inputs[0].raw);profile,_,_=self.c.context.arguments()
        raw=encode(re_sign_outcome(chain,profile,purpose='fixture:unapproved'))
        c=replace(self.c,inputs=(b.RawInput('fixture:rejected',raw),b.RawInput('fixture:malformed',b'bad')),
                  exposures={})
        core,external=b.project_b1(c)
        self.assertEqual(len(core),2);self.assertIsNotNone(core[0].pair_key);self.assertIsNone(core[1].pair_key)
        self.assertEqual(len(b.evaluate_b1(core,external,cohort_ref='fixture:c',snapshot_ref='fixture:s')['ledger']),2)

    def test_b1_scalar_slice_never_leaks_metadata_on_invalid_values(self):
        for value in [True,None,'4',2.0,[],{'profile':'do not leak'},'\ud800']:
            with self.subTest(value=repr(value)):
                c=replace(self.c,external_rows=(ExternalRow.from_mapping(external_mapping(self.f['outcome'],value=value)),))
                _,rows=b.project_b1(c);data=encode(rows[0].scalar_descriptor)
                self.assertNotIn(b'composite',data);self.assertNotIn(b'rubric',data);self.assertNotIn(b'do not leak',data)

    def test_resource_bounds_duplicate_refs_and_scope_fail_explicitly(self):
        for action in [lambda:replace(self.c,inputs=itertools.repeat(self.c.inputs[0])),
                       lambda:replace(self.c,inputs=self.c.inputs*2),
                       lambda:replace(self.c,exposures={'fixture:outside':b'x'}),
                       lambda:replace(self.c,auxiliary={'fixture:large':b'x'*(b.MAX_BYTES+1)}),
                       lambda:b.RawInput('fixture:raw',b'x'*(16777216+1)),
                       lambda:b.evaluate_b1([b.AblationRow(None,None,typed_value('x'*8192))]*10000,[],cohort_ref='fixture:c',snapshot_ref='fixture:s'),
                       lambda:b.evaluate_b1(itertools.repeat(b.AblationRow(None,None,typed_value(None))),[],cohort_ref='fixture:c',snapshot_ref='fixture:s')]:
            with self.subTest(action=str(action)),self.assertRaises(ContractError):action()

    def test_raw_generator_is_refused_at_byte_budget_before_materialization(self):
        raw=b'x'*16777216;seen=[]
        def generated():
            for number in range(10000):
                seen.append(number);yield b.RawInput('fixture:large-'+str(number),raw)
        with self.assertRaises(ContractError):replace(self.c,inputs=generated(),exposures={})
        self.assertEqual(len(seen),5)

    def test_absolute_pinned_rules_ignore_sys_path_shadow(self):
        # A fake global comparator is never read/executed by the private loader.
        with patch.dict(sys.modules,{'comparator.independent_rules':SimpleNamespace(validate_raw=lambda *a,**k:(_ for _ in ()).throw(AssertionError('shadow')))}):
            module=b._rules_dependency();self.assertEqual(module.COMPARATOR_VERSION,'1.0.1')
            self.assertTrue(Path(module.__file__).resolve().is_relative_to(Path(os.environ['WSS_CODE_ROOT'])/'references'))
            self.assertEqual(evaluate(self.c)['results'][0]['result']['disposition'],'ADMIT')
        with patch.object(b,'verify_pinned_references',side_effect=ContractError('modified catalogue')):
            result=evaluate(self.c)
        self.assertEqual(result['status'],'INCOMPLETE_EVALUATION')

    def test_engine_receipts_bind_exact_rules_catalogue_and_reject_wrong_pin(self):
        reference=plain_json(evaluate(self.c,'CPC_REFERENCE'));alternative=plain_json(evaluate(self.c))
        self.assertEqual(alternative['engine_receipt']['version'],'1.0.1')
        self.assertIn('comparator_release/implementation/spec/FIELD_REQUIREMENTS.json',alternative['engine_receipt']['files'])
        for change in [{'manifest_sha256':'sha256:'+'0'*64},{'version':'other'},{'files':{}}]:
            altered=json.loads(encode(alternative));altered['engine_receipt'].update(change)
            with self.subTest(change=list(change)),self.assertRaises(ContractError):b.compare_full(reference,altered)
        for change in [{'method':'FAKE'},{'format':'other'},{'extra':'unexpected'}]:
            with self.subTest(change=list(change)),self.assertRaises(ContractError):b.compare_full(reference,{**alternative,**change})

    def test_b1_rejects_noncanonical_scalar_descriptors(self):
        for descriptor in [{'type':'int','decimal':'bogus'},{'type':'int','decimal':'01'},
                           {'type':'float','hex':'bogus'},{'type':'str-surrogatepass','hex':'GG'},
                           {'type':'bool','value':1},{'type':'int','decimal':True}]:
            with self.subTest(descriptor=descriptor),self.assertRaises(ContractError):b.AblationRow(None,None,descriptor)

    def test_native_captured_snapshot_contains_retained_initial_and_followup_bytes(self):
        native=self.c.native
        self.assertGreaterEqual(len(native['retained_local_snapshot_hex']),4)
        source=native['selected_sources'][self.f['attempt']]
        self.assertEqual(bytes.fromhex(source['value_hex']),b'separates input and instruction')
        transports=[]
        for value in native['retained_local_snapshot_hex'].values():
            try:row=json.loads(bytes.fromhex(value))
            except (ValueError,UnicodeError):continue
            if isinstance(row,dict) and 'transport_version' in row:transports.append(row)
        self.assertGreaterEqual(len(transports),2)

    def test_source_value_cannot_smuggle_unreferenced_snapshot_pointer(self):
        f=flow();ctl=f['controller']
        secret=ctl.store.put('fixture:unreferenced-test-marker',b'UNREFERENCED_MARKER_NOT_COMMON_SOURCE')
        followup(ctl,f['attempt'],encode(secret.to_mapping()),log_id=103,watermark=102)
        revised=ctl.analysis_snapshot(reason='WP08_REFERENCE_SHAPED_VALUE')
        native=b.capture_native(ctl,revised)
        self.assertNotIn(secret.snapshot_ref,native['retained_local_snapshot_hex'])
        self.assertNotIn(b'UNREFERENCED_MARKER_NOT_COMMON_SOURCE'.hex(),native['retained_local_snapshot_hex'].values())

    def test_valid_CPC_unicode_domain_survives_full_rules_and_projection(self):
        f=flow(unicode_context=True);c=common(f);result=b.run_comparison(c,cohort_ref='fixture:c',snapshot_ref='fixture:s')
        self.assertEqual(result['comparisons']['B2']['status'],'MATCH')
        self.assertIn('\u200d',result['arms']['B2']['results'][0]['result']['admitted_record']['purpose'])

    def test_b1_pure_evaluation_has_no_file_process_network_access(self):
        code='''import sys
from wss_bridge.baselines import AblationRow,evaluate_b1
def guard(event,args):
 if event=='open' or event.startswith(('socket.','subprocess.','sqlite3.')) or event in {'os.listdir','os.scandir','os.system'}:raise PermissionError(event)
sys.addaudithook(guard)
r=evaluate_b1([AblationRow('pair:1','hint',{'type':'null'})],[],cohort_ref='fixture:c',snapshot_ref='fixture:s')
assert r['abstained']==1
'''
        env=dict(os.environ,PYTHONPATH=str(Path(os.environ['WSS_CODE_ROOT'])/'src'))
        result=subprocess.run([sys.executable,'-B','-c',code],env=env,capture_output=True,text=True,timeout=20)
        self.assertEqual(result.returncode,0,result.stderr)

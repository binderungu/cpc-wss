from dataclasses import FrozenInstanceError
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from wss_bridge.capture import ClockObservation, LocalClock, capture_and_render
from wss_bridge.ledger import SnapshotStore
from wss_bridge.primitives import ContractError
from wp04_fixtures import inputs, encode, digest, independent_expected


class ConsumeCaptureTests(unittest.TestCase):
    def setUp(self):
        self.root=Path(tempfile.mkdtemp(prefix='consume-',dir=os.environ['WSS_TEST_ARTIFACT_ROOT']))
        self.store=SnapshotStore.create(self.root/'store','fixture:consume-store')

    def test_saved_consumed_inputs_same_instances_and_independent_body(self):
        p,g,c,b=inputs();raw=json.dumps(g.to_mapping(),indent=4).encode()
        from wss_bridge.capture import render as actual_render
        seen=[]
        def observe(*args):seen.append(args);return actual_render(*args)
        with patch('wss_bridge.capture.render',side_effect=observe):
            x=capture_and_render(p,raw,c,b,self.store,'fixture:invocation',LocalClock('fixture:clock'))
        self.assertIs(seen[0][0],p);self.assertIs(seen[0][1],x.result.generation)
        self.assertIs(x.result.prompt_bytes,p)
        self.assertEqual(self.store.get(x.prompt_reference),p)
        self.assertEqual(self.store.get(x.generation_reference),encode(g.to_mapping()))
        expected=independent_expected(self.store.get(x.prompt_reference),self.store.get(x.generation_reference),c.raw_bytes)
        self.assertEqual(expected,x.result.body)
        manifest=json.loads(self.store.get(x.manifest_reference))
        transport=next(raw_bytes for f,raw_bytes in [(q,q.read_bytes()) for q in (self.root/'store').glob('*.bin')]
                       if raw_bytes==raw)
        self.assertEqual(transport,raw)
        for ref,name in [(x.prompt_use_reference,'prompt'),(x.generation_use_reference,'generation')]:
            use=json.loads(self.store.get(ref));self.assertEqual(use['component_id'],name)
            self.assertEqual(use['invocation_ref'],'fixture:invocation')
            self.assertEqual(use['body_digest'],digest(expected));self.assertFalse(use['independent_secure_observer'])
        self.assertEqual(manifest['observed_use']['source'],'REAL_UTC')

    def test_malformed_generation_preserves_both_raw_inputs(self):
        p,g,c,b=inputs();raw=b'{"seed":false,"seed":0}'
        with self.assertRaises(ContractError):capture_and_render(p,raw,c,b,self.store,'fixture:inv',LocalClock('fixture:c'))
        values=[q.read_bytes() for q in (self.root/'store').glob('*.bin')]
        self.assertIn(p,values);self.assertIn(raw,values);self.assertEqual(len(values),2)

    def test_renderer_failure_keeps_actual_normalized_inputs_without_use_proof(self):
        p,g,c,b=inputs();bad=b'{"invalid":"prompt"}'
        with self.assertRaises(ContractError):capture_and_render(bad,g.canonical_bytes,c,b,self.store,'fixture:inv',LocalClock('fixture:c'))
        values=[q.read_bytes() for q in (self.root/'store').glob('*.bin')]
        self.assertIn(bad,values);self.assertIn(g.canonical_bytes,values)
        self.assertFalse(any(b'wss-consume-use-v1' in raw for raw in values))

    def test_mutable_prompt_rejected_and_no_fabricated_capture(self):
        p,g,c,b=inputs()
        with self.assertRaises(ContractError):capture_and_render(bytearray(p),g.canonical_bytes,c,b,self.store,'fixture:inv',LocalClock('fixture:c'))
        self.assertEqual(list((self.root/'store').glob('*.bin')),[])

    def test_postrender_clock_failure_retains_partial_capture(self):
        p,g,c,b=inputs()
        def fault():raise OSError('synthetic clock unavailable')
        with self.assertRaises(OSError):capture_and_render(p,g.canonical_bytes,c,b,self.store,'fixture:inv',LocalClock('fixture:c',fault_reader=fault))
        self.assertGreaterEqual(len(list((self.root/'store').glob('*.bin'))),4)

    def test_identity_substitution_is_not_accepted_as_consumption(self):
        p,g,c,b=inputs()
        from wss_bridge.renderer import render,Generation
        def substitute(prompt,generation,catalog,binding):
            return render(prompt,Generation.from_mapping(generation.to_mapping()),catalog,binding)
        with patch('wss_bridge.capture.render',side_effect=substitute),self.assertRaises(ContractError):
            capture_and_render(p,g.canonical_bytes,c,b,self.store,'fixture:inv',LocalClock('fixture:c'))

    def test_snapshot_readback_failure_retains_orphan_without_silent_retry(self):
        p,g,c,b=inputs();original=self.store.get;calls=[]
        def failure(ref):calls.append(ref);raise OSError('synthetic readback failure')
        with patch.object(self.store,'get',side_effect=failure),self.assertRaises(OSError):
            capture_and_render(p,g.canonical_bytes,c,b,self.store,'fixture:inv',LocalClock('fixture:c'))
        self.assertEqual(len(calls),1);self.assertEqual(len(list((self.root/'store').glob('*.bin'))),1)

    def test_real_clock_and_strict_observation_types(self):
        c=LocalClock('fixture:real');a=c.observe();b=c.observe()
        self.assertEqual((a.sequence,b.sequence),(0,1));self.assertGreaterEqual(b.monotonic_ns,a.monotonic_ns)
        for bad in [True,-1,1.0,'1']:
            with self.subTest(bad=bad),self.assertRaises(ContractError):ClockObservation(a.utc,bad,0,'fixture:c','REAL_UTC')
        with self.assertRaises(FrozenInstanceError):a.sequence=99

    def test_fault_clock_equal_is_observed_not_adjusted_backwards_rejected(self):
        seq=iter([('2026-10-17T00:00:00Z',1),('2026-10-17T00:00:00Z',2),('2026-10-16T23:59:59Z',3)])
        c=LocalClock('fixture:fault',fault_reader=lambda:next(seq))
        a=c.observe();b=c.observe();self.assertEqual(a.utc,b.utc)
        self.assertEqual(a.source,'SYNTHETIC_FAULT_INJECTION')
        with self.assertRaises(ContractError):c.observe()

"""WP00/WP01 mechanical tests with synthetic declarations; no native evidence.

Root freezes and runs this suite. This file does not import CPC admission code.
Assertions derive from README/docs and the frozen protocol, not private tables.
"""
from __future__ import annotations

import copy
from dataclasses import FrozenInstanceError
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
from types import MappingProxyType
import unittest

from wss_bridge.configuration import (
    DeclarationRef, FactDeclaration, OperatorConfiguration,
    parse_operator_configuration, verify_pinned_references,
)
from wss_bridge.native_contract import (
    ActorBinding, CoreDisposition, EvaluationState, LedgerRecord, MappingStatus,
    NativeOccurrence, NativeReadReceipt, NativeReadStatus, NativeTarget,
    NativeValueSnapshot, ObservationRelation, RecordKind, SourceIdentity,
    classify_observations,
)
from wss_bridge.primitives import (
    ContractError, canonical_json_bytes, decode_json_object, freeze_json,
    optional_identifier, plain_json, require_bool, require_digest,
    require_identifier, require_int, require_mapping, require_rfc3339,
    require_text,
)

# Deliberately independent written-contract oracles, not production constants.
PIN = "sha256:9c4dee342dc86a4c614a337f6891bdae63e8fd75b00f2267e3081de011bc62ad"
FACTS = (
    "runtime_profile", "key_registry", "key_policy", "role_policy",
    "runtime_dependency", "source_epoch", "actor_registry", "context_map",
    "approved_content", "outcome_recipe", "sandbox_authorization",
    "internal_material_rights", "execution_grant",
)
DIGEST_A = "sha256:" + "a" * 64
DIGEST_B = "sha256:" + "b" * 64
DIGEST_C = "sha256:" + "c" * 64
TIME = "2026-10-17T10:00:00Z"


def configuration_row():
    return {
        "configuration_version": "wss-operator-declaration-1.0",
        "configuration_ref": "synthetic-config",
        "scope_grant_ref": {"ref": "synthetic-unverified-scope"},
        "operator_ref": "synthetic-operator",
        "reference_manifest_digest": PIN,
        "evidence_root_ref": "synthetic-evidence-ref",
    }


def receipt_row():
    """Internally consistent asserted fields; no Moodle observation or authority."""
    return {
        "observation_ref": "synthetic-observation-1",
        "operation_ref": "synthetic-operation-1",
        "status": "MATCH_OBSERVED", "observer_time": TIME,
        "observer_sequence": 1,
        "source": {
            "source_epoch_ref": "synthetic-epoch-1", "instance_ref": "synthetic-instance",
            "source_version_ref": "synthetic-source-version",
            "runtime_version_ref": "synthetic-runtime-version",
        },
        "actor": {
            "actor_ref": "synthetic-actor", "registry_ref": "synthetic-registry",
            "expected_userid": 101,
        },
        "target": {
            "target_ref": "synthetic-target", "source_epoch_ref": "synthetic-epoch-1",
            "courseid": 11, "feedback_route": "ordinary_course", "response_scope_courseid": 0, "cmid": 22, "feedback_id": 33, "item_id": 44,
            "contextid": 55, "contextlevel": 70,
            "eventname": "synthetic-response-submitted", "objecttable": "feedback_completed",
            "item_type": "textarea", "item_digest": DIGEST_A,
            "item_presentation_digest": DIGEST_B, "controlled_value_digest": DIGEST_C,
        },
        "occurrences": [{
            "standard_log_record_id": 900, "eventname": "synthetic-response-submitted",
            "objecttable": "feedback_completed", "objectid": 66,
            "contextid": 55, "contextlevel": 70, "contextinstanceid": 22,
            "courseid": 11, "userid": 101, "relateduserid": 101,
            "realuserid": None, "realuserid_observed": True, "origin": "web",
            "other_cmid": 22, "other_instanceid": 33, "anonymous": False,
            "other_anonymous": False, "native_time": TIME,
        }],
        "snapshots": [{
            "snapshot_ref": "synthetic-source-snapshot", "completed_id": 66,
            "completed_feedback_id": 33, "completed_userid": 101,
            "completed_anonymous": False, "completed_courseid": 0,
            "completed_modified_time": TIME, "item_id": 44, "item_feedback_id": 33,
            "item_type": "textarea", "item_text_ref": "synthetic-item-bytes",
            "item_digest": DIGEST_A, "item_presentation_ref": "synthetic-presentation-bytes",
            "item_presentation_digest": DIGEST_B, "value_id": 77,
            "value_completed_id": 66, "value_item_id": 44, "value_courseid": 0,
            "value_bytes_ref": "synthetic-value-bytes", "value_digest": DIGEST_C,
        }],
        "read_context_ref": "synthetic-read", "transaction_ref": "synthetic-tx",
        "connection_ref": "synthetic-connection", "consistent_snapshot_observed": True, "target_course_category": 1,
        "target_window_before_ref": "synthetic-window-before",
        "target_window_after_ref": "synthetic-window-after",
        "log_watermark": 800, "cursor_end": 950,
        "clean_interval_evidence_ref": "synthetic-clean-claim",
        "prior_operations_evidence_ref": None, "sole_writer_evidence_ref": "synthetic-writer-claim",
        "native_result_known": True, "diagnostics": [], "native_lira_event_id": None,
    }


# Explicit required-field and primary-reference oracle from docs/native_contract.md.
# NATIVE_OBSERVATION is handled as the closed receipt mapping above.
GENERIC_KINDS = {
    "OPPORTUNITY": ("opportunity_ref", {"opportunity_ref": "e", "actor_ref": "a", "target_ref": "t", "status": "PENDING"}),
    "SUBMIT_OPERATION": ("operation_ref", {"operation_ref": "e", "actor_ref": "a", "target_ref": "t", "status": "PENDING"}),
    "ATTEMPT_REFERENCE": ("attempt_ref", {"attempt_ref": "e", "occurrence_ref": "o", "status": "PENDING"}),
    "INVOCATION_REFERENCE": ("invocation_ref", {"invocation_ref": "e", "attempt_ref": "a", "status": "PENDING"}),
    "PUBLICATION_REFERENCE": ("publication_ref", {"publication_ref": "e", "invocation_ref": "i", "status": "PENDING"}),
    "FOLLOWUP_REFERENCE": ("followup_ref", {"followup_ref": "e", "attempt_ref": "a", "occurrence_ref": "o", "status": "PENDING"}),
    "CORE_INPUT_REFERENCE": ("input_ref", {"input_ref": "e", "invocation_ref": "i", "status": "PENDING"}),
    "CORE_RESULT_REFERENCE": ("input_ref", {"input_ref": "e", "evaluation_state": "COMPLETED", "disposition": "ADMIT"}),
    "MAPPING_ASSESSMENT": ("input_ref", {"input_ref": "e", "mapping_status": "HOLD", "reason_flags": ["synthetic-hold"]}),
    "EXTERNAL_ROW_REFERENCE": ("row_ref", {"row_ref": "e", "attempt_ref": "a", "status": "PENDING"}),
    "JOIN_ASSESSMENT": ("input_ref", {"input_ref": "e", "terminal_reason": "synthetic-hold", "reason_flags": []}),
    "ANALYSIS_SNAPSHOT_REFERENCE": ("snapshot_ref", {"snapshot_ref": "e", "status": "PENDING"}),
    "FAILURE": ("operation_ref", {"operation_ref": "e", "layer": "API", "status": "FAILED", "code": "synthetic-error"}),
    "AUDIT_REFERENCE": ("audit_ref", {"audit_ref": "e", "status": "PENDING"}),
}


class PrimitiveContractTests(unittest.TestCase):
    def test_exact_scalars_and_null_are_not_coerced(self):
        self.assertEqual(require_int(0, "x"), 0)
        self.assertEqual(require_int(1, "x", minimum=1), 1)
        self.assertIs(require_bool(True, "x"), True)
        self.assertIs(require_bool(False, "x"), False)
        self.assertIsNone(optional_identifier(None, "x"))
        for bad in (True, False, "1", 1.0, None, -1):
            with self.subTest(integer=repr(bad)), self.assertRaises(ContractError):
                require_int(bad, "x")
        for bad in (0, 1, "true", None):
            with self.subTest(boolean=repr(bad)), self.assertRaises(ContractError):
                require_bool(bad, "x")
        with self.assertRaises(ContractError):
            require_int(0, "x", minimum=1)

    def test_identifier_unicode_and_size_boundaries(self):
        self.assertEqual(require_identifier("Café-合成", "x"), "Café-合成")
        self.assertEqual(require_identifier("a" * 256, "x"), "a" * 256)
        self.assertEqual(require_text("", "x", allow_empty=True), "")
        self.assertEqual(require_text("ab", "x", max_chars=2), "ab")
        for bad in ("", " ", " x", "x ", "x\n", "x\u200b", "\ud800", "a" * 257, b"x", 5):
            with self.subTest(identifier=repr(bad)), self.assertRaises(ContractError):
                require_identifier(bad, "x")
        for bad in ("", "\udfff", 2):
            with self.subTest(text=repr(bad)), self.assertRaises(ContractError):
                require_text(bad, "x")
        with self.assertRaises(ContractError):
            require_text("abc", "x", max_chars=2)

    def test_digest_exact_spelling(self):
        self.assertEqual(require_digest(DIGEST_A, "x"), DIGEST_A)
        for bad in ("a" * 64, "sha256:" + "A" * 64, "sha256:" + "a" * 63, DIGEST_A + "\n", None):
            with self.subTest(digest=repr(bad)), self.assertRaises(ContractError):
                require_digest(bad, "x")

    def test_explicit_zone_time_validation(self):
        for good in (TIME, "2024-02-29T12:30:00.123456+07:00", "2026-10-17T12:30:00-03:30", "2026-10-17T12:30:00+05:30"):
            with self.subTest(time=good):
                self.assertEqual(require_rfc3339(good, "x"), good)
        for bad in ("2026-10-17T10:00:00", "2026-02-29T10:00:00Z", "2026-10-17 10:00:00Z", "2026-10-17T10:00:60Z", "2026-10-17T10:00:00+24:00", "2026-10-17T10:00:00.1234567Z"):
            with self.subTest(time=bad), self.assertRaises(ContractError):
                require_rfc3339(bad, "x")

    def test_rfc3339_numeric_offset_components_are_not_normalized(self):
        # RFC3339 time-hour is 00..23 and time-minute is 00..59. The
        # datetime parser's normalization cannot relax this written promise.
        for offset in ("+05:60", "+05:99", "-03:60", "+24:00"):
            with self.subTest(offset=offset), self.assertRaises(ContractError):
                require_rfc3339("2026-10-17T12:30:00" + offset, "x")

    def test_closed_mapping_rejects_keys_and_accepts_immutable_mapping(self):
        self.assertEqual(require_mapping(MappingProxyType({"a": 1}), "x", required=("a",)), {"a": 1})
        for bad in ({}, {"a": 1, "b": 2}, {1: 2}, [], None):
            with self.subTest(mapping=repr(bad)), self.assertRaises(ContractError):
                require_mapping(bad, "x", required=("a",))

    def test_immutable_copy_and_independent_plain_copy(self):
        original = {"nested": [{"value": 1}], "unicode": "é", "null": None, "bool": False}
        frozen = freeze_json(original)
        original["nested"][0]["value"] = 2
        self.assertEqual(frozen["nested"][0]["value"], 1)
        with self.assertRaises(TypeError):
            frozen["nested"][0]["value"] = 3
        mutable = plain_json(frozen)
        mutable["nested"][0]["value"] = 4
        self.assertEqual(frozen["nested"][0]["value"], 1)
        self.assertEqual(canonical_json_bytes({"z": 2, "é": [1, False], "a": None}), b'{"a":null,"z":2,"\xc3\xa9":[1,false]}')

    def test_unsupported_json_types_cycles_depth_and_shared_children(self):
        for bad in (1.0, float("nan"), float("inf"), {1: "x"}, {"x": object()}, "\ud800"):
            with self.subTest(value=repr(bad)), self.assertRaises(ContractError):
                freeze_json(bad)
        cycle = []
        cycle.append(cycle)
        with self.assertRaises(ContractError):
            freeze_json(cycle)
        shared = {"v": 1}
        self.assertEqual(plain_json([shared, shared]), [{"v": 1}, {"v": 1}])
        value = 0
        for _ in range(64):
            value = [value]
        freeze_json(value)
        with self.assertRaises(ContractError):
            freeze_json([value])

    def test_raw_json_transport_duplicate_keys_numbers_root_and_errors(self):
        self.assertEqual(decode_json_object(b'{"a":1,"nested":{"b":false}}'), {"a": 1, "nested": {"b": False}})
        for bad in ('{"a":1,"a":2}', '{"a":{"x":1,"x":2}}', '{"a":1.0}', '{"a":NaN}', '{"a":Infinity}', '[1]', 'null', '{', b'\xff', 1, '{"x":"\\ud800"}'):
            with self.subTest(raw=repr(bad)), self.assertRaises(ContractError):
                decode_json_object(bad)
        with self.assertRaises(ContractError) as captured:
            decode_json_object('{"sensitive-marker": invalid}')
        self.assertNotIn("sensitive-marker", str(captured.exception))
        self.assertLess(len(str(captured.exception)), 150)


class ConfigurationContractTests(unittest.TestCase):
    def test_minimal_closed_configuration_normalizes_pending_without_authority(self):
        config = OperatorConfiguration.from_mapping(configuration_row())
        self.assertEqual(config.pending_facts, FACTS + ("validation_time",))
        self.assertEqual(tuple(config.facts), FACTS)
        self.assertTrue(all(fact.state == "PENDING" and fact.reference is None for fact in config.facts.values()))
        self.assertIsNone(config.validation_time)
        self.assertFalse(hasattr(config, "authorized"))
        self.assertFalse(hasattr(config, "ready"))
        self.assertEqual(parse_operator_configuration(json.dumps(configuration_row())).to_dict(), config.to_dict())
        with self.assertRaises(TypeError):
            config.facts["source_epoch"] = FactDeclaration()
        with self.assertRaises(FrozenInstanceError):
            config.operator_ref = "changed"

    def test_all_declared_is_not_readiness_and_explicit_round_trip(self):
        row = configuration_row()
        row["facts"] = {name: {"state": "DECLARED", "reference": {"ref": "synthetic-" + name, "sha256": DIGEST_A}} for name in FACTS}
        row["validation_time"] = TIME
        config = OperatorConfiguration.from_mapping(row)
        self.assertEqual(config.pending_facts, ())
        self.assertFalse(hasattr(config, "authorized"))
        self.assertFalse(hasattr(config, "ready"))
        self.assertEqual(OperatorConfiguration.from_json(json.dumps(config.to_dict()).encode()).to_dict(), config.to_dict())
        row["facts"]["execution_grant"]["reference"]["ref"] = "modified-source"
        self.assertEqual(config.facts["execution_grant"].reference.ref, "synthetic-execution_grant")

    def test_unknown_missing_and_unsupported_configuration_fields(self):
        base = configuration_row()
        for key in base:
            row = copy.deepcopy(base)
            del row[key]
            with self.subTest(missing=key), self.assertRaises(ContractError):
                OperatorConfiguration.from_mapping(row)
        for field, value in (("configuration_version", "other"), ("reference_manifest_digest", DIGEST_A), ("operator_ref", " "), ("validation_time", "2026-10-17"), ("private_key", "synthetic-forbidden"), ("profile", {}), ("facts", {"unknown": {"state": "PENDING", "reference": None}}), ("facts", None)):
            row = copy.deepcopy(base)
            row[field] = value
            with self.subTest(field=field, value=repr(value)), self.assertRaises(ContractError):
                OperatorConfiguration.from_mapping(row)
        with self.assertRaises(ContractError):
            parse_operator_configuration(json.dumps(base)[:-1] + ',"operator_ref":"duplicate"}')

    def test_declaration_shapes_and_reference_repr(self):
        reference = DeclarationRef("synthetic-reference-secret-marker", DIGEST_A)
        self.assertNotIn("synthetic-reference-secret-marker", repr(reference))
        self.assertEqual(DeclarationRef.from_mapping(reference.to_dict()), reference)
        for bad in ({}, {"ref": "r", "private_key": "x"}, {"ref": " "}, {"ref": "r", "sha256": "wrong"}):
            with self.subTest(reference=bad), self.assertRaises(ContractError):
                DeclarationRef.from_mapping(bad)
        for bad in ({"state": "PENDING", "reference": {"ref": "r"}}, {"state": "DECLARED", "reference": None}, {"state": "VERIFIED", "reference": None}, {"state": "AUTHORIZED", "reference": {"ref": "r"}}, {"state": "PENDING"}, {"state": "PENDING", "reference": None, "extra": True}, None):
            with self.subTest(fact=bad), self.assertRaises(ContractError):
                FactDeclaration.from_mapping(bad)
        with self.assertRaises(ContractError):
            OperatorConfiguration(**{key: value for key, value in {**configuration_row(), "scope_grant_ref": reference, "facts": {"runtime_profile": {"state": "PENDING", "reference": None}}}.items()})


class ReferenceIntegrityTests(unittest.TestCase):
    def setUp(self):
        artifact_root = Path(os.environ["WSS_TEST_ARTIFACT_ROOT"])
        artifact_root.mkdir(parents=True, exist_ok=True)
        self.work = Path(tempfile.mkdtemp(prefix=self._testMethodName + "-", dir=artifact_root))
        self.original = Path(os.environ["WSS_CODE_ROOT"]) / "references"

    def fixture(self):
        destination = self.work / "references"
        shutil.copytree(self.original, destination)
        manifest = json.loads((destination / "REFERENCE_MANIFEST.json").read_text())
        return destination, manifest["files"][0]

    def test_exact_pinned_actual_tree_and_independent_file_oracle(self):
        raw = (self.original / "REFERENCE_MANIFEST.json").read_bytes()
        self.assertEqual("sha256:" + hashlib.sha256(raw).hexdigest(), PIN)
        manifest = json.loads(raw)
        expected = []
        for row in manifest["files"]:
            payload = (self.original / row["path"]).read_bytes()
            self.assertEqual(len(payload), row["size_bytes"])
            self.assertEqual("sha256:" + hashlib.sha256(payload).hexdigest(), row["copied_sha256"])
            expected.append(row["path"])
        self.assertEqual(len(expected), 41)
        receipt = verify_pinned_references(self.original)
        self.assertEqual(receipt.manifest_sha256, PIN)
        self.assertEqual(receipt.matched_files, tuple(sorted(expected)))
        self.assertEqual(receipt.evidence_class, "SOURCE_BYTE_MATCH_ONLY")
        self.assertFalse(hasattr(receipt, "authorized"))
        self.assertFalse(hasattr(receipt, "runtime_verified"))

    def test_same_size_content_tamper(self):
        root, entry = self.fixture()
        path = root / entry["path"]
        payload = path.read_bytes()
        self.assertGreater(len(payload), 0)
        path.write_bytes(bytes([payload[0] ^ 1]) + payload[1:])
        with self.assertRaisesRegex(ContractError, "pinned source byte mismatch"):
            verify_pinned_references(root)

    def test_size_growth_and_shrink(self):
        for mutation in ("grow", "shrink"):
            with self.subTest(mutation=mutation):
                case = self.work / mutation
                shutil.copytree(self.original, case)
                entry = json.loads((case / "REFERENCE_MANIFEST.json").read_text())["files"][0]
                path = case / entry["path"]
                payload = path.read_bytes()
                self.assertGreater(len(payload), 0)
                path.write_bytes(payload + b"x" if mutation == "grow" else payload[:-1])
                with self.assertRaisesRegex(ContractError, "size mismatch"):
                    verify_pinned_references(case)

    def test_missing_and_extra_inventory(self):
        for mutation in ("missing", "extra"):
            with self.subTest(mutation=mutation):
                case = self.work / mutation
                shutil.copytree(self.original, case)
                entry = json.loads((case / "REFERENCE_MANIFEST.json").read_text())["files"][0]
                if mutation == "missing":
                    (case / entry["path"]).unlink()
                else:
                    (case / "unexpected.json").write_text("{}")
                with self.assertRaisesRegex(ContractError, "inventory mismatch"):
                    verify_pinned_references(case)

    def test_manifest_edit_and_manifest_size_bound(self):
        for mutation in ("edit", "oversize"):
            with self.subTest(mutation=mutation):
                case = self.work / mutation
                shutil.copytree(self.original, case)
                path = case / "REFERENCE_MANIFEST.json"
                path.write_bytes(path.read_bytes() + b" " if mutation == "edit" else b"x" * (1024 * 1024 + 1))
                with self.assertRaises(ContractError):
                    verify_pinned_references(case)

    def test_root_file_directory_and_manifest_symlinks(self):
        root, entry = self.fixture()
        link = self.work / "root-link"
        link.symlink_to(root, target_is_directory=True)
        with self.assertRaises(ContractError):
            verify_pinned_references(link)
        path = root / entry["path"]
        original_bytes = path.read_bytes()
        outside = self.work / "outside-source"
        outside.write_bytes(original_bytes)
        path.unlink()
        path.symlink_to(outside)
        with self.assertRaisesRegex(ContractError, "symlinks"):
            verify_pinned_references(root)
        path.unlink()
        path.write_bytes(original_bytes)
        manifest = root / "REFERENCE_MANIFEST.json"
        target = self.work / "outside-manifest"
        target.write_bytes(manifest.read_bytes())
        manifest.unlink()
        manifest.symlink_to(target)
        with self.assertRaises(ContractError):
            verify_pinned_references(root)
        manifest.unlink()
        manifest.write_bytes(target.read_bytes())
        (root / "extra-directory-link").symlink_to(self.work, target_is_directory=True)
        with self.assertRaisesRegex(ContractError, "symlinks"):
            verify_pinned_references(root)

    def test_missing_root_and_directory_in_place_of_file_are_sanitized(self):
        with self.assertRaises(ContractError):
            verify_pinned_references(self.work / "absent")
        root, entry = self.fixture()
        target = root / entry["path"]
        target.unlink()
        target.mkdir()
        with self.assertRaises(ContractError):
            verify_pinned_references(root)
        # Keep failure messages independent of arbitrary local path fragments.
        with self.assertRaises(ContractError) as captured:
            verify_pinned_references(self.work / "synthetic-sensitive-marker")
        self.assertNotIn("synthetic-sensitive-marker", str(captured.exception))


class NativeContractTests(unittest.TestCase):
    def test_full_synthetic_claims_have_no_structural_binding_issues(self):
        row = receipt_row()
        receipt = NativeReadReceipt.from_mapping(row)
        self.assertEqual(receipt.binding_issues(), ())
        self.assertEqual(receipt.to_mapping(), row)
        self.assertIs(receipt.status, NativeReadStatus.MATCH_OBSERVED)
        self.assertIsNone(receipt.native_lira_event_id)
        self.assertFalse(hasattr(receipt, "native_verified"))
        self.assertFalse(hasattr(receipt, "authorized"))
        with self.assertRaises(FrozenInstanceError):
            receipt.observer_sequence = 2
        row["occurrences"][0]["userid"] = 999
        self.assertEqual(receipt.occurrences[0].userid, 101)
        output = receipt.to_mapping()
        output["snapshots"][0]["value_id"] = 999
        self.assertEqual(receipt.snapshots[0].value_id, 77)

    def test_nullable_native_fields_closed_parsers_and_exact_types(self):
        for cls in (SourceIdentity, ActorBinding, NativeTarget, NativeOccurrence, NativeValueSnapshot):
            with self.subTest(contract=cls.__name__):
                parsed = cls.from_mapping({})
                self.assertTrue(all(value is None for value in parsed.to_mapping().values()))
                with self.assertRaises(ContractError):
                    cls.from_mapping({"unknown": 1})
        for bad in (True, False, -1, "1", 1.0):
            with self.subTest(native_id=repr(bad)), self.assertRaises(ContractError):
                NativeOccurrence(standard_log_record_id=bad)
        self.assertIsNone(NativeOccurrence().standard_log_record_id)
        self.assertEqual(NativeOccurrence(standard_log_record_id=0).standard_log_record_id, 0)
        for bad in (0, 1, "false"):
            with self.subTest(boolean=repr(bad)), self.assertRaises(ContractError):
                NativeOccurrence(anonymous=bad)
        for bad in ("wrong", "sha256:" + "F" * 64):
            with self.subTest(digest=bad), self.assertRaises(ContractError):
                NativeValueSnapshot(value_digest=bad)

    def test_legitimate_empty_source_value_has_explicit_locator_and_digest(self):
        row = receipt_row()
        empty_digest = "sha256:" + hashlib.sha256(b"").hexdigest()
        row["target"]["controlled_value_digest"] = empty_digest
        row["snapshots"][0]["value_digest"] = empty_digest
        row["snapshots"][0]["value_bytes_ref"] = "synthetic-empty-source-locator"
        parsed = NativeReadReceipt.from_mapping(row)
        self.assertEqual(parsed.binding_issues(), ())
        self.assertEqual(parsed.snapshots[0].value_digest, empty_digest)
        self.assertEqual(parsed.snapshots[0].value_bytes_ref, "synthetic-empty-source-locator")

    def test_receipt_closed_required_fields_types_and_selected_route_null(self):
        for key in ("observation_ref", "operation_ref", "status", "observer_time", "observer_sequence"):
            row = receipt_row()
            del row[key]
            with self.subTest(missing=key), self.assertRaises(ContractError):
                NativeReadReceipt.from_mapping(row)
        for field, bad in (("status", "VERIFIED"), ("observer_sequence", True), ("source", []), ("occurrences", {}), ("snapshots", [None]), ("diagnostics", "flag"), ("native_lira_event_id", 123), ("unknown", True)):
            row = receipt_row()
            row[field] = bad
            with self.subTest(field=field), self.assertRaises(ContractError):
                NativeReadReceipt.from_mapping(row)

    def test_status_and_partial_receipts_preserve_claims(self):
        names = {"MATCH_OBSERVED", "NO_MATCH", "MULTIPLE_MATCH", "READ_UNAVAILABLE", "SOURCE_CONFLICT", "NATIVE_RESULT_UNRESOLVED"}
        self.assertEqual({item.value for item in NativeReadStatus}, names)
        for status in sorted(names):
            row = {"observation_ref": "o", "operation_ref": "p", "status": status, "observer_time": TIME, "observer_sequence": 0}
            parsed = NativeReadReceipt.from_mapping(row)
            issues = parsed.binding_issues()
            self.assertEqual(parsed.status.value, status)
            self.assertIn("SOURCE_IDENTITY_UNRESOLVED", issues)
            self.assertIn("ACTOR_REGISTRY_UNRESOLVED", issues)
            self.assertIn("NATIVE_OCCURRENCE_UNAVAILABLE", issues)
            if status != "MATCH_OBSERVED":
                self.assertIn(status, issues)

    def test_missing_context_target_actor_item_and_version_flags(self):
        cases = (
            ("source", "source_version_ref", "SOURCE_VERSION_REF_MISSING"),
            ("source", "runtime_version_ref", "RUNTIME_VERSION_REF_MISSING"),
            ("target", "target_ref", "TARGET_REF_MISSING"),
            ("actor", "registry_ref", "ACTOR_REGISTRY_UNRESOLVED"),
            ("target", "item_type", "ITEM_TYPE_UNRESOLVED"),
            ("target", "item_presentation_digest", "ITEM_PRESENTATION_UNRESOLVED"),
        )
        for section, field, flag in cases:
            row = receipt_row()
            row[section][field] = None
            with self.subTest(section=section, field=field):
                self.assertIn(flag, NativeReadReceipt.from_mapping(row).binding_issues())
        for field, flag in (("read_context_ref", "READ_CONTEXT_REF_MISSING"), ("native_result_known", "NATIVE_RESULT_UNRESOLVED"), ("consistent_snapshot_observed", "CONSISTENT_SNAPSHOT_UNVERIFIED"), ("clean_interval_evidence_ref", "CLEAN_INTERVAL_UNVERIFIED"), ("sole_writer_evidence_ref", "SOLE_WRITER_UNVERIFIED")):
            row = receipt_row()
            row[field] = None
            with self.subTest(field=field):
                self.assertIn(flag, NativeReadReceipt.from_mapping(row).binding_issues())

    def test_conflicting_bindings_are_reported_and_not_rewritten(self):
        cases = (
            ("source", "source_epoch_ref", "other-epoch", "SOURCE_EPOCH_CONFLICT"),
            ("target", "courseid", 99, "EVENT_COURSE_CONFLICT"),
            ("target", "cmid", 99, "EVENT_CONTEXT_INSTANCE_CONFLICT"),
            ("target", "item_id", 99, "SOURCE_ITEM_CONFLICT"),
            ("actor", "expected_userid", 99, "INITIATING_ACTOR_CONFLICT"),
            ("target", "item_type", "numeric", "ITEM_TYPE_CONFLICT"),
            ("target", "item_digest", DIGEST_C, "ITEM_CONTENT_CONFLICT"),
            ("target", "item_presentation_digest", DIGEST_C, "ITEM_PRESENTATION_CONFLICT"),
            ("target", "controlled_value_digest", DIGEST_A, "SOURCE_VALUE_CONFLICT"),
        )
        for section, field, value, flag in cases:
            row = receipt_row()
            row[section][field] = value
            parsed = NativeReadReceipt.from_mapping(row)
            with self.subTest(section=section, field=field):
                self.assertIn(flag, parsed.binding_issues())
                self.assertEqual(parsed.to_mapping()[section][field], value)
                self.assertEqual(parsed.status.value, "MATCH_OBSERVED")
        for field, value, flag in (("value_completed_id", 99, "VALUE_COMPLETED_CONFLICT"), ("value_item_id", 99, "VALUE_ITEM_CONFLICT"), ("completed_userid", 99, "COMPLETED_OWNER_CONFLICT"), ("completed_id", 99, "EVENT_COMPLETED_CONFLICT")):
            row = receipt_row()
            row["snapshots"][0][field] = value
            with self.subTest(snapshot_field=field):
                self.assertIn(flag, NativeReadReceipt.from_mapping(row).binding_issues())

    def test_zero_ids_impersonation_anonymity_and_watermarks(self):
        cases = (
            ("occurrence", "standard_log_record_id", 0, "SOURCE_ZERO_ID_REPORTED"),
            ("occurrence", "realuserid", 0, "REALUSERID_BINDING_UNRESOLVED"),
            ("occurrence", "realuserid", 99, "IMPERSONATION_REPORTED"),
            ("occurrence", "realuserid_observed", None, "NO_IMPERSONATION_UNVERIFIED"),
            ("occurrence", "anonymous", True, "ANONYMOUS_ROUTE_CONFLICT"),
            ("occurrence", "other_anonymous", None, "OTHER_ANONYMITY_UNRESOLVED"),
            ("occurrence", "standard_log_record_id", 800, "OCCURRENCE_OUTSIDE_WATERMARK"),
            ("occurrence", "standard_log_record_id", 951, "OCCURRENCE_OUTSIDE_CURSOR_END"),
            ("snapshot", "value_id", 0, "SOURCE_ZERO_ID_REPORTED"),
            ("target", "cmid", 0, "TARGET_ZERO_ID"),
            ("actor", "expected_userid", 0, "ACTOR_REGISTRY_ZERO_ID"),
        )
        for section, field, value, flag in cases:
            row = receipt_row()
            destination = row["occurrences"][0] if section == "occurrence" else row["snapshots"][0] if section == "snapshot" else row[section]
            destination[field] = value
            with self.subTest(section=section, field=field, value=value):
                self.assertIn(flag, NativeReadReceipt.from_mapping(row).binding_issues())
        row = receipt_row()
        row["cursor_end"] = 700
        self.assertIn("CURSOR_WINDOW_CONFLICT", NativeReadReceipt.from_mapping(row).binding_issues())
        row = receipt_row()
        row["log_watermark"] = 898
        self.assertEqual(NativeReadReceipt.from_mapping(row).binding_issues(), ())

    def test_ambiguity_missing_digests_and_diagnostic_order_retained(self):
        row = receipt_row()
        row["occurrences"].append(copy.deepcopy(row["occurrences"][0]))
        row["snapshots"].append(copy.deepcopy(row["snapshots"][0]))
        row["snapshots"][0]["value_bytes_ref"] = None
        row["snapshots"][0]["value_digest"] = None
        row["diagnostics"] = ["original-flag", "another-flag"]
        parsed = NativeReadReceipt.from_mapping(row)
        self.assertEqual(parsed.diagnostics, ("original-flag", "another-flag"))
        self.assertEqual(len(parsed.occurrences), 2)
        self.assertEqual(len(parsed.snapshots), 2)
        self.assertEqual(parsed.binding_issues()[:2], ("original-flag", "another-flag"))
        for flag in ("NATIVE_OCCURRENCE_AMBIGUOUS", "SOURCE_SNAPSHOT_AMBIGUOUS", "VALUE_BYTES_REF_MISSING", "VALUE_DIGEST_MISSING", "SOURCE_VALUE_UNRESOLVED"):
            self.assertIn(flag, parsed.binding_issues())

    def test_observer_repeats_ignore_observation_locators_and_clocks(self):
        previous = NativeReadReceipt.from_mapping(receipt_row())
        incoming = receipt_row()
        incoming.update(observation_ref="synthetic-observation-2", operation_ref="synthetic-operation-2", observer_sequence=2, observer_time="2026-10-17T10:01:00Z", read_context_ref="synthetic-read-2", transaction_ref="synthetic-tx-2", connection_ref="synthetic-connection-2")
        for field in ("snapshot_ref", "item_text_ref", "item_presentation_ref", "value_bytes_ref"):
            incoming["snapshots"][0][field] = "synthetic-other-" + field
        self.assertIs(classify_observations(previous, NativeReadReceipt.from_mapping(incoming)), ObservationRelation.DUPLICATE_OBSERVATION)
        self.assertEqual(previous.operation_ref, "synthetic-operation-1")

    def test_new_log_or_epoch_is_new_occurrence_with_identical_completed_content(self):
        previous = NativeReadReceipt.from_mapping(receipt_row())
        for mutation in ("log", "epoch"):
            incoming = receipt_row()
            if mutation == "log":
                incoming["occurrences"][0]["standard_log_record_id"] = 901
            else:
                incoming["source"]["source_epoch_ref"] = "synthetic-epoch-2"
                incoming["target"]["source_epoch_ref"] = "synthetic-epoch-2"
            with self.subTest(mutation=mutation):
                self.assertIs(classify_observations(previous, NativeReadReceipt.from_mapping(incoming)), ObservationRelation.NEW_OCCURRENCE)
                self.assertEqual(incoming["snapshots"][0]["completed_id"], previous.snapshots[0].completed_id)

    def test_same_identity_known_native_content_conflicts(self):
        previous = NativeReadReceipt.from_mapping(receipt_row())
        for section, field, value in (("source", "source_version_ref", "different"), ("occurrence", "userid", 999), ("snapshot", "value_digest", DIGEST_A), ("snapshot", "item_presentation_digest", DIGEST_C)):
            incoming = receipt_row()
            target = incoming["occurrences"][0] if section == "occurrence" else incoming["snapshots"][0] if section == "snapshot" else incoming[section]
            target[field] = value
            with self.subTest(section=section, field=field):
                self.assertIs(classify_observations(previous, NativeReadReceipt.from_mapping(incoming)), ObservationRelation.SOURCE_CONFLICT)

    def test_partial_or_zero_identity_unresolved_and_known_partial_conflict_retained(self):
        previous = NativeReadReceipt.from_mapping(receipt_row())
        for mutation in ("no-source", "zero-log", "no-log", "two-log", "no-snapshot", "missing-digest", "unequal-knowledge"):
            incoming = receipt_row()
            if mutation == "no-source":
                incoming["source"] = None
            elif mutation == "zero-log":
                incoming["occurrences"][0]["standard_log_record_id"] = 0
            elif mutation == "no-log":
                incoming["occurrences"] = []
            elif mutation == "two-log":
                incoming["occurrences"].append(copy.deepcopy(incoming["occurrences"][0]))
            elif mutation == "no-snapshot":
                incoming["snapshots"] = []
            elif mutation == "missing-digest":
                incoming["snapshots"][0]["value_digest"] = None
            else:
                incoming["occurrences"][0]["origin"] = None
            with self.subTest(mutation=mutation):
                self.assertIs(classify_observations(previous, NativeReadReceipt.from_mapping(incoming)), ObservationRelation.IDENTITY_UNRESOLVED)
        incoming = receipt_row()
        incoming["snapshots"] = []
        incoming["occurrences"][0]["userid"] = 999
        self.assertIs(classify_observations(previous, NativeReadReceipt.from_mapping(incoming)), ObservationRelation.SOURCE_CONFLICT)


class LedgerRecordContractTests(unittest.TestCase):
    def test_all_fifteen_record_kinds_required_fields_primary_identity_and_roundtrip(self):
        self.assertEqual({kind.value for kind in RecordKind}, set(GENERIC_KINDS) | {"NATIVE_OBSERVATION"})
        self.assertEqual(len(RecordKind), 15)
        cases = dict(GENERIC_KINDS)
        cases["NATIVE_OBSERVATION"] = ("observation_ref", receipt_row())
        for kind, (primary, payload) in cases.items():
            with self.subTest(kind=kind):
                record = LedgerRecord("synthetic-record", kind, payload[primary], payload)
                self.assertEqual(record.kind.value, kind)
                encoded = record.to_mapping()
                self.assertEqual(set(encoded), {"record_ref", "kind", "entity_ref", "payload"})
                self.assertEqual(LedgerRecord.from_mapping(encoded).to_mapping(), encoded)
                with self.assertRaises(ContractError):
                    LedgerRecord("synthetic-record", kind, "different-primary", payload)
                missing = copy.deepcopy(payload)
                del missing[primary]
                with self.assertRaises(ContractError):
                    LedgerRecord("synthetic-record", kind, payload[primary], missing)
        for kind, (primary, payload) in GENERIC_KINDS.items():
            for required_field in payload:
                with self.subTest(kind=kind, required_field=required_field):
                    missing = copy.deepcopy(payload)
                    del missing[required_field]
                    with self.assertRaises(ContractError):
                        LedgerRecord("record", kind, payload[primary], missing)

    def test_record_json_deep_immutability_and_closed_top_level(self):
        payload = {"audit_ref": "a", "status": "PENDING", "extra": {"items": [1, {"flag": True}]}, "optional_ref": None}
        record = LedgerRecord("r", "AUDIT_REFERENCE", "a", payload)
        payload["extra"]["items"][1]["flag"] = False
        self.assertIs(record.payload["extra"]["items"][1]["flag"], True)
        with self.assertRaises(TypeError):
            record.payload["extra"]["items"][1]["flag"] = False
        encoded = record.to_mapping()
        encoded["payload"]["extra"]["items"].append("mutation")
        self.assertEqual(len(record.payload["extra"]["items"]), 2)
        for malformed in ({**record.to_mapping(), "unknown": True}, {key: value for key, value in record.to_mapping().items() if key != "record_ref"}):
            with self.subTest(keys=tuple(malformed)), self.assertRaises(ContractError):
                LedgerRecord.from_mapping(malformed)
        for patch in ({"extra": 1.0}, {"optional_ref": 1}, {"status": " "}, {"native_lira_event_id": "invented"}):
            with self.subTest(patch=patch), self.assertRaises(ContractError):
                LedgerRecord("r", "AUDIT_REFERENCE", "a", {"audit_ref": "a", "status": "PENDING", **patch})

    def test_core_result_dispositions_are_separate_from_unevaluated_errors(self):
        self.assertEqual({item.value for item in CoreDisposition}, {"ADMIT", "REJECT", "QUARANTINE", "ERROR_INPUT"})
        self.assertEqual({item.value for item in EvaluationState}, {"COMPLETED", "NOT_EVALUATED_CONFIG", "API_FAILURE", "PENDING"})
        for disposition in ("ADMIT", "REJECT", "QUARANTINE", "ERROR_INPUT"):
            record = LedgerRecord("r", "CORE_RESULT_REFERENCE", "i", {"input_ref": "i", "evaluation_state": "COMPLETED", "disposition": disposition})
            self.assertEqual(record.payload["disposition"], disposition)
        for state in ("NOT_EVALUATED_CONFIG", "API_FAILURE", "PENDING"):
            payload = {"input_ref": "i", "evaluation_state": state, "disposition": None}
            if state != "PENDING":
                with self.subTest(state=state, missing_error=True), self.assertRaises(ContractError):
                    LedgerRecord("r", "CORE_RESULT_REFERENCE", "i", payload)
                payload["error_ref"] = "synthetic-error"
            record = LedgerRecord("r", "CORE_RESULT_REFERENCE", "i", payload)
            self.assertIsNone(record.payload["disposition"])
            with self.subTest(state=state, invented_disposition=True), self.assertRaises(ContractError):
                LedgerRecord("r", "CORE_RESULT_REFERENCE", "i", {**payload, "disposition": "ERROR_INPUT"})
        for disposition in (None, "ERROR_CONFIG", "NOT_EVALUATED_CONFIG", "API_FAILURE"):
            with self.subTest(completed_disposition=disposition), self.assertRaises(ContractError):
                LedgerRecord("r", "CORE_RESULT_REFERENCE", "i", {"input_ref": "i", "evaluation_state": "COMPLETED", "disposition": disposition})
        with self.assertRaises(ContractError):
            LedgerRecord("r", "CORE_RESULT_REFERENCE", "i", {"input_ref": "i", "evaluation_state": "ERROR_CONFIG", "disposition": None})

    def test_mapping_vocabulary_reason_flags_and_history_grains(self):
        self.assertEqual({item.value for item in MappingStatus}, {"PENDING", "HOLD", "ELIGIBLE"})
        for status in ("PENDING", "HOLD", "ELIGIBLE"):
            record = LedgerRecord("r", "MAPPING_ASSESSMENT", "i", {"input_ref": "i", "mapping_status": status, "reason_flags": ["second", "first"]})
            self.assertEqual(record.payload["reason_flags"], ("second", "first"))
            self.assertEqual(record.payload["mapping_status"], status)
        for patch in ({"mapping_status": "ADMIT"}, {"reason_flags": "one"}, {"reason_flags": [1]}, {"reason_flags": [" "]}):
            with self.subTest(patch=patch), self.assertRaises(ContractError):
                LedgerRecord("r", "MAPPING_ASSESSMENT", "i", {"input_ref": "i", "mapping_status": "HOLD", "reason_flags": [], **patch})
        # Separate history records may refer to one entity; allocation/uniqueness
        # and state transitions belong outside this value contract.
        first = LedgerRecord("record-1", "AUDIT_REFERENCE", "same-audit", {"audit_ref": "same-audit", "status": "PENDING"})
        second = LedgerRecord("record-2", "AUDIT_REFERENCE", "same-audit", {"audit_ref": "same-audit", "status": "COMPLETE"})
        self.assertEqual(first.entity_ref, second.entity_ref)
        self.assertNotEqual(first.record_ref, second.record_ref)


if __name__ == "__main__":
    unittest.main()

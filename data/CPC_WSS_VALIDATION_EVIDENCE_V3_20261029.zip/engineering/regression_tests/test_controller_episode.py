"""Synthetic local lifecycle tests. No Moodle, helper, renderer or provider IO."""
import hashlib
import json
import os
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

from wss_bridge.controller import ControllerContext, OfflineController, WorkflowRefused
from wss_bridge.ledger import LedgerScope, LedgerCorruptionError
from wss_bridge.primitives import ContractError, plain_json
from wp03_fixtures import context, make_wire

VALUE = b'synthetic response'
DIGEST = 'sha256:' + hashlib.sha256(VALUE).hexdigest()


class ControllerEpisodeTests(unittest.TestCase):
    def setUp(self):
        self.temp = Path(tempfile.mkdtemp(prefix='controller-', dir=os.environ.get('WSS_TEST_ARTIFACT_ROOT')))
        self.path = self.temp / 'workflow'
        self.context = context()
        self.scope = LedgerScope('fixture:ledger', 'fixture:run', 'SYNTHETIC_OFFLINE_FIXTURE', self.context.source.source_epoch_ref)
        self.controller = OfflineController.create(self.path, self.scope, self.context)

    def begin(self, kind='TASK', attempt=None, watermark=100):
        return self.controller.begin_operation(self.controller.opportunity(note_ref='fixture:note'), kind,
            controlled_value_digest=DIGEST, log_watermark=watermark, attempt_ref=attempt,
            **({'logical_resource':'WSS-U01-HINT','config_id':'G_BASE'} if kind == 'TASK' else {}))

    def anchor(self, log_id=101):
        op = self.begin(watermark=log_id - 1)
        self.controller.record_completion(op, known=True, evidence_ref='fixture:completion')
        ack = self.controller.observe(op, 0, make_wire(operation_ref=op, log_id=log_id, watermark=log_id - 1))
        self.assertTrue(ack['acknowledged'])
        return ack['anchor']['attempt_ref'], op

    def publish(self, attempt):
        call = self.controller.receive_help(attempt, logical_resource='WSS-U01-HINT', config_id='G_BASE')
        for stage in ['CONSUME_STARTED', 'CAPTURED', 'COMMIT_DURABLE', 'PUBLISHED']:
            self.controller.advance_invocation(call, stage, evidence_ref='fixture:' + stage)
        self.controller.finish_invocation(call, publication='PUBLISHED', evidence_ref='fixture:finish')
        return call

    def followup(self, attempt, log_id=102):
        op = self.begin('FOLLOWUP', attempt, log_id-1)
        self.controller.record_completion(op, known=True, evidence_ref='fixture:completion')
        ack = self.controller.observe(op, 0, make_wire(operation_ref=op, kind='FOLLOWUP', log_id=log_id, watermark=log_id-1))
        self.assertTrue(ack['acknowledged'])
        return ack, op

    def test_successful_episode_has_one_exposure_and_first_followup(self):
        attempt, _ = self.anchor()
        self.publish(attempt)
        ack, _ = self.followup(attempt)
        view = self.controller.view()
        self.assertEqual(view['attempts'][attempt]['selected_followup'], ack['anchor']['followup_ref'])
        self.assertTrue(view['attempts'][attempt]['single_invocation_interpretation'])
        self.assertEqual(view['counts']['attempts'], 1)
        self.assertEqual(view['counts']['operations'], 2)
        self.assertEqual(view['counts']['ingestions'], 2)

    def test_receive_unknown_help_is_durable_before_refusal(self):
        call = self.controller.receive_help('unknown:attempt', logical_resource='WSS-U01-HINT', config_id='G_BASE')
        value = self.controller.view()['invocations'][call]
        self.assertEqual(value['history'], ('RECEIVED', 'PRECONDITION_REFUSED'))
        self.assertIn('ATTEMPT_UNKNOWN', value['reason_flags'])
        self.assertIsNone(value['native_lira_event_id'])
        self.assertTrue(value['settled'])

    def test_pending_operation_blocks_help_and_other_submit(self):
        attempt, _ = self.anchor()
        self.begin('FOLLOWUP', attempt, 101)
        call = self.controller.receive_help(attempt, logical_resource='WSS-U01-HINT', config_id='G_BASE')
        self.assertEqual(self.controller.view()['invocations'][call]['stage'], 'PRECONDITION_REFUSED')
        with self.assertRaises(WorkflowRefused):
            self.begin(watermark=102)

    def test_unknown_completion_cannot_be_rescued_by_match(self):
        op = self.begin()
        self.controller.record_completion(op, known=False, evidence_ref='fixture:timeout')
        ack = self.controller.observe(op, 0, make_wire(operation_ref=op))
        self.assertFalse(ack['acknowledged'])
        self.assertEqual(self.controller.view()['counts']['attempts'], 0)
        self.assertIn('NATIVE_RESULT_UNRESOLVED', self.controller.view()['stopped_flags'])
        self.assertEqual(self.controller.view()['counts']['ingestions'], 1)
        with self.assertRaises(WorkflowRefused):
            self.controller.observe(op, 1000, make_wire(operation_ref=op))

    def test_duplicate_ingestion_keeps_one_attempt(self):
        attempt, op = self.anchor()
        ack = self.controller.observe(op, 1000, make_wire(operation_ref=op, observation_ref='fixture:again'))
        self.assertEqual(ack['status'], 'DUPLICATE')
        self.assertEqual(self.controller.view()['counts']['ingestions'], 2)
        self.assertEqual(self.controller.view()['counts']['attempts'], 1)

    def test_identical_values_distinct_native_ids_make_distinct_attempts(self):
        first, _ = self.anchor(101)
        second, _ = self.anchor(102)
        view = self.controller.view()
        self.assertNotEqual(first, second)
        self.assertEqual(view['counts']['occurrences'], 2)
        self.assertEqual(view['attempts'][first]['close_reason'], 'SUPERSEDED_BEFORE_FOLLOWUP')
        self.assertEqual(view['active_attempt'], second)

    def test_same_identity_conflicting_source_is_not_latest_wins(self):
        attempt, op = self.anchor()
        before = self.controller.analysis_snapshot(reason='BEFORE_CONFLICT')
        prior_bytes = self.controller.store.get(before)
        ack = self.controller.observe(op, 1000, make_wire(operation_ref=op, value=b'changed'))
        self.assertFalse(ack['acknowledged'])
        view = self.controller.view()
        self.assertIn('SOURCE_ID_CONFLICT', view['stopped_flags'])
        self.assertIn('SOURCE_ID_CONFLICT', view['attempts'][attempt]['reason_flags'])
        self.assertEqual(view['counts']['attempts'], 1)
        self.assertIn('CLOSURE_UNRESOLVED', view['attempts'][attempt]['reason_flags'])
        self.assertEqual(view['counts']['analyses'], 2)
        self.assertEqual(self.controller.store.get(before), prior_bytes)

    def test_reused_native_identity_across_operations_is_held(self):
        self.anchor()
        op = self.begin(watermark=100)
        self.controller.record_completion(op, known=True, evidence_ref='fixture:completion')
        ack = self.controller.observe(op, 0, make_wire(operation_ref=op))
        self.assertFalse(ack['acknowledged'])
        self.assertIn('OCCURRENCE_REUSED_ACROSS_OPERATIONS', self.controller.view()['stopped_flags'])

    def test_two_published_invocations_preserve_multi_exposure_hold(self):
        attempt, _ = self.anchor()
        self.publish(attempt)
        self.publish(attempt)
        self.followup(attempt)
        view = self.controller.view()
        self.assertEqual(view['counts']['invocations'], 2)
        self.assertEqual(view['counts']['publications'], 2)
        self.assertIn('HOLD_MULTI_INVOCATION', view['attempts'][attempt]['reason_flags'])
        self.assertFalse(view['attempts'][attempt]['single_invocation_interpretation'])

    def test_uncertain_publication_is_not_zero_exposure(self):
        attempt, _ = self.anchor()
        call = self.controller.receive_help(attempt, logical_resource='WSS-U01-HINT', config_id='G_BASE')
        self.controller.advance_invocation(call, 'CONSUME_STARTED', evidence_ref='fixture:consume')
        self.controller.finish_invocation(call, publication='UNRESOLVED', evidence_ref='fixture:failure')
        self.followup(attempt)
        view = self.controller.view()
        self.assertTrue(view['invocations'][call]['publication_unresolved'])
        self.assertIn('HOLD_PUBLICATION_UNRESOLVED', view['attempts'][attempt]['reason_flags'])
        self.assertEqual(view['attempts'][attempt]['closure_status'], 'CLOSURE_UNRESOLVED')

    def test_later_error_does_not_erase_known_publication(self):
        attempt, _ = self.anchor()
        call = self.controller.receive_help(attempt, logical_resource='WSS-U01-HINT', config_id='G_BASE')
        for stage in ['CONSUME_STARTED', 'CAPTURED', 'COMMIT_DURABLE', 'PUBLISHED']:
            self.controller.advance_invocation(call, stage, evidence_ref='fixture:stage')
        first_publication = next(iter(self.controller.view()['publications'].values()))
        self.controller.finish_invocation(call, publication='NONE', evidence_ref='fixture:later-error')
        self.assertEqual(next(iter(self.controller.view()['publications'].values())), first_publication)
        self.assertEqual(first_publication['evidence_ref'], 'fixture:stage')
        self.assertTrue(self.controller.view()['invocations'][call]['ever_published'])
        self.assertEqual(self.controller.view()['counts']['publications'], 1)

    def test_condition_switch_refused_and_accounted(self):
        attempt, _ = self.anchor()
        call = self.controller.receive_help(attempt, logical_resource='WSS-U01-ANSWER', config_id='G_SEED')
        self.assertEqual(self.controller.view()['invocations'][call]['stage'], 'PRECONDITION_REFUSED')
        self.assertIn('CONDITION_RESOURCE_CONFLICT', self.controller.view()['attempts'][attempt]['reason_flags'])

    def test_first_followup_retained_postclose_revision_does_not_replace(self):
        attempt, _ = self.anchor()
        self.publish(attempt)
        ack, _ = self.followup(attempt)
        first = ack['anchor']['followup_ref']
        self.followup(attempt, 103)
        view = self.controller.view()
        self.assertEqual(view['attempts'][attempt]['selected_followup'], first)
        self.assertEqual(view['counts']['followups'], 2)
        self.assertEqual(sum(v['post_close_revision'] for v in view['followups'].values()), 1)
        self.assertTrue(view['attempts'][attempt]['single_invocation_interpretation'])

    def test_closed_help_is_refused_not_reassigned_to_new_attempt(self):
        first, _ = self.anchor()
        second, _ = self.anchor(102)
        call = self.controller.receive_help(first, logical_resource='WSS-U01-HINT', config_id='G_BASE')
        view = self.controller.view()
        self.assertEqual(view['invocations'][call]['attempt_ref'], first)
        self.assertEqual(view['invocations'][call]['stage'], 'PRECONDITION_REFUSED')
        self.assertEqual(view['active_attempt'], second)

    def test_late_old_operation_event_creates_new_analysis_without_overwrite(self):
        attempt, op = self.anchor()
        self.publish(attempt)
        self.followup(attempt)
        before = self.controller.analysis_snapshot(reason='CLOSED_VIEW')
        before_bytes = self.controller.store.get(before)
        ack = self.controller.observe(op, 1000, make_wire(operation_ref=op, log_id=103, cursor_end=103))
        self.assertFalse(ack['acknowledged'])
        view = self.controller.view()
        self.assertIn('HOLD_LATE_EVIDENCE', view['attempts'][attempt]['reason_flags'])
        self.assertEqual(view['counts']['analyses'], 2)
        self.assertEqual(self.controller.store.get(before), before_bytes)
        self.assertEqual(view['attempts'][attempt]['closure_status'], 'CLOSURE_UNRESOLVED')

    def test_invalid_transport_raw_is_retained_before_failure(self):
        op = self.begin()
        self.controller.record_completion(op, known=True, evidence_ref='fixture:completion')
        ack = self.controller.observe(op, 0, b'not JSON')
        self.assertFalse(ack['acknowledged'])
        ingestion = self.controller.view()['ingestions'][ack['ingestion_ref']]
        from wss_bridge.ledger import SnapshotReference
        self.assertEqual(self.controller.store.get(SnapshotReference.from_mapping(ingestion['raw_snapshot'])), b'not JSON')
        self.assertIn('INVALID_TRANSPORT', self.controller.view()['stopped_flags'])
        with self.assertRaises(WorkflowRefused):
            self.controller.observe(op, 1000, make_wire(operation_ref=op))
        self.assertEqual(self.controller.view()['counts']['ingestions'], 1)

    def test_io_failure_poison_handle_without_retry_or_ack(self):
        op = self.begin()
        self.controller.record_completion(op, known=True, evidence_ref='fixture:completion')
        with patch.object(self.controller.store, 'put', side_effect=OSError('synthetic IO failure')):
            with self.assertRaises(OSError):
                self.controller.observe(op, 0, make_wire(operation_ref=op))
        with self.assertRaises(WorkflowRefused):
            self.controller.receive_help('missing', logical_resource='WSS-U01-HINT', config_id='G_BASE')
        self.assertEqual(self.controller.view()['counts']['attempts'], 0)

    def test_readonly_reopen_verifies_context_and_capture_references(self):
        self.anchor()
        before = {str(p.relative_to(self.path)): p.read_bytes() for p in self.path.rglob('*') if p.is_file()}
        handle = OfflineController.open_readonly(self.path, self.scope, self.context)
        self.assertEqual(handle.view()['counts']['attempts'], 1)
        with self.assertRaises(WorkflowRefused):
            handle.opportunity(note_ref='fixture:refused')
        after = {str(p.relative_to(self.path)): p.read_bytes() for p in self.path.rglob('*') if p.is_file()}
        self.assertEqual(before, after)
        with self.assertRaises(LedgerCorruptionError):
            OfflineController.open_readonly(self.path, self.scope, replace(self.context, task_version_ref='fixture:wrong'))

    def test_readonly_replay_detects_corrupt_capture_bytes(self):
        self.anchor()
        for file in (self.path / 'snapshots').glob('*.bin'):
            file.write_bytes(b'corrupt')
            break
        with self.assertRaises(LedgerCorruptionError):
            OfflineController.open_readonly(self.path, self.scope, self.context)

    def test_unsettled_invocation_closure_remains_unresolved(self):
        attempt, _ = self.anchor()
        call = self.controller.receive_help(attempt, logical_resource='WSS-U01-HINT', config_id='G_BASE')
        self.controller.close_episode(attempt, reason='ABORT')
        self.assertEqual(self.controller.view()['attempts'][attempt]['closure_status'], 'CLOSURE_UNRESOLVED')
        self.controller.finish_invocation(call, publication='NONE', evidence_ref='fixture:failed')
        self.assertIn('HOLD_LATE_EVIDENCE', self.controller.view()['attempts'][attempt]['reason_flags'])
        self.assertEqual(self.controller.view()['counts']['analyses'], 1)

    def test_visibility_slots_are_bounded_labels_and_missing_deadline_stops(self):
        op = self.begin()
        self.controller.record_completion(op, known=True, evidence_ref='fixture:completion')
        # New contract requires coherent source windows even while NO_MATCH.
        from test_native_capture import fixture_cases
        packet = json.loads(json.dumps(fixture_cases()['no_match']))
        packet['receipt']['operation_ref'] = op
        raw = json.dumps(packet).encode()
        for slot in (0,1000):
            self.assertEqual(self.controller.observe(op, slot, raw)['status'], 'WAIT')
        self.assertEqual(self.controller.observe(op, 5000, raw)['status'], 'HOLD')
        with self.assertRaises(WorkflowRefused):
            self.controller.observe(op, 5000, raw)
        self.assertIn('NATIVE_OCCURRENCE_UNAVAILABLE_AT_DEADLINE', self.controller.view()['stopped_flags'])

    def test_independent_expected_context_rejects_consistent_source_epoch_lie(self):
        op = self.begin()
        self.controller.record_completion(op, known=True, evidence_ref='fixture:completion')
        ack = self.controller.observe(op, 0, make_wire(operation_ref=op, source_epoch_ref='fixture:different'))
        self.assertFalse(ack['acknowledged'])
        self.assertIn('EXPECTED_SOURCE_CONFLICT', self.controller.view()['stopped_flags'])

    def test_pending_declarations_do_not_create_readiness(self):
        other = OfflineController.create(self.temp/'pending', self.scope, replace(self.context, pending_facts=('SANDBOX_RIGHTS_PENDING',)))
        opportunity = other.opportunity(note_ref='fixture:opportunity')
        with self.assertRaises(WorkflowRefused):
            other.begin_operation(opportunity,'TASK',controlled_value_digest=DIGEST,log_watermark=100, logical_resource='WSS-U01-HINT',config_id='G_BASE')
        self.assertEqual(other.view()['counts']['opportunities'],1)

    def test_ordered_publication_stages_cannot_be_skipped(self):
        attempt, _ = self.anchor()
        call = self.controller.receive_help(attempt, logical_resource='WSS-U01-HINT', config_id='G_BASE')
        with self.assertRaises(WorkflowRefused):
            self.controller.advance_invocation(call, 'PUBLISHED', evidence_ref='fixture:skip')
        self.assertEqual(self.controller.view()['invocations'][call]['history'],('RECEIVED',))


    def test_poison_rechecked_after_exclusive_lock_acquisition(self):
        import fcntl
        original = fcntl.flock
        def acquired(descriptor, operation):
            original(descriptor, operation)
            if operation == fcntl.LOCK_EX:
                self.controller._poisoned = True
        with patch('wss_bridge.controller.fcntl.flock', side_effect=acquired):
            with self.assertRaises(WorkflowRefused):
                self.controller.opportunity(note_ref='fixture:must-not-write')
        self.assertEqual(self.controller.view()['counts']['opportunities'], 0)

    def test_unsupported_feedback_route_never_becomes_ready(self):
        for field, value in [('eventname', 'other:event'), ('objecttable', 'other_table'), ('contextlevel', 50)]:
            with self.subTest(field=field):
                bad = replace(self.context, task_target=replace(self.context.task_target, **{field: value}))
                self.assertIn('UNSUPPORTED_NATIVE_ROUTE', bad.readiness_issues())


    def test_malformed_help_always_persists_safe_received_then_refusal(self):
        malformed = ['', '\ud800', 'x' * 10000, 'unsafe\nvalue', '\u200bhidden', 7, None]
        prior_count = 0
        for field in ('attempt_ref', 'logical_resource', 'config_id'):
            for invalid in malformed:
                with self.subTest(field=field, invalid_type=type(invalid).__name__):
                    values = dict(attempt_ref='fixture:unknown', logical_resource='WSS-U01-HINT', config_id='G_BASE')
                    values[field] = invalid
                    call = self.controller.receive_help(**values)
                    view = self.controller.view()
                    prior_count += 1
                    self.assertEqual(view['counts']['invocations'], prior_count)
                    invocation = view['invocations'][call]
                    self.assertEqual(invocation['history'], ('RECEIVED', 'PRECONDITION_REFUSED'))
                    self.assertIn('INVALID_' + field.upper(), invocation['reason_flags'])
                    self.assertIsNone(invocation[field])
                    self.assertTrue(invocation['settled'])


    def test_followup_begun_before_abort_arriving_later_never_replaces_closure(self):
        attempt, _ = self.anchor()
        self.publish(attempt)
        op = self.begin('FOLLOWUP', attempt, 101)
        self.controller.close_episode(attempt, reason='ABORT')
        prior = self.controller.view()['attempts'][attempt]
        snapshot = self.controller.analysis_snapshot(reason='ABORT_VIEW')
        snapshot_bytes = self.controller.store.get(snapshot)
        self.controller.record_completion(op, known=True, evidence_ref='fixture:late-completion')
        ack = self.controller.observe(op, 0, make_wire(operation_ref=op,kind='FOLLOWUP',log_id=102,watermark=101))
        view = self.controller.view()
        final = view['attempts'][attempt]
        self.assertFalse(ack['acknowledged'])
        self.assertEqual(final['closed_sequence'], prior['closed_sequence'])
        self.assertEqual(final['close_reason'], 'ABORT')
        self.assertIsNone(final['selected_followup'])
        self.assertIn('HOLD_LATE_EVIDENCE', final['reason_flags'])
        self.assertEqual(view['counts']['analyses'], 2)
        self.assertEqual(self.controller.store.get(snapshot), snapshot_bytes)


if __name__ == '__main__':
    unittest.main()

from dataclasses import replace
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from wss_bridge.cpc_adapter import (AdmissionContext,CPCAdapter,AdapterStopped,_dependency)
from wss_bridge.ledger import LedgerCorruptionError,SnapshotStore
from wss_bridge.primitives import ContractError,plain_json
from wp04_fixtures import encode,digest
from wp05_fixtures import KEYS,policy_data
from wp06_fixtures import full_chain,re_sign_outcome


def fresh(context):
    root=Path(tempfile.mkdtemp(prefix='wp06-',dir=os.environ['WSS_TEST_ARTIFACT_ROOT']))
    return CPCAdapter.create(root/'admission',context,'fixture:wp06-batch')


class AdapterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.chain,cls.profile,cls.keys,cls.now,cls.producer_args=full_chain()
        cls.raw=encode(cls.chain)

    def context(self,**changes):
        return AdmissionContext(changes.get('profile',self.profile),changes.get('keys',self.keys),changes.get('now',self.now))

    def test_actual_API_four_dispositions_and_config_export_partition(self):
        context=self.context();adapter=fresh(context)
        rejected=encode(re_sign_outcome(self.chain,self.profile,purpose='fixture:unapproved'))
        partial={**self.chain,'records':self.chain['records'][:-1]}
        inputs=[self.raw,rejected,b'not json',encode(partial)]
        expected=['ADMIT','REJECT','ERROR_INPUT','QUARANTINE'];direct=[]
        from cpc2.api import validate_raw
        from cpc2.export import partition_results
        for i,(raw,want) in enumerate(zip(inputs,expected)):
            with self.subTest(i=i,want=want):
                ref='fixture:input-'+str(i);truth=validate_raw(raw,self.profile,self.keys,self.now,input_ref=ref)
                result=adapter.evaluate(raw,input_ref=ref)
                self.assertEqual(result.status,'RESULT_RETAINED')
                self.assertEqual(plain_json(result.result),truth)
                self.assertEqual(result.result['disposition'],want)
                direct.append(truth)
        exported=plain_json(adapter.export());partition=partition_results(direct)
        self.assertEqual(exported,{k:v for k,v in partition.items() if k not in {'admitted','excluded'}})
        root=adapter.root/'export'
        admitted=[json.loads(line) for line in (root/'admitted.jsonl').read_text().splitlines()]
        self.assertEqual(admitted,partition['admitted'])
        self.assertEqual(set(admitted[0]),{'input_ref','case_id','experiment_id','experiment_version','unit_token',
            'attributed_condition','artifact_version','exposure_record_id','exposure_digest','outcome_key','purpose'})
        self.assertEqual(exported['counts'],{'ADMIT':1,'REJECT':1,'QUARANTINE':1,'ERROR_INPUT':1,'NOT_EVALUATED_CONFIG':0})
        state=adapter.view();self.assertEqual(state['status'],'EXPORTED');self.assertEqual(state['received'],4)
        self.assertEqual(sum(state['counts'].values())+len(state['unresolved_receipts']),state['received'])
        (Path(os.environ['WSS_TEST_ARTIFACT_ROOT'])/'WP06_ADMISSION_PARITY.json').write_bytes(encode({
            'evidence_class':'SYNTHETIC_OFFLINE_MECHANICAL_QA','actual_direct_results':direct,
            'adapter_export':exported,'CPC_core_changed':False,'native_outcome_measurement':False}))

    def test_error_config_is_actual_result_and_not_evaluated_config_export(self):
        for change in [{'profile':{}},{'keys':None},{'now':None}]:
            with self.subTest(change=list(change)):
                context=self.context(**change);adapter=fresh(context);result=adapter.evaluate(self.raw)
                self.assertEqual(result.result['disposition'],'ERROR_CONFIG')
                summary=adapter.export();self.assertEqual(summary['counts']['NOT_EVALUATED_CONFIG'],1)
                excluded=json.loads((adapter.root/'export/exclusion_ledger.jsonl').read_bytes())
                self.assertEqual(excluded['disposition'],'NOT_EVALUATED_CONFIG');self.assertEqual(summary['received'],1)

    def test_raw_bytes_and_string_forwarded_without_object_serialization(self):
        for raw in [self.raw,self.raw.decode()]:
            with self.subTest(kind=type(raw).__name__):
                adapter=fresh(self.context());module=_dependency('api');actual=module.validate_raw;seen=[]
                def observe(value,*args,**kwargs):seen.append(value);return actual(value,*args,**kwargs)
                with patch.object(module,'validate_raw',side_effect=observe):receipt=adapter.evaluate(raw)
                self.assertIs(seen[0],raw);self.assertEqual(receipt.result['disposition'],'ADMIT')

    def test_invalid_utf8_and_unencodable_string_preserve_hash_and_encoding_label(self):
        for raw,label,data in [(b'\xff','BYTES',b'\xff'),('\ud800','STR_SURROGATEPASS_NOT_VALID_UTF8',b'\xed\xa0\x80')]:
            with self.subTest(label=label):
                adapter=fresh(self.context());result=adapter.evaluate(raw)
                self.assertEqual(result.result['disposition'],'ERROR_INPUT');self.assertEqual(result.result['input_sha256'],digest(data))
                row=adapter.view()['rows'][0];self.assertEqual(row['raw_kind'],label)
                from wss_bridge.ledger import SnapshotReference
                self.assertEqual(adapter.store.get(SnapshotReference.from_mapping(row['raw_reference'])),data)

    def test_dict_API_misuse_retains_actual_receipt_and_no_fake_core_verdict(self):
        adapter=fresh(self.context());receipt=adapter.evaluate({'bad':'not transport'})
        self.assertIsNone(receipt.result);self.assertEqual(receipt.failure_code,'CORE_API_EXCEPTION')
        state=adapter.view();self.assertEqual(state['received'],1);self.assertEqual(len(state['unresolved_receipts']),1)
        self.assertFalse(state['accounting_complete']);self.assertEqual(sum(state['counts'].values()),0)
        self.assertEqual(state['rows'][0]['raw_kind'],'NON_TRANSPORT_JSON_API_MISUSE')
        with self.assertRaises(AdapterStopped):adapter.export()

    def test_runtime_API_exception_retains_input_context_and_stops_future_work(self):
        for error in [TypeError('private value'),ValueError('private value'),RuntimeError(KEYS['runtime-key'].decode())]:
            with self.subTest(kind=type(error).__name__):
                adapter=fresh(self.context());module=_dependency('api')
                with patch.object(module,'validate_raw',side_effect=error):receipt=adapter.evaluate(self.raw)
                self.assertEqual(receipt.status,'UNRESOLVED');self.assertEqual(receipt.failure_code,'CORE_API_EXCEPTION')
                self.assertIsNone(receipt.result);self.assertEqual(adapter.view()['status'],'INCOMPLETE')
                for file in (adapter.root/'snapshots').glob('*.bin'):
                    for key in KEYS.values():self.assertNotIn(key,file.read_bytes())
                self.assertNotIn(b'private value',(adapter.root/'journal/entries.jsonl').read_bytes())
                with self.assertRaises(AdapterStopped):adapter.evaluate(self.raw)

    def test_duplicate_operator_ref_is_retained_as_unresolved_without_new_API_call(self):
        adapter=fresh(self.context());first=adapter.evaluate(self.raw,input_ref='fixture:same')
        module=_dependency('api')
        with patch.object(module,'validate_raw',side_effect=AssertionError('must not evaluate duplicate')):
            second=adapter.evaluate(b'other bytes',input_ref='fixture:same')
        self.assertEqual(second.failure_code,'DUPLICATE_OPERATOR_INPUT_REF')
        self.assertNotEqual(first.receipt_ref,second.receipt_ref)
        state=adapter.view();self.assertEqual(state['received'],2);self.assertEqual(state['counts']['ADMIT'],1)
        self.assertEqual(len(state['unresolved_receipts']),1);self.assertFalse(state['accounting_complete'])
        with self.assertRaises(AdapterStopped):adapter.export()

    def test_same_case_metadata_kept_with_distinct_input_refs(self):
        adapter=fresh(self.context());a=adapter.evaluate(self.raw);b=adapter.evaluate(self.raw)
        self.assertNotEqual(a.input_ref,b.input_ref);self.assertEqual(a.result['case_id'],b.result['case_id'])
        self.assertEqual(adapter.export()['counts']['ADMIT'],2)

    def test_malformed_API_result_preserved_before_contract_failure(self):
        adapter=fresh(self.context());module=_dependency('api')
        with patch.object(module,'validate_raw',return_value={'disposition':'ADMIT','unapproved_field':'test'}):
            receipt=adapter.evaluate(self.raw)
        self.assertEqual(receipt.failure_code,'CORE_RESULT_CONTRACT_FAILURE');self.assertIsNone(receipt.result)
        state=adapter.view();self.assertIsNotNone(state['rows'][0]['returned_reference'])
        self.assertEqual(state['counts']['ADMIT'],0);self.assertEqual(len(state['unresolved_receipts']),1)

    def test_well_formed_wrong_input_identity_not_accepted(self):
        from cpc2.api import validate_raw
        adapter=fresh(self.context());wrong=validate_raw(self.raw,self.profile,self.keys,self.now,input_ref='fixture:other')
        with patch.object(_dependency('api'),'validate_raw',return_value=wrong):receipt=adapter.evaluate(self.raw,input_ref='fixture:requested')
        self.assertEqual(receipt.failure_code,'CORE_RESULT_CONTRACT_FAILURE');self.assertIsNone(receipt.result)

    def test_operator_context_is_frozen_and_keys_not_written(self):
        profile=json.loads(encode(self.profile));keys=dict(self.keys);context=AdmissionContext(profile,keys,self.now)
        profile['profile_state']='draft';keys['runtime-key']=b'changed'
        adapter=fresh(context);self.assertEqual(adapter.evaluate(self.raw).result['disposition'],'ADMIT')
        with self.assertRaises(TypeError):context.profile['profile_state']='changed'
        for file in (adapter.root/'snapshots').glob('*.bin'):
            for key in self.keys.values():self.assertNotIn(key,file.read_bytes())

    def test_readonly_reopen_verifies_context_and_blocks_writes(self):
        context=self.context();adapter=fresh(context);adapter.evaluate(self.raw);adapter.export()
        other=CPCAdapter.open_readonly(adapter.root,context,adapter.run_ref)
        self.assertEqual(other.view()['status'],'EXPORTED')
        with self.assertRaises(AdapterStopped):other.evaluate(self.raw)
        with self.assertRaises(LedgerCorruptionError):CPCAdapter.open_readonly(adapter.root,self.context(now=None),adapter.run_ref)

    def test_corrupted_raw_result_context_and_export_files_fail_readback(self):
        for kind in ['raw','result','context','export','meta','operator-ref']:
            with self.subTest(kind=kind):
                adapter=fresh(self.context());adapter.evaluate(self.raw,input_ref='fixture:explicit')
                if kind=='export':adapter.export();file=adapter.root/'export/admitted.jsonl'
                elif kind=='meta':file=adapter.root/'adapter.meta.json'
                elif kind=='context':
                    records=adapter.journal.read_records();ref=records[0].payload['data']['context_reference']
                    file=adapter.store._path(ref['snapshot_ref'])
                else:
                    row=adapter.view()['rows'][0];ref=row['raw_reference'] if kind=='raw' else row['requested_ref_reference'] if kind=='operator-ref' else row['returned_reference']
                    file=adapter.store._path(ref['snapshot_ref'])
                file.write_bytes(b'corrupted')
                with self.assertRaises((LedgerCorruptionError,ContractError)):adapter.view()

    def test_partial_raw_or_result_snapshot_failure_remains_unresolved(self):
        for prefix in ['received-raw:','actual-core-return:']:
            with self.subTest(prefix=prefix):
                adapter=fresh(self.context());actual=adapter.store.put
                def fail(name,data):
                    result=actual(name,data)
                    if name.startswith(prefix):raise OSError('synthetic after file write')
                    return result
                with patch.object(adapter.store,'put',side_effect=fail):receipt=adapter.evaluate(self.raw)
                self.assertEqual(receipt.status,'UNRESOLVED');self.assertFalse(adapter.view()['accounting_complete'])
                self.assertGreaterEqual(len(list((adapter.root/'snapshots').glob('*.bin'))),2)
                with self.assertRaises(AdapterStopped):adapter.export()

    def test_received_journal_failure_is_explicit_and_never_retried(self):
        adapter=fresh(self.context());actual=adapter.journal.append;calls=[]
        def fail(record):
            if record.payload['event']=='RECEIVED':calls.append(1);actual(record);raise OSError('synthetic after receive')
            return actual(record)
        with patch.object(adapter.journal,'append',side_effect=fail):receipt=adapter.evaluate(self.raw)
        self.assertEqual(receipt.status,'UNRESOLVED');self.assertEqual(calls,[1]);self.assertEqual(adapter.view()['received'],1)
        self.assertEqual(adapter.view()['unresolved_receipts'],(receipt.receipt_ref,))

    def test_valid_explicit_ref_raw_capture_append_failure_is_storage_failure(self):
        adapter=fresh(self.context());actual=adapter.journal.append
        def fail(record):
            if record.payload['event']=='RAW_CAPTURED':raise OSError('synthetic journal failure')
            return actual(record)
        with patch.object(adapter.journal,'append',side_effect=fail):receipt=adapter.evaluate(self.raw,input_ref='fixture:valid-ref')
        self.assertEqual(receipt.failure_code,'RAW_OR_RECEIPT_PRESERVATION_FAILURE')
        self.assertEqual(adapter.view()['received'],1);self.assertFalse(adapter.view()['accounting_complete'])

    def test_partial_export_and_existing_directory_never_overwrite_or_claim_complete(self):
        for mode in ['partial','existing']:
            with self.subTest(mode=mode):
                adapter=fresh(self.context());adapter.evaluate(self.raw)
                if mode=='existing':
                    (adapter.root/'export').mkdir();(adapter.root/'export/marker').write_bytes(b'keep')
                    with self.assertRaises(FileExistsError):adapter.export()
                    self.assertEqual((adapter.root/'export/marker').read_bytes(),b'keep')
                else:
                    from wss_bridge.cpc_adapter import _new_file as actual
                    def fail(path,data):
                        if path.name=='exclusion_ledger.jsonl':raise OSError('synthetic export failure')
                        return actual(path,data)
                    with patch('wss_bridge.cpc_adapter._new_file',side_effect=fail),self.assertRaises(OSError):adapter.export()
                    self.assertTrue((adapter.root/'export/admitted.jsonl').exists())
                state=adapter.view();self.assertEqual(state['status'],'INCOMPLETE');self.assertIsNone(state['export'])
                self.assertFalse(state['accounting_complete'])

    def test_export_completion_ledger_failure_retains_files_and_pending_export(self):
        adapter=fresh(self.context());adapter.evaluate(self.raw);actual=adapter.journal.append
        def fail(record):
            if record.payload['event']=='EXPORT_COMPLETED':raise OSError('synthetic ledger completion failure')
            return actual(record)
        with patch.object(adapter.journal,'append',side_effect=fail),self.assertRaises(OSError):adapter.export()
        self.assertEqual(adapter.view()['status'],'INCOMPLETE');self.assertIsNone(adapter.view()['export'])
        self.assertTrue((adapter.root/'export/accounting.json').exists())

    def test_missing_dependency_is_error_without_fabricated_result(self):
        for missing_name in ['api','profile','export']:
            with self.subTest(missing=missing_name):
                adapter=fresh(self.context());actual=_dependency
                def missing(name):
                    if name==missing_name:raise FileNotFoundError('synthetic absent schema/module')
                    return actual(name)
                with patch('wss_bridge.cpc_adapter._dependency',side_effect=missing):
                    receipt=adapter.evaluate(self.raw);state=adapter.view()
                self.assertEqual(receipt.status,'UNRESOLVED');self.assertIsNone(receipt.result)
                self.assertEqual(len(state['unresolved_receipts']),1);self.assertIsNotNone(state['rows'][0]['raw_reference'])

    def test_invalid_and_overbound_operator_refs_do_not_drop_raw_input(self):
        for ref in ['',True,'\ud800','x'*257,'x'*49]:
            with self.subTest(ref=repr(ref)[:30]):
                profile=json.loads(encode(self.profile));profile['input_limits']['max_identifier_chars']=48
                adapter=fresh(self.context(profile=profile));receipt=adapter.evaluate(self.raw,input_ref=ref)
                self.assertEqual(receipt.status,'UNRESOLVED');self.assertEqual(receipt.failure_code,'INVALID_OPERATOR_INPUT_REF')
                state=adapter.view();self.assertEqual(state['received'],1)
                self.assertIsNotNone(state['rows'][0]['raw_reference']);self.assertFalse(state['accounting_complete'])

    def test_stricter_identifier_and_byte_limits_are_not_widened(self):
        profile=json.loads(encode(self.profile));profile['input_limits']['max_identifier_chars']=48
        adapter=fresh(self.context(profile=profile));receipt=adapter.evaluate(self.raw)
        self.assertLessEqual(len(receipt.input_ref),48);self.assertEqual(receipt.status,'RESULT_RETAINED')
        # Existing chain capture refs are 50 chars, so stricter raw input fails.
        self.assertNotEqual(receipt.result['disposition'],'ADMIT')
        profile=json.loads(encode(self.profile));profile['input_limits']['max_bytes']=1
        adapter=fresh(self.context(profile=profile));self.assertEqual(adapter.evaluate(self.raw).result['disposition'],'ERROR_INPUT')

    def test_one_character_schema_bound_keeps_actual_core_config_result(self):
        profile=json.loads(encode(self.profile));profile['input_limits']['max_identifier_chars']=1
        adapter=fresh(self.context(profile=profile));receipt=adapter.evaluate(self.raw)
        from cpc2.api import validate_raw
        expected=validate_raw(self.raw,profile,self.keys,self.now,input_ref=receipt.input_ref)
        self.assertEqual(len(receipt.input_ref),1);self.assertEqual(plain_json(receipt.result),expected)
        # With this actual fixed profile the core rejects its own long policy
        # identifiers as ERROR_CONFIG; no fake one-character valid profile claim.
        self.assertEqual(receipt.result['disposition'],'ERROR_CONFIG')

    def test_invalid_scalar_and_nested_key_material_is_always_redacted(self):
        for keys in [12345678987654321,{'runtime-key':12345678987654321},
                     {'runtime-key':True},{'runtime-key':None},{'runtime-key':['secret-key-value',123]}]:
            with self.subTest(kind=type(keys).__name__):
                context=self.context(keys=keys);fingerprint=context.receipt['key_fingerprints_not_material']
                self.assertEqual(set(fingerprint),{'type','sha256'})
                adapter=fresh(context);result=adapter.evaluate(self.raw)
                self.assertEqual(result.result['disposition'],'ERROR_CONFIG')
                for file in (adapter.root/'snapshots').glob('*.bin'):
                    self.assertNotIn(b'12345678987654321',file.read_bytes());self.assertNotIn(b'secret-key-value',file.read_bytes())

    def test_empty_batch_and_sealed_batch_lifecycle(self):
        adapter=fresh(self.context());self.assertEqual(adapter.export()['received'],0)
        with self.assertRaises(AdapterStopped):adapter.evaluate(self.raw)
        with self.assertRaises(AdapterStopped):adapter.export()

    def test_private_loader_does_not_execute_shadow_global_cpc_package(self):
        root=Path(tempfile.mkdtemp(prefix='wp06-shadow-',dir=os.environ['WSS_TEST_ARTIFACT_ROOT']))
        (root/'cpc2').mkdir();marker=root/'BAD'
        (root/'cpc2/__init__.py').write_text('from pathlib import Path\nPath('+repr(str(marker))+').write_text("bad")\n')
        script='''import sys
sys.path[:0]=sys.argv[1:4]
from wss_bridge.cpc_adapter import AdmissionContext,CPCAdapter
from pathlib import Path
c=AdmissionContext({},None,None)
a=CPCAdapter.create(Path(sys.argv[4])/'adapter',c,'fixture:shadow')
assert a.evaluate(b'{}').result['disposition']=='ERROR_CONFIG'
assert 'cpc2' not in sys.modules
assert not Path(sys.argv[5]).exists()
'''
        result=subprocess.run([sys.executable,'-I','-B','-c',script,str(root),str(Path(os.environ['WSS_CODE_ROOT'])/'src'),
            str(Path(__file__).parent),str(root),str(marker)],capture_output=True,text=True,timeout=30)
        (root/'stdout.txt').write_text(result.stdout);(root/'stderr.txt').write_text(result.stderr)
        self.assertEqual(result.returncode,0,result.stderr);self.assertFalse(marker.exists())

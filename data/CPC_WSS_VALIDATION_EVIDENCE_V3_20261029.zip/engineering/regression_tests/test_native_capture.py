"""Offline capture persistence checks using prior actual-PHP synthetic wires.

No helper process, native reader, PDO, Moodle/LIRA or network is invoked.
"""
import base64
import copy
import dataclasses
import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from wss_bridge.ledger import LedgerCorruptionError, SnapshotStore
from wss_bridge.native_capture import (
    check_and_store_capture, load_capture, persist_raw,
)
from wss_bridge.primitives import ContractError, canonical_json_bytes

WORKSPACE = Path(__file__).resolve().parents[3]
WIRES = WORKSPACE / "outputs/CPC_JLA_WSS_SC01_SEMANTIC_REPAIR_V1_20261020/frozen_inputs/PHP_WIRE_CASES_final.jsonl"


def fixture_cases():
    return {row["case_id"]: row["envelope"] for row in
            (json.loads(line) for line in WIRES.read_text().splitlines())}


def blob(raw):
    digest = hashlib.sha256(raw).hexdigest()
    return {"ref": "blob:" + digest, "sha256": "sha256:" + digest,
            "byte_length": len(raw), "data_base64": base64.b64encode(raw).decode("ascii")}


def content(row, ref):
    return base64.b64decode(next(item for item in row["blobs"] if item["ref"] == ref)["data_base64"])


def mutate_snapshot(row, change):
    snapshot = row["receipt"]["snapshots"][0]
    old_ref = snapshot["snapshot_ref"]
    metadata = json.loads(content(row, old_ref))
    change(metadata)
    replacement = blob(canonical_json_bytes(metadata))
    row["blobs"] = [replacement if item["ref"] == old_ref else item for item in row["blobs"]]
    snapshot["snapshot_ref"] = replacement["ref"]


def mutate_event(row, change, *, duplicate=False):
    for item in row["blobs"]:
        try:
            metadata = json.loads(base64.b64decode(item["data_base64"]))
        except (ValueError, UnicodeError):
            continue
        if isinstance(metadata, dict) and "native_occurrence" in metadata:
            change(metadata)
            replacement = blob(canonical_json_bytes(metadata))
            if duplicate:
                row["blobs"].append(replacement)
            else:
                row["blobs"] = [replacement if value["ref"] == item["ref"] else value for value in row["blobs"]]
            return
    raise AssertionError("fixture event metadata absent")


class NativeCaptureTests(unittest.TestCase):
    def setUp(self):
        self.artifact_directory = Path(tempfile.mkdtemp(
            prefix=self._testMethodName + "-", dir=os.environ["WSS_TEST_ARTIFACT_ROOT"],
        ))
        self.store = SnapshotStore.create(self.artifact_directory / "store", "synthetic:store")
        self.cases = fixture_cases()

    def capture(self, row):
        raw = canonical_json_bytes(row)
        raw_ref = persist_raw(raw, self.store)
        return check_and_store_capture(raw_ref, self.store)

    def positive(self):
        return copy.deepcopy(self.cases["positive_json"])

    def assert_incoherent(self, row):
        bundle = self.capture(row)
        self.assertIn("CAPTURE_METADATA_INCOHERENT", bundle.metadata_issues)
        self.assertEqual(self.store.get(bundle.raw_reference), canonical_json_bytes(row))
        self.assertEqual(len(bundle.blob_references), len(row["blobs"]))

    def test_three_actual_php_positive_wires_preserve_exactbytes(self):
        for name in ("positive_json", "positive_serialized_other", "legitimate_empty_value"):
            with self.subTest(case=name):
                row = self.cases[name]
                bundle = self.capture(row)
                self.assertEqual(bundle.metadata_issues, ())
                self.assertEqual(bundle.transport.to_mapping(), row)
                for reference, item in zip(bundle.blob_references, row["blobs"]):
                    self.assertEqual(self.store.get(reference), base64.b64decode(item["data_base64"]))
                self.assertEqual(bundle.transport.evidence_class, "SYNTHETIC_OFFLINE_FIXTURE")
                self.assertFalse(hasattr(bundle, "authorized"))
                with self.assertRaises(dataclasses.FrozenInstanceError):
                    bundle.metadata_issues = ()

    def test_all_eighteen_wires_retained_nonmatch_never_unflagged(self):
        self.assertEqual(len(self.cases), 18)
        for name, row in self.cases.items():
            with self.subTest(case=name):
                bundle = self.capture(row)
                self.assertEqual(len(bundle.blob_references), len(row["blobs"]))
                self.assertEqual(self.store.get(bundle.raw_reference), canonical_json_bytes(row))
                if row["receipt"]["status"] != "MATCH_OBSERVED":
                    self.assertIn("CAPTURE_STATUS_NOT_MATCH", bundle.metadata_issues)

    def test_invalid_transport_raw_is_retained(self):
        for raw in (b"\xffbad", b'{"receipt":', b"[]"):
            with self.subTest(raw=raw):
                reference = persist_raw(raw, self.store)
                with self.assertRaises(ContractError):
                    check_and_store_capture(reference, self.store)
                self.assertEqual(self.store.get(reference), raw)

    def test_exact_reuse_and_readonly_replay_write_nothing(self):
        row = self.positive()
        first = self.capture(row)
        before = {p.name: p.read_bytes() for p in self.store._directory.iterdir()}
        second = self.capture(row)
        self.assertEqual(first.manifest_reference, second.manifest_reference)
        self.assertEqual(before, {p.name: p.read_bytes() for p in self.store._directory.iterdir()})
        with patch.object(self.store, "put", side_effect=AssertionError("replay must not write")):
            loaded = load_capture(first.manifest_reference, self.store)
        self.assertEqual(loaded, first)

    def test_closed_snapshot_shape_and_projection_fields(self):
        for change in (
            lambda meta: meta.update(unknown=True),
            lambda meta: meta["native_snapshot_fields"].update(value_id=999),
            lambda meta: meta["native_snapshot_fields"].pop("value_id"),
            lambda meta: meta["native_snapshot_fields"].update(snapshot_ref="invented"),
            lambda meta: meta.update(standard_log_record_id=102),
            lambda meta: meta.update(standard_log_record_id=True),
        ):
            row = self.positive(); mutate_snapshot(row, change)
            with self.subTest(change=change): self.assert_incoherent(row)

    def test_projection_lengths_tmp_and_itemtype(self):
        for field, value in (("item_byte_length", 9), ("presentation_byte_length", True),
                             ("value_byte_length", 17), ("tmp_completed", 1),
                             ("tmp_completed", False), ("raw_item_type_ref", "missing")):
            row = self.positive()
            mutate_snapshot(row, lambda meta: meta["source_projection_details"].update({field: value}))
            with self.subTest(field=field, value=value): self.assert_incoherent(row)
        row = self.positive()
        mutate_snapshot(row, lambda meta: meta["source_projection_details"].pop("raw_item_type_ref"))
        self.assert_incoherent(row)

    def test_missing_other_source_not_acknowledged(self):
        row = self.positive()
        other = json.loads(content(row, row["receipt"]["snapshots"][0]["snapshot_ref"]))["raw_other_ref"]
        row["blobs"] = [item for item in row["blobs"] if item["ref"] != other]
        self.assert_incoherent(row)

    def test_duplicate_event_metadata_and_event_projection_tamper(self):
        row = self.positive()
        mutate_event(row, lambda meta: meta.update(raw_other_byte_length=40), duplicate=True)
        self.assert_incoherent(row)
        for change in (
            lambda meta: meta.update(extra=True),
            lambda meta: meta.update(raw_other_byte_length=True),
            lambda meta: meta["native_occurrence"].update(objectid=2000),
            lambda meta: meta["raw_text_column_refs"].update(origin="missing"),
            lambda meta: meta["raw_text_column_refs"].update(origin=meta["raw_text_column_refs"]["objecttable"]),
        ):
            row = self.positive(); mutate_event(row, change)
            with self.subTest(change=change): self.assert_incoherent(row)

    def test_no_snapshot_missing_bytes_or_bad_digests_fail_closed(self):
        row = self.positive(); row["receipt"]["snapshots"] = []
        self.assertIn("CAPTURE_SNAPSHOT_NOT_SINGLETON", self.capture(row).metadata_issues)
        for field in ("value_bytes_ref", "snapshot_ref"):
            row = self.positive(); ref = row["receipt"]["snapshots"][0][field]
            row["blobs"] = [item for item in row["blobs"] if item["ref"] != ref]
            raw_ref = persist_raw(canonical_json_bytes(row), self.store)
            with self.subTest(field=field), self.assertRaises(ContractError):
                check_and_store_capture(raw_ref, self.store)
            self.assertEqual(self.store.get(raw_ref), canonical_json_bytes(row))

    def test_unreadable_existing_raw_fails_without_overwrite(self):
        raw = canonical_json_bytes(self.positive()); reference = persist_raw(raw, self.store)
        path = self.store._path(reference.snapshot_ref); path.write_bytes(b"corrupt")
        with self.assertRaises(LedgerCorruptionError): persist_raw(raw, self.store)
        self.assertEqual(path.read_bytes(), b"corrupt")

    def test_partial_write_failure_leaves_raw_and_orphan_inspectable(self):
        raw = canonical_json_bytes(self.positive()); reference = persist_raw(raw, self.store)
        original_put = self.store.put
        calls = []
        def fail_second(name, data):
            calls.append(name)
            if len(calls) == 2: raise OSError("synthetic IO failure")
            return original_put(name, data)
        with patch.object(self.store, "put", side_effect=fail_second), self.assertRaises(OSError):
            check_and_store_capture(reference, self.store)
        self.assertEqual(self.store.get(reference), raw)
        first = self.positive()["blobs"][0]
        self.assertTrue(self.store._path(first["ref"]).exists())
        # Raw plus first blob only: no manifest or remaining source blobs.
        self.assertEqual(len(list(self.store._directory.glob("*.bin"))), 2)

    def test_readback_failure_stops_after_persisted_bytes(self):
        row = self.positive(); raw = canonical_json_bytes(row)
        reference = persist_raw(raw, self.store)
        original_get = self.store.get
        def fail_blob_readback(candidate):
            if candidate.snapshot_ref.startswith("blob:"):
                raise OSError("synthetic readback failure")
            return original_get(candidate)
        with patch.object(self.store, "get", side_effect=fail_blob_readback), self.assertRaises(OSError):
            check_and_store_capture(reference, self.store)
        self.assertEqual(self.store.get(reference), raw)
        self.assertEqual(len(list(self.store._directory.glob("*.bin"))), 2)

    def test_replay_rejects_missing_or_corrupted_blob_and_manifest(self):
        bundle = self.capture(self.positive())
        ref = bundle.blob_references[0]
        path = self.store._path(ref.snapshot_ref); old = path.read_bytes(); path.unlink()
        with self.assertRaises(OSError): load_capture(bundle.manifest_reference, self.store)
        path.write_bytes(old + b"tampered")
        with self.assertRaises(LedgerCorruptionError): load_capture(bundle.manifest_reference, self.store)

    def test_replay_rejects_forged_closed_manifest(self):
        bundle = self.capture(self.positive())
        for change in (lambda row: row.update(extra=True),
                       lambda row: row.update(metadata_issues=["invented"]),
                       lambda row: row.update(blob_references=[]),
                       lambda row: row.update(format="other")):
            row = json.loads(self.store.get(bundle.manifest_reference)); change(row)
            raw = canonical_json_bytes(row)
            reference = self.store.put("capture-manifest:" + hashlib.sha256(raw).hexdigest(), raw)
            with self.subTest(change=change), self.assertRaises(ContractError):
                load_capture(reference, self.store)


if __name__ == "__main__":
    unittest.main()

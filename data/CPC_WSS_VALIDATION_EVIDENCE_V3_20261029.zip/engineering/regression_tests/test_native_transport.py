"""Synthetic PHP-wire companion checks; does not execute PHP or PDO."""
import base64
import copy
import dataclasses
import hashlib
import json
import unittest
from unittest.mock import patch
from test_contracts import receipt_row
from wss_bridge.native_transport import NativeBlob,NativeReadTransport
from wss_bridge.primitives import ContractError


def blob(content):
    digest=hashlib.sha256(content).hexdigest()
    return {'ref':'blob:'+digest,'sha256':'sha256:'+digest,'byte_length':len(content),
            'data_base64':base64.b64encode(content).decode('ascii')}


def envelope():
    row=receipt_row();blobs=[blob(b'item source'),blob(b'presentation'),blob(b'\x00\xffnative bytes')]
    for source,(ref,digest) in zip(blobs,[('item_text_ref','item_digest'),('item_presentation_ref','item_presentation_digest'),('value_bytes_ref','value_digest')]):
        row['snapshots'][0][ref]=source['ref'];row['snapshots'][0][digest]=source['sha256']
    return {'transport_version':'wss-native-read-1.1','evidence_class':'SYNTHETIC_OFFLINE_FIXTURE','receipt':row,'blobs':blobs}


def parse(row):return NativeReadTransport.from_json(json.dumps(row))


class NativeTransportTests(unittest.TestCase):
    def test_exact_bytes_roundtrip_immutable_no_authority(self):
        row=envelope();parsed=parse(row)
        self.assertEqual(parsed.to_mapping(),row)
        self.assertEqual(parsed.blobs[-1].content,b'\x00\xffnative bytes')
        self.assertNotIn('native bytes',repr(parsed.blobs[-1]))
        self.assertFalse(hasattr(parsed,'authorized'));self.assertFalse(hasattr(parsed,'ready'))
        with self.assertRaises(dataclasses.FrozenInstanceError):parsed.blobs=()
        row['blobs'][0]['data_base64']='changed'
        self.assertEqual(parsed.blobs[0].content,b'item source')
        self.assertEqual(parsed.receipt.status.value,'MATCH_OBSERVED')
        # Fixture target digests intentionally differ; codec does not erase binding conflicts.
        self.assertIn('ITEM_CONTENT_CONFLICT',parsed.receipt.binding_issues())

    def test_closed_version_class_json_types_and_duplicate_keys(self):
        for field,value in [('transport_version','other'),('evidence_class','VERIFIED'),('evidence_class',[]),('blobs',{}),('blobs',None),('unknown',True)]:
            row=envelope();row[field]=value
            with self.subTest(field=field),self.assertRaises(ContractError):parse(row)
        for raw in [b'\xff','[]',json.dumps(envelope())[:-1]+',"transport_version":"wss-native-read-1.1"}',1]:
            with self.subTest(raw_type=type(raw).__name__),self.assertRaises(ContractError):NativeReadTransport.from_json(raw)

    def test_tampered_blob_digest_address_length_and_encoding(self):
        for field,value in [('sha256','sha256:'+'0'*64),('ref','arbitrary-local-ref'),('byte_length',True),('byte_length',99),('data_base64','@@@'),('data_base64','aWJ='),('data_base64',None),('unknown',True)]:
            row=envelope();row['blobs'][0][field]=value
            with self.subTest(field=field,value=value),self.assertRaises(ContractError):parse(row)
        with self.assertRaises(ContractError):NativeBlob('bad','sha256:'+'0'*64,b'')

    def test_empty_bytes_not_missing_and_duplicate_blob_rejected(self):
        row=envelope();empty=blob(b'');row['blobs'][-1]=empty
        row['receipt']['snapshots'][0].update(value_bytes_ref=empty['ref'],value_digest=empty['sha256'])
        parsed=parse(row);self.assertEqual(parsed.blobs[-1].content,b'')
        row['blobs'].append(copy.deepcopy(row['blobs'][0]))
        with self.assertRaises(ContractError):parse(row)

    def test_supplied_source_ref_missing_or_digest_conflict_rejected(self):
        for field,value in [('value_bytes_ref','unresolved'),('value_digest','sha256:'+'1'*64),('snapshot_ref','blob:'+'2'*64)]:
            row=envelope();row['receipt']['snapshots'][0][field]=value
            with self.subTest(field=field),self.assertRaises(ContractError):parse(row)
        row=envelope();metadata=blob(b'{"raw_source":"synthetic"}')
        row['blobs'].append(metadata);row['receipt']['snapshots'][0]['snapshot_ref']=metadata['ref']
        self.assertEqual(parse(row).receipt.snapshots[0].snapshot_ref,metadata['ref'])

    def test_partial_multiple_unavailable_claims_preserved(self):
        row=envelope();row['receipt']['snapshots'].append(copy.deepcopy(row['receipt']['snapshots'][0]))
        row['receipt']['occurrences'].append(copy.deepcopy(row['receipt']['occurrences'][0]));row['receipt']['status']='MULTIPLE_MATCH'
        row['receipt']['diagnostics']=['SYNTHETIC_AMBIGUITY']
        parsed=parse(row);self.assertEqual(len(parsed.receipt.occurrences),2);self.assertEqual(len(parsed.receipt.snapshots),2)
        self.assertIn('SYNTHETIC_AMBIGUITY',parsed.receipt.binding_issues())
        row['receipt'].update(status='READ_UNAVAILABLE',snapshots=[],occurrences=[]);row['blobs']=[]
        self.assertEqual(parse(row).receipt.status.value,'READ_UNAVAILABLE')

    def test_caps_fail_closed_using_small_unit_bounds(self):
        import wss_bridge.native_transport as module
        for name,value in [('MAX_TRANSPORT_BYTES',10),('MAX_BLOB_BYTES',2),('MAX_BLOBS',1),('MAX_BLOB_TOTAL',3)]:
            with self.subTest(bound=name),patch.object(module,name,value),self.assertRaises(ContractError):parse(envelope())

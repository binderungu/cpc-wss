from dataclasses import replace
from datetime import datetime, timedelta, timezone
import hashlib
import hmac
import itertools
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch

from wss_bridge.capture import LocalClock
from wss_bridge.ledger import SnapshotReference,SnapshotStore
from wss_bridge.primitives import ContractError,plain_json
from wss_bridge.producer import ProducerError,ProducerPolicy,produce
from wp04_fixtures import CONFIGS,RESOURCES,encode,digest,independent_expected
from wp05_fixtures import setup,policy_data,policy_from,resolution,snapshots,objects,sign,utc,KEYS


def one_object(root,predicate):
    matches=[o for _,o in objects(root) if isinstance(o,dict) and predicate(o)]
    if len(matches)!=1:raise AssertionError('Expected one object, found '+str(len(matches)))
    return matches[0]


def file_for_ref(root,ref):
    return Path(root)/'snapshots'/(hashlib.sha256(ref['snapshot_ref'].encode()).hexdigest()+'.bin')


class ProducerTests(unittest.TestCase):
    def verify_signature(self,value,keys,*,proof=False):
        signed=value['body'] if proof else {k:v for k,v in value.items() if k!='integrity'}
        actual=digest(encode(signed));integrity=value['integrity']
        self.assertEqual(actual,integrity['content_digest'])
        self.assertEqual(integrity['algorithm'],'HMAC-SHA256')
        self.assertEqual(integrity['mac'],'hmac-sha256:'+hmac.new(keys[integrity['key_id']],actual.encode(),hashlib.sha256).hexdigest())

    def test_ten_positive_bundles_real_clock_crypto_body_and_order_reconstructed(self):
        rows=[]
        for condition,config in itertools.product(RESOURCES,CONFIGS):
            with self.subTest(condition=condition,config=config):
                ctl,attempt,args=setup(condition,config);r=produce(ctl,attempt,**args)
                self.assertEqual(r.status,'COMPLETE');self.assertEqual(r.publication,'PUBLISHED');self.assertTrue(r.controller_reconciled)
                root=args['root'];self.assertEqual(ctl.view()['counts']['publications'],1)
                final=one_object(root,lambda o:o.get('record_type')=='exposure')
                commit=final['payload']['commitment'];usage=commit['body']['usage_attestation'];release=final['payload']['release_attestation']
                from cpc2.schema import validate_named
                maximum=args['policy'].profile['input_limits']['max_identifier_chars']
                for value,name in [(final,'exposure'),(commit,'commitment'),
                                   (usage,'usage_attestation'),(release,'release_attestation')]:
                    self.assertEqual(validate_named(value,name,max_identifier_chars=maximum),[])
                self.verify_signature(final,KEYS)
                for proof in [commit,usage,release]:self.verify_signature(proof,KEYS,proof=True)
                self.assertEqual(release['body']['commitment_digest'],digest(encode(commit)))
                self.assertNotEqual(release['body']['commitment_digest'],commit['integrity']['content_digest'])
                rawres=json.loads(args['resolution_raw'])
                self.assertEqual(final['predecessor_digest'],rawres['integrity']['content_digest'])
                self.assertEqual(commit['body']['resolution_digest'],rawres['integrity']['content_digest'])
                for part in [final,commit['body'],usage['body'],release['body']]:
                    self.assertEqual(part['unit_token'],attempt);self.assertEqual(part['profile_id'],'fixture:WP05-profile')
                for part in [commit['body'],usage['body'],release['body']]:self.assertEqual(part['invocation_id'],r.invocation_ref)
                self.assertEqual(release['body']['exposure_record_id'],final['record_id'])
                self.assertNotIn('release_time',commit['body']);self.assertNotIn('release_attestation',commit['body'])
                self.assertEqual(set(usage['body']['measured_components']),{'prompt','generation'})
                for name,entry in final['payload']['artifacts'].items():
                    self.assertEqual(entry['evidence_mode'],'measured' if name in ['prompt','generation'] else 'declared')
                complete=one_object(root,lambda o:o.get('format')=='wss-production-v1')
                context_receipt=one_object(root,lambda o:o.get('format')=='wss-producer-context-v1')
                self.assertEqual(context_receipt['configuration_time'],args['policy'].configuration_time)
                self.assertEqual(context_receipt['controller_scope'],ctl.scope.to_mapping())
                saved_profile=one_object(root,lambda o:'artifact_registry' in o)
                from cpc2.profile import validate_profile
                self.assertEqual(validate_profile(saved_profile,context_receipt['configuration_time'],KEYS),[])
                manifest=json.loads(file_for_ref(root,complete['consumption_reference']).read_bytes())
                prompt=file_for_ref(root,manifest['prompt_reference']).read_bytes()
                gen=file_for_ref(root,manifest['generation_reference']).read_bytes()
                catalog=file_for_ref(root,manifest['catalog_reference']).read_bytes()
                body=independent_expected(prompt,gen,catalog)
                self.assertEqual((root/'publications/response.txt').read_bytes(),body)
                for name,raw in [('prompt',prompt),('generation',gen)]:
                    self.assertEqual(usage['body']['measured_components'][name]['digest'],digest(raw))
                    self.assertEqual(final['payload']['artifacts'][name]['digest'],digest(raw))
                durable=json.loads(file_for_ref(root,complete['durability_reference']).read_bytes())
                def t(x):return datetime.fromisoformat(x.replace('Z','+00:00'))
                self.assertLessEqual(t(usage['body']['issued_at']),t(commit['body']['issued_at']))
                self.assertLessEqual(t(commit['body']['issued_at']),t(durable['durable_complete_observed']['utc']))
                self.assertLessEqual(t(durable['durable_complete_observed']['utc']),t(release['body']['issued_at']))
                self.assertLess(t(commit['body']['issued_at']),t(release['body']['issued_at']))
                self.assertLessEqual(t(release['body']['issued_at']),t(final['issued_at']))
                self.assertLess(commit['body']['sequence'],release['body']['sequence'])
                self.assertEqual(manifest['observed_use']['source'],'REAL_UTC')
                ledger=[json.loads(line) for line in (ctl.root/'journal/entries.jsonl').read_text().splitlines()]
                stages=[x['record']['payload']['data']['stage'] for x in ledger if x['record']['payload']['event']=='INVOCATION_STAGE']
                self.assertEqual(stages,['CONSUME_STARTED','CAPTURED','COMMIT_DURABLE','PUBLISHED','PUBLISHED'])
                for _,raw in snapshots(root):
                    for key in KEYS.values():self.assertNotIn(key,raw)
                rows.append({'condition':condition,'config':config,'invocation_ref':r.invocation_ref,'root':str(root),
                    'exposure_record_id':final['record_id'],'body_digest':digest(body),'HMAC_independent':'MATCH',
                    'body_reconstruction':'MATCH','clock_source':'REAL_UTC','full_chain_admission':False})
        p=Path(os.environ['WSS_TEST_ARTIFACT_ROOT'])/'WP05_TEN_BUNDLE_RECONSTRUCTION.json'
        p.write_bytes(encode({'evidence_class':'SYNTHETIC_OFFLINE_MECHANICAL_QA','cases':rows,'native_data':False}))

    def test_capture_writes_and_commit_durability_precede_actual_publication(self):
        ctl,attempt,args=setup();from wss_bridge.producer import _new_file as actual
        observed=[]
        def publish(path,body):
            if path.name=='response.txt':
                root=args['root'];commit=one_object(root,lambda o:'body' in o and 'usage_attestation' in o['body'])
                self.assertNotIn('release_time',commit['body'])
                durable=one_object(root,lambda o:'durable_complete_observed' in o)
                self.assertTrue(durable['file_fsync_directory_fsync_readback_completed'])
                view=ctl.view();inv=next(iter(view['invocations'].values()))
                self.assertEqual(inv['stage'],'COMMIT_DURABLE');self.assertEqual(view['counts']['publications'],0)
                self.assertFalse(any('release_boundary' in o.get('body',{}) for _,o in objects(root) if isinstance(o,dict)))
                observed.append(True)
            return actual(path,body)
        with patch('wss_bridge.producer._new_file',side_effect=publish):r=produce(ctl,attempt,**args)
        self.assertEqual(r.status,'COMPLETE');self.assertEqual(observed,[True])

    def test_declared_drift_is_not_reclassified_as_measured_or_core_detection(self):
        data=policy_data();data[0]['artifact_registry']['fixture:hint-G_BASE']['model']['digest']=digest(b'new declared model assertion')
        ctl,attempt,args=setup(data=data);r=produce(ctl,attempt,**args)
        self.assertEqual(r.status,'COMPLETE')
        e=one_object(args['root'],lambda o:o.get('record_type')=='exposure')
        self.assertEqual(e['payload']['artifacts']['model']['evidence_mode'],'declared')
        self.assertEqual(set(e['payload']['commitment']['body']['usage_attestation']['body']['measured_components']),{'prompt','generation'})

    def test_profile_role_map_and_bundle_preconditions(self):
        for mutation in [lambda p,m:p['proof_issuers'].update(usage_attestation='fixture:runtime'),
            lambda p,m:p['issuer_key_policy'].update({'fixture:observer':'runtime-key'}),
            lambda p,m:m['WSS-U01-HINT'].pop('G_SEED'),
            lambda p,m:m['WSS-U01-HINT'].update(G_SEED=m['WSS-U01-HINT']['G_BASE']),
            lambda p,m:p.update(profile_state='draft'),lambda p,m:p.update(release_boundary='browser'),
            lambda p,m:p['required_measured_components'].append('model')]:
            data=policy_data();mutation(data[0],data[1])
            with self.subTest(mutation=repr(mutation)),self.assertRaises(ContractError):policy_from(data)

    def test_no_live_secret_keys_or_unscoped_keys(self):
        p,m,start,end,now=policy_data()
        for keys in [{**KEYS,'extra-key':b'SYNTHETIC_ONLY_EXTRA'},
                     {**KEYS,'observer-key':b'ACTUAL_DEPLOYMENT_CREDENTIAL_NOT_ALLOWED'}]:
            with self.assertRaises(ContractError):ProducerPolicy(encode(p),encode(m),keys,start,end,now,
                digest(b'fixture:context'),'fixture:task','fixture:v1')

    def test_invalid_resolution_signature_retained_before_refusal(self):
        ctl,attempt,args=setup();raw=json.loads(args['resolution_raw']);raw['payload']['resolved_condition']='answer'
        args['resolution_raw']=encode(raw);r=produce(ctl,attempt,**args)
        self.assertEqual(r.status,'INCOMPLETE');self.assertEqual(r.publication,'NONE')
        self.assertEqual(r.error_code,'RESOLUTION_INTEGRITY_INVALID')
        self.assertIn(args['resolution_raw'],[v for _,v in snapshots(args['root'])])
        self.assertEqual(ctl.view()['counts']['invocations'],1)

    def test_resigned_context_namespace_launch_and_fallback_faults(self):
        mutations=[lambda r:r.update(unit_token='wrong-unit'),lambda r:r.update(context_id='wrong-context'),
            lambda r:r['payload'].update(resolved_condition='answer'),lambda r:r['payload'].update(fallback_used=True),
            lambda r:r['payload'].update(claim_namespaces={'fixture.condition':'A'}),
            lambda r:r['payload']['launch_attestation']['body'].update(resource_id='wrong-resource')]
        for mutation in mutations:
            with self.subTest(mutation=repr(mutation)):
                ctl,attempt,args=setup();args['resolution_raw']=resolution(args['policy'],attempt,modify=mutation)
                r=produce(ctl,attempt,**args);self.assertEqual(r.status,'INCOMPLETE');self.assertEqual(r.publication,'NONE')
                self.assertFalse((args['root']/'publications/response.txt').exists())

    def test_bound_config_bundle_cannot_be_silently_changed(self):
        ctl,attempt,args=setup();args['binding']=replace(args['binding'],bundle_ref='fixture:answer-G_BASE')
        r=produce(ctl,attempt,**args);self.assertEqual(r.error_code,'RESOLUTION_ASSIGNMENT_BUNDLE_MISMATCH')
        self.assertEqual(r.publication,'NONE')

    def test_actual_measured_digest_is_checked_not_copied_from_registry(self):
        data=policy_data();data[0]['artifact_registry']['fixture:hint-G_BASE']['generation']['digest']=digest(b'wrong registered generation')
        ctl,attempt,args=setup(data=data);r=produce(ctl,attempt,**args)
        self.assertEqual(r.error_code,'ACTUAL_CAPTURE_REGISTRY_MISMATCH');self.assertEqual(r.publication,'NONE')
        self.assertFalse(any('measured_components' in o.get('body',{}) for _,o in objects(args['root']) if isinstance(o,dict)))

    def test_malformed_generation_has_preallocated_invocation_and_partial_raw_capture(self):
        ctl,attempt,args=setup();args['generation_raw']=b'{"seed":false}'
        r=produce(ctl,attempt,**args);view=ctl.view()
        self.assertEqual(r.status,'INCOMPLETE');self.assertEqual(r.publication,'NONE')
        self.assertEqual(view['invocations'][r.invocation_ref]['stage'],'FAILED_BEFORE_PUBLICATION')
        self.assertIn(args['generation_raw'],[v for _,v in snapshots(args['root'])])

    def test_renderer_failure_never_creates_usage_commit_or_response(self):
        ctl,attempt,args=setup();args['prompt_raw']=b'{}'
        r=produce(ctl,attempt,**args);self.assertEqual(r.publication,'NONE')
        self.assertFalse((args['root']/'publications').exists())
        self.assertFalse(any('body' in o and 'proof_id' in o['body'] for _,o in objects(args['root']) if isinstance(o,dict)))

    def test_signing_failure_before_commit_never_publishes(self):
        ctl,attempt,args=setup();from wss_bridge.producer import _sign as actual
        def fail(policy,value,issuer,*,proof):
            if proof and 'usage_attestation' in value:raise OSError('synthetic signing failure')
            return actual(policy,value,issuer,proof=proof)
        with patch('wss_bridge.producer._sign',side_effect=fail):r=produce(ctl,attempt,**args)
        self.assertEqual(r.publication,'NONE');self.assertFalse((args['root']/'publications').exists())

    def test_commit_write_fails_after_bytes_without_false_durable_or_cleanup(self):
        ctl,attempt,args=setup();actual=SnapshotStore.put
        def fail(store,name,raw):
            ref=actual(store,name,raw)
            if name.startswith('signed-commitment:'):raise OSError('synthetic error after commitment file')
            return ref
        with patch.object(SnapshotStore,'put',new=fail):r=produce(ctl,attempt,**args)
        self.assertEqual(r.publication,'NONE');self.assertFalse((args['root']/'publications').exists())
        one_object(args['root'],lambda o:'usage_attestation' in o.get('body',{}))
        self.assertFalse(any('durable_complete_observed' in o for _,o in objects(args['root']) if isinstance(o,dict)))

    def test_partial_response_write_is_unknown_publication_not_zero(self):
        ctl,attempt,args=setup();from wss_bridge.producer import _new_file as actual
        def partial(path,raw):
            if path.name=='response.txt':actual(path,raw[:12]);raise OSError('synthetic partial response')
            return actual(path,raw)
        with patch('wss_bridge.producer._new_file',side_effect=partial):r=produce(ctl,attempt,**args)
        self.assertEqual(r.publication,'UNRESOLVED');self.assertEqual(r.status,'INCOMPLETE')
        self.assertEqual((args['root']/'publications/response.txt').stat().st_size,12)
        self.assertEqual(ctl.view()['invocations'][r.invocation_ref]['stage'],'PUBLICATION_UNRESOLVED')

    def test_release_directory_fsync_failure_retains_unknown_full_response(self):
        ctl,attempt,args=setup();from wss_bridge.producer import _fsync_directory as actual
        def fail(path):
            if path.name=='publications':raise OSError('synthetic directory fsync failure')
            return actual(path)
        with patch('wss_bridge.producer._fsync_directory',side_effect=fail):r=produce(ctl,attempt,**args)
        self.assertEqual(r.publication,'UNRESOLVED');self.assertTrue((args['root']/'publications/response.txt').exists())
        f=one_object(args['root'],lambda o:o.get('format')=='wss-producer-failure-v1')
        self.assertEqual(f['publication'],'UNRESOLVED')

    def test_failure_after_known_publication_still_counts_exposure(self):
        ctl,attempt,args=setup();from wss_bridge.producer import _sign as actual
        def fail(policy,value,issuer,*,proof):
            if proof and 'release_boundary' in value:raise OSError('synthetic release-proof failure')
            return actual(policy,value,issuer,proof=proof)
        with patch('wss_bridge.producer._sign',side_effect=fail):r=produce(ctl,attempt,**args)
        self.assertEqual((r.status,r.publication),('INCOMPLETE','PUBLISHED'))
        self.assertEqual(ctl.view()['counts']['publications'],1)
        self.assertEqual(ctl.view()['invocations'][r.invocation_ref]['stage'],'PUBLISHED')
        self.assertIsNone(r.exposure_reference)

    def test_controller_write_uncertainty_after_publication_is_not_retried(self):
        ctl,attempt,args=setup();actual=ctl.advance_invocation;calls=[]
        def fail(inv,stage,**kwargs):
            if stage=='PUBLISHED':calls.append(stage);raise OSError('synthetic controller write unavailable')
            return actual(inv,stage,**kwargs)
        with patch.object(ctl,'advance_invocation',side_effect=fail):r=produce(ctl,attempt,**args)
        self.assertEqual(r.publication,'PUBLISHED');self.assertFalse(r.controller_reconciled)
        self.assertEqual(calls,['PUBLISHED']);self.assertTrue((args['root']/'publications/response.txt').exists())
        self.assertFalse(ctl.view()['invocations'][r.invocation_ref]['settled'])

    def test_final_exposure_persisted_but_finish_failure_retains_known_publication(self):
        ctl,attempt,args=setup();calls=[]
        def fail(*a,**k):calls.append(1);raise OSError('synthetic finish failure')
        with patch.object(ctl,'finish_invocation',side_effect=fail):r=produce(ctl,attempt,**args)
        self.assertEqual(r.publication,'PUBLISHED');self.assertEqual(r.status,'INCOMPLETE')
        self.assertFalse(r.controller_reconciled);self.assertIsNotNone(r.exposure_reference);self.assertEqual(calls,[1])
        one_object(args['root'],lambda o:o.get('record_type')=='exposure')

    def test_same_or_backwards_observed_time_is_not_repaired(self):
        for mode in ['same','backwards']:
            with self.subTest(mode=mode):
                ctl,attempt,args=setup();base=datetime.fromisoformat(args['policy'].configuration_time)
                readings=[(utc(base),i) for i in range(6)]
                if mode=='backwards':readings[1]=(utc(base-timedelta(seconds=1)),1)
                seq=iter(readings);args['clock']=LocalClock('fixture:WP05-clock',fault_reader=lambda:next(seq))
                r=produce(ctl,attempt,**args);self.assertEqual(r.status,'INCOMPLETE')
                self.assertEqual(r.publication,'PUBLISHED' if mode=='same' else 'NONE')
                if mode=='same':self.assertEqual(r.error_code,'RELEASE_ORDER_NOT_ESTABLISHED')
                failure=one_object(args['root'],lambda o:o.get('format')=='wss-producer-failure-v1')
                self.assertTrue(all(o['source']=='SYNTHETIC_FAULT_INJECTION' for o in failure['clock_observations_including_failed_order']))

    def test_expiry_before_release_stops_without_adjusting_time(self):
        ctl,attempt,args=setup();base=datetime.fromisoformat(args['policy'].configuration_time)
        expiry=datetime.fromisoformat(args['policy'].expires_at)
        times=[base,base+timedelta(microseconds=1),expiry+timedelta(seconds=1)]
        seq=iter((utc(x),i) for i,x in enumerate(times));args['clock']=LocalClock('fixture:WP05-clock',fault_reader=lambda:next(seq))
        r=produce(ctl,attempt,**args);self.assertEqual(r.publication,'NONE');self.assertEqual(r.error_code,'POLICY_WINDOW_INACTIVE')

    def test_abort_before_publication_is_not_overridden_by_prepared_body(self):
        ctl,attempt,args=setup();actual=ctl.advance_invocation
        def abort(inv,stage,**kwargs):
            actual(inv,stage,**kwargs)
            if stage=='COMMIT_DURABLE':ctl.close_episode(attempt,reason='ABORT')
        with patch.object(ctl,'advance_invocation',side_effect=abort):r=produce(ctl,attempt,**args)
        self.assertEqual(r.publication,'NONE');self.assertEqual(r.error_code,'CONTROLLER_NO_LONGER_ELIGIBLE_FOR_PUBLICATION')

    def test_root_collision_and_second_call_preserve_original_artifacts(self):
        ctl,attempt,args=setup();first=produce(ctl,attempt,**args);self.assertEqual(first.status,'COMPLETE')
        before={str(p.relative_to(args['root'])):p.read_bytes() for p in args['root'].rglob('*') if p.is_file()}
        second=produce(ctl,attempt,**args);self.assertEqual(second.status,'INCOMPLETE');self.assertEqual(second.publication,'NONE')
        after={str(p.relative_to(args['root'])):p.read_bytes() for p in args['root'].rglob('*') if p.is_file()}
        self.assertEqual(before,after);self.assertNotEqual(first.invocation_ref,second.invocation_ref)
        self.assertEqual(ctl.view()['counts']['invocations'],2);self.assertEqual(ctl.view()['counts']['publications'],1)

    def test_controller_refusal_counts_call_without_touching_producer_root(self):
        ctl,attempt,args=setup();args['logical_resource']='WSS-U01-ANSWER'
        r=produce(ctl,attempt,**args);self.assertEqual(r.status,'PRECONDITION_REFUSED')
        self.assertFalse(args['root'].exists());self.assertEqual(ctl.view()['counts']['invocations'],1)

    def test_unsafe_exception_text_never_enters_receipts(self):
        ctl,attempt,args=setup();secret=KEYS['runtime-key'].decode()
        with patch('wss_bridge.producer.capture_and_render',side_effect=ProducerError(secret)):
            r=produce(ctl,attempt,**args)
        self.assertEqual(r.error_code,'WP05_ProducerError')
        for _,raw in snapshots(args['root']):self.assertNotIn(secret.encode(),raw)

    def test_policy_context_and_task_binding_checked_before_consumption(self):
        for field,bad in [('controller_context_digest',digest(b'wrong controller context')),
                          ('task_id','other-task'),('task_version','other-version')]:
            with self.subTest(field=field):
                ctl,attempt,args=setup();args['policy']=replace(args['policy'],**{field:bad})
                r=produce(ctl,attempt,**args)
                self.assertEqual(r.error_code,'CONTROLLER_TASK_CONTEXT_MISMATCH');self.assertEqual(r.publication,'NONE')
                self.assertFalse(args['root'].exists())
                self.assertEqual(ctl.view()['invocations'][r.invocation_ref]['stage'],'FAILED_BEFORE_PUBLICATION')

    def test_valid_stricter_profile_identifier_limit_refused_or_supported(self):
        data=policy_data();data[0]['input_limits']['max_identifier_chars']=48
        # This profile is valid for the core but cannot hold our generated
        # actual-generation capture refs. Producer-specific rejection is honest.
        from cpc2.profile import validate_profile
        self.assertEqual(validate_profile(data[0],data[4],KEYS),[])
        with self.assertRaisesRegex(ContractError,'PRODUCER_IDENTIFIER_CAPACITY_UNSUPPORTED'):policy_from(data)
        data=policy_data();data[0]['input_limits']['max_identifier_chars']=50
        ctl,attempt,args=setup(data=data);r=produce(ctl,attempt,**args)
        self.assertEqual(r.status,'COMPLETE')

    def test_signed_resolution_exceeding_strict_identifier_bound_stops_before_release(self):
        data=policy_data();data[0]['input_limits']['max_identifier_chars']=50
        ctl,attempt,args=setup(data=data)
        args['resolution_raw']=resolution(args['policy'],attempt,modify=lambda r:r.update(nonce='n'*51))
        r=produce(ctl,attempt,**args);self.assertEqual(r.error_code,'SIGNED_OBJECT_SCHEMA_INVALID')
        self.assertEqual(r.publication,'NONE')

    def test_expired_launch_at_start_and_later_resolution_expiry_are_recorded(self):
        ctl,attempt,args=setup();p=json.loads(args['policy'].profile_raw)
        raw=json.loads(args['resolution_raw']);launch=raw['payload']['launch_attestation']['body']
        launch['expires_at']=utc(datetime.now(timezone.utc)-timedelta(seconds=1))
        raw['payload']['launch_attestation']=sign(launch,'fixture:assignment',p,proof=True)
        raw={k:v for k,v in raw.items() if k!='integrity'};args['resolution_raw']=encode(sign(raw,'fixture:resolver',p))
        r=produce(ctl,attempt,**args);self.assertEqual(r.publication,'NONE');self.assertEqual(r.error_code,'LAUNCH_WINDOW_INVALID')
        ctl,attempt,args=setup();base=datetime.fromisoformat(args['policy'].configuration_time)
        p=json.loads(args['policy'].profile_raw);raw=json.loads(args['resolution_raw'])
        raw['expires_at']=utc(base+timedelta(seconds=1))
        raw={k:v for k,v in raw.items() if k!='integrity'};args['resolution_raw']=encode(sign(raw,'fixture:resolver',p))
        seq=iter([(utc(base),0),(utc(base+timedelta(seconds=2)),1)])
        args['clock']=LocalClock('fixture:WP05-clock',fault_reader=lambda:next(seq))
        r=produce(ctl,attempt,**args);self.assertEqual(r.publication,'NONE');self.assertEqual(r.error_code,'SOURCE_CONTEXT_WINDOW_INACTIVE')

    def test_expiry_only_discovered_after_boundary_remains_publication(self):
        ctl,attempt,args=setup();base=datetime.fromisoformat(args['policy'].configuration_time)
        p=json.loads(args['policy'].profile_raw);raw=json.loads(args['resolution_raw'])
        raw['expires_at']=utc(base+timedelta(seconds=1));raw={k:v for k,v in raw.items() if k!='integrity'}
        args['resolution_raw']=encode(sign(raw,'fixture:resolver',p))
        times=[base+timedelta(microseconds=i) for i in range(4)]+[base+timedelta(seconds=2)]
        seq=iter((utc(t),i) for i,t in enumerate(times));args['clock']=LocalClock('fixture:WP05-clock',fault_reader=lambda:next(seq))
        r=produce(ctl,attempt,**args);self.assertEqual(r.publication,'PUBLISHED')
        self.assertEqual(r.error_code,'SOURCE_CONTEXT_WINDOW_INACTIVE');self.assertIsNone(r.exposure_reference)
        self.assertEqual(ctl.view()['counts']['publications'],1)

    def test_shadow_global_cpc2_package_is_never_executed(self):
        root=Path(tempfile.mkdtemp(prefix='shadow-cpc-',dir=os.environ['WSS_TEST_ARTIFACT_ROOT']))
        package=root/'cpc2';package.mkdir();marker=root/'EXECUTED_UNTRUSTED_PACKAGE'
        (package/'__init__.py').write_text('from pathlib import Path\nPath('+repr(str(marker))+').write_text("BAD")\nraise RuntimeError("SHADOW")\n')
        code='''import sys
from pathlib import Path
sys.path[:0]=[sys.argv[1],sys.argv[2],sys.argv[3]]
from wp05_fixtures import policy_data,policy_from
p=policy_from(policy_data())
assert p.profile['contract_version']=='2.0.1'
assert not Path(sys.argv[4]).exists()
assert 'cpc2' not in sys.modules
print('PRIVATE_PINNED_LOAD_PASS_NO_GLOBAL_CPC2_EXECUTION')
'''
        completed=subprocess.run([sys.executable,'-I','-B','-c',code,str(root),
            str(Path(os.environ['WSS_CODE_ROOT'])/'src'),str(Path(__file__).parent),str(marker)],
            capture_output=True,text=True,timeout=30)
        (root/'stdout.txt').write_text(completed.stdout);(root/'stderr.txt').write_text(completed.stderr)
        self.assertEqual(completed.returncode,0,completed.stderr);self.assertFalse(marker.exists())

    def test_failure_after_durable_receive_does_not_lose_or_retry_invocation(self):
        ctl,attempt,args=setup();actual=ctl.receive_help;calls=[]
        def uncertain(*a,**k):
            inv=actual(*a,**k);calls.append(inv);raise OSError('synthetic failure after receive')
        with patch.object(ctl,'receive_help',side_effect=uncertain):r=produce(ctl,attempt,**args)
        self.assertEqual(r.status,'ALLOCATION_UNRESOLVED');self.assertEqual(r.invocation_ref,calls[0])
        self.assertEqual(len(calls),1);self.assertTrue(r.call_ref.startswith('producer-call:'))
        self.assertFalse(r.controller_reconciled);self.assertFalse(args['root'].exists())
        self.assertEqual(ctl.view()['counts']['invocations'],1)
        from dataclasses import asdict
        (Path(os.environ['WSS_TEST_ARTIFACT_ROOT'])/(self._testMethodName+'.json')).write_bytes(encode(asdict(r)))

    def test_postallocation_view_failure_returns_reference_and_no_publication(self):
        ctl,attempt,args=setup();actual=ctl.view;calls=[]
        def fail_second():
            calls.append(1)
            if len(calls)==2:raise OSError('synthetic view read unavailable')
            return actual()
        with patch.object(ctl,'view',side_effect=fail_second):r=produce(ctl,attempt,**args)
        self.assertEqual(r.status,'ALLOCATION_UNRESOLVED');self.assertIsNotNone(r.invocation_ref)
        self.assertEqual(r.publication,'NONE');self.assertFalse(args['root'].exists())
        from dataclasses import asdict
        (Path(os.environ['WSS_TEST_ARTIFACT_ROOT'])/(self._testMethodName+'.json')).write_bytes(encode(asdict(r)))

    def test_preallocation_read_failure_is_explicit_not_a_fake_invocation(self):
        ctl,attempt,args=setup()
        with patch.object(ctl,'view',side_effect=OSError('synthetic view unavailable')):
            r=produce(ctl,attempt,**args)
        self.assertEqual(r.status,'ALLOCATION_NOT_STARTED');self.assertIsNone(r.invocation_ref)
        self.assertEqual(ctl.view()['counts']['invocations'],0);self.assertFalse(args['root'].exists())
        from dataclasses import asdict
        (Path(os.environ['WSS_TEST_ARTIFACT_ROOT'])/(self._testMethodName+'.json')).write_bytes(encode(asdict(r)))

    def test_future_configuration_time_cannot_consume_or_publish(self):
        ctl,attempt,args=setup();base=datetime.fromisoformat(args['policy'].configuration_time)
        args['clock']=LocalClock('fixture:WP05-clock',fault_reader=lambda:(utc(base-timedelta(seconds=1)),0))
        r=produce(ctl,attempt,**args)
        self.assertEqual(r.error_code,'CONFIGURATION_AFTER_OBSERVATION')
        self.assertEqual(r.publication,'NONE');self.assertFalse(args['root'].exists())
        self.assertEqual(ctl.view()['invocations'][r.invocation_ref]['stage'],'FAILED_BEFORE_PUBLICATION')
        from dataclasses import asdict
        (Path(os.environ['WSS_TEST_ARTIFACT_ROOT'])/(self._testMethodName+'.json')).write_bytes(encode({
            'result':asdict(r),'configuration_time':args['policy'].configuration_time,
            'observed_execution_time':utc(base-timedelta(seconds=1)),
            'clock_source':'SYNTHETIC_FAULT_INJECTION'}))

from dataclasses import replace
import hashlib
import json
import os
from pathlib import Path
import stat
import tempfile
import unittest
from unittest.mock import patch

from wss_bridge import producer_references as pr
from wss_bridge import reporting as r
from wss_bridge import baselines as b
from wss_bridge.ledger import SnapshotStore,SnapshotReference,AppendOnlyLedger,LedgerError
from wss_bridge.native_contract import LedgerRecord,RecordKind
from wss_bridge.primitives import ContractError,plain_json
from wss_bridge.producer import produce
from wp05_fixtures import setup,KEYS
from wp07_fixtures import encode
import wp07_fixtures
from test_baselines import common


def fresh():return Path(tempfile.mkdtemp(prefix='producer-ref-',dir=os.environ['WSS_TEST_ARTIFACT_ROOT']))


def new_store():
    root=fresh();store=pr.IndexedSnapshotStore.create(root/'snapshots','fixture:indexed-store')
    index=pr.ProducerReferenceIndex.create(root/'reference-index',store,call_ref='fixture:call',invocation_ref='fixture:invocation')
    return root,store,index


def read_index(root,**changes):
    return pr.ProducerReferenceIndex.open_readonly(root,invocation_ref=changes.get('invocation_ref','fixture:invocation'),call_ref=changes.get('call_ref','fixture:call'))


def produced_flow(extra=None):
    observed=[];actual=wp07_fixtures.produce
    def observe(*args,**kwargs):
        result=actual(*args,**kwargs);observed.append(result);return result
    with patch.object(wp07_fixtures,'produce',side_effect=observe):f=wp07_fixtures.flow(extra=extra)
    self_authored={}
    for number,result in enumerate(observed):
        if result.status!='COMPLETE':raise AssertionError('new synthetic producer failed')
        for path in sorted(Path(result.root).rglob('*')):
            if stat.S_ISREG(path.lstat().st_mode):self_authored['producer'+str(number)+':'+str(path.relative_to(result.root))]=path.read_bytes()
    self_authored['source-response-recipe']=f['recipe'].raw
    c=common(f,auxiliary=self_authored)
    # Only explicit typed nonproducer sources; do not reuse the historical
    # rglob/JSON producer payload collector as evidence for this repair.
    controller=f['controller'].store
    control_refs=tuple(SnapshotReference(controller._store_ref,name,'sha256:'+hashlib.sha256(bytes.fromhex(raw)).hexdigest(),len(bytes.fromhex(raw)))
                       for name,raw in c.native['retained_local_snapshot_hex'].items())
    outcome_refs={}
    for derivation in f['store'].view()['derivations']:
        for field in ('input_snapshots','output_snapshots'):
            for value in derivation[field].values():outcome_refs[value['snapshot_ref']]=SnapshotReference.from_mapping(value)
    adapter_refs={}
    for record in f['adapter'].journal.read_records():
        if record.payload['event']=='OPENED':
            value=record.payload['data']['context_reference'];adapter_refs[value['snapshot_ref']]=SnapshotReference.from_mapping(value)
    for row in f['adapter'].view()['rows']:
        for field in ('raw_reference','returned_reference','requested_ref_reference'):
            if row.get(field) is not None:
                value=row[field];adapter_refs[value['snapshot_ref']]=SnapshotReference.from_mapping(value)
    inventories=[r.capture_inventory(controller,'CONTROLLER',control_refs),
                 r.capture_inventory(f['store'].snapshots,'OUTCOME',tuple(outcome_refs.values())),
                 r.capture_inventory(f['adapter'].store,'ADAPTER',tuple(adapter_refs.values()))]
    required={item.role:[item.store_ref] for item in inventories}
    producer_inventories=[r.capture_producer_inventory(result.root,invocation_ref=result.invocation_ref,call_ref=result.call_ref) for result in observed]
    inventories.extend(producer_inventories);required['PRODUCER']=[item.store_ref for item in producer_inventories]
    comparison=b.run_comparison(c,cohort_ref='fixture:repair-cohort',snapshot_ref='fixture:repair-snapshot')
    report=r.build_handoff(c,comparison,f['store'].view(),report_ref='fixture:typed-reference-repair',
        inventories=tuple(inventories),required_stores=required,adapter_views={f['adapter'].run_ref:f['adapter'].view()})
    return f,c,report,observed,producer_inventories


class ProducerReferenceTests(unittest.TestCase):
    def test_exact_returned_reference_is_durably_indexed_before_return(self):
        root,store,index=new_store();ref=store.put('fixture:one',b'exact bytes')
        self.assertEqual(index.references(),(ref,))
        self.assertEqual(read_index(root).references(),(ref,))
        row=index.journal.read_records()[0]
        self.assertEqual(row.payload['reference'],ref.to_mapping())
        self.assertEqual(row.payload['audit_ref'],row.record_ref)
        self.assertEqual(row.payload['call_ref'],'fixture:call')

    def test_actual_producer_indexes_all_snapshots_including_seven_categories(self):
        ctl,attempt,args=setup();result=produce(ctl,attempt,**args)
        self.assertEqual(result.status,'COMPLETE')
        index=pr.ProducerReferenceIndex.open_readonly(result.root,invocation_ref=result.invocation_ref,call_ref=result.call_ref)
        refs=index.references();files=list((Path(result.root)/'snapshots').glob('*.bin'))
        self.assertEqual(len(refs),len(files))
        prefixes={ref.snapshot_ref.rsplit(':',1)[0] for ref in refs}
        self.assertTrue({'operator-profile','operator-bundle-map','received-resolution','producer-context','usage-proof','release-proof','complete-manifest'}<=prefixes)
        for ref in refs:self.assertEqual(index.store.get(ref),index.store._path(ref.snapshot_ref).read_bytes())
        inv=r.capture_producer_inventory(result.root,invocation_ref=result.invocation_ref,call_ref=result.call_ref)
        self.assertTrue(inv.complete);self.assertTrue(all(row['classification']=='REFERENCED' for row in inv.files))
        (Path(os.environ['WSS_TEST_ARTIFACT_ROOT'])/'PRODUCER_ALL_TYPED_REFERENCES.json').write_bytes(encode({
            'root':result.root,'call_ref':result.call_ref,'invocation_ref':result.invocation_ref,
            'snapshot_count':len(files),'reference_count':len(refs),'references':[ref.to_mapping() for ref in refs],
            'former_seven_categories':sorted(prefixes & {'operator-profile','operator-bundle-map','received-resolution','producer-context','usage-proof','release-proof','complete-manifest'}),
            'orphan_count':0,'native_data':False}))

    def test_capture_inputs_are_indexed_before_renderer_consumes_them(self):
        ctl,attempt,args=setup();created=[];actual_create=pr.ProducerReferenceIndex.create
        from wss_bridge import capture
        actual_render=capture.render;seen=[]
        def create(*a,**k):
            index=actual_create(*a,**k);created.append(index);return index
        def render(*a,**k):
            refs=created[0].references();prefixes={ref.snapshot_ref.rsplit(':',1)[0] for ref in refs}
            self.assertTrue({'actual-prompt','raw-generation-transport','actual-generation','catalog-snapshot'}<=prefixes)
            seen.append(True);return actual_render(*a,**k)
        with patch.object(pr.ProducerReferenceIndex,'create',side_effect=create),patch.object(capture,'render',side_effect=render):
            result=produce(ctl,attempt,**args)
        self.assertEqual(result.status,'COMPLETE');self.assertEqual(seen,[True])

    def test_new_positive_handoff_has_zero_orphans_and_reconciles(self):
        f,c,report,results,inventory=produced_flow()
        self.assertEqual(report['status'],'RECONCILED_DECLARED_SCOPE');self.assertEqual(report['reason_flags'],())
        self.assertEqual(report['inventory']['reference_coverage_gaps'],())
        self.assertEqual(report['examples']['positive']['status'],'AVAILABLE')
        self.assertEqual(report['source_map'][0]['primary_reason'],'JOINED');self.assertEqual(report['source_map'][0]['core_row']['value'],2)
        self.assertTrue(all(i.complete for i in inventory))
        self.assertTrue(all(n==0 for n in report['counts']['inventory_orphans_per_store'].values()))
        for method in ('B0','B2'):self.assertEqual(report['ledgers']['comparison']['comparisons'][method]['status'],'MATCH')
        (Path(os.environ['WSS_TEST_ARTIFACT_ROOT'])/'REPAIRED_POSITIVE_HANDOFF.json').write_bytes(encode(report))

    def test_hold_covers_both_producer_roots_without_erasing_hold(self):
        f,c,report,results,inventory=produced_flow('second-publication')
        self.assertEqual(len(results),2);self.assertEqual(len(inventory),2)
        self.assertEqual(report['status'],'RECONCILED_DECLARED_SCOPE');self.assertEqual(report['reason_flags'],())
        self.assertEqual(report['counts']['native']['invocations'],2);self.assertEqual(report['counts']['native']['publications'],2)
        self.assertTrue(all(n==0 for n in report['counts']['inventory_orphans_per_store'].values()))
        self.assertEqual(report['examples']['native_hold']['status'],'AVAILABLE')
        row=report['source_map'][0]['core_row']
        self.assertEqual(row['core_disposition'],'ADMIT');self.assertEqual(row['primary_reason'],'NATIVE_MAPPING_HOLD')
        self.assertIn('HOLD_MULTI_INVOCATION',row['reason_flags'])
        self.assertEqual(len(report['source_map'][0]['native']['all_attempt_publications']),2)
        (Path(os.environ['WSS_TEST_ARTIFACT_ROOT'])/'REPAIRED_HOLD_HANDOFF.json').write_bytes(encode(report))

    def test_failed_parse_retains_indexed_partial_inputs_and_failure_receipt(self):
        ctl,attempt,args=setup();args['generation_raw']=b'{"seed":false}'
        result=produce(ctl,attempt,**args)
        self.assertEqual(result.status,'INCOMPLETE');self.assertEqual(result.publication,'NONE')
        index=pr.ProducerReferenceIndex.open_readonly(result.root,invocation_ref=result.invocation_ref,call_ref=result.call_ref)
        refs=index.references();self.assertIn(result.failure_reference,refs)
        self.assertTrue(any(ref.snapshot_ref.startswith('raw-generation-transport:') for ref in refs))
        self.assertEqual(len(refs),len(list(index.store._directory.glob('*.bin'))))

    def test_failure_after_publication_still_counts_published(self):
        ctl,attempt,args=setup()
        from wss_bridge import producer
        actual=producer._sign
        def fail(policy,value,issuer,*,proof):
            if proof and 'release_boundary' in value:raise OSError('injected after publication')
            return actual(policy,value,issuer,proof=proof)
        with patch.object(producer,'_sign',side_effect=fail):result=produce(ctl,attempt,**args)
        self.assertEqual((result.status,result.publication),('INCOMPLETE','PUBLISHED'))
        self.assertEqual(ctl.view()['counts']['publications'],1)
        index=pr.ProducerReferenceIndex.open_readonly(result.root,invocation_ref=result.invocation_ref,call_ref=result.call_ref)
        self.assertIn(result.failure_reference,index.references())

    def test_index_append_failure_leaves_real_orphan_and_stops_producer(self):
        ctl,attempt,args=setup();actual=AppendOnlyLedger.append
        def fail(ledger,record):
            if record.payload.get('format')==pr.FORMAT:raise OSError('index unavailable')
            return actual(ledger,record)
        with patch.object(AppendOnlyLedger,'append',new=fail):result=produce(ctl,attempt,**args)
        self.assertEqual((result.status,result.publication),('INCOMPLETE','NONE'))
        self.assertFalse((args['root']/'publications/response.txt').exists())
        inventory=r.capture_producer_inventory(result.root,invocation_ref=result.invocation_ref,call_ref=result.call_ref)
        self.assertFalse(inventory.complete);self.assertTrue(any(row['classification']=='ORPHAN' for row in inventory.files))

    def test_index_failure_after_publication_never_becomes_no_exposure(self):
        ctl,attempt,args=setup();actual=AppendOnlyLedger.append
        def fail(ledger,record):
            data=record.payload
            if data.get('format')==pr.FORMAT and data['reference']['snapshot_ref'].startswith('publication-receipt:'):
                raise OSError('index failure after publication')
            return actual(ledger,record)
        with patch.object(AppendOnlyLedger,'append',new=fail):result=produce(ctl,attempt,**args)
        self.assertEqual((result.status,result.publication),('INCOMPLETE','PUBLISHED'))
        self.assertEqual(ctl.view()['counts']['publications'],1)
        self.assertTrue((args['root']/'publications/response.txt').exists())
        inventory=r.capture_producer_inventory(result.root,invocation_ref=result.invocation_ref,call_ref=result.call_ref)
        self.assertFalse(inventory.complete)

    def test_append_after_bytes_error_is_preserved_without_retry(self):
        root,store,index=new_store();actual=index.journal.append;seen=[]
        def fail(record):seen.append(1);actual(record);raise OSError('after durable index bytes')
        with patch.object(index.journal,'append',side_effect=fail),self.assertRaises(OSError):store.put('fixture:uncertain',b'bytes')
        self.assertEqual(seen,[1]);self.assertEqual(len(read_index(root).references()),1)
        with self.assertRaises(pr.ReferenceIndexError):store.put('fixture:no-resume',b'other')
        self.assertEqual(len(list(store._directory.glob('*.bin'))),1)

    def test_original_snapshot_write_failure_is_not_retroactively_indexed(self):
        root,store,index=new_store();actual=SnapshotStore.put
        def fail(handle,name,raw):actual(handle,name,raw);raise OSError('after snapshot bytes')
        with patch.object(SnapshotStore,'put',new=fail),self.assertRaises(OSError):store.put('fixture:partial',b'partial')
        self.assertEqual(index.references(),())
        inventory=r.capture_producer_inventory(root,invocation_ref='fixture:invocation',call_ref='fixture:call')
        self.assertFalse(inventory.complete);self.assertEqual(inventory.files[0]['classification'],'ORPHAN')

    def test_missing_legacy_index_is_unavailable_not_empty_or_backfilled(self):
        root=fresh();legacy=SnapshotStore.create(root/'snapshots','fixture:legacy');ref=legacy.put('fixture:old',b'old bytes')
        before=legacy.get(ref)
        with self.assertRaises(LedgerError):r.capture_producer_inventory(root,invocation_ref='fixture:old',call_ref='fixture:old-call')
        candidate=pr.IndexedSnapshotStore.open_existing(root/'snapshots','fixture:legacy')
        with self.assertRaises(pr.ReferenceIndexError):pr.ProducerReferenceIndex.create(root/'reference-index',candidate,call_ref='fixture:old-call',invocation_ref='fixture:old')
        self.assertEqual(legacy.get(ref),before);self.assertFalse((root/'reference-index').exists())

    def test_call_and_invocation_owner_are_required_and_exact(self):
        root,store,index=new_store();store.put('fixture:one',b'one')
        for change in [{'call_ref':'fixture:wrong'},{'invocation_ref':'fixture:wrong'}]:
            with self.subTest(change=change),self.assertRaises(pr.ReferenceIndexError):read_index(root,**change)
        with self.assertRaises(TypeError):pr.ProducerReferenceIndex.open_readonly(root,invocation_ref='fixture:invocation')
        with self.assertRaises(TypeError):r.capture_producer_inventory(root,invocation_ref='fixture:invocation')

    def test_readonly_index_cannot_append_or_resume_writes(self):
        root,store,index=new_store();ref=store.put('fixture:one',b'one');reader=read_index(root)
        with self.assertRaises(pr.ReferenceIndexError):reader._record(ref)
        self.assertEqual(reader.references(),(ref,))

    def test_duplicate_and_foreign_references_are_rejected(self):
        for mode in ['duplicate','foreign']:
            with self.subTest(mode=mode):
                root,store,index=new_store();ref=store.put('fixture:one',b'one')
                bad=ref if mode=='duplicate' else SnapshotReference('fixture:foreign','fixture:one',ref.sha256,ref.byte_length)
                with self.assertRaises(pr.ReferenceIndexError):index._record(bad)
                self.assertEqual(read_index(root).references(),(ref,))

    def test_same_snapshot_name_cannot_overwrite_or_duplicate_index(self):
        root,store,index=new_store();ref=store.put('fixture:same',b'one')
        with self.assertRaises(LedgerError):store.put('fixture:same',b'one')
        self.assertEqual(read_index(root).references(),(ref,));self.assertEqual(store.get(ref),b'one')

    def test_payload_pointer_cannot_register_unindexed_file(self):
        root,store,index=new_store()
        unindexed=SnapshotStore.put(store,'fixture:out-of-band',b'unreferenced bytes')
        pointer=store.put('fixture:pointer-shaped-response',encode(unindexed.to_mapping()))
        self.assertEqual(index.references(),(pointer,))
        inv=r.capture_producer_inventory(root,invocation_ref='fixture:invocation',call_ref='fixture:call')
        self.assertFalse(inv.complete);self.assertEqual(sum(row['classification']=='ORPHAN' for row in inv.files),1)

    def test_corrupted_or_truncated_journal_fails_readonly(self):
        for mode in ('corrupt','truncated'):
            with self.subTest(mode=mode):
                root,store,index=new_store();store.put('fixture:one',b'one')
                path=root/'reference-index/journal/entries.jsonl';raw=path.read_bytes()
                path.write_bytes(raw[:-1] if mode=='truncated' else raw.replace(b'RECORDED',b'CHANGED!'))
                with self.assertRaises((LedgerError,pr.ReferenceIndexError)):read_index(root)
                self.assertTrue(path.exists())

    def test_record_schema_and_duplicate_payload_refs_are_not_deduplicated(self):
        for mode in ('unknown-field','duplicate'):
            with self.subTest(mode=mode):
                root,store,index=new_store();ref=store.put('fixture:one',b'one');token='fixture:extra-record'
                data={'audit_ref':token,'status':'RECORDED','format':pr.FORMAT,'call_ref':index.call_ref,'invocation_ref':index.invocation_ref,'reference':ref.to_mapping()}
                if mode=='unknown-field':data['unapproved']='payload'
                index.journal.append(LedgerRecord(token,RecordKind.AUDIT_REFERENCE,token,data))
                with self.assertRaises(pr.ReferenceIndexError):read_index(root)

    def test_metadata_store_scope_and_root_layout_are_checked(self):
        root,store,index=new_store();store.put('fixture:one',b'one')
        meta=root/'reference-index/index.meta.json';data=json.loads(meta.read_bytes());data['store_ref']='fixture:wrong'
        meta.write_bytes(encode(data))
        with self.assertRaises((LedgerError,ContractError)):read_index(root)
        other=fresh();new=pr.IndexedSnapshotStore.create(other/'snapshots','fixture:new')
        with self.assertRaises(pr.ReferenceIndexError):pr.ProducerReferenceIndex.create(other/'wrong-directory',new,call_ref='fixture:c',invocation_ref='fixture:i')

    def test_referenced_bytes_corruption_never_passes_as_complete(self):
        root,store,index=new_store();ref=store.put('fixture:one',b'one')
        store._path(ref.snapshot_ref).write_bytes(b'changed')
        with self.assertRaises(LedgerError):read_index(root)
        with self.assertRaises(LedgerError):r.capture_producer_inventory(root,invocation_ref='fixture:invocation',call_ref='fixture:call')

    def test_nonregular_metadata_snapshot_and_index_root_fail_closed(self):
        for mode in ('metadata-link','snapshot-fifo','snapshot-hardlink','index-root-link'):
            with self.subTest(mode=mode):
                root,store,index=new_store();ref=store.put('fixture:one',b'one')
                if mode=='metadata-link':
                    path=root/'reference-index/index.meta.json';path.rename(root/'retained.meta');path.symlink_to(root/'retained.meta')
                elif mode=='snapshot-fifo':
                    path=store._path(ref.snapshot_ref);path.rename(root/'retained.bin');os.mkfifo(path)
                elif mode=='snapshot-hardlink':os.link(store._path(ref.snapshot_ref),root/'retained.bin')
                else:
                    (root/'reference-index').rename(root/'retained-index');(root/'reference-index').symlink_to(root/'retained-index',target_is_directory=True)
                with self.assertRaises((LedgerError,ContractError,OSError)):read_index(root)

    def test_index_capacity_refusal_preserves_unindexed_bytes(self):
        for setting,value in [('MAX_REFERENCES',1),('MAX_TOTAL_BYTES',5)]:
            with self.subTest(setting=setting):
                root,store,index=new_store();first=store.put('fixture:first',b'one')
                with patch.object(pr,setting,value),self.assertRaises(pr.ReferenceIndexError):store.put('fixture:second',b'two')
                self.assertEqual(read_index(root).references(),(first,))
                inv=r.capture_producer_inventory(root,invocation_ref='fixture:invocation',call_ref='fixture:call')
                self.assertFalse(inv.complete);self.assertEqual(len(inv.files),2)

    def test_index_does_not_serialize_secret_keys_or_payloads(self):
        ctl,attempt,args=setup();result=produce(ctl,attempt,**args)
        self.assertEqual(result.status,'COMPLETE')
        for file in (Path(result.root)/'reference-index').rglob('*'):
            if file.is_file():
                raw=file.read_bytes()
                for key in KEYS.values():self.assertNotIn(key,raw)
                self.assertNotIn(args['prompt_raw'],raw)
        candidate=r.reader_candidate(produced_flow()[2]);self.assertNotIn(b'input_ref',encode(candidate))
        self.assertEqual(len(candidate['four_D2_counterexamples']),4)

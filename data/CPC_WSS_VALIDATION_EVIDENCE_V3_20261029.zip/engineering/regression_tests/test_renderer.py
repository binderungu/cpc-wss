from dataclasses import FrozenInstanceError, replace
import itertools
import json
import os
from pathlib import Path
import unittest

from wss_bridge.primitives import ContractError, plain_json
from wss_bridge.renderer import CatalogSnapshot, Generation, ResolutionBinding, RendererError, render
from wp04_fixtures import CONFIGS, RESOURCES, catalog_dict, digest, encode, independent_expected, inputs, prompt_dict


class RendererTests(unittest.TestCase):
    def rejected(self,call,code=None):
        with self.assertRaises(ContractError) as caught:call()
        if code:self.assertEqual(caught.exception.code,code)

    def test_ten_bundles_reconstruct_from_saved_actual_inputs(self):
        root=Path(os.environ['WSS_TEST_ARTIFACT_ROOT'])/'wp04-ten-bundles'
        root.mkdir()
        rows=[]
        for condition,config in itertools.product(RESOURCES,CONFIGS):
            with self.subTest(condition=condition,config=config):
                p,g,c,b=inputs(condition,config);r=render(p,g,c,b)
                folder=root/(condition+'-'+config);folder.mkdir()
                for name,raw in [('prompt.json',p),('generation.json',g.canonical_bytes),
                                 ('catalog.json',c.raw_bytes),('body.txt',r.body)]:
                    (folder/name).write_bytes(raw)
                (folder/'trace.json').write_bytes(encode(plain_json(r.trace)))
                body=independent_expected((folder/'prompt.json').read_bytes(),
                    (folder/'generation.json').read_bytes(),(folder/'catalog.json').read_bytes())
                self.assertEqual((folder/'body.txt').read_bytes(),body)
                self.assertEqual(r.trace['body_digest'],digest(body))
                self.assertEqual(r.trace['body_codepoints'],len(body.decode()))
                self.assertEqual(r.trace['body_byte_length'],len(body))
                self.assertIn(json.loads(p)['task_span'].encode(),body)
                self.assertLessEqual(len(body.decode()),g.max_output_chars)
                self.assertIs(r.prompt_bytes,p);self.assertIs(r.generation,g)
                self.assertIs(r.catalog,c);self.assertIs(r.binding,b)
                self.assertEqual(r.trace['status'],'BODY_PREPARED_NOT_PUBLISHED')
                self.assertFalse(r.trace['independent_observer_or_actual_use_proof'])
                rows.append({'condition':condition,'config':config,'body_sha256':digest(body),
                    'codepoints':len(body.decode()),'bytes':len(body),'reconstruction':'MATCH',
                    'trace':plain_json(r.trace)})
        (root/'RECONSTRUCTION.json').write_bytes(encode({'evidence_class':'SYNTHETIC_MECHANICAL_QA',
            'pedagogical_approval':False,'cases':rows}))

    def test_four_field_witnesses_each_condition(self):
        for condition in RESOURCES:
            with self.subTest(condition=condition):
                results={name:render(*inputs(condition,name)) for name in CONFIGS}
                base=results['G_BASE'];style=results['G_STYLE'];cap=results['G_CAP']
                rationale=results['G_RATIONALE'];seed=results['G_SEED']
                self.assertEqual(base.trace['selected_slots'],('C','R','E'))
                self.assertEqual(style.trace['selected_slots'],('C','R'))
                self.assertEqual(cap.trace['selected_slots'],('C','R'))
                self.assertEqual(rationale.trace['selected_slots'],('C','E'))
                self.assertEqual(cap.body,style.body)
                self.assertEqual(cap.trace['elaboration_decision'],'elaboration_omitted_budget')
                self.assertEqual(style.trace['elaboration_decision'],'elaboration_not_requested_style')
                self.assertTrue(base.body.startswith(cap.body+b'\n\n'))
                self.assertEqual(seed.trace['variant'],'B')
                for changed in [style,cap,rationale,seed]:self.assertNotEqual(base.body,changed.body)
                self.assertNotEqual(base.body.split(b'\n\n')[0],seed.body.split(b'\n\n')[0])

    def test_all_joint_tuples_only_five_supported(self):
        wanted={tuple(row.values()) for row in CONFIGS.values()}
        for values in itertools.product(['compact','expanded'],[640,1024],[False,True],[0,1]):
            with self.subTest(values=values):
                if values in wanted:self.assertIn(Generation(*values).config_id,CONFIGS)
                else:self.rejected(lambda:Generation(*values),'GENERATION_UNSUPPORTED_JOINT_TUPLE')

    def test_strict_generation_scalar_types(self):
        for field,bads in {'response_style':[True,0,None,[],{},'EXPANDED'],
            'max_output_chars':[True,1024.0,'1024',None,0,-1,1025],
            'include_rationale':[1,0,'true',None,[]],
            'seed':[True,False,0.0,'0',None,2,-1]}.items():
            for bad in bads:
                with self.subTest(field=field,bad=bad):
                    row=dict(CONFIGS['G_BASE']);row[field]=bad
                    self.rejected(lambda:Generation.from_mapping(row))

    def test_closed_generation_schema_and_transport(self):
        for field in CONFIGS['G_BASE']:
            row=dict(CONFIGS['G_BASE']);del row[field]
            self.rejected(lambda:Generation.from_mapping(row))
        row={**CONFIGS['G_BASE'],'temperature':0};self.rejected(lambda:Generation.from_mapping(row))
        for raw in [b'[]',b'null',b'{"seed":0,"seed":1}',b'\xff',b'{}',b' '*1048577,
                    b'{"seed":NaN}',b'{"seed":0.0}',b'{"seed":"\\ud800"}']:
            with self.subTest(raw=raw[:60]):self.rejected(lambda:Generation.from_bytes(raw))

    def test_generation_transport_whitespace_same_consumed_object(self):
        row=dict(reversed(list(CONFIGS['G_BASE'].items())))
        a=Generation.from_bytes(json.dumps(row,indent=4).encode());b=Generation.from_mapping(row)
        self.assertEqual(a,b);self.assertEqual(a.canonical_bytes,b.canonical_bytes)
        p,_,c,r=inputs();self.assertEqual(render(p,a,c,r).body,render(p,b,c,r).body)

    def test_prompt_closed_ten_string_fields(self):
        p,g,c,b=inputs();base=json.loads(p)
        for name in base:
            for bad in [None,False,0,[],{},'', '\ud800']:
                with self.subTest(name=name,bad=repr(bad)):
                    row={**base,name:bad}
                    # Malformed UTF8 cannot be encoded by the fixture writer.
                    raw=json.dumps(row,ensure_ascii=True,sort_keys=True,separators=(',',':')).encode()
                    self.rejected(lambda:render(raw,g,c,replace(b,prompt_digest=digest(raw))))
            row=base.copy();del row[name]
            self.rejected(lambda:render(encode(row),g,c,b))
        self.rejected(lambda:render(encode({**base,'attempt_ref':'forbidden'}),g,c,b))

    def test_prompt_exact_canonical_immutable_utf8_bytes(self):
        p,g,c,b=inputs()
        for raw in [p+b'\n',json.dumps(json.loads(p),ensure_ascii=True).encode(),
                    b'\xef\xbb\xbf'+p,b'\xff',b'{"a":1,"a":1}',b'null',bytearray(p),p.decode(),b'',b' '*1048577]:
            with self.subTest(kind=type(raw).__name__,prefix=str(raw)[:45]):
                self.rejected(lambda:render(raw,g,c,b))

    def test_prompt_digest_mismatch_has_no_fallback(self):
        p,g,c,b=inputs();row=json.loads(p);row['help_request']='changed request'
        self.rejected(lambda:render(encode(row),g,c,b),'PROMPT_NOT_REGISTERED')

    def test_each_task_source_field_checked_even_if_digest_aligned(self):
        p,g,c,b=inputs();base=json.loads(p)
        for name in ['task_id','task_version','task_text','task_span','source_selection_ref','source_excerpt','help_request','catalog_version']:
            with self.subTest(name=name):
                changed=encode({**base,name:'different'})
                self.rejected(lambda:render(changed,g,c,replace(b,prompt_digest=digest(changed))),
                              'PROMPT_CATALOG_TASK_SOURCE_MISMATCH')

    def test_prompt_format_and_resolution_fields(self):
        p,g,c,b=inputs()
        wrong=encode({**json.loads(p),'prompt_format':'unknown'})
        self.rejected(lambda:render(wrong,g,c,replace(b,prompt_digest=digest(wrong))),'PROMPT_FORMAT')
        for name in ['task_id','task_version','task_span']:
            with self.subTest(name=name):
                self.rejected(lambda:render(p,g,c,replace(b,**{name:'different'})),'PROMPT_RESOLUTION_MISMATCH')

    def test_condition_resource_cannot_switch(self):
        p,g,c,b=inputs();a,_,_,answer=inputs('answer')
        self.rejected(lambda:render(a,g,c,replace(b,prompt_digest=digest(a))),'PROMPT_RESOLUTION_MISMATCH')
        self.rejected(lambda:replace(b,condition='answer'),'RESOLUTION_RESOURCE_CONDITION_MISMATCH')
        self.rejected(lambda:replace(b,logical_resource_id='unmapped'),'RESOLUTION_RESOURCE_CONDITION_MISMATCH')
        self.assertNotEqual(render(p,g,c,b).body,render(a,g,c,answer).body)

    def test_catalog_generation_bundle_digests_and_config_binding(self):
        p,g,c,b=inputs()
        for field,code in [('catalog_digest','CATALOG_NOT_BOUND'),('generation_digest','GENERATION_NOT_REGISTERED')]:
            self.rejected(lambda:render(p,g,c,replace(b,**{field:'sha256:'+'0'*64})),code)
        self.rejected(lambda:render(p,g,c,replace(b,config_id='G_SEED')),'GENERATION_NOT_REGISTERED')
        other=Generation.from_mapping(CONFIGS['G_SEED'])
        self.rejected(lambda:render(p,other,c,b),'GENERATION_NOT_REGISTERED')

    def test_pending_content_refs_fail_before_body(self):
        p,g,c,b=inputs()
        for field in ['content_review_ref','internal_rights_ref']:
            with self.subTest(field=field):
                self.rejected(lambda:render(p,g,c,replace(b,**{field:None})),'CONTENT_DECLARATIONS_PENDING')

    def test_catalog_length_exact_endpoints_after_binding(self):
        for lengths in [(280,160,260),(360,200,300)]:
            with self.subTest(lengths=lengths):
                p,g,c,b=inputs(data=catalog_dict(lengths));r=render(p,g,c,b)
                self.assertEqual(list(r.trace['slot_codepoints'].values()),list(lengths))
                self.assertEqual(r.trace['body_codepoints'],sum(lengths)+4)
                self.assertLessEqual(r.trace['mandatory_codepoints'],562)
                self.assertLessEqual(r.trace['body_codepoints'],864)
                self.assertGreaterEqual(r.trace['body_codepoints'],704)
                # 640 keeps all mandatory C/R bytes; never truncates.
                p,g,c,b=inputs(config='G_CAP',data=catalog_dict(lengths));r=render(p,g,c,b)
                self.assertEqual(r.trace['body_codepoints'],sum(lengths[:2])+2)
                self.assertEqual(r.trace['elaboration_decision'],'elaboration_omitted_budget')

    def test_reject_any_invalid_slot_including_unselected(self):
        for condition,variant,slot in itertools.product(RESOURCES,['A','B'],['C','R','E']):
            for n in {'C':[279,361],'R':[159,201],'E':[259,301]}[slot]:
                with self.subTest(condition=condition,variant=variant,slot=slot,n=n):
                    d=catalog_dict();text=d['conditions'][condition]['variants'][variant][slot]
                    bound=text.replace('{{task_span}}',d['task']['task_span'])
                    # Literalize existing span, vary only code-point length.
                    d['conditions'][condition]['variants'][variant][slot]=bound[:n]+'x'*max(0,n-len(bound))
                    self.rejected(lambda:CatalogSnapshot(encode(d)),'CATALOG_POST_BINDING_SLOT_LENGTH')

    def test_binding_length_uses_unicode_codepoints_not_bytes_or_utf16(self):
        d=catalog_dict();d['task']['task_span']='😀'*30+'e\u0301'
        # Existing templates padded for old span must be adjusted after substitution.
        for e in d['conditions'].values():
            for v in e['variants'].values():
                text=v['C'];post=text.replace('{{task_span}}',d['task']['task_span'])
                v['C']=text[:-(len(post)-320)]
        p,g,c,b=inputs(data=d);r=render(p,g,c,b)
        self.assertEqual(r.trace['slot_codepoints']['C'],320)
        self.assertGreater(len(r.body),r.trace['body_codepoints'])
        self.assertIn(d['task']['task_span'].encode(),r.body)
        self.assertEqual(r.body,independent_expected(p,g.canonical_bytes,c.raw_bytes))

    def test_post_substitution_overflow_blocks_instead_of_truncate(self):
        d=catalog_dict();d['task']['task_span']='😀'*400
        self.rejected(lambda:CatalogSnapshot(encode(d)),'CATALOG_POST_BINDING_SLOT_LENGTH')

    def test_repeated_tokens_have_projected_bound_before_expansion(self):
        # Raw input remains <1MiB. Test code never constructs the expanded
        # string. Correct code rejects its projected 2 billion codepoints
        # arithmetically, before replace can allocate that output.
        d=catalog_dict();d['task']['task_span']='z'*200000
        d['conditions']['hint']['variants']['A']['C']='{{task_span}}'*10000
        raw=encode(d);self.assertLess(len(raw),1048576)
        self.rejected(lambda:CatalogSnapshot(raw),'CATALOG_POST_BINDING_SLOT_LENGTH')

    def test_multiple_tokens_replace_exactly_after_bound(self):
        d=catalog_dict();d['task']['task_span']='😀e\u0301'
        for entry in d['conditions'].values():
            for variant,slots in entry['variants'].items():
                lead=variant+':{{task_span}}|{{task_span}}|'
                slots['C']=lead+'x'*(320-len(lead.replace('{{task_span}}',d['task']['task_span'])))
        p,g,c,b=inputs(data=d);r=render(p,g,c,b)
        self.assertEqual(r.trace['slot_codepoints']['C'],320)
        self.assertEqual(r.body.count(d['task']['task_span'].encode()),2)
        self.assertEqual(r.body,independent_expected(p,g.canonical_bytes,c.raw_bytes))

    def test_missing_task_span_and_identical_bound_seed_cores_rejected(self):
        d=catalog_dict();d['conditions']['hint']['variants']['B']['C']='x'*320
        self.rejected(lambda:CatalogSnapshot(encode(d)),'CATALOG_CORE_TASK_SPAN_TOKEN_REQUIRED')
        d=catalog_dict();v=d['conditions']['hint']['variants']['A']
        v['C']=v['C'].replace('{{task_span}}',d['task']['task_span'])
        self.rejected(lambda:CatalogSnapshot(encode(d)),'CATALOG_CORE_TASK_SPAN_TOKEN_REQUIRED')
        d=catalog_dict();v=d['conditions']['answer']['variants'];v['B']['C']=v['A']['C']
        self.rejected(lambda:CatalogSnapshot(encode(d)),'CATALOG_SEED_CORES_IDENTICAL')
        d=catalog_dict();d['task']['task_span']='{{task_span}}'
        self.rejected(lambda:CatalogSnapshot(encode(d)),'TASK_SPAN_RECURSIVE_TOKEN')

    def test_catalog_closed_shape_and_binding(self):
        mutations=[lambda d:d.update(extra=1),lambda d:d.pop('task'),
            lambda d:d.update(catalog_format='unknown'),lambda d:d.update(evidence_class='APPROVED'),
            lambda d:d['task'].update(extra='x'),lambda d:d['task'].update(help_request=''),
            lambda d:d['conditions'].pop('answer'),lambda d:d['conditions'].update(other={}),
            lambda d:d['conditions']['hint'].update(logical_resource_id='WSS-U01-ANSWER'),
            lambda d:d['conditions']['hint']['variants'].pop('B'),
            lambda d:d['conditions']['hint']['variants']['A'].update(extra='x'),
            lambda d:d['conditions']['hint']['variants']['A'].update(R=False)]
        for index,mut in enumerate(mutations):
            with self.subTest(index=index):
                d=catalog_dict();mut(d);self.rejected(lambda:CatalogSnapshot(encode(d)))

    def test_catalog_canonical_and_immutable_bytes_required(self):
        d=catalog_dict();raw=encode(d)
        for bad in [raw+b'\n',bytearray(raw),raw.decode(),b'\xff',b'{}',b' '*1048577]:
            with self.subTest(kind=type(bad).__name__):self.rejected(lambda:CatalogSnapshot(bad))

    def test_source_mutation_after_normalization_does_not_change_output(self):
        d=catalog_dict();row=dict(CONFIGS['G_BASE']);g=Generation.from_mapping(row)
        p,_,c,b=inputs(data=d);r=render(p,g,c,b)
        d['conditions']['hint']['variants']['A']['C']='changed';row['seed']=1
        self.assertEqual(render(p,g,c,b).body,r.body)
        with self.assertRaises(TypeError):c.task['task_span']='changed'
        with self.assertRaises(TypeError):c.conditions['hint']['variants']['A']['C']='changed'
        with self.assertRaises(FrozenInstanceError):g.seed=1
        with self.assertRaises(FrozenInstanceError):b.bundle_ref='changed'
        with self.assertRaises(TypeError):r.trace['selected_slots'][0]='changed'

    def test_mutable_or_subclass_inputs_rejected_at_consume(self):
        p,g,c,b=inputs()
        class DerivedGeneration(Generation):pass
        class DerivedCatalog(CatalogSnapshot):pass
        class DerivedBinding(ResolutionBinding):pass
        for badargs in [(p,g.to_mapping(),c,b),(p,g,object(),b),(p,g,c,{}),
                        (p,DerivedGeneration(**g.to_mapping()),c,b),
                        (p,g,DerivedCatalog(c.raw_bytes),b),
                        (p,g,c,DerivedBinding(**b.__dict__))]:
            self.rejected(lambda:render(*badargs),'IMMUTABLE_RENDERER_INPUTS_REQUIRED')

    def test_binding_identifiers_types_and_digests_fail_closed(self):
        *_,b=inputs()
        for name in ['resolution_ref','context_ref','task_id','task_version','logical_resource_id','bundle_ref',
                     'content_review_ref','internal_rights_ref']:
            for bad in ['',True,'\nnot-identifier','x'*257]:
                with self.subTest(name=name,bad=str(bad)[:20]):self.rejected(lambda:replace(b,**{name:bad}))
        for name in ['catalog_digest','prompt_digest','generation_digest']:
            for bad in ['',True,'sha256:'+'A'*64,'bad']:
                self.rejected(lambda:replace(b,**{name:bad}))
        for name in ['condition','config_id']:
            for bad in [True,None,[],{},'unknown']:
                with self.subTest(name=name,bad=bad):self.rejected(lambda:replace(b,**{name:bad}))

    def test_literal_source_text_is_never_executed_or_expanded(self):
        d=catalog_dict();d['task']['task_span']='${HOME}; {{literal}}'
        # Exact same length as original isn't assumed; reset fixture lengths.
        for e in d['conditions'].values():
            for v in e['variants'].values():
                lead=v['C'].rstrip('x');n=len(lead.replace('{{task_span}}',d['task']['task_span']))
                v['C']=lead+'x'*(320-n)
        p,g,c,b=inputs(data=d);r=render(p,g,c,b)
        self.assertIn(d['task']['task_span'].encode(),r.body)
        self.assertNotIn(b'{{task_span}}',r.body)


if __name__=='__main__':unittest.main()

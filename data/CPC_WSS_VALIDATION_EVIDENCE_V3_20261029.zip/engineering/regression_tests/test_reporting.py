from dataclasses import replace
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from wss_bridge import reporting as r
from wss_bridge import baselines as b
from wss_bridge.cpc_adapter import CPCAdapter
from wss_bridge.ledger import SnapshotStore,SnapshotReference,LedgerError
from wss_bridge.primitives import ContractError,plain_json
from wp07_fixtures import flow,followup,encode,external_mapping
from test_baselines import common


def fresh(name):return Path(tempfile.mkdtemp(prefix=name,dir=os.environ['WSS_TEST_ARTIFACT_ROOT']))


def store_evidence(f,c,extra_adapters=None):
    stores=[('CONTROLLER',f['controller'].store),('OUTCOME',f['store'].snapshots),('ADAPTER',f['adapter'].store)]
    if extra_adapters:stores.extend(('ADAPTER',a.store) for a in extra_adapters)
    path=f['root']/'producer/snapshots';meta=json.loads((path/'snapshot-store.meta.json').read_bytes())
    stores.append(('PRODUCER',SnapshotStore.open_existing(path,meta['store_ref'])))
    references={store._store_ref:{} for _,store in stores}
    def collect(value):
        # QA helper on newly generated local metadata only, not production
        # capture logic. Raw response bytes are never interpreted here.
        if isinstance(value,dict):
            if set(value)=={'store_ref','snapshot_ref','sha256','byte_length'}:
                if value['store_ref'] in references:references[value['store_ref']][value['snapshot_ref']]=SnapshotReference.from_mapping(value)
            else:
                for item in value.values():collect(item)
        elif isinstance(value,list):
            for item in value:collect(item)
    collect(plain_json(f['store'].view()))
    for adapter in [f['adapter'],*(extra_adapters or [])]:
        for record in adapter.journal.read_records():collect(plain_json(record.payload))
    for ref,raw in c.native['retained_local_snapshot_hex'].items():
        content=bytes.fromhex(raw)
        references[f['controller'].store._store_ref][ref]=SnapshotReference(f['controller'].store._store_ref,ref,'sha256:'+hashlib.sha256(content).hexdigest(),len(content))
    # Typed producer ledger/saved consume/proof metadata records contain the
    # actual returned refs for raw inputs/body/captures. Fixture content is
    # self-authored and this read does not supply native/runtime authority.
    for file in (f['root']/'producer').rglob('*'):
        if file.is_file() and file.suffix in {'.bin','.json','.jsonl'}:
            try:
                if file.suffix=='.jsonl':
                    for line in file.read_bytes().splitlines():collect(json.loads(line))
                else:collect(json.loads(file.read_bytes()))
            except (ValueError,UnicodeError):pass
    inventory=tuple(r.capture_inventory(store,role,tuple(references[store._store_ref].values())) for role,store in stores)
    required={role:[store._store_ref for item_role,store in stores if item_role==role] for role in r._ROLES}
    return inventory,required


def report(f,*,c=None,comparison=None,with_inventory=True,extra_adapters=None):
    c=common(f) if c is None else c
    comparison=b.run_comparison(c,cohort_ref='fixture:wp09-cohort',snapshot_ref='fixture:wp09-snapshot') if comparison is None else comparison
    inventories,required=store_evidence(f,c,extra_adapters) if with_inventory else ((),None)
    return r.build_handoff(c,comparison,f['store'].view(),report_ref='fixture:wp09-report',inventories=inventories,
        required_stores=required,adapter_views={a.run_ref:a.view() for a in [f['adapter'],*(extra_adapters or [])]}),c,comparison


class ReportingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.f=flow();cls.report,cls.common,cls.comparison=report(cls.f)

    def test_actual_positive_trace_and_independent_allgrain_recount(self):
        report=self.report;native=report['ledgers']['native']
        expected={key:len(native[key]) for key in ('opportunities','operations','ingestions','occurrences','attempts','invocations','publications','followups','analyses')}
        self.assertEqual(report['counts']['native'],expected)
        self.assertEqual(expected['attempts'],1);self.assertEqual(expected['occurrences'],2)
        self.assertEqual(expected['invocations'],1);self.assertEqual(expected['publications'],1)
        self.assertEqual(report['examples']['positive']['status'],'AVAILABLE')
        trace=report['source_map'][report['examples']['positive']['source_map_ordinal']]
        self.assertEqual(trace['linkage'],'LINKED_SUPPLIED_LOCAL_EVIDENCE')
        self.assertEqual(trace['outcome']['row']['value'],2)
        self.assertEqual(trace['native']['selected_followup']['operation_ref'],trace['outcome']['row']['lineage']['operation_ref'])
        self.assertEqual(len(trace['native']['all_attempt_publications']),1)
        self.assertEqual(trace['external_ordinals'],(0,))
        for arm in report['ledgers']['comparison']['arms'].values():
            counts=arm['join']['counts']
            self.assertEqual(counts['received_core'],sum(counts['core_buckets'].values())+counts['unresolved_core'])
            self.assertEqual(counts['core_buckets']['ADMIT'],sum(counts['admitted_mapping'].values()))
            self.assertEqual(counts['admitted_mapping']['ELIGIBLE'],sum(counts['eligible_terminals'].values()))
        (Path(os.environ['WSS_TEST_ARTIFACT_ROOT'])/'WP09_POSITIVE_HANDOFF.json').write_bytes(encode(report))
        (Path(os.environ['WSS_TEST_ARTIFACT_ROOT'])/'WP09_INDEPENDENT_RECOUNT.json').write_bytes(encode({'native':expected,'three_equations':True,'scientific_or_native_validation':False}))

    def test_actual_reasoned_hold_retains_all_invocations_and_publications(self):
        f=flow(extra='second-publication');result,_,_=report(f)
        self.assertEqual(result['examples']['native_hold']['status'],'AVAILABLE')
        trace=result['source_map'][result['examples']['native_hold']['source_map_ordinal']]
        self.assertEqual(trace['core_row']['core_disposition'],'ADMIT')
        self.assertIn('HOLD_MULTI_INVOCATION',trace['core_row']['reason_flags'])
        self.assertEqual(len(trace['native']['all_attempt_invocations']),2)
        self.assertEqual(len(trace['native']['all_attempt_publications']),2)
        self.assertEqual(result['examples']['positive']['status'],'NOT_AVAILABLE')
        (Path(os.environ['WSS_TEST_ARTIFACT_ROOT'])/'WP09_REASONED_HOLD_HANDOFF.json').write_bytes(encode(result))

    def test_missing_examples_are_not_fabricated(self):
        self.assertEqual(self.report['examples']['native_hold'],{'status':'NOT_AVAILABLE','source_map_ordinal':None})

    def test_missing_inventory_is_unknown_not_zero(self):
        result,_,_=report(self.f,c=self.common,comparison=self.comparison,with_inventory=False)
        self.assertEqual(result['status'],'DIAGNOSTIC_INCOMPLETE')
        self.assertFalse(result['inventory']['scope_declared'])
        self.assertFalse(result['inventory']['complete_for_declared_roots'])
        self.assertTrue(result['inventory']['reference_coverage_gaps'])
        self.assertEqual(result['inventory']['stores'],())

    def test_native_count_join_count_and_comparison_tamper_fail_closed(self):
        native=plain_json(self.common.native);native['view']['counts']['attempts']=99
        with self.assertRaises(ContractError):report(self.f,c=replace(self.common,native=native),comparison=self.comparison)
        for field in ['counts','core-row','common','B1','comparison','claim']:
            altered=plain_json(self.comparison)
            if field=='counts':altered['arms']['CPC_REFERENCE']['join']['counts']['received_core']=99
            elif field=='core-row':altered['arms']['B2']['join']['core_ledger'][0]['value']=4
            elif field=='common':altered['arms']['B0']['common_evidence_digest']='wrong'
            elif field=='B1':altered['B1']['abstained']=0
            elif field=='comparison':altered['comparisons']['B2']['status']='MISMATCH_REQUIRES_DIAGNOSIS'
            else:altered['scientific_JLA_sufficiency']='READY'
            with self.subTest(field=field),self.assertRaises(ContractError):
                r.build_handoff(self.common,altered,self.f['store'].view(),report_ref='fixture:tampered')

    def test_outcome_partition_and_output_ref_tamper_fail(self):
        for field in ['counts','output_ref','duplicate']:
            view=plain_json(self.f['store'].view())
            if field=='counts':view['counts']['received_derivations']+=1
            elif field=='output_ref':view['derivations'][0]['outcome_ref']='fixture:wrong'
            else:view['outcomes'].append(view['outcomes'][0])
            with self.subTest(field=field),self.assertRaises(ContractError):r.build_handoff(self.common,self.comparison,view,report_ref='fixture:tampered')

    def test_outcome_lineage_mismatch_is_visible_and_never_positive(self):
        view=plain_json(self.f['store'].view());view['outcomes'][0]['lineage']['value_digest']='sha256:'+'0'*64
        result=r.build_handoff(self.common,self.comparison,view,report_ref='fixture:lineage')
        self.assertIn('JOINED_SOURCE_LINKAGE_INCOMPLETE',result['reason_flags'])
        self.assertEqual(result['examples']['positive']['status'],'NOT_AVAILABLE')
        self.assertEqual(result['source_map'][0]['core_row']['primary_reason'],'JOINED')

    def test_trace_rejects_tampered_source_capture_analysis_and_purpose(self):
        for field in ('source_snapshot','native_occurrence','capture_reference','analysis_reference','purpose'):
            view=plain_json(self.f['store'].view())
            if field=='source_snapshot':view['outcomes'][0]['lineage'][field]['value_id']+=1
            elif field=='native_occurrence':view['outcomes'][0]['lineage'][field]['standard_log_record_id']+=1
            elif field=='capture_reference':view['outcomes'][0]['lineage'][field]['sha256']='sha256:'+'0'*64
            elif field=='analysis_reference':view['derivations'][0][field]['sha256']='sha256:'+'0'*64
            else:view['derivations'][0]['requested_purpose']='fixture:other-purpose'
            with self.subTest(field=field):
                result=r.build_handoff(self.common,self.comparison,view,report_ref='fixture:tampered')
                self.assertEqual(result['examples']['positive']['status'],'NOT_AVAILABLE')
                self.assertEqual(result['source_map'][0]['linkage'],'NOT_AVAILABLE')

    def test_derivation_input_output_crosslinks_are_required(self):
        view=plain_json(self.f['store'].view());view['derivations'][0]['input_snapshots']['recipe']['sha256']='sha256:'+'0'*64
        with self.assertRaises(ContractError):r.build_handoff(self.common,self.comparison,view,report_ref='fixture:tampered')

    def test_unlinked_hold_is_not_advertised_as_worked_example(self):
        f=flow(extra='second-publication');c=common(f)
        comparison=b.run_comparison(c,cohort_ref='fixture:c',snapshot_ref='fixture:s')
        view=plain_json(f['store'].view());view['outcomes'][0]['lineage']['value_digest']='sha256:'+'0'*64
        result=r.build_handoff(c,comparison,view,report_ref='fixture:hold-incomplete')
        self.assertEqual(result['source_map'][0]['primary_reason'],'NATIVE_MAPPING_HOLD')
        self.assertEqual(result['examples']['native_hold']['status'],'NOT_AVAILABLE')

    def test_failed_derivation_and_orphans_are_visible_without_rescore(self):
        f=flow();c=common(f)
        with self.assertRaises(ContractError):f['store'].derive(f['controller'],f['analysis'],f['exposure_raw'],f['recipe'],f['outcome']['composite']['purpose'])
        f['store'].snapshots.put('fixture:orphan-partial',b'partial unreferenced data')
        result,_,_=report(f,c=c)
        self.assertEqual(result['counts']['outcomes']['received_derivations'],2)
        self.assertEqual(result['counts']['outcomes']['failed_derivations'],1)
        self.assertEqual(result['counts']['outcomes']['external_rows'],1)
        self.assertGreaterEqual(result['counts']['outcome_store_orphan_files'],1)
        self.assertIn('DERIVATION_FAILURE_OR_PENDING',result['reason_flags'])
        self.assertIn('ORPHAN_SNAPSHOTS_PRESENT',result['reason_flags'])
        self.assertEqual(result['source_map'][0]['outcome']['row']['value'],2)

    def test_external_orphan_invalid_and_duplicate_ordinals_remain_visible(self):
        row=external_mapping(self.f['outcome']);other=external_mapping(self.f['outcome'],composite={**row['composite'],'outcome_key':'fixture:orphan'},value=True)
        c=replace(self.common,external_rows=(self.f['external'],self.f['external'],other,{'broken':'row'}))
        result,_,_=report(self.f,c=c)
        self.assertEqual(result['source_map'][0]['external_ordinals'],(0,1))
        self.assertEqual(result['source_map'][0]['primary_reason'],'EXTERNAL_COMPOSITE_AMBIGUOUS')
        self.assertEqual(result['counts']['external_orphan_ordinals'],(2,3))
        self.assertEqual(len(result['ledgers']['comparison']['arms']['CPC_REFERENCE']['join']['external_ledger']),4)

    def test_unresolved_comparison_is_diagnostic_not_complete(self):
        with patch.object(b,'_rules_dependency',side_effect=RuntimeError('private-marker')):
            comparison=b.run_comparison(self.common,cohort_ref='fixture:wp09-cohort',snapshot_ref='fixture:wp09-snapshot')
        result,_,_=report(self.f,c=self.common,comparison=comparison)
        self.assertEqual(result['status'],'DIAGNOSTIC_INCOMPLETE')
        self.assertEqual(result['counts']['comparison_per_arm']['B2']['unresolved_core'],1)
        self.assertNotIn(b'private-marker',encode(result))

    def test_separate_adapter_failure_keeps_own_scope_not_added_to_common_N(self):
        root=fresh('wp09-adapter-');adapter=CPCAdapter.create(root/'adapter',self.common.context,'fixture:separate-batch')
        adapter.evaluate({'not':'wire'},input_ref='fixture:misuse')
        result,_,_=report(self.f,c=self.common,comparison=self.comparison,extra_adapters=[adapter])
        self.assertEqual(result['counts']['comparison_per_arm']['CPC_REFERENCE']['received_core'],1)
        batches=result['ledgers']['separate_adapter_batches'];self.assertEqual(len(batches),2)
        self.assertEqual(len(batches[-1]['unresolved']),1)
        self.assertIn('SEPARATE_ADAPTER_INCOMPLETE',result['reason_flags'])
        bad=plain_json(adapter.view());bad['received']=2
        with self.assertRaises(ContractError):r.build_handoff(self.common,self.comparison,self.f['store'].view(),report_ref='fixture:x',adapter_views={'fixture:bad':bad})

    def test_adapter_failure_export_results_and_completeness_tamper_fail(self):
        original=plain_json(self.f['adapter'].view())
        for change in [{'failures':[{'failure_code':'ORPHAN_PARTIAL'}]}, {'export_started':True},
                       {'accounting_complete':False}, {'results':[]}, {'status':'EXPORTED'}]:
            with self.subTest(change=list(change)),self.assertRaises(ContractError):
                r.build_handoff(self.common,self.comparison,self.f['store'].view(),report_ref='fixture:x',adapter_views={'fixture:bad':{**original,**change}})

    def test_source_only_attempt_with_no_core_input_has_no_fake_verdict(self):
        c=replace(self.common,inputs=(),exposures={})
        result,_,_=report(self.f,c=c)
        self.assertEqual(result['counts']['comparison_per_arm']['CPC_REFERENCE']['received_core'],0)
        self.assertEqual(result['counts']['native']['attempts'],1)
        source=result['ledgers']['source_only_attempts'][0]
        self.assertEqual(source['submission_status'],'NOT_SUBMITTED_IN_DECLARED_COHORT')
        self.assertIsNone(source['core_verdict'])
        self.assertEqual(result['examples']['positive']['status'],'NOT_AVAILABLE')

    def test_late_revision_does_not_replace_old_handoff_or_selected_outcome(self):
        f=flow();old,c,_=report(f);before=encode(old)
        followup(f['controller'],f['attempt'],b'explains and checks the rule',log_id=103,watermark=102)
        revised=f['controller'].analysis_snapshot(reason='WP09_LATER_REVISION')
        result,_,_=report({**f,'analysis':revised})
        self.assertEqual(encode(old),before)
        self.assertEqual(result['counts']['native']['followups'],2)
        self.assertEqual(result['counts']['post_close_followup_revisions'],1)
        self.assertEqual(result['source_map'][0]['outcome']['row']['value'],2)
        self.assertEqual(result['source_map'][0]['native']['attempt']['selected_followup'],old['source_map'][0]['native']['attempt']['selected_followup'])

    def test_inventory_orphans_missing_refs_and_nonregular_nodes(self):
        root=fresh('wp09-inventory-');store=SnapshotStore.create(root/'store','fixture:inventory')
        good=store.put('fixture:good',b'known');orphan=store.put('fixture:orphan',b'partial')
        inv=r.capture_inventory(store,'OUTCOME',(good,))
        self.assertTrue(inv.complete);self.assertEqual(sum(f['classification']=='ORPHAN' for f in inv.files),1)
        missing=SnapshotReference(store._store_ref,'fixture:missing','sha256:'+'0'*64,1)
        inv=r.capture_inventory(store,'OUTCOME',(missing,));self.assertFalse(inv.complete)
        self.assertEqual(inv.references[0]['status'],'MISSING_OR_INVALID')
        symlink=store._path('fixture:symlink');symlink.symlink_to(store._path(good.snapshot_ref))
        fifo=store._path('fixture:fifo');os.mkfifo(fifo)
        inv=r.capture_inventory(store,'OUTCOME',())
        self.assertFalse(inv.complete);self.assertEqual({f['kind'] for f in inv.files},{'REGULAR','SYMLINK','FIFO'})
        self.assertTrue(fifo.is_fifo());self.assertTrue(symlink.is_symlink())

    def test_inventory_hardlink_and_reference_corruption_are_not_complete(self):
        root=fresh('wp09-inventory-');store=SnapshotStore.create(root/'store','fixture:inventory')
        ref=store.put('fixture:original',b'known');os.link(store._path(ref.snapshot_ref),store._path('fixture:hardlink'))
        inv=r.capture_inventory(store,'OUTCOME',(ref,));self.assertFalse(inv.complete)
        self.assertEqual(inv.references[0]['status'],'MISSING_OR_INVALID')
        self.assertTrue(all(f['classification']=='UNREADABLE_OR_CHANGED' for f in inv.files))

    def test_inventory_empty_or_wrong_scopes_cannot_cover_source_refs(self):
        inventories=[];required={}
        for role in r._ROLES:
            store=SnapshotStore.create(fresh('wp09-empty-')/'store','fixture:empty-'+role)
            inventories.append(r.capture_inventory(store,role));required[role]=[store._store_ref]
        result=r.build_handoff(self.common,self.comparison,self.f['store'].view(),report_ref='fixture:scope',inventories=tuple(inventories),required_stores=required)
        self.assertFalse(result['inventory']['complete_for_declared_roots']);self.assertTrue(result['inventory']['reference_coverage_gaps'])
        with self.assertRaises(ContractError):r.build_handoff(self.common,self.comparison,self.f['store'].view(),report_ref='fixture:scope',inventories=tuple(inventories)*2,required_stores=required)

    def test_inventory_typed_match_requires_matching_file(self):
        ref=SnapshotReference('fixture:store','fixture:ref','sha256:'+'0'*64,1)
        with self.assertRaises(ContractError):r.StoreInventory('OUTCOME',ref.store_ref,(),({'reference':ref.to_mapping(),'status':'MATCH'},),True)
        with self.assertRaises(ContractError):r.StoreInventory('OUTCOME',ref.store_ref,({'name':'../escape','kind':'REGULAR','classification':'ORPHAN','sha256':ref.sha256,'byte_length':1},),(),True)
        name=hashlib.sha256(ref.snapshot_ref.encode()).hexdigest()+'.bin'
        with self.assertRaises(ContractError):r.StoreInventory('OUTCOME',ref.store_ref,({'name':name,'kind':'REGULAR','classification':'NONREGULAR','sha256':None,'byte_length':None},),(),True)

    def test_adapter_view_rejects_unbounded_rows_before_processing(self):
        bad=plain_json(self.f['adapter'].view());bad['rows']=iter(())
        with self.assertRaises((ContractError,TypeError)):r.build_handoff(self.common,self.comparison,self.f['store'].view(),report_ref='fixture:rows',adapter_views={'fixture:bad':bad})

    def test_reader_candidate_excludes_raw_native_strategy_paths_and_key_material(self):
        restricted=plain_json(self.report);marker='PRIVATE_QA_STRATEGY_RAW_KEY_MARKER'
        restricted['report_ref']=marker;restricted['ledgers']['private_note']=marker
        restricted['source_map'][0]['native']['raw_text']=marker
        candidate=r.reader_candidate(restricted);raw=encode(candidate)+r.render_markdown(restricted,reader=True).encode()
        self.assertNotIn(marker.encode(),raw)
        for forbidden in [b'input_ref',b'native_occurrence',b'key_registry',b'profile_id',b'raw_text',b'outcome_key',b'/Users/',b'lineage_ref']:
            self.assertNotIn(forbidden,raw)
        self.assertEqual(candidate['status'],'CANDIDATE_FOR_REVIEW_NOT_RELEASE_AUTHORIZED')
        self.assertEqual(len(candidate['four_D2_counterexamples']),4)
        self.assertEqual([row['archived_case_id'] for row in candidate['four_D2_counterexamples']],['D3-00014','D3-00029','D3-00044','D3-00059'])

    def test_reader_candidate_rejects_noninteger_counts_and_unknown_state(self):
        for value in ['PRIVATE_MARKER',True,-1,1.0,100001]:
            changed=plain_json(self.report);changed['counts']['native']['attempts']=value
            with self.subTest(value=value),self.assertRaises(ContractError):r.reader_candidate(changed)
        changed=plain_json(self.report);changed['status']='READY_FOR_PUBLICATION'
        with self.assertRaises(ContractError):r.reader_candidate(changed)

    def test_writer_restricted_and_reader_candidate_verify_fixed_files(self):
        root=fresh('wp09-handoff-')
        for mode in ('RESTRICTED','READER_CANDIDATE'):
            with self.subTest(mode=mode):
                target=root/mode;receipt=r.write_handoff(self.report,target,mode=mode)
                self.assertEqual(receipt['status'],'VERIFIED_LOCAL_PAYLOAD_ONLY')
                self.assertEqual(r.verify_handoff(target,mode=mode),receipt)
                self.assertEqual({p.name for p in target.iterdir()},r._FILES[mode]|{'STARTED.json','MANIFEST.json','COMPLETED.json'})
                for key in self.common.context.key_registry.values():
                    for file in target.iterdir():self.assertNotIn(key if type(key) is bytes else key.encode(),file.read_bytes())
        (Path(os.environ['WSS_TEST_ARTIFACT_ROOT'])/'WP09_WRITTEN_HANDOFF_PATHS.json').write_bytes(encode({'restricted':str(root/'RESTRICTED'),'reader_candidate':str(root/'READER_CANDIDATE'),'release_authorized':False}))

    def test_writer_refuses_overwrite_and_traversal(self):
        root=fresh('wp09-exclusive-');target=root/'handoff';r.write_handoff(self.report,target)
        before={p.name:p.read_bytes() for p in target.iterdir()}
        with self.assertRaises((LedgerError,FileExistsError)):r.write_handoff(self.report,target)
        self.assertEqual(before,{p.name:p.read_bytes() for p in target.iterdir()})
        with self.assertRaises(LedgerError):r.write_handoff(self.report,root/'..'/'escape')
        link=root/'link';link.symlink_to(target,target_is_directory=True)
        with self.assertRaises(LedgerError):r.verify_handoff(link)

    def test_partial_write_retains_started_bytes_and_never_verifies_or_retries(self):
        root=fresh('wp09-partial-');target=root/'handoff';actual=r._new_file
        def fail(path,raw):
            actual(path,raw)
            if path.name=='report.json':raise OSError('injected after bytes')
        with patch.object(r,'_new_file',side_effect=fail),self.assertRaises(OSError):r.write_handoff(self.report,target)
        self.assertTrue((target/'STARTED.json').exists());self.assertTrue((target/'report.json').exists())
        self.assertFalse((target/'COMPLETED.json').exists())
        with self.assertRaises(ContractError):r.verify_handoff(target)
        with self.assertRaises((LedgerError,FileExistsError)):r.write_handoff(self.report,target)

    def test_verifier_rejects_corruption_symlink_hardlink_fifo_and_extra_files(self):
        for fault in ('corrupt','symlink','hardlink','fifo','extra','completion'):
            with self.subTest(fault=fault):
                root=fresh('wp09-corrupt-');target=root/'handoff';r.write_handoff(self.report,target,mode='READER_CANDIDATE')
                file=target/'reader_candidate.json'
                if fault=='corrupt':file.write_bytes(b'changed')
                elif fault=='symlink':file.rename(root/'retained');file.symlink_to(root/'retained')
                elif fault=='hardlink':os.link(file,root/'hardlink')
                elif fault=='fifo':file.rename(root/'retained');os.mkfifo(file)
                elif fault=='extra':(target/'unexpected').write_bytes(b'extra')
                else:(target/'COMPLETED.json').write_bytes(b'{}')
                with self.assertRaises((ContractError,LedgerError)):r.verify_handoff(target,mode='READER_CANDIDATE')

    def test_manifest_cannot_select_arbitrary_payload_path_even_with_matching_completion(self):
        root=fresh('wp09-manifest-');target=root/'handoff';r.write_handoff(self.report,target,mode='READER_CANDIDATE')
        manifest=json.loads((target/'MANIFEST.json').read_bytes());manifest['files']={'../outside':'sha256:'+'0'*64}
        raw=encode(manifest);(target/'MANIFEST.json').write_bytes(raw)
        completed=json.loads((target/'COMPLETED.json').read_bytes());completed['manifest_sha256']='sha256:'+hashlib.sha256(raw).hexdigest();(target/'COMPLETED.json').write_bytes(encode(completed))
        with self.assertRaises(ContractError):r.verify_handoff(target,mode='READER_CANDIDATE')

    def test_writer_verifier_checks_permissions_and_reader_allowlist(self):
        root=fresh('wp09-permissions-');target=root/'handoff';r.write_handoff(self.report,target,mode='READER_CANDIDATE')
        file=target/'reader_candidate.json';os.chmod(file,0o644)
        with self.assertRaises(ContractError):r.verify_handoff(target,mode='READER_CANDIDATE')
        os.chmod(file,0o600);os.chmod(target,0o755)
        with self.assertRaises(ContractError):r.verify_handoff(target,mode='READER_CANDIDATE')
        os.chmod(target,0o700)
        candidate=json.loads(file.read_bytes());candidate['private_key']='PRIVATE_MARKER';raw=encode(candidate);file.write_bytes(raw)
        manifest=json.loads((target/'MANIFEST.json').read_bytes());manifest['files'][file.name]='sha256:'+hashlib.sha256(raw).hexdigest();raw=encode(manifest);(target/'MANIFEST.json').write_bytes(raw)
        complete=json.loads((target/'COMPLETED.json').read_bytes());complete['manifest_sha256']='sha256:'+hashlib.sha256(raw).hexdigest();(target/'COMPLETED.json').write_bytes(encode(complete))
        with self.assertRaises(ContractError):r.verify_handoff(target,mode='READER_CANDIDATE')

    def test_report_and_candidate_deterministic_no_mutation_or_implicit_execution(self):
        before=encode(self.comparison);outcome_before=encode(self.f['store'].view())
        with patch.object(b,'run_comparison',side_effect=AssertionError('must not execute')),patch.object(b,'_rules_dependency',side_effect=AssertionError('must not execute')):
            a=r.build_handoff(self.common,self.comparison,self.f['store'].view(),report_ref='fixture:pure')
            b_report=r.build_handoff(self.common,self.comparison,self.f['store'].view(),report_ref='fixture:pure')
        self.assertEqual(encode(a),encode(b_report));self.assertEqual(encode(self.comparison),before)
        self.assertEqual(encode(self.f['store'].view()),outcome_before)
        self.assertEqual(encode(r.reader_candidate(a)),encode(r.reader_candidate(b_report)))

    def test_four_counterexamples_and_claim_boundaries_never_upgrade(self):
        rows=self.report['four_D2_counterexamples']
        self.assertEqual([row['input_ref'] for row in rows],['D3-00014','D3-00029','D3-00044','D3-00059'])
        for row in rows:
            self.assertEqual((row['archived_core'],row['archived_primary_join'],row['archived_physical_binding']),('ADMIT','JOINED','MISMATCH'))
            self.assertTrue(row['actual_prompt_differs'] and row['actual_generation_differs']);self.assertFalse(row['mitigated'])
        self.assertEqual(self.report['boundaries']['JLA'],'INSUFFICIENT_EVIDENCE_UNCHANGED')
        self.assertEqual(self.report['boundaries']['release'],'NOT_AUTHORIZED')

    def test_builder_candidate_and_renderer_have_no_file_process_network_io(self):
        code='''import sys
from wp07_fixtures import flow
from test_baselines import common
from wss_bridge.baselines import run_comparison
from wss_bridge.reporting import build_handoff,reader_candidate,render_markdown
f=flow();c=common(f);comparison=run_comparison(c,cohort_ref='fixture:c',snapshot_ref='fixture:s');view=f['store'].view()
def guard(event,args):
 if event=='open' or event.startswith(('socket.','subprocess.','sqlite3.')) or event in {'os.listdir','os.scandir','os.system'}:raise PermissionError(event)
sys.addaudithook(guard)
r=build_handoff(c,comparison,view,report_ref='fixture:pure')
assert reader_candidate(r)['status']=='CANDIDATE_FOR_REVIEW_NOT_RELEASE_AUTHORIZED'
assert 'NOT_MEASURED' in render_markdown(r)
'''
        env=dict(os.environ,PYTHONPATH=os.pathsep.join([str(Path(os.environ['WSS_CODE_ROOT'])/'src'),str(Path(__file__).parent)]))
        result=subprocess.run([sys.executable,'-B','-c',code],env=env,capture_output=True,text=True,timeout=30)
        self.assertEqual(result.returncode,0,result.stderr)

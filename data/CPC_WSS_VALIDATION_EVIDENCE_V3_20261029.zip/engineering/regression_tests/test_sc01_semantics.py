"""SC01 acceptance/negative controls: synthetic records only, never native IO."""
import copy
from dataclasses import replace
import json
import unittest

from test_contracts import receipt_row
from test_native_capture import mutate_snapshot
from wp03_fixtures import context, make_wire as transport
from test_native_capture import blob
from wss_bridge.controller import FORMAT
from wss_bridge.native_contract import NativeReadReceipt, ObservationRelation, classify_observations
from wss_bridge.native_transport import NativeReadTransport
from wss_bridge.native_capture import _issues
from wss_bridge.primitives import ContractError, canonical_json_bytes

class SC01Tests(unittest.TestCase):
    def test_explicit_zero_scope_and_positive_context_roundtrip(self):
        row=receipt_row();receipt=NativeReadReceipt.from_mapping(row)
        self.assertEqual(receipt.to_mapping(),row)
        self.assertEqual(receipt.binding_issues(),())
        self.assertGreater(receipt.target.courseid,0)
        self.assertEqual(receipt.target.response_scope_courseid,0)
        self.assertEqual(receipt.snapshots[0].completed_courseid,0)
        self.assertEqual(receipt.snapshots[0].value_courseid,0)
    def test_missing_route_or_scope_remains_unresolved(self):
        for field,flag in [('feedback_route','FEEDBACK_ROUTE_UNRESOLVED'),('response_scope_courseid','RESPONSE_SCOPE_UNRESOLVED')]:
            row=receipt_row();del row['target'][field]
            receipt=NativeReadReceipt.from_mapping(row)
            self.assertIsNone(getattr(receipt.target,field))
            self.assertIn(flag,receipt.binding_issues())
    def test_scope_zero_not_coerced_from_bool_string_float_negative(self):
        for bad in [True,False,'0',0.0,-1]:
            for where in ['target','completed','value']:
                row=receipt_row()
                if where=='target':row['target']['response_scope_courseid']=bad
                else:row['snapshots'][0]['completed_courseid' if where=='completed' else 'value_courseid']=bad
                with self.subTest(value=repr(bad),where=where),self.assertRaises(ContractError):
                    NativeReadReceipt.from_mapping(row)
    def test_scope_nonzero_or_missing_is_conflict_not_normalized(self):
        for field,label in [('completed_courseid','COMPLETED_RESPONSE_SCOPE'),('value_courseid','VALUE_RESPONSE_SCOPE')]:
            for bad in [7,None]:
                row=receipt_row();row['snapshots'][0][field]=bad
                r=NativeReadReceipt.from_mapping(row)
                self.assertEqual(getattr(r.snapshots[0],field),bad)
                self.assertIn(label+('_UNRESOLVED' if bad is None else '_CONFLICT'),r.binding_issues())
        row=receipt_row();row['target']['response_scope_courseid']=7
        self.assertIn('UNSUPPORTED_RESPONSE_SCOPE',NativeReadReceipt.from_mapping(row).binding_issues())
    def test_site_route_and_category_never_admitted(self):
        row=receipt_row();row['target']['feedback_route']='site_feedback'
        self.assertIn('UNSUPPORTED_FEEDBACK_ROUTE',NativeReadReceipt.from_mapping(row).binding_issues())
        for category,flag in [(0,'UNSUPPORTED_SITE_FEEDBACK'),(None,'TARGET_COURSE_CATEGORY_UNRESOLVED')]:
            row=receipt_row();row['target_course_category']=category
            self.assertIn(flag,NativeReadReceipt.from_mapping(row).binding_issues())
    def test_reported_category_has_exact_integer_type(self):
        for bad in [True,False,'1',1.0,-1]:
            row=receipt_row();row['target_course_category']=bad
            with self.subTest(bad=repr(bad)),self.assertRaises(ContractError):NativeReadReceipt.from_mapping(row)
    def test_other_native_zero_identity_guards_remain(self):
        for section,field in [('target','courseid'),('target','cmid'),('occurrences','standard_log_record_id'),('occurrences','courseid'),('snapshots','completed_id'),('snapshots','value_id')]:
            row=receipt_row();section_row=row[section][0] if section in ['occurrences','snapshots'] else row[section]
            section_row[field]=0;r=NativeReadReceipt.from_mapping(row)
            self.assertIn('TARGET_ZERO_ID' if section=='target' else 'SOURCE_ZERO_ID_REPORTED',r.binding_issues())
    def test_context_event_and_actor_comparisons_remain(self):
        for field,flag in [('courseid','EVENT_COURSE_CONFLICT'),('contextinstanceid','EVENT_CONTEXT_INSTANCE_CONFLICT'),('userid','INITIATING_ACTOR_CONFLICT'),('relateduserid','RESPONSE_OWNER_CONFLICT')]:
            row=receipt_row();row['occurrences'][0][field]=999
            self.assertIn(flag,NativeReadReceipt.from_mapping(row).binding_issues())
    def test_controller_scope_readiness_and_history_version(self):
        ctx=context();self.assertEqual(ctx.readiness_issues(),())
        self.assertEqual(FORMAT,'wss-controller-v2')
        for field,bad,flag in [('feedback_route',None,'FEEDBACK_ROUTE_UNRESOLVED'),('feedback_route','site_feedback','UNSUPPORTED_FEEDBACK_ROUTE'),('response_scope_courseid',None,'RESPONSE_SCOPE_UNRESOLVED'),('response_scope_courseid',7,'UNSUPPORTED_RESPONSE_SCOPE')]:
            badctx=replace(ctx,task_target=replace(ctx.task_target,**{field:bad}))
            self.assertIn(flag,badctx.readiness_issues())
    def test_new_wire_full_capture_coherence(self):
        r=NativeReadTransport.from_json(transport())
        self.assertEqual(r.receipt.binding_issues(),())
        self.assertEqual(_issues(r),())
        self.assertEqual(r.receipt.target_course_category,1)
    def test_old_wire_version_not_silently_accepted(self):
        row=json.loads(transport());row['transport_version']='wss-native-read-1.0'
        with self.assertRaises(ContractError):NativeReadTransport.from_json(json.dumps(row))
    def test_relabelled_legacy_target_missing_new_claims_cannot_bind(self):
        row=receipt_row()
        del row['target']['feedback_route'];del row['target']['response_scope_courseid'];del row['target_course_category']
        row['snapshots'][0]['completed_courseid']=row['target']['courseid']
        row['snapshots'][0]['value_courseid']=row['target']['courseid']
        issues=NativeReadReceipt.from_mapping(row).binding_issues()
        self.assertIn('FEEDBACK_ROUTE_UNRESOLVED',issues)
        self.assertIn('RESPONSE_SCOPE_UNRESOLVED',issues)
        self.assertIn('TARGET_COURSE_CATEGORY_UNRESOLVED',issues)
    def test_known_category_conflict_and_missing_duplicate_are_retained(self):
        row=receipt_row();old=NativeReadReceipt.from_mapping(row)
        self.assertIs(classify_observations(old,replace(old,target_course_category=2)),ObservationRelation.SOURCE_CONFLICT)
        self.assertIs(classify_observations(old,replace(old,target_course_category=None)),ObservationRelation.IDENTITY_UNRESOLVED)
        self.assertIs(classify_observations(old,old),ObservationRelation.DUPLICATE_OBSERVATION)
    def test_receipt_category_tamper_fails_raw_window_coherence(self):
        row=json.loads(transport());row['receipt']['target_course_category']=2
        parsed=NativeReadTransport.from_json(json.dumps(row))
        self.assertIn('CAPTURE_METADATA_INCOHERENT',_issues(parsed))
    def test_missing_or_site_target_metadata_cannot_qualify_capture(self):
        import base64
        for mode in ['missing','site','different_positive']:
            row=json.loads(transport());new=[]
            for item in row['blobs']:
                try:meta=json.loads(base64.b64decode(item['data_base64']))
                except (ValueError,UnicodeError):new.append(item);continue
                if isinstance(meta,dict) and 'target_window_ref' in meta:
                    if mode=='missing':continue
                    meta['native_target_rows'][0]['course_category']=0 if mode=='site' else 2
                    item=blob(canonical_json_bytes(meta))
                new.append(item)
            row['blobs']=new
            self.assertIn('CAPTURE_METADATA_INCOHERENT',_issues(NativeReadTransport.from_json(json.dumps(row))))
    def test_window_category_must_belong_to_same_context_course_and_cmid(self):
        import base64
        for field in ['courseid','cmid']:
            row=json.loads(transport());new=[]
            for item in row['blobs']:
                try:meta=json.loads(base64.b64decode(item['data_base64']))
                except (ValueError,UnicodeError):new.append(item);continue
                if isinstance(meta,dict) and 'target_window_ref' in meta:
                    meta['native_target_rows'][0][field]=999
                    item=blob(canonical_json_bytes(meta))
                new.append(item)
            row['blobs']=new
            self.assertIn('CAPTURE_METADATA_INCOHERENT',_issues(NativeReadTransport.from_json(json.dumps(row))))
    def test_no_match_invalid_window_holds_instead_of_wait(self):
        import base64,hashlib,os,tempfile
        from pathlib import Path
        from test_native_capture import fixture_cases
        from wss_bridge.controller import OfflineController
        from wss_bridge.ledger import LedgerScope
        for field,bad in [(None,None),('__remove_windows__',None),('course_category',0),('course_category',None),('course_category',2),('courseid',999),('cmid',999)]:
            ctx=context();directory=Path(tempfile.mkdtemp(dir=os.environ['WSS_TEST_ARTIFACT_ROOT']))
            scope=LedgerScope('fixture:sc01-ledger','fixture:sc01-run','SYNTHETIC_OFFLINE_FIXTURE',ctx.source.source_epoch_ref)
            ctl=OfflineController.create(directory/'workflow',scope,ctx)
            op=ctl.begin_operation(ctl.opportunity(note_ref='fixture:note'),'TASK',
                controlled_value_digest='sha256:'+hashlib.sha256(b'synthetic response').hexdigest(),
                log_watermark=100,logical_resource='WSS-U01-HINT',config_id='G_BASE')
            ctl.record_completion(op,known=True,evidence_ref='fixture:completion')
            row=copy.deepcopy(fixture_cases()['no_match']);row['receipt']['operation_ref']=op
            if field is not None:
                changed=[]
                for item in row['blobs']:
                    try:meta=json.loads(base64.b64decode(item['data_base64']))
                    except (ValueError,UnicodeError):changed.append(item);continue
                    if isinstance(meta,dict) and 'target_window_ref' in meta:
                        if field=='__remove_windows__':continue
                        meta['native_target_rows'][0][field]=bad
                        item=blob(canonical_json_bytes(meta))
                    changed.append(item)
                row['blobs']=changed
                self.assertIn('CAPTURE_METADATA_INCOHERENT',_issues(NativeReadTransport.from_json(json.dumps(row))))
            raw=canonical_json_bytes(row);ack=ctl.observe(op,0,raw)
            self.assertEqual(ack['status'],'WAIT' if field is None else 'HOLD')
            self.assertFalse(ack['acknowledged'])
            self.assertEqual(ctl.view()['counts']['attempts'],0)
            if field is not None:self.assertIn('CAPTURE_METADATA_INCOHERENT',ctl.view()['stopped_flags'])
    def test_v1_controller_journal_rejected_without_writes_or_migration(self):
        import hashlib,os,tempfile
        from pathlib import Path
        from unittest.mock import patch
        import wss_bridge.controller as module
        from wss_bridge.ledger import LedgerScope,LedgerCorruptionError
        ctx=context();root=Path(tempfile.mkdtemp(dir=os.environ['WSS_TEST_ARTIFACT_ROOT']))/'legacy'
        scope=LedgerScope('fixture:legacy-ledger','fixture:legacy-run','SYNTHETIC_OFFLINE_FIXTURE',ctx.source.source_epoch_ref)
        with patch.object(module,'FORMAT','wss-controller-v1'):
            module.OfflineController.create(root,scope,ctx)
        def snapshot():
            return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
        before=snapshot()
        with self.assertRaises(LedgerCorruptionError):module.OfflineController.open_readonly(root,scope,ctx)
        self.assertEqual(snapshot(),before)

if __name__=='__main__':unittest.main()

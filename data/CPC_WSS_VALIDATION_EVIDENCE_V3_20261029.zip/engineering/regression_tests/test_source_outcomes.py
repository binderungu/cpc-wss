from dataclasses import replace
import base64
import fcntl
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from wss_bridge.outcomes import (OutcomeRecipe,OutcomeStore,Composite,ExternalRow,external_from_outcome,
                                 read_analysis,exposure_metadata)
from wss_bridge.join import analyze,JoinPolicy,mapping_from_analysis
from wss_bridge.ledger import SnapshotReference,LedgerCorruptionError,SnapshotStore,_checked_fd
from wss_bridge.primitives import ContractError,plain_json
from wp03_fixtures import make_wire
from wp04_fixtures import digest
from wp07_fixtures import flow,followup,make_recipe,RESPONSES,encode


class SourceOutcomeTests(unittest.TestCase):
    def test_derive_uses_saved_selected_response_recipe_and_exact_lineage(self):
        f=flow();store=f['store'];state=store.view();row=state['outcomes'][0]
        self.assertEqual(row['value'],2);self.assertEqual(row['measure_state'],'VALID')
        self.assertEqual(row['lineage']['attempt_ref'],f['attempt'])
        self.assertEqual(row['lineage']['recipe_digest'],f['recipe'].digest)
        self.assertEqual(row['composite']['unit_token'],f['attempt'])
        derivation=state['derivations'][0];refs=derivation['output_snapshots']
        raw=store.snapshots.get(SnapshotReference.from_mapping(refs['value']))
        recipe=json.loads(store.snapshots.get(SnapshotReference.from_mapping(refs['recipe'])))
        transport=json.loads(store.snapshots.get(SnapshotReference.from_mapping(refs['native_transport'])))
        snap=transport['receipt']['snapshots'][0];value_ref=snap['value_bytes_ref']
        source=next(base64.b64decode(b['data_base64']) for b in transport['blobs'] if b['ref']==value_ref)
        # Independent response->score reconstruction, no production score() oracle.
        expected=recipe['responses'][source.decode('utf-8')]
        self.assertEqual(source,raw);self.assertEqual(row['value'],expected)
        self.assertEqual(row['lineage']['value_digest'],digest(raw))
        self.assertEqual(row['lineage']['source_key'][1],102)
        self.assertEqual(row['lineage']['source_key'][2],f['controller'].context.followup_target.item_id)
        self.assertEqual(state['counts'],{'received_derivations':1,'external_rows':1,'failed_derivations':0,'pending_derivations':0})
        self.assertEqual(state['orphan_snapshot_files'],())
        (Path(os.environ['WSS_TEST_ARTIFACT_ROOT'])/'WP07_SOURCE_RECONSTRUCTION.json').write_bytes(encode({
            'evidence_class':'SYNTHETIC_OFFLINE_MECHANICAL_QA','root':str(f['root']),
            'selected_source_value_digest':digest(raw),'reconstructed_integer':expected,
            'outcome_key':row['composite']['outcome_key'],'source_key':row['lineage']['source_key'],
            'pedagogical_validity_or_native_truth_verified':False}))

    def test_recipe_all_five_scores_empty_unknown_and_exact_bytes(self):
        f=flow();recipe=f['recipe']
        for response,value in RESPONSES.items():
            with self.subTest(value=value):self.assertEqual(recipe.score(response.encode()),('VALID',value))
        self.assertEqual(recipe.score(b''),('MISSING',None))
        for value in [b'4',b'unknown',b' separates input and instruction',b'\xff',b' ']:
            with self.subTest(raw=value):self.assertEqual(recipe.score(value),('INVALID',None))

    def test_recipe_strict_domain_schema_and_frozen_content(self):
        f=flow();original=json.loads(f['recipe'].raw)
        for value in [True,False,1.0,'2',-1,5,None]:
            with self.subTest(value=value):
                data={**original,'responses':{'answer':value}}
                with self.assertRaises(ContractError):OutcomeRecipe(encode(data))
        for modification in [{'extra':1},{'rubric_version':''},{'review_ref':None},{'responses':{}},
                             {'responses':{'':0}},{'followup_item_digest':'not-digest'}]:
            with self.subTest(modification=list(modification)),self.assertRaises(ContractError):
                OutcomeRecipe(encode({**original,**modification}))
        with self.assertRaises(TypeError):f['recipe'].data['responses']['new']=0
        with self.assertRaises(ContractError):OutcomeRecipe(f['recipe'].raw+b'\n')

    def test_first_invalid_response_not_replaced_by_valid_postclose_revision(self):
        f=flow(b'unknown first answer');ctl=f['controller'];old_analysis=ctl.store.get(f['analysis'])
        old_outcome=encode(f['outcome']);selected=ctl.view()['attempts'][f['attempt']]['selected_followup']
        followup(ctl,f['attempt'],b'explains and checks the rule',log_id=103,watermark=102)
        revised=ctl.analysis_snapshot(reason='WP07_POST_CLOSE_REVISION')
        mapping=mapping_from_analysis(ctl,revised,f['entry'],f['exposure_raw'])
        self.assertEqual(mapping.status,'ELIGIBLE')
        result=analyze([f['entry']],[f['external']],{f['entry'].receipt_ref:mapping},JoinPolicy.from_recipe(f['recipe']),
            cohort_ref='fixture:first-only',snapshot_ref='fixture:revision')
        self.assertEqual(result['core_ledger'][0]['primary_reason'],'EXTERNAL_MEASURE_INVALID')
        self.assertIsNone(result['core_ledger'][0]['value'])
        self.assertEqual(ctl.view()['attempts'][f['attempt']]['selected_followup'],selected)
        self.assertEqual(ctl.store.get(f['analysis']),old_analysis);self.assertEqual(encode(f['outcome']),old_outcome)
        self.assertEqual(sum(r['post_close_revision'] for r in ctl.view()['followups'].values()),1)

    def test_real_zero_and_missing_first_response_remain_distinct(self):
        for response,state,value in [(b'no boundary evidence','VALID',0),(b'','MISSING',None)]:
            with self.subTest(state=state):
                f=flow(response);self.assertEqual(f['outcome']['measure_state'],state);self.assertEqual(f['outcome']['value'],value)

    def test_failed_before_publication_retry_is_counted_without_extra_exposure(self):
        f=flow(extra='failed-retry');view=f['controller'].view()
        self.assertEqual(view['counts']['invocations'],2);self.assertEqual(view['counts']['publications'],1)
        self.assertEqual(mapping_from_analysis(f['controller'],f['analysis'],f['entry'],f['exposure_raw']).status,'ELIGIBLE')

    def test_multiple_and_unknown_publications_hold_without_changing_core(self):
        for mode,flag in [('second-publication','HOLD_MULTI_INVOCATION'),('unknown-retry','HOLD_PUBLICATION_UNRESOLVED')]:
            with self.subTest(mode=mode):
                f=flow(extra=mode);mapping=mapping_from_analysis(f['controller'],f['analysis'],f['entry'],f['exposure_raw'])
                self.assertEqual(mapping.status,'HOLD');self.assertIn(flag,mapping.reason_flags)
                result=analyze([f['entry']],[f['external']],{f['entry'].receipt_ref:mapping},JoinPolicy.from_recipe(f['recipe']),
                    cohort_ref='fixture:hold',snapshot_ref='fixture:hold')
                self.assertEqual(result['core_ledger'][0]['primary_reason'],'NATIVE_MAPPING_HOLD')
                self.assertEqual(result['core_ledger'][0]['core_disposition'],'ADMIT')

    def test_open_episode_pending_without_fabricated_outcome(self):
        f=flow(do_followup=False);mapping=mapping_from_analysis(f['controller'],f['analysis'],f['entry'],f['exposure_raw'])
        self.assertEqual(mapping.status,'PENDING');self.assertIn('NO_SELECTED_FOLLOWUP',mapping.reason_flags)
        with self.assertRaises(ContractError):f['store'].derive(f['controller'],f['analysis'],f['exposure_raw'],f['recipe'],'fixture:mechanical-only')
        view=f['store'].view();self.assertEqual(view['counts']['external_rows'],0);self.assertEqual(view['counts']['failed_derivations'],1)
        failed=view['derivations'][0];self.assertEqual(failed['failure_stage'],'INPUTS_CAPTURED')
        self.assertEqual(set(failed['input_snapshots']),{'exposure','recipe'})

    def test_store_scoped_duplicate_and_source_clone_refusal_preserve_old_outcome(self):
        f=flow();before=encode(f['store'].view()['outcomes'])
        with self.assertRaises(ContractError):f['store'].derive(f['controller'],f['analysis'],f['exposure_raw'],f['recipe'],'fixture:other-purpose')
        after=f['store'].view();self.assertEqual(encode(after['outcomes']),before)
        self.assertEqual(after['counts']['received_derivations'],2);self.assertEqual(after['counts']['external_rows'],1)
        self.assertEqual(after['counts']['failed_derivations'],1)
        self.assertEqual(after['derivations'][-1]['requested_purpose'],'fixture:other-purpose')

    def test_actual_source_path_preserves_CPC_unicode_experiment_and_purpose(self):
        f=flow(unicode_context=True)
        self.assertEqual(f['outcome']['composite']['experiment_id'],'fixture:experiment\u200dopaque')
        self.assertEqual(f['outcome']['composite']['purpose'],'fixture:purpose\u200dopaque')
        mapping=mapping_from_analysis(f['controller'],f['analysis'],f['entry'],f['exposure_raw'])
        result=analyze([f['entry']],[f['external']],{f['entry'].receipt_ref:mapping},JoinPolicy.from_recipe(f['recipe']),
            cohort_ref='fixture:unicode',snapshot_ref='fixture:unicode')
        self.assertEqual(result['core_ledger'][0]['primary_reason'],'JOINED')

    def test_late_evidence_new_hold_and_supersession_preserve_old_join(self):
        f=flow();ctl=f['controller'];oldbytes=ctl.store.get(f['analysis'])
        oldmapping=mapping_from_analysis(ctl,f['analysis'],f['entry'],f['exposure_raw'])
        oldjoin=analyze([f['entry']],[f['external']],{f['entry'].receipt_ref:oldmapping},JoinPolicy.from_recipe(f['recipe']),
            cohort_ref='fixture:late',snapshot_ref='fixture:old')
        saved=encode(oldjoin)
        taskop=ctl.view()['attempts'][f['attempt']]['operation_ref']
        ctl.observe(taskop,1000,make_wire(operation_ref=taskop,log_id=999,watermark=100))
        latest=ctl.analysis_snapshot(reason='WP07_LATE_EVIDENCE')
        mapping=mapping_from_analysis(ctl,latest,f['entry'],f['exposure_raw'])
        self.assertEqual(mapping.status,'HOLD');self.assertIn('HOLD_LATE_EVIDENCE',mapping.reason_flags)
        revised=analyze([f['entry']],[f['external']],{f['entry'].receipt_ref:mapping},JoinPolicy.from_recipe(f['recipe']),
            cohort_ref='fixture:late',snapshot_ref='fixture:new')
        self.assertEqual(revised['core_ledger'][0]['primary_reason'],'NATIVE_MAPPING_HOLD')
        historical=mapping_from_analysis(ctl,f['analysis'],f['entry'],f['exposure_raw'])
        h=analyze([f['entry']],[f['external']],{f['entry'].receipt_ref:historical},JoinPolicy.from_recipe(f['recipe']),
            cohort_ref='fixture:late',snapshot_ref='fixture:historical')
        self.assertFalse(h['complete_for_declared_snapshot']);self.assertFalse(h['all_mappings_at_current_head'])
        self.assertEqual(saved,encode(oldjoin));self.assertEqual(ctl.store.get(f['analysis']),oldbytes)

    def test_wrong_recipe_source_binding_and_missing_exposure_link_are_not_success(self):
        f=flow(do_followup=False);followup(f['controller'],f['attempt'],b'separates input and instruction')
        analysis=f['controller'].analysis_snapshot(reason='WP07_WRONG_RECIPE')
        recipe=make_recipe(f['controller'],task_version_ref='fixture:wrong-task')
        with self.assertRaises(ContractError):f['store'].derive(f['controller'],analysis,f['exposure_raw'],recipe,'fixture:mechanical-only')
        self.assertEqual(f['store'].view()['counts']['external_rows'],0)
        pending=mapping_from_analysis(f['controller'],analysis,f['entry'],None)
        self.assertEqual(pending.status,'PENDING')
        invalid=mapping_from_analysis(f['controller'],analysis,f['entry'],b'{}')
        self.assertEqual(invalid.status,'HOLD')

    def test_readonly_reopen_and_corrupted_lineage_bytes_fail_closed(self):
        f=flow();store=OutcomeStore.open_readonly(f['store'].root,f['store'].run_ref)
        self.assertEqual(store.view()['outcomes'],f['store'].view()['outcomes'])
        with self.assertRaises(ContractError):store.derive(f['controller'],f['analysis'],f['exposure_raw'],f['recipe'],'fixture:mechanical-only')
        ref=f['store'].view()['derivations'][0]['output_snapshots']['value']
        file=f['store'].snapshots._path(ref['snapshot_ref']);file.write_bytes(b'corrupted')
        with self.assertRaises(LedgerCorruptionError):f['store'].view()

    def test_partial_snapshot_failure_retains_pending_and_orphan_bytes(self):
        f=flow(do_followup=False);followup(f['controller'],f['attempt'],b'separates input and instruction')
        analysis=f['controller'].analysis_snapshot(reason='WP07_ORPHAN')
        store=f['store'];actual=store.snapshots.put
        def fail(name,raw):
            ref=actual(name,raw)
            if name.startswith('outcome-value:'):raise OSError('synthetic after persisted value')
            return ref
        with patch.object(store.snapshots,'put',side_effect=fail),self.assertRaises(OSError):
            store.derive(f['controller'],analysis,f['exposure_raw'],f['recipe'],'fixture:mechanical-only')
        view=store.view();self.assertEqual(view['counts']['pending_derivations'],1)
        self.assertEqual(view['counts']['external_rows'],0);self.assertGreaterEqual(len(view['orphan_snapshot_files']),1)
        self.assertEqual(set(view['derivations'][0]['input_snapshots']),{'exposure','recipe'})

    def test_analysis_prefix_bytes_and_registration_checked(self):
        f=flow();ctl=f['controller']
        arbitrary=ctl.store.put('fixture:unregistered-analysis',ctl.store.get(f['analysis']))
        with self.assertRaises(ContractError):read_analysis(ctl,arbitrary)
        raw=json.loads(ctl.store.get(f['analysis']));self.assertEqual(raw['basis_sequence'],read_analysis(ctl,f['analysis'])['document']['basis_sequence'])

    def test_analysis_read_holds_cooperative_controller_lock(self):
        f=flow();ctl=f['controller'];actual=ctl._events;lock_results=[]
        def observe():
            fd=_checked_fd(ctl.root/'.controller.lock',os.O_RDONLY)
            try:
                try:fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
                except BlockingIOError:lock_results.append('LOCKED')
                else:
                    lock_results.append('UNLOCKED');fcntl.flock(fd,fcntl.LOCK_UN)
            finally:os.close(fd)
            return actual()
        with patch.object(ctl,'_events',side_effect=observe):read_analysis(ctl,f['analysis'])
        self.assertTrue(lock_results);self.assertEqual(set(lock_results),{'LOCKED'})

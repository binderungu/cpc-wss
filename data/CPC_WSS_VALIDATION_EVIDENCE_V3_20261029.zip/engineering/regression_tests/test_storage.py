"""Retained synthetic local-IO verification; never imports native integrations.

This source is authored separately from production. The root freezes/runs it.
Small patched bounds test decisions, not advertised production-size capacity.
"""
from __future__ import annotations

import dataclasses
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest import mock

from wss_bridge import ledger as storage
from wss_bridge.native_contract import LedgerRecord, RecordKind
from wss_bridge.primitives import ContractError


def encoded(value):
    """Independent JSON wire oracle using the documented workflow encoding."""
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
                      allow_nan=False).encode("utf-8")


def digest(raw):
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def record(ref="record:1", entity="audit:repeated", **extra):
    return LedgerRecord(ref, RecordKind.AUDIT_REFERENCE, entity,
                        {"audit_ref": entity, "status": "LOCAL_SYNTHETIC", **extra})


CHILD = r'''
import os, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(os.environ["WSS_CODE_ROOT"]) / "src"))
from wss_bridge.ledger import AppendOnlyLedger, LedgerScope, DuplicateRecordReference
from wss_bridge.native_contract import LedgerRecord, RecordKind
root, worker, shared = Path(sys.argv[1]), sys.argv[2], sys.argv[3] == "shared"
scope = LedgerScope("ledger:synthetic", "run:mechanical", "offline-unit", "epoch:synthetic")
handle = AppendOnlyLedger.open_existing(root / "journal", scope)
(root / ("ready-" + worker)).write_text("ready", encoding="ascii")
deadline = time.monotonic() + 10
while not (root / "go").exists():
    if time.monotonic() >= deadline:
        raise SystemExit("bounded barrier timeout")
    time.sleep(0.01)
try:
    handle.append(LedgerRecord("record:shared" if shared else "record:" + worker,
        RecordKind.AUDIT_REFERENCE, "audit:repeated",
        {"audit_ref": "audit:repeated", "status": "LOCAL_SYNTHETIC"}))
    print("APPENDED", flush=True)
except DuplicateRecordReference:
    print("DUPLICATE", flush=True)
'''


class StorageTests(unittest.TestCase):
    def setUp(self):
        artifact_root = Path(os.environ["WSS_TEST_ARTIFACT_ROOT"])
        artifact_root.mkdir(parents=True, exist_ok=True)
        self.root = Path(tempfile.mkdtemp(prefix=self._testMethodName + "-", dir=artifact_root))
        self.scope = storage.LedgerScope("ledger:synthetic", "run:mechanical", "offline-unit",
                                         "epoch:synthetic")

    def journal(self, name="journal"):
        return storage.AppendOnlyLedger.create(self.root / name, self.scope)

    def store(self, name="snapshots"):
        return storage.SnapshotStore.create(self.root / name, "store:synthetic")

    def assert_chain(self, path, expected_refs):
        metadata = (path / "ledger.meta.json").read_bytes()
        self.assertEqual(json.loads(metadata), {
            "format": "wss-ledger-v1", "scope": self.scope.to_mapping(),
            "scope_is_a_declaration_not_authority": True,
            "encoding": "wss-workflow-json-v1"})
        self.assertEqual(metadata, encoded(json.loads(metadata)) + b"\n")
        prior = digest(metadata)
        refs = []
        for sequence, line in enumerate((path / "entries.jsonl").read_bytes().splitlines(keepends=True), 1):
            row = json.loads(line)
            self.assertEqual(row["sequence"], sequence)
            self.assertEqual(row["previous_digest"], prior)
            self.assertEqual(row["format"], "wss-ledger-v1")
            self.assertEqual(set(row), {"format", "sequence", "previous_digest", "recorded_at",
                                        "record", "content_digest"})
            body = {key: value for key, value in row.items() if key != "content_digest"}
            self.assertEqual(row["content_digest"], digest(encoded(body)))
            self.assertEqual(line, encoded(row) + b"\n")
            self.assertIn("+00:00", row["recorded_at"])
            refs.append(row["record"]["record_ref"])
            prior = row["content_digest"]
        self.assertEqual(sorted(refs), sorted(expected_refs))
        self.assertEqual(len(refs), len(set(refs)))

    def test_create_open_roundtrip_and_independent_chain(self):
        handle = self.journal()
        self.assertEqual(handle.read_entries(), ())
        first = handle.append(record("record:1", note="Ω / asli"))
        handle.append(record("record:2"))
        again = storage.AppendOnlyLedger.open_existing(handle.directory, self.scope)
        self.assertEqual([row.record_ref for row in again.read_records()], ["record:1", "record:2"])
        self.assertEqual([row.entity_ref for row in again.read_records()], ["audit:repeated"] * 2)
        self.assert_chain(handle.directory, ["record:1", "record:2"])
        with self.assertRaises(TypeError):
            first["sequence"] = 8
        with self.assertRaises(TypeError):
            first["record"]["payload"]["status"] = "changed"

    def test_duplicate_record_reference_never_overwrites(self):
        handle = self.journal()
        handle.append(record())
        prior = (handle.directory / "entries.jsonl").read_bytes()
        with self.assertRaises(storage.DuplicateRecordReference):
            handle.append(record(note="different payload"))
        self.assertEqual((handle.directory / "entries.jsonl").read_bytes(), prior)

    def test_scope_mismatch_never_rewrites_metadata(self):
        handle = self.journal()
        before = {p.name: p.read_bytes() for p in handle.directory.iterdir()}
        for scope in (dataclasses.replace(self.scope, run_ref="run:other"),
                      dataclasses.replace(self.scope, source_epoch_ref="epoch:other"),
                      dataclasses.replace(self.scope, ledger_ref="ledger:other")):
            with self.assertRaises(storage.LedgerCorruptionError):
                storage.AppendOnlyLedger.open_existing(handle.directory, scope)
        self.assertEqual({p.name: p.read_bytes() for p in handle.directory.iterdir()}, before)

    def test_existing_create_and_invalid_scope_are_rejected(self):
        handle = self.journal()
        with self.assertRaises(storage.LedgerError):
            storage.AppendOnlyLedger.create(handle.directory, self.scope)
        with self.assertRaises(ContractError):
            storage.AppendOnlyLedger.create(self.root / "unused", {})
        self.assertFalse((self.root / "unused").exists())
        with self.assertRaises(ContractError):
            storage.AppendOnlyLedger.open_existing(handle.directory, {})
        with self.assertRaises(ContractError):
            handle.append(record().to_mapping())
        self.assertEqual(handle.read_records(), ())

    def test_corrupt_history_is_retained_and_blocks_append(self):
        def malformed(row):
            return b"{unparseable}\n"
        def torn(row):
            return encoded(row)
        def digest_bad(row):
            row["content_digest"] = "sha256:" + "0" * 64
            return encoded(row) + b"\n"
        def sequence_bad(row):
            row["sequence"] = 2
            row["content_digest"] = digest(encoded({k: v for k, v in row.items() if k != "content_digest"}))
            return encoded(row) + b"\n"
        def predecessor_bad(row):
            row["previous_digest"] = "sha256:" + "1" * 64
            row["content_digest"] = digest(encoded({k: v for k, v in row.items() if k != "content_digest"}))
            return encoded(row) + b"\n"
        def noncanonical(row):
            return json.dumps(row, sort_keys=True).encode("utf-8") + b"\n"
        def duplicate_json_key(row):
            raw = encoded(row)
            return b'{"sequence":1,' + raw[1:] + b"\n"
        for name, transform in (("malformed", malformed), ("torn", torn), ("digest", digest_bad),
                                ("sequence", sequence_bad), ("predecessor", predecessor_bad),
                                ("noncanonical", noncanonical), ("duplicate-key", duplicate_json_key)):
            with self.subTest(corruption=name):
                handle = self.journal(name)
                handle.append(record())
                path = handle.directory / "entries.jsonl"
                raw = transform(json.loads(path.read_bytes()))
                path.write_bytes(raw)
                for action in (handle.read_entries, lambda: handle.append(record("record:new")),
                               lambda: storage.AppendOnlyLedger.open_existing(handle.directory, self.scope)):
                    with self.assertRaises(storage.LedgerCorruptionError):
                        action()
                    self.assertEqual(path.read_bytes(), raw)

    def test_rehashed_duplicate_record_in_history_is_not_accepted(self):
        handle = self.journal()
        handle.append(record())
        path = handle.directory / "entries.jsonl"
        first = json.loads(path.read_bytes())
        duplicate = dict(first, sequence=2, previous_digest=first["content_digest"])
        duplicate["content_digest"] = digest(encoded({k: v for k, v in duplicate.items() if k != "content_digest"}))
        raw = path.read_bytes() + encoded(duplicate) + b"\n"
        path.write_bytes(raw)
        with self.assertRaises(storage.LedgerCorruptionError):
            handle.read_entries()
        self.assertEqual(path.read_bytes(), raw)

    def test_record_limit_with_small_patched_bound(self):
        handle = self.journal()
        handle.append(record())
        before = (handle.directory / "entries.jsonl").read_bytes()
        with mock.patch.object(storage, "MAX_RECORDS", 1):
            with self.assertRaises(storage.LedgerCapacityError):
                handle.append(record("record:2"))
        self.assertEqual((handle.directory / "entries.jsonl").read_bytes(), before)

    def test_entry_and_journal_limits_with_small_patched_bounds(self):
        for name, constant in (("entry-bound", "MAX_ENTRY_BYTES"), ("journal-bound", "MAX_JOURNAL_BYTES")):
            handle = self.journal(name)
            metadata_size = (handle.directory / "ledger.meta.json").stat().st_size
            with mock.patch.object(storage, constant, metadata_size + 16):
                with self.assertRaises(storage.LedgerCapacityError):
                    handle.append(record(note="x" * 500))
            self.assertEqual((handle.directory / "entries.jsonl").read_bytes(), b"")
        handle = self.journal("existing-bound")
        handle.append(record())
        raw = (handle.directory / "entries.jsonl").read_bytes()
        with mock.patch.object(storage, "MAX_JOURNAL_BYTES", len(raw) - 1):
            with self.assertRaises(storage.LedgerCapacityError):
                handle.read_entries()
        self.assertEqual((handle.directory / "entries.jsonl").read_bytes(), raw)

    def test_missing_parent_parent_traversal_and_directory_symlinks(self):
        with self.assertRaises(storage.LedgerError):
            storage.AppendOnlyLedger.create(self.root / "missing" / "journal", self.scope)
        with self.assertRaises(storage.LedgerError):
            storage.AppendOnlyLedger.create(self.root / ".." / "traversal", self.scope)
        actual = self.root / "actual"
        actual.mkdir()
        link = self.root / "linked"
        link.symlink_to(actual, target_is_directory=True)
        with self.assertRaises(storage.LedgerError):
            storage.AppendOnlyLedger.create(link / "journal", self.scope)
        handle = self.journal()
        leaf = self.root / "journal-alias"
        leaf.symlink_to(handle.directory, target_is_directory=True)
        with self.assertRaises(storage.LedgerError):
            storage.AppendOnlyLedger.open_existing(leaf, self.scope)

    def test_storage_file_symlinks_hardlinks_and_nonregular_are_rejected(self):
        for variant in ("symlink", "hardlink", "directory", "fifo"):
            with self.subTest(variant=variant):
                handle = self.journal(variant)
                path = handle.directory / "entries.jsonl"
                retained = handle.directory / "original-retained.jsonl"
                path.rename(retained)
                if variant == "symlink":
                    path.symlink_to(retained)
                elif variant == "hardlink":
                    os.link(retained, path)
                elif variant == "directory":
                    path.mkdir()
                else:
                    os.mkfifo(path)
                before = time.monotonic()
                if variant == "fifo":
                    script = '''import os, sys
from pathlib import Path
sys.path.insert(0, str(Path(os.environ["WSS_CODE_ROOT"]) / "src"))
from wss_bridge.ledger import AppendOnlyLedger, LedgerScope, LedgerError
try:
    AppendOnlyLedger.open_existing(sys.argv[1], LedgerScope("ledger:synthetic", "run:mechanical", "offline-unit", "epoch:synthetic"))
except (LedgerError, OSError):
    print("REJECTED")
else:
    raise SystemExit("nonregular FIFO was accepted")
'''
                    child = subprocess.Popen([sys.executable, "-I", "-B", "-c", script, str(handle.directory)],
                                             stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                             env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
                    try:
                        out, err = child.communicate(timeout=5)
                    finally:
                        if child.poll() is None:
                            child.kill()
                            out, err = child.communicate(timeout=5)
                    (self.root / "fifo.stdout").write_bytes(out)
                    (self.root / "fifo.stderr").write_bytes(err)
                    self.assertEqual(child.returncode, 0, err.decode("utf-8", errors="replace"))
                    self.assertEqual(out, b"REJECTED\n")
                else:
                    with self.assertRaises((storage.LedgerError, OSError)):
                        handle.read_entries()
                self.assertLess(time.monotonic() - before, 10, "nonregular input must not block")
                self.assertEqual(retained.read_bytes(), b"")

    def test_missing_metadata_and_lock_are_not_recreated(self):
        for filename in ("ledger.meta.json", ".ledger.lock", "entries.jsonl"):
            handle = self.journal(filename.replace(".", "-"))
            path = handle.directory / filename
            path.rename(path.with_name(path.name + ".retained"))
            with self.assertRaises((storage.LedgerError, OSError)):
                storage.AppendOnlyLedger.open_existing(handle.directory, self.scope)
            self.assertFalse(path.exists())

    def test_short_writes_are_completed_without_duplicate_bytes(self):
        handle = self.journal()
        original = storage.os.write
        def short(fd, raw):
            return original(fd, raw[:max(1, min(7, len(raw)))])
        with mock.patch.object(storage.os, "write", side_effect=short):
            handle.append(record())
        self.assert_chain(handle.directory, ["record:1"])

    def test_partial_write_failure_retains_torn_bytes_and_blocks_reuse(self):
        handle = self.journal()
        original = storage.os.write
        calls = 0
        def partial_then_zero(fd, raw):
            nonlocal calls
            calls += 1
            return original(fd, raw[:17]) if calls == 1 else 0
        with mock.patch.object(storage.os, "write", side_effect=partial_then_zero):
            with self.assertRaises(OSError):
                handle.append(record())
        raw = (handle.directory / "entries.jsonl").read_bytes()
        self.assertEqual(len(raw), 17)
        for action in (handle.read_entries, lambda: handle.append(record("record:retry"))):
            with self.assertRaises(storage.LedgerCorruptionError):
                action()
        self.assertEqual((handle.directory / "entries.jsonl").read_bytes(), raw)

    def test_fsync_failure_does_not_claim_rollback(self):
        handle = self.journal()
        with mock.patch.object(storage.os, "fsync", side_effect=OSError("synthetic fsync failure")):
            with self.assertRaises(OSError):
                handle.append(record())
        self.assert_chain(handle.directory, ["record:1"])
        with self.assertRaises(storage.DuplicateRecordReference):
            handle.append(record())

    def test_create_failure_retains_partial_directory(self):
        path = self.root / "partial-create"
        with mock.patch.object(storage.os, "fsync", side_effect=OSError("synthetic create failure")):
            with self.assertRaises(OSError):
                storage.AppendOnlyLedger.create(path, self.scope)
        self.assertTrue(path.is_dir())
        self.assertTrue((path / "ledger.meta.json").exists())
        self.assertFalse((path / "entries.jsonl").exists())
        with self.assertRaises(storage.LedgerError):
            storage.AppendOnlyLedger.create(path, self.scope)

    def test_snapshot_raw_and_empty_roundtrip_independent_digest(self):
        store = self.store()
        for name, raw in (("snapshot:raw", b"\x00\xff\nnot-json"), ("snapshot:empty", b"")):
            reference = store.put(name, raw)
            self.assertEqual(reference.sha256, digest(raw))
            self.assertEqual(reference.byte_length, len(raw))
            self.assertEqual(storage.SnapshotReference.from_mapping(reference.to_mapping()), reference)
            self.assertEqual(store.get(reference), raw)
            independent_path = self.root / "snapshots" / (hashlib.sha256(name.encode()).hexdigest() + ".bin")
            self.assertEqual(independent_path.read_bytes(), raw)
            with self.assertRaises(dataclasses.FrozenInstanceError):
                reference.byte_length = 2
        again = storage.SnapshotStore.open_existing(self.root / "snapshots", "store:synthetic")
        self.assertEqual(again.get(reference), b"")

    def test_snapshot_same_ref_identical_and_changed_retries_never_overwrite(self):
        store = self.store()
        reference = store.put("snapshot:once", b"original")
        for retry in (b"original", b"changed"):
            with self.assertRaises(storage.SnapshotExistsError):
                store.put("snapshot:once", retry)
            self.assertEqual(store.get(reference), b"original")

    def test_snapshot_store_scope_and_reference_types(self):
        store = self.store()
        reference = store.put("snapshot:once", b"original")
        with self.assertRaises(storage.LedgerCorruptionError):
            storage.SnapshotStore.open_existing(self.root / "snapshots", "store:other")
        with self.assertRaises(ContractError):
            store.get(dataclasses.replace(reference, store_ref="store:other"))
        with self.assertRaises(ContractError):
            store.get(reference.to_mapping())
        for bad in (bytearray(b"data"), "data", memoryview(b"data")):
            with self.assertRaises(ContractError):
                store.put("snapshot:bad", bad)

    def test_snapshot_wrong_digest_length_and_changed_bytes_are_retained(self):
        store = self.store()
        reference = store.put("snapshot:once", b"original")
        for wrong in (dataclasses.replace(reference, sha256="sha256:" + "0" * 64),
                      dataclasses.replace(reference, byte_length=9)):
            with self.assertRaises(storage.LedgerCorruptionError):
                store.get(wrong)
        path = self.root / "snapshots" / (hashlib.sha256(b"snapshot:once").hexdigest() + ".bin")
        path.write_bytes(b"corrupt!")
        with self.assertRaises(storage.LedgerCorruptionError):
            store.get(reference)
        self.assertEqual(path.read_bytes(), b"corrupt!")

    def test_snapshot_missing_not_recreated_and_orphan_retained(self):
        store = self.store()
        reference = store.put("snapshot:orphan", b"orphan without journal")
        handle = self.journal()
        with self.assertRaises(ContractError):
            handle.append({"malformed": True})
        self.assertEqual(store.get(reference), b"orphan without journal")
        path = self.root / "snapshots" / (hashlib.sha256(b"snapshot:orphan").hexdigest() + ".bin")
        path.rename(path.with_suffix(".retained"))
        with self.assertRaises(FileNotFoundError):
            store.get(reference)
        self.assertFalse(path.exists())

    def test_snapshot_small_patched_bound(self):
        store = self.store()
        with mock.patch.object(storage, "MAX_SNAPSHOT_BYTES", 4):
            with self.assertRaises(storage.LedgerCapacityError):
                store.put("snapshot:too-large", b"12345")
            with self.assertRaises(storage.LedgerCapacityError):
                storage.SnapshotReference("store:synthetic", "snapshot:x", digest(b"12345"), 5)
            reference = store.put("snapshot:at-bound", b"1234")
            self.assertEqual(store.get(reference), b"1234")
        self.assertEqual(len(list((self.root / "snapshots").glob("*.bin"))), 1)

    def test_snapshot_fsync_failure_retains_unacknowledged_bytes(self):
        store = self.store()
        with mock.patch.object(storage.os, "fsync", side_effect=OSError("synthetic fsync failure")):
            with self.assertRaises(OSError):
                store.put("snapshot:uncertain", b"retained")
        path = self.root / "snapshots" / (hashlib.sha256(b"snapshot:uncertain").hexdigest() + ".bin")
        self.assertEqual(path.read_bytes(), b"retained")
        with self.assertRaises(storage.SnapshotExistsError):
            store.put("snapshot:uncertain", b"retained")

    def test_snapshot_metadata_tamper_and_symlink_or_hardlink_payload_rejected(self):
        for variant in ("metadata", "symlink", "hardlink"):
            with self.subTest(variant=variant):
                store = self.store(variant)
                reference = store.put("snapshot:once", b"original")
                directory = self.root / variant
                if variant == "metadata":
                    path = directory / "snapshot-store.meta.json"
                    raw = b'{"format":"wrong-store"}\n'
                    path.write_bytes(raw)
                else:
                    path = directory / (hashlib.sha256(b"snapshot:once").hexdigest() + ".bin")
                    retained = path.with_suffix(".retained")
                    path.rename(retained)
                    if variant == "symlink":
                        path.symlink_to(retained)
                    else:
                        os.link(retained, path)
                with self.assertRaises((storage.LedgerError, OSError)):
                    store.get(reference)
                if variant == "metadata":
                    self.assertEqual(path.read_bytes(), raw)
                else:
                    self.assertEqual(retained.read_bytes(), b"original")

    def run_children(self, *, shared):
        handle = self.journal()
        children = []
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
        self.assertIn("WSS_CODE_ROOT", env)
        try:
            for index in range(3):
                children.append(subprocess.Popen([sys.executable, "-I", "-B", "-c", CHILD,
                                                  str(self.root), str(index), "shared" if shared else "distinct"],
                                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env))
            deadline = time.monotonic() + 10
            while len(list(self.root.glob("ready-*"))) != len(children):
                if time.monotonic() >= deadline:
                    self.fail("bounded child barrier readiness timeout")
                time.sleep(0.01)
            (self.root / "go").write_text("go", encoding="ascii")
            results = []
            for index, child in enumerate(children):
                out, err = child.communicate(timeout=20)
                (self.root / f"child-{index}.stdout").write_bytes(out)
                (self.root / f"child-{index}.stderr").write_bytes(err)
                self.assertEqual(child.returncode, 0, err.decode("utf-8", errors="replace"))
                self.assertEqual(err, b"")
                results.append(out.decode("ascii").strip())
            return handle, results
        finally:
            for index, child in enumerate(children):
                if child.poll() is None:
                    child.kill()
                    out, err = child.communicate(timeout=5)
                    (self.root / f"child-{index}.terminated.stdout").write_bytes(out)
                    (self.root / f"child-{index}.terminated.stderr").write_bytes(err)

    def test_cooperating_processes_preserve_all_distinct_record_refs(self):
        handle, results = self.run_children(shared=False)
        self.assertEqual(results, ["APPENDED"] * 3)
        self.assert_chain(handle.directory, ["record:0", "record:1", "record:2"])
        self.assertEqual([r.entity_ref for r in handle.read_records()], ["audit:repeated"] * 3)

    def test_cooperating_processes_same_ref_race_has_one_winner(self):
        handle, results = self.run_children(shared=True)
        self.assertEqual(results.count("APPENDED"), 1)
        self.assertEqual(results.count("DUPLICATE"), 2)
        self.assert_chain(handle.directory, ["record:shared"])


if __name__ == "__main__":
    unittest.main()

"""Timestamp repair regression: synthetic metadata and local fixture only."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest

from wss_bridge.primitives import ContractError,require_rfc3339
from wss_bridge.configuration import OperatorConfiguration
from wss_bridge.native_contract import NativeReadReceipt,NativeOccurrence,NativeValueSnapshot,LedgerRecord
from wss_bridge.ledger import AppendOnlyLedger,LedgerScope,LedgerCorruptionError

INVALID_OFFSETS=('+05:60','+05:99','-03:60','+00:60','-00:60','+23:60','-23:60','+24:00','-24:00','+99:99')
VALID_OFFSETS=('Z','+00:00','-00:00','+00:59','-00:59','+01:00','-01:00','+05:30','+23:59','-23:59')


def constructors(value):
    return (
        ('configuration',lambda:OperatorConfiguration.from_mapping({
            'configuration_version':'wss-operator-declaration-1.0','configuration_ref':'synthetic-time-config',
            'scope_grant_ref':{'ref':'synthetic-not-authority'},'operator_ref':'synthetic-operator',
            'evidence_root_ref':'synthetic-root','validation_time':value,
            'reference_manifest_digest':'sha256:9c4dee342dc86a4c614a337f6891bdae63e8fd75b00f2267e3081de011bc62ad'})),
        ('observer_time',lambda:NativeReadReceipt('synthetic-observation','synthetic-operation',
                                                'READ_UNAVAILABLE',value,0)),
        ('native_time',lambda:NativeOccurrence(native_time=value)),
        ('completed_modified_time',lambda:NativeValueSnapshot(completed_modified_time=value)),
    )


class TimestampRegressionTests(unittest.TestCase):
    def test_invalid_offset_boundary_and_original_failed_cases(self):
        for offset in INVALID_OFFSETS:
            with self.subTest(offset=offset),self.assertRaises(ContractError):
                require_rfc3339('2026-10-17T12:30:00'+offset,'synthetic_time')

    def test_valid_offset_boundaries_preserve_original_spelling(self):
        for offset in VALID_OFFSETS:
            for fraction in ('','.123456'):
                value='2024-02-29T23:59:59'+fraction+offset
                with self.subTest(offset=offset,fraction=fraction):
                    self.assertEqual(require_rfc3339(value,'synthetic_time'),value)

    def test_exhaustive_two_digit_offset_domain(self):
        accepted=rejected=0
        # Independent numeric-domain oracle, not the production regex or private table.
        # No subtest object per grid cell: bound retained receipt size.
        for sign in ('+','-'):
            for hour in range(100):
                for minute in range(100):
                    value=f'2026-10-17T12:30:00{sign}{hour:02d}:{minute:02d}'
                    valid=hour<24 and minute<60
                    try:
                        returned=require_rfc3339(value,'synthetic_time')
                    except ContractError:
                        rejected+=1
                        if valid:self.fail('Supported offset rejected: '+value)
                    else:
                        accepted+=1
                        if not valid:self.fail('Invalid offset accepted: '+value)
                        self.assertEqual(returned,value)
        self.assertEqual((accepted,rejected),(2880,17120))
        root=Path(os.environ['WSS_TEST_ARTIFACT_ROOT'])
        (root/'OFFSET_DOMAIN_RECEIPT.json').write_text(json.dumps({
            'evidence_class':'BOUNDED_SYNTHETIC_MECHANICAL_INPUT_CHECK','cases':20000,
            'oracle':'both signs; hour<24 and minute<60','accepted':accepted,'rejected':rejected,
            'scientific_experiment':False},indent=2)+'\n')

    def test_invalid_offsets_rejected_by_shared_callers(self):
        for offset in INVALID_OFFSETS:
            value='2026-10-17T12:30:00'+offset
            for label,construct in constructors(value):
                with self.subTest(caller=label,offset=offset),self.assertRaises(ContractError):
                    construct()

    def test_valid_shared_caller_serialization_stays_exact(self):
        for offset in VALID_OFFSETS:
            value='2026-10-17T12:30:00.000001'+offset
            for label,construct in constructors(value):
                with self.subTest(caller=label,offset=offset):
                    obj=construct()
                    if label=='configuration':
                        self.assertEqual(obj.to_dict()['validation_time'],value)
                        self.assertFalse(hasattr(obj,'authorized'))
                    else:self.assertEqual(getattr(obj,label),value)

    def test_legacy_invalid_stored_time_rejected_without_rewriting(self):
        root=Path(tempfile.mkdtemp(prefix='legacy-invalid-time-',dir=os.environ['WSS_TEST_ARTIFACT_ROOT']))
        scope=LedgerScope('synthetic-ledger','synthetic-run','offline-regression')
        ledger=AppendOnlyLedger.create(root/'journal',scope)
        ledger.append(LedgerRecord('synthetic-record','AUDIT_REFERENCE','synthetic-audit',
                                  {'audit_ref':'synthetic-audit','status':'SYNTHETIC'}))
        path=ledger.directory/'entries.jsonl'
        row=json.loads(path.read_bytes());row['recorded_at']='2026-10-17T12:30:00+05:60'
        encode=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf-8')
        row['content_digest']='sha256:'+hashlib.sha256(encode({k:v for k,v in row.items() if k!='content_digest'})).hexdigest()
        raw=encode(row)+b'\n';path.write_bytes(raw)
        for action in (ledger.read_entries,lambda:AppendOnlyLedger.open_existing(ledger.directory,scope),
                       lambda:ledger.append(LedgerRecord('synthetic-new','AUDIT_REFERENCE','synthetic-audit',
                                                        {'audit_ref':'synthetic-audit','status':'SYNTHETIC'}))):
            with self.subTest(action=repr(action)),self.assertRaises(LedgerCorruptionError):action()
            self.assertEqual(path.read_bytes(),raw)


if __name__=='__main__':unittest.main()

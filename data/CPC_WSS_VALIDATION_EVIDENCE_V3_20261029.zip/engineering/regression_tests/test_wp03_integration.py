"""Independent local IO integration, no helper launch or native observation."""
import base64
import copy
import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from wss_bridge.controller import OfflineController,WorkflowRefused
from wss_bridge.ledger import LedgerScope
from wp03_fixtures import context,make_wire,BASE

VALUE=b'synthetic response'


def digest(raw):return 'sha256:'+hashlib.sha256(raw).hexdigest()


class WP03IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.root=Path(tempfile.mkdtemp(prefix=self._testMethodName+'-',dir=os.environ['WSS_TEST_ARTIFACT_ROOT']))
        self.context=context();self.scope=LedgerScope('fixture:integration-ledger','fixture:integration-run','SYNTHETIC_OFFLINE_FIXTURE',self.context.source.source_epoch_ref)
        self.controller=OfflineController.create(self.root/'workflow',self.scope,self.context)

    def begin(self,kind='TASK',attempt=None,value=VALUE,watermark=100):
        op=self.controller.begin_operation(self.controller.opportunity(note_ref='fixture:opportunity'),kind,
            controlled_value_digest=digest(value),log_watermark=watermark,attempt_ref=attempt,
            **({'logical_resource':'WSS-U01-HINT','config_id':'G_BASE'} if kind=='TASK' else {}))
        self.controller.record_completion(op,known=True,evidence_ref='fixture:completion')
        return op

    def test_prior_actual_php_synthetic_packet_persists_every_byte_before_ack(self):
        op=self.begin();packet=copy.deepcopy(BASE);packet['receipt']['operation_ref']=op
        raw=json.dumps(packet,separators=(',',':')).encode()
        ack=self.controller.observe(op,0,raw);self.assertTrue(ack['acknowledged'])
        store=self.controller.root/'snapshots'
        lines=[json.loads(line) for line in (self.controller.root/'journal/entries.jsonl').read_text().splitlines()]
        prior=digest((self.controller.root/'journal/ledger.meta.json').read_bytes())
        for sequence,row in enumerate(lines,1):
            self.assertEqual(row['sequence'],sequence);self.assertEqual(row['previous_digest'],prior)
            body={k:v for k,v in row.items() if k!='content_digest'}
            self.assertEqual(digest(json.dumps(body,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()),row['content_digest'])
            prior=row['content_digest']
        accepted=next(row['record']['payload']['data'] for row in lines if row['record']['payload']['event']=='OBSERVATION' and row['record']['payload']['data']['status']=='ACCEPTED')
        def readref(ref):
            path=store/(hashlib.sha256(ref['snapshot_ref'].encode()).hexdigest()+'.bin')
            data=path.read_bytes();self.assertEqual(len(data),ref['byte_length']);self.assertEqual(digest(data),ref['sha256']);return data
        manifest=json.loads(readref(accepted['capture_snapshot']))
        self.assertEqual(readref(manifest['raw_reference']),raw)
        self.assertEqual(len(manifest['blob_references']),len(packet['blobs']))
        for ref,blob in zip(manifest['blob_references'],packet['blobs']):self.assertEqual(readref(ref),base64.b64decode(blob['data_base64']))
        readonly=OfflineController.open_readonly(self.controller.root,self.scope,self.context)
        self.assertEqual(readonly.view()['counts']['attempts'],1)

    def test_journal_accept_failure_leaves_no_ack_anchor_and_retains_bytes(self):
        op=self.begin();original=self.controller.journal.append
        def append(record):
            if record.payload['event']=='OBSERVATION':raise OSError('fixture:accept-write-failure')
            return original(record)
        with patch.object(self.controller.journal,'append',side_effect=append),self.assertRaises(OSError):
            self.controller.observe(op,0,make_wire(operation_ref=op))
        state=self.controller.view();self.assertEqual(state['counts']['attempts'],0);self.assertEqual(state['counts']['ingestions'],1)
        self.assertIsNotNone(state['pending_operation'])
        self.assertGreater(len(list((self.controller.root/'snapshots').glob('*.bin'))),1)
        with self.assertRaises(WorkflowRefused):self.controller.analysis_snapshot()

    def test_first_followup_selection_does_not_use_future_score_validity(self):
        op=self.begin();ack=self.controller.observe(op,0,make_wire(operation_ref=op));attempt=ack['anchor']['attempt_ref']
        inv=self.controller.receive_help(attempt,logical_resource='WSS-U01-HINT',config_id='G_BASE')
        for stage in ['CONSUME_STARTED','CAPTURED','COMMIT_DURABLE','PUBLISHED']:self.controller.advance_invocation(inv,stage,evidence_ref='fixture:'+stage)
        self.controller.finish_invocation(inv,publication='PUBLISHED',evidence_ref='fixture:finish')
        first_value=b'not-a-score';follow=self.begin('FOLLOWUP',attempt,first_value,101)
        first=self.controller.observe(follow,0,make_wire(operation_ref=follow,kind='FOLLOWUP',log_id=102,watermark=101,value=first_value))
        first_ref=first['anchor']['followup_ref'];analysis=self.controller.analysis_snapshot(reason='FIRST_NON_NUMERIC_FOLLOWUP');old=self.controller.store.get(analysis)
        revision=self.begin('FOLLOWUP',attempt,b'4',102)
        self.controller.observe(revision,0,make_wire(operation_ref=revision,kind='FOLLOWUP',log_id=103,watermark=102,value=b'4'))
        self.assertEqual(self.controller.view()['attempts'][attempt]['selected_followup'],first_ref)
        self.assertEqual(self.controller.store.get(analysis),old)
        self.assertEqual(sum(row['post_close_revision'] for row in self.controller.view()['followups'].values()),1)

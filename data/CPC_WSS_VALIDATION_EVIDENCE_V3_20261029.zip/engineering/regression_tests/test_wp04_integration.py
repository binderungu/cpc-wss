"""Explicit caller integration only; no producer/capture/native orchestration."""
import json
import os
from pathlib import Path
import tempfile
import unittest
from dataclasses import replace

from wss_bridge.controller import OfflineController
from wss_bridge.ledger import LedgerScope
from wss_bridge.primitives import ContractError
from wss_bridge.renderer import render
from wp03_fixtures import context, make_wire
from wp04_fixtures import digest, inputs


class WP04IntegrationTests(unittest.TestCase):
    def setup_controller(self):
        root=Path(tempfile.mkdtemp(prefix='wp04-caller-',dir=os.environ['WSS_TEST_ARTIFACT_ROOT']))
        c=context();scope=LedgerScope('fixture:wp04-ledger','fixture:wp04-run',
                                    'SYNTHETIC_OFFLINE_FIXTURE',c.source.source_epoch_ref)
        ctl=OfflineController.create(root/'workflow',scope,c)
        op=ctl.begin_operation(ctl.opportunity(note_ref='fixture:opportunity'),'TASK',
            controlled_value_digest=digest(b'synthetic response'),log_watermark=100,
            logical_resource='WSS-U01-HINT',config_id='G_BASE')
        ctl.record_completion(op,known=True,evidence_ref='fixture:completion')
        ack=ctl.observe(op,0,make_wire(operation_ref=op));attempt=ack['anchor']['attempt_ref']
        return ctl,attempt

    def test_failed_renderer_invocation_survives_without_publication_or_fake_core_result(self):
        ctl,attempt=self.setup_controller()
        invocation=ctl.receive_help(attempt,logical_resource='WSS-U01-HINT',config_id='G_BASE')
        ctl.advance_invocation(invocation,'CONSUME_STARTED',evidence_ref='fixture:consume-entry')
        p,g,c,b=inputs()
        try:render(p,g,c,replace(b,prompt_digest='sha256:'+'0'*64))
        except ContractError as error:
            # Caller explicitly retains local failure; not part of pure renderer.
            ref=ctl.store.put('fixture:renderer-failure',json.dumps({
                'evidence_class':'SYNTHETIC_MECHANICAL_QA','error':str(error),
                'invocation_ref':invocation,'core_result':None,'publication':False}).encode())
            ctl.finish_invocation(invocation,publication='NONE',evidence_ref=ref.snapshot_ref)
        else:self.fail('mismatched prompt unexpectedly rendered')
        view=ctl.view();self.assertEqual(view['counts']['invocations'],1)
        self.assertEqual(view['counts']['publications'],0)
        self.assertEqual(view['invocations'][invocation]['stage'],'FAILED_BEFORE_PUBLICATION')
        self.assertTrue(view['invocations'][invocation]['settled'])
        self.assertEqual(json.loads(ctl.store.get(ref))['invocation_ref'],invocation)

    def test_prepared_body_does_not_advance_capture_commit_or_publication(self):
        ctl,attempt=self.setup_controller()
        invocation=ctl.receive_help(attempt,logical_resource='WSS-U01-HINT',config_id='G_BASE')
        ctl.advance_invocation(invocation,'CONSUME_STARTED',evidence_ref='fixture:consume-entry')
        before=(ctl.root/'journal/entries.jsonl').read_bytes()
        r=render(*inputs());self.assertEqual(r.trace['status'],'BODY_PREPARED_NOT_PUBLISHED')
        self.assertEqual((ctl.root/'journal/entries.jsonl').read_bytes(),before)
        view=ctl.view();self.assertEqual(view['counts']['publications'],0)
        self.assertEqual(view['invocations'][invocation]['stage'],'CONSUME_STARTED')
        self.assertFalse(view['invocations'][invocation]['settled'])
        # Intentionally retains the unresolved/unpublished caller state.

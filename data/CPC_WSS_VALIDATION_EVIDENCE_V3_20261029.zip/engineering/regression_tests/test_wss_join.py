import itertools
from dataclasses import replace
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

from wss_bridge.join import CoreEntry,NativeMapping,JoinPolicy,analyze,mapping_from_analysis,entries_from_adapter
from wss_bridge.outcomes import Composite,ExternalRow,COMPOSITE_FIELDS
from wss_bridge.primitives import ContractError,plain_json
from wp04_fixtures import digest
from wp07_fixtures import flow,entry_variant,external_mapping,encode


class JoinTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fixture=flow();cls.entry=cls.fixture['entry'];cls.outcome=cls.fixture['outcome']
        cls.policy=JoinPolicy.from_recipe(cls.fixture['recipe'])

    def run_join(self,entries=None,rows=None,mappings=None,policy=None):
        entries=[self.entry] if entries is None else entries
        rows=[self.fixture['external']] if rows is None else rows
        mappings={e.receipt_ref:NativeMapping('ELIGIBLE') for e in entries if e.result is not None and e.result['disposition']=='ADMIT'} if mappings is None else mappings
        return analyze(entries,rows,mappings,self.policy if policy is None else policy,
            cohort_ref='fixture:explicit-cohort',snapshot_ref='fixture:explicit-analysis')

    def test_actual_positive_mapping_and_three_equations(self):
        f=self.fixture;before=f['controller'].store.get(f['analysis'])
        mapping=mapping_from_analysis(f['controller'],f['analysis'],self.entry,f['exposure_raw'])
        self.assertEqual(mapping.status,'ELIGIBLE')
        result=self.run_join(mappings={self.entry.receipt_ref:mapping})
        self.assertEqual(result['core_ledger'][0]['primary_reason'],'JOINED')
        self.assertEqual(result['core_ledger'][0]['value'],2)
        counts=result['counts'];self.assertEqual(counts['received_core'],sum(counts['core_buckets'].values())+counts['unresolved_core'])
        self.assertEqual(counts['core_buckets']['ADMIT'],sum(counts['admitted_mapping'].values()))
        self.assertEqual(counts['admitted_mapping']['ELIGIBLE'],sum(counts['eligible_terminals'].values()))
        self.assertTrue(result['complete_for_declared_snapshot']);self.assertEqual(f['controller'].store.get(f['analysis']),before)
        (Path(os.environ['WSS_TEST_ARTIFACT_ROOT'])/'WP07_POSITIVE_JOIN.json').write_bytes(encode(result))

    def test_held_ADMIT_still_causes_admission_ambiguity_before_native_filter(self):
        second=entry_variant(self.entry,2)
        mappings={self.entry.receipt_ref:NativeMapping('ELIGIBLE'),second.receipt_ref:NativeMapping('HOLD',('HOLD_LATE_EVIDENCE',))}
        result=self.run_join(entries=[self.entry,second],mappings=mappings)
        first,held=result['core_ledger']
        self.assertEqual(first['primary_reason'],'ADMISSION_COMPOSITE_AMBIGUOUS')
        self.assertEqual(held['primary_reason'],'NATIVE_MAPPING_HOLD')
        self.assertIn('ADMISSION_COMPOSITE_AMBIGUOUS',held['reason_flags'])
        self.assertEqual(first['admission_multiplicity'],2)
        self.assertEqual(result['counts']['admitted_mapping'],{'PENDING':0,'HOLD':1,'ELIGIBLE':1})

    def test_invalid_score_duplicate_still_causes_external_ambiguity(self):
        valid=external_mapping(self.outcome);invalid=external_mapping(self.outcome,row_ref='fixture:invalid',value=True)
        result=self.run_join(rows=[valid,invalid]);row=result['core_ledger'][0]
        self.assertEqual(row['primary_reason'],'EXTERNAL_COMPOSITE_AMBIGUOUS')
        self.assertIn('EXTERNAL_MEASURE_INVALID',row['reason_flags']);self.assertEqual(row['external_multiplicity'],2)

    def test_identical_external_refs_and_values_are_not_deduplicated(self):
        row=external_mapping(self.outcome)
        result=self.run_join(rows=[row,row])
        self.assertEqual(result['counts']['external_received'],2)
        self.assertEqual(len(result['external_ledger']),2)
        self.assertEqual(result['core_ledger'][0]['primary_reason'],'EXTERNAL_COMPOSITE_AMBIGUOUS')

    def test_every_bad_scalar_remains_received_and_is_never_default_zero(self):
        values=[True,False,0.0,2.0,'0','4',-1,5,100,None,[],{},float('nan'),float('inf'),'\ud800']
        for value in values:
            with self.subTest(kind=type(value).__name__,value=repr(value)):
                result=self.run_join(rows=[external_mapping(self.outcome,value=value)])
                row=result['core_ledger'][0]
                self.assertEqual(row['primary_reason'],'EXTERNAL_MEASURE_INVALID');self.assertIsNone(row['value'])
                self.assertEqual(result['counts']['external_interpretable'],1)

    def test_all_five_integer_scores_are_valid_including_real_zero(self):
        for score in range(5):
            with self.subTest(score=score):
                row=self.run_join(rows=[external_mapping(self.outcome,value=score)])['core_ledger'][0]
                self.assertEqual(row['primary_reason'],'JOINED');self.assertEqual(row['value'],score)

    def test_forged_typed_bool_cannot_pass_integer_validation(self):
        row=replace(self.fixture['external'],integer_value=True,scalar_type='int')
        self.assertEqual(self.run_join(rows=[row])['core_ledger'][0]['primary_reason'],'EXTERNAL_MEASURE_INVALID')

    def test_direct_typed_metadata_cannot_bypass_external_row_domain(self):
        for changes in [{'lineage_ref':42},{'lineage_ref':True},{'row_ref':None},
                        {'recipe_digest':False},{'rubric_id':1.5},{'shape_valid':1}]:
            with self.subTest(changes=list(changes)):
                row=replace(self.fixture['external'],**changes)
                self.assertEqual(self.run_join(rows=[row])['core_ledger'][0]['primary_reason'],'EXTERNAL_MEASURE_INVALID')

    def test_oversized_infinite_cohort_fails_without_full_materialization(self):
        counter=[]
        def values():
            while True:
                counter.append(1);yield self.entry
        with self.assertRaises(ContractError):self.run_join(entries=values(),mappings={})
        self.assertEqual(len(counter),10001)

    def test_missing_row_is_distinct_from_present_missing_value(self):
        absent=self.run_join(rows=[])['core_ledger'][0]
        present=self.run_join(rows=[external_mapping(self.outcome,value=None,measure_state='MISSING')])['core_ledger'][0]
        self.assertEqual(absent['primary_reason'],'EXTERNAL_MISSING')
        self.assertEqual(present['primary_reason'],'EXTERNAL_MEASURE_INVALID')
        self.assertIn('EXTERNAL_VALUE_MISSING',present['reason_flags']);self.assertIsNone(present['value'])

    def test_rubric_recipe_and_lineage_mismatches_do_not_escape_counting(self):
        for change in [{'rubric_id':'other'},{'rubric_version':'other'},{'recipe_digest':digest(b'other')},
                       {'lineage_ref':None},{'rubric_id':1.5},{'measure_state':False},{'extra':'unsupported'}]:
            with self.subTest(change=list(change)):
                result=self.run_join(rows=[external_mapping(self.outcome,**change)])
                self.assertEqual(result['core_ledger'][0]['primary_reason'],'EXTERNAL_MEASURE_INVALID')
                self.assertEqual(result['counts']['external_interpretable'],1)

    def test_all_seven_composite_fields_are_required_for_exact_join(self):
        original=dict(self.outcome['composite'])
        for name in COMPOSITE_FIELDS:
            with self.subTest(field=name):
                changed={**original,name:digest(b'other') if name=='exposure_digest' else 'fixture:other'}
                self.assertEqual(self.run_join(rows=[external_mapping(self.outcome,composite=changed)])['core_ledger'][0]['primary_reason'],'EXTERNAL_MISSING')
                del changed[name]
                result=self.run_join(rows=[external_mapping(self.outcome,composite=changed)])
                self.assertEqual(result['counts']['external_uninterpretable'],1)
                self.assertEqual(result['core_ledger'][0]['primary_reason'],'EXTERNAL_MISSING')

    def test_composite_preserves_the_pinned_CPC_unicode_identifier_domain(self):
        purpose='fixture:purpose\u200dvalue'
        from cpc2.common import is_identifier
        self.assertTrue(is_identifier(purpose))
        core=entry_variant(self.entry,31,composite_changes={'purpose':purpose})
        key={**self.outcome['composite'],'purpose':purpose}
        result=self.run_join(entries=[core],rows=[external_mapping(self.outcome,composite=key)])
        self.assertEqual(result['core_ledger'][0]['primary_reason'],'JOINED')

    def test_pending_and_hold_precedence_retain_all_independent_flags(self):
        duplicate=entry_variant(self.entry,3)
        rows=[external_mapping(self.outcome,value=False)]*2
        for status,want in [('PENDING','NATIVE_MAPPING_PENDING'),('HOLD','NATIVE_MAPPING_HOLD')]:
            with self.subTest(status=status):
                mappings={e.receipt_ref:NativeMapping(status,('ACTOR_CONTEXT_CONFLICT',),'fixture:head','fixture:head') for e in [self.entry,duplicate]}
                result=self.run_join(entries=[self.entry,duplicate],rows=rows,mappings=mappings)
                flags=result['core_ledger'][0]['reason_flags']
                self.assertEqual(result['core_ledger'][0]['primary_reason'],want)
                for flag in ['ADMISSION_COMPOSITE_AMBIGUOUS','EXTERNAL_COMPOSITE_AMBIGUOUS','EXTERNAL_MEASURE_INVALID','ACTOR_CONTEXT_CONFLICT']:
                    self.assertIn(flag,flags)
                self.assertEqual(result['complete_for_declared_snapshot'],status!='PENDING')

    def test_core_reasons_and_unresolved_ref_are_separate_from_native_join(self):
        entries=[entry_variant(self.entry,i,disposition=d) for i,d in enumerate(['REJECT','QUARANTINE','ERROR_INPUT','ERROR_CONFIG'])]
        entries.append(CoreEntry('fixture:unresolved',None,None))
        result=self.run_join(entries=entries,rows=[],mappings={})
        self.assertEqual([r['primary_reason'] for r in result['core_ledger']],
            ['CORE_REJECT','CORE_QUARANTINE','CORE_ERROR_INPUT','NOT_EVALUATED_CONFIG','CORE_EVALUATION_UNRESOLVED'])
        self.assertEqual(result['counts']['received_core'],5);self.assertEqual(result['counts']['unresolved_core'],1)
        self.assertFalse(result['complete_for_declared_snapshot'])

    def test_superseded_or_unverified_mapping_never_claims_snapshot_complete(self):
        for mapping in [NativeMapping('ELIGIBLE'),NativeMapping('ELIGIBLE',(),'fixture:old','fixture:new')]:
            with self.subTest(mapping=mapping):
                result=self.run_join(mappings={self.entry.receipt_ref:mapping})
                self.assertEqual(result['core_ledger'][0]['primary_reason'],'JOINED')
                self.assertFalse(result['all_mappings_at_current_head']);self.assertFalse(result['complete_for_declared_snapshot'])
        self.assertFalse(self.run_join(mappings={})['all_mappings_at_current_head'])

    def test_omitted_mapping_is_pending_and_no_fake_disposition(self):
        result=self.run_join(mappings={});row=result['core_ledger'][0]
        self.assertEqual(row['primary_reason'],'NATIVE_MAPPING_PENDING');self.assertEqual(row['core_disposition'],'ADMIT')
        self.assertFalse(result['complete_for_declared_snapshot'])

    def test_uninterpretable_external_rows_remain_in_their_ledger(self):
        result=self.run_join(rows=[{'bad':'row'},False,external_mapping(self.outcome)])
        self.assertEqual(result['counts']['external_received'],3)
        self.assertEqual(result['counts']['external_uninterpretable'],2)
        self.assertEqual(result['core_ledger'][0]['primary_reason'],'JOINED')

    def test_invalid_mapping_and_duplicate_core_receipt_ids_fail_explicitly(self):
        with self.assertRaises(ContractError):NativeMapping('ELIGIBLE',('HOLD_LATE_EVIDENCE',))
        with self.assertRaises(ContractError):self.run_join(entries=[self.entry,self.entry])
        with self.assertRaises(ContractError):self.run_join(mappings={'outside':NativeMapping('ELIGIBLE')})

    def test_input_order_invariance_and_no_mutation(self):
        a=entry_variant(self.entry,10);b=entry_variant(self.entry,11)
        rows=[external_mapping(self.outcome),external_mapping(self.outcome,value='bad')]
        frozen=encode(self.outcome)
        for entries in [[a,b],[b,a]]:
            for external in [rows,list(reversed(rows))]:
                result=self.run_join(entries=entries,rows=external)
                self.assertEqual(result['counts']['eligible_terminals']['ADMISSION_COMPOSITE_AMBIGUOUS'],2)
                self.assertTrue(all('EXTERNAL_COMPOSITE_AMBIGUOUS' in r['reason_flags'] for r in result['core_ledger']))
        self.assertEqual(encode(self.outcome),frozen)

    def test_pure_analysis_reads_or_writes_no_files(self):
        root=self.fixture['root'];payload={'core':plain_json(self.entry.result),'external':external_mapping(self.outcome),
            'recipe':self.fixture['recipe'].data}
        file=root/'pure_join_input.json';file.write_bytes(encode(payload))
        code='''import sys,json
sys.path.insert(0,sys.argv[1])
from wss_bridge.join import CoreEntry,NativeMapping,JoinPolicy,analyze
data=json.loads(open(sys.argv[2]).read())
entry=CoreEntry('fixture:pure',data['core']['input_ref'],data['core'])
policy=JoinPolicy(data['recipe']['rubric_id'],data['recipe']['rubric_version'],data['external']['recipe_digest'])
def no_io(event,args):
 if event=='open' or event.startswith(('socket.','subprocess.','sqlite3.')):raise PermissionError('join IO forbidden')
sys.addaudithook(no_io)
r=analyze([entry],[data['external']],{entry.receipt_ref:NativeMapping('ELIGIBLE')},policy,cohort_ref='fixture:pure',snapshot_ref='fixture:pure')
assert r['core_ledger'][0]['primary_reason']=='JOINED'
print('PURE_JOIN_NO_IO_PASS')
'''
        result=subprocess.run([sys.executable,'-I','-B','-c',code,str(Path(os.environ['WSS_CODE_ROOT'])/'src'),str(file)],
            capture_output=True,text=True,timeout=30)
        (root/'pure_join_stdout.txt').write_text(result.stdout);(root/'pure_join_stderr.txt').write_text(result.stderr)
        self.assertEqual(result.returncode,0,result.stderr)

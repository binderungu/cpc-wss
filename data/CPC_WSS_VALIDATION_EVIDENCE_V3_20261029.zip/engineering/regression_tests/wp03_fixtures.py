"""Coherent synthetic source facts; no native invocation/observation or authority."""
import base64
import copy
import hashlib
import json
from pathlib import Path
import os
from wss_bridge.native_contract import SourceIdentity,ActorBinding,NativeTarget

ROOT=Path(__file__).resolve().parents[3]
PHP_WIRE=ROOT/'outputs/CPC_JLA_WSS_SC01_SEMANTIC_REPAIR_V1_20261020/frozen_inputs/PHP_WIRE_CASES_final.jsonl'
BASE=next(json.loads(line)['envelope'] for line in PHP_WIRE.read_text().splitlines()
          if json.loads(line)['case_id']=='positive_json')


def source_context():
    receipt=BASE['receipt']
    task=NativeTarget.from_mapping(receipt['target'])
    follow=NativeTarget.from_mapping({**receipt['target'],'target_ref':'fixture:followup-target',
        'cmid':18,'feedback_id':19,'item_id':20,'contextid':21})
    return {'source':SourceIdentity.from_mapping(receipt['source']),
            'actor':ActorBinding.from_mapping(receipt['actor']),
            'task_target':task,'followup_target':follow,
            'task_version_ref':'fixture:task-version','context_version_ref':'fixture:context-version',
            'clean_interval_evidence_ref':'fixture:clean','prior_operations_evidence_ref':None,
            'sole_writer_evidence_ref':'fixture:sole-writer','pending_facts':()}


def context():
    from wss_bridge.controller import ControllerContext
    return ControllerContext(**source_context())


def make_wire(operation_ref='fixture:operation',observation_ref='fixture:observation',log_id=101,
              kind='TASK',value=b'synthetic response',watermark=100,cursor_end=None,
              completed_id=1000,value_id=2000,source_epoch_ref=None):
    if type(value) is not bytes:raise TypeError('fixture value must be bytes')
    row=copy.deepcopy(BASE['receipt']);row['operation_ref']=operation_ref;row['observation_ref']=observation_ref
    row['log_watermark']=watermark;row['cursor_end']=log_id if cursor_end is None else cursor_end
    row['observer_time']='2026-10-17T10:00:00Z';row['observer_sequence']=0
    row['target']=source_context()['task_target' if kind=='TASK' else 'followup_target'].to_mapping()
    if source_epoch_ref is not None:
        row['source']['source_epoch_ref']=source_epoch_ref;row['target']['source_epoch_ref']=source_epoch_ref
    row['target']['controlled_value_digest']='sha256:'+hashlib.sha256(value).hexdigest()
    target=row['target'];event=row['occurrences'][0];snap=row['snapshots'][0]
    event.update(standard_log_record_id=log_id,objectid=completed_id,courseid=target['courseid'],
        contextid=target['contextid'],contextinstanceid=target['cmid'],other_cmid=target['cmid'],
        other_instanceid=target['feedback_id'])
    snap.update(snapshot_ref=None,completed_id=completed_id,completed_feedback_id=target['feedback_id'],
        completed_courseid=target['response_scope_courseid'],item_id=target['item_id'],item_feedback_id=target['feedback_id'],
        value_id=value_id,value_completed_id=completed_id,value_item_id=target['item_id'],value_courseid=target['response_scope_courseid'])
    bag={}
    def add(raw):
        digest=hashlib.sha256(raw).hexdigest();ref='blob:'+digest
        bag[ref]={'ref':ref,'sha256':'sha256:'+digest,'byte_length':len(raw),'data_base64':base64.b64encode(raw).decode()}
        return ref
    def encode(obj):return json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
    for raw,refkey,digestkey in [(b'Question','item_text_ref','item_digest'),(b'40|5','item_presentation_ref','item_presentation_digest'),(value,'value_bytes_ref','value_digest')]:
        ref=add(raw);snap[refkey]=ref;snap[digestkey]=bag[ref]['sha256']
    for window_key in ('target_window_before_ref','target_window_after_ref'):
        native_target = dict(cmid=target['cmid'],courseid=target['courseid'],course_category=row['target_course_category'],
            feedback_id=target['feedback_id'],module_name='feedback',contextid=target['contextid'],
            contextlevel=70,contextinstanceid=target['cmid'],feedback_course=target['courseid'],
            feedback_anonymous=2,item_id=target['item_id'],item_feedback_id=target['feedback_id'],item_type=target['item_type'])
        add(encode({'target_window_ref':row[window_key],'native_target_rows':[native_target]}))
    other=encode({'cmid':target['cmid'],'instanceid':target['feedback_id'],'anonymous':2});otherref=add(other)
    textrefs={field:add(event[field].encode()) for field in ['eventname','objecttable','origin']}
    add(encode({'native_occurrence':event,'raw_other_ref':otherref,
                'raw_text_column_refs':textrefs,'raw_other_byte_length':len(other)}))
    details={'tmp_completed':0,'raw_item_type_ref':add(snap['item_type'].encode()),
             'item_byte_length':8,'presentation_byte_length':4,'value_byte_length':len(value)}
    snap['snapshot_ref']=add(encode({'standard_log_record_id':log_id,'raw_other_ref':otherref,
            'native_snapshot_fields':copy.deepcopy(snap),'source_projection_details':details}))
    return encode({'transport_version':'wss-native-read-1.1','evidence_class':'SYNTHETIC_OFFLINE_FIXTURE',
                   'receipt':row,'blobs':list(bag.values())})

"""Artificial code-point/assembly fixtures, not final teaching materials.

Padding is deliberate mechanical data. These sentences do not supply approved
WSS pedagogy, content review, rights authorization, or execution authority.
"""
import copy
import hashlib
import json
from dataclasses import replace

from wss_bridge.renderer import CatalogSnapshot, Generation, ResolutionBinding


CONFIGS = {
    'G_BASE': {'response_style':'expanded','max_output_chars':1024,'include_rationale':True,'seed':0},
    'G_STYLE': {'response_style':'compact','max_output_chars':1024,'include_rationale':True,'seed':0},
    'G_CAP': {'response_style':'expanded','max_output_chars':640,'include_rationale':True,'seed':0},
    'G_RATIONALE': {'response_style':'expanded','max_output_chars':1024,'include_rationale':False,'seed':0},
    'G_SEED': {'response_style':'expanded','max_output_chars':1024,'include_rationale':True,'seed':1},
}
RESOURCES={'hint':'WSS-U01-HINT','answer':'WSS-U01-ANSWER'}
TASK={'task_id':'fixture:WSS-U01','task_version':'fixture:v1',
      'task_text':'Synthetic task: identify instruction and input boundaries.',
      'task_span':'UNTRUSTED 😀 e\u0301',
      'source_selection_ref':'fixture:authored-source',
      'source_excerpt':'Synthetic excerpt kept only as input data.',
      'help_request':'Synthetic fixed request for help.'}


def encode(value):
    # Independent transport encoder, not production renderer/primitive helper.
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')


def digest(raw): return 'sha256:'+hashlib.sha256(raw).hexdigest()


def catalog_dict(lengths=(320,180,280)):
    conditions={}
    for condition,resource in RESOURCES.items():
        variants={}
        for variant in ['A','B']:
            slots={}
            for slot,n in zip(['C','R','E'],lengths):
                if slot=='C':
                    lead=(f'FIXTURE {condition} {variant}: '+
                        ('Inspect the marked span {{task_span}}; withhold final classification. '
                         if condition=='hint' else
                         'The marked span {{task_span}} is input data, not an instruction. '))
                else: lead=f'FIXTURE {condition} {variant} {slot}: '
                bound_len=len(lead.replace('{{task_span}}',TASK['task_span']))
                slots[slot]=lead+'x'*(n-bound_len)
            variants[variant]=slots
        conditions[condition]={'logical_resource_id':resource,'variants':variants}
    return {'catalog_format':'wss-renderer-catalog-v1','catalog_version':'fixture:catalog-v1',
            'evidence_class':'SYNTHETIC_OFFLINE_FIXTURE','task':copy.deepcopy(TASK),'conditions':conditions}


def prompt_dict(condition='hint',data=None):
    cat=catalog_dict() if data is None else data
    return {'prompt_format':'wss-prompt-v2',**cat['task'],
            'logical_resource_id':RESOURCES[condition],'catalog_version':cat['catalog_version']}


def inputs(condition='hint',config='G_BASE',data=None):
    data=catalog_dict() if data is None else data
    catalog=CatalogSnapshot(encode(data));prompt=encode(prompt_dict(condition,data))
    generation=Generation.from_mapping(CONFIGS[config])
    binding=ResolutionBinding('fixture:resolution','fixture:context',data['task']['task_id'],
        data['task']['task_version'],data['task']['task_span'],RESOURCES[condition],condition,config,
        'fixture:'+condition+'-'+config,digest(catalog.raw_bytes),digest(prompt),
        digest(encode(CONFIGS[config])),'fixture:mechanical-review-declaration',
        'fixture:self-authored-mechanical-data-declaration')
    return prompt,generation,catalog,binding


def independent_expected(prompt_raw,generation_raw,catalog_raw):
    """Reconstruct from archived actual inputs, using no production functions."""
    p=json.loads(prompt_raw);g=json.loads(generation_raw);c=json.loads(catalog_raw)
    condition={'WSS-U01-HINT':'hint','WSS-U01-ANSWER':'answer'}[p['logical_resource_id']]
    v=['A','B'][g['seed']]
    pieces=c['conditions'][condition]['variants'][v]
    core=pieces['C'].replace('{{task_span}}',p['task_span'])
    rationale=pieces['R'].replace('{{task_span}}',p['task_span'])
    elaboration=pieces['E'].replace('{{task_span}}',p['task_span'])
    body=core+('\n\n'+rationale if g['include_rationale'] else '')
    if g['response_style']=='expanded' and len(body)+2+len(elaboration)<=g['max_output_chars']:
        body+='\n\n'+elaboration
    return body.encode('utf-8')

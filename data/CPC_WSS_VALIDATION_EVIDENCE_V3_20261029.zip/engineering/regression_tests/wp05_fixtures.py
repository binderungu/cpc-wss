"""New WP05 synthetic QA-only policy and supplied assertions, never authority.

No historical profile/key material is promoted to current WSS evidence. Fixtures
reuse only the artificial WP04 padding task and WP03 synthetic wire interface.
"""
from datetime import datetime, timedelta, timezone
from dataclasses import replace
import hashlib
import hmac
import json
import os
from pathlib import Path
import tempfile

from wss_bridge.controller import OfflineController
from wss_bridge.ledger import LedgerScope
from wss_bridge.producer import ProducerPolicy
from wp03_fixtures import context, make_wire
from wp04_fixtures import inputs, CONFIGS, RESOURCES, encode, digest, TASK

KEYS={role+'-key':('SYNTHETIC_ONLY_WP05_'+role.upper()).encode() for role in
      ['assignment','resolver','runtime','outcome','observer']}


def utc(value): return value.astimezone(timezone.utc).isoformat(timespec='microseconds')


def sign(value,issuer,profile,*,proof=False):
    # Independent stdlib oracle; never calls producer._sign/integrity helpers.
    digest_value=digest(encode(value));key=profile['issuer_key_policy'][issuer]
    integrity={'algorithm':'HMAC-SHA256','key_id':key,'content_digest':digest_value,
        'mac':'hmac-sha256:'+hmac.new(KEYS[key],digest_value.encode('ascii'),hashlib.sha256).hexdigest()}
    return {'body':value,'integrity':integrity} if proof else {**value,'integrity':integrity}


def policy_data(now=None):
    now=datetime.now(timezone.utc) if now is None else now
    registry={};mapping={}
    for condition,resource in RESOURCES.items():
        mapping[resource]={}
        for config in CONFIGS:
            p,g,c,b=inputs(condition,config);bundle=b.bundle_ref;mapping[resource][config]=bundle
            vector={name:{'version':'fixture:WP05-declared-'+name,'digest':digest(('WP05-declared-'+name).encode()),
                'evidence_mode':'declared'} for name in ['ui','corpus','retriever','index','model','policy']}
            vector.update(prompt={'version':'fixture:WP05-prompt-v1','digest':digest(p),'evidence_mode':'measured'},
                generation={'version':'fixture:WP05-generation-'+config,'digest':digest(g.canonical_bytes),'evidence_mode':'measured'})
            registry[bundle]=vector
    profile={'profile_id':'fixture:WP05-profile','profile_version':'fixture:1','contract_version':'2.0.1',
        'schema_version':'cpc-2.0.1','experiment_id':'fixture:WP05-mechanical','experiment_version':'fixture:1',
        'expected_audience':'fixture:local-QA','deployment_id':'fixture:offline-only','context_id':'fixture:context',
        'scope':'fixture:synthetic-offline','assignment_policy_version':'fixture:assignment-v1',
        'resolver_version':'fixture:resolver-v1','mapping_version':'fixture:mapping-v1',
        'consent_policy_version':'fixture:consent-declaration-v1','observer_clock_id':'fixture:WP05-clock',
        'release_boundary':'durable_local_response_file','profile_state':'frozen',
        'freeze_timestamp':utc(now-timedelta(minutes=2)),'conditions':['hint','answer'],
        'resource_condition_map':{r:c for c,r in RESOURCES.items()},
        'namespace_policy':{'fixture.condition':{'role':'authoritative','required':True,'mapping':{'H':'hint','A':'answer'}}},
        'record_issuers':{'assignment':'fixture:assignment','resolution':'fixture:resolver','exposure':'fixture:runtime','outcome':'fixture:outcome'},
        'proof_issuers':{'launch_attestation':'fixture:assignment','usage_attestation':'fixture:observer',
            'commitment':'fixture:runtime','release_attestation':'fixture:observer'},
        'issuer_key_policy':{'fixture:'+r:r+'-key' for r in ['assignment','resolver','runtime','outcome','observer']},
        'permitted_purposes':['fixture:mechanical-only'],'consent_authority_refs':['fixture:not-human-consent'],
        'artifact_registry':registry,'required_measured_components':['prompt','generation'],
        'component_canonicalizations':{'prompt':'raw-bytes consumed','generation':'cpc-json-v2 object consumed'},
        'fallback_permissions':{},'extension_keys':[],'privacy_denylist':['email'],
        'input_limits':{'max_bytes':1048576,'max_records':16,'max_depth':32,'max_identifier_chars':256}}
    return profile,mapping,utc(now-timedelta(minutes=1)),utc(now+timedelta(hours=1)),utc(now)


def policy_from(data,ctx=None,**overrides):
    p,m,valid,expiry,now=data
    ctx=context() if ctx is None else ctx
    extra={'controller_context_digest':digest(encode(ctx.to_mapping())),
           'task_id':TASK['task_id'],'task_version':TASK['task_version'],**overrides}
    return ProducerPolicy(encode(p),encode(m),KEYS,valid,expiry,now,**extra)


def resolution(policy,attempt,condition='hint',*,modify=None):
    p=json.loads(policy.profile_raw);now=datetime.now(timezone.utc)
    common={k:p[k] for k in ['contract_version','profile_id','profile_version','experiment_id','experiment_version','deployment_id','context_id']}
    common.update(unit_token=attempt,audience=p['expected_audience'],valid_from=policy.valid_from,expires_at=policy.expires_at)
    launch={**common,'proof_id':'fixture:WP05-launch','issuer':'fixture:assignment',
        'issued_at':utc(now-timedelta(seconds=4)),'assignment_record_id':'fixture:prospective-assignment',
        'assignment_digest':digest(b'fixture:upstream-assignment-declaration'),
        'resource_id':RESOURCES[condition],'launch_nonce':'fixture:launch-nonce',
        'namespace_values':{'fixture.condition':'H' if condition=='hint' else 'A'}}
    value={**common,'schema_version':'cpc-2.0.1','record_id':'fixture:resolution','record_type':'resolution',
        'issuer':'fixture:resolver','nonce':'fixture:resolution-nonce','issued_at':utc(now-timedelta(seconds=3)),
        'predecessor_record_id':launch['assignment_record_id'],'predecessor_digest':launch['assignment_digest'],
        'payload':{'requested_condition':condition,'resolved_condition':condition,'claim_namespaces':dict(launch['namespace_values']),
            'resolver_version':p['resolver_version'],'fallback_used':False,'fallback_authorized':False,'authorization_ref':None,
            'launch_nonce':launch['launch_nonce'],'launch_attestation':sign(launch,'fixture:assignment',p,proof=True)}}
    if modify:modify(value)
    return encode(sign(value,'fixture:resolver',p))


def setup(condition='hint',config='G_BASE',*,data=None):
    root=Path(tempfile.mkdtemp(prefix='wp05-',dir=os.environ['WSS_TEST_ARTIFACT_ROOT']))
    ctx=context();scope=LedgerScope('fixture:wp05-ledger','fixture:wp05-run','SYNTHETIC_OFFLINE_FIXTURE',ctx.source.source_epoch_ref)
    ctl=OfflineController.create(root/'workflow',scope,ctx)
    op=ctl.begin_operation(ctl.opportunity(note_ref='fixture:opportunity'),'TASK',
        controlled_value_digest=digest(b'synthetic response'),log_watermark=100,
        logical_resource=RESOURCES[condition],config_id=config)
    ctl.record_completion(op,known=True,evidence_ref='fixture:completion')
    ack=ctl.observe(op,0,make_wire(operation_ref=op));attempt=ack['anchor']['attempt_ref']
    policy=policy_from(policy_data() if data is None else data,ctx=ctx)
    prompt,generation,catalog,binding=inputs(condition,config)
    return ctl,attempt,{'logical_resource':RESOURCES[condition],'config_id':config,'root':root/'producer',
        'policy':policy,'resolution_raw':resolution(policy,attempt,condition),
        'prompt_raw':prompt,'generation_raw':generation.canonical_bytes,'catalog':catalog,'binding':binding}


def snapshots(root):
    return [(p,p.read_bytes()) for p in sorted((Path(root)/'snapshots').glob('*.bin'))]


def objects(root):
    result=[]
    for path,raw in snapshots(root):
        try:result.append((path,json.loads(raw)))
        except (ValueError,UnicodeError):pass
    return result

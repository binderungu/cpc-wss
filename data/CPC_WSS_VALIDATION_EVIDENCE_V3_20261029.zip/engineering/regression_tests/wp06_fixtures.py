"""Metadata-only chain assertions for mechanical WP06 QA, not WP07 outcomes.

No native or learner outcomes are measured. Assignment/outcome records here are
new synthetic signed assertions around the actual new WP05 exposure.
"""
from datetime import datetime,timedelta,timezone
import json
from pathlib import Path
import uuid

from wss_bridge.producer import produce
from wp05_fixtures import setup,sign,utc,KEYS
from wp04_fixtures import encode,digest


def full_chain(condition='hint',config='G_BASE'):
    controller,attempt,args=setup(condition,config)
    profile=json.loads(args['policy'].profile_raw)
    resolution=json.loads(args['resolution_raw'])
    launch=resolution['payload']['launch_attestation']['body']
    common={k:resolution[k] for k in ['contract_version','profile_id','profile_version','schema_version',
        'experiment_id','experiment_version','unit_token','audience','deployment_id','context_id','valid_from','expires_at']}
    assignment={**common,'record_id':launch['assignment_record_id'],'record_type':'assignment',
        'issuer':profile['record_issuers']['assignment'],'nonce':'fixture:wp06-assignment-nonce',
        'issued_at':utc(datetime.fromisoformat(launch['issued_at'])-timedelta(seconds=1)),
        'predecessor_record_id':None,'predecessor_digest':None,
        'payload':{'assigned_condition':condition,'assignment_policy_version':profile['assignment_policy_version'],
            'scope':profile['scope'],'resource_id':args['logical_resource'],'launch_nonce':launch['launch_nonce']}}
    assignment=sign(assignment,assignment['issuer'],profile)
    launch['assignment_digest']=assignment['integrity']['content_digest']
    resolution['predecessor_digest']=assignment['integrity']['content_digest']
    resolution['payload']['launch_attestation']=sign(launch,launch['issuer'],profile,proof=True)
    resolution=sign({k:v for k,v in resolution.items() if k!='integrity'},resolution['issuer'],profile)
    args['resolution_raw']=encode(resolution)
    production=produce(controller,attempt,**args)
    if production.status!='COMPLETE':raise AssertionError('WP05 fixture production failed: '+str(production))
    ref=production.exposure_reference
    file=Path(args['root'])/'snapshots'/(__import__('hashlib').sha256(ref.snapshot_ref.encode()).hexdigest()+'.bin')
    exposure=json.loads(file.read_bytes())
    outcome={**common,'record_id':'fixture:wp06-outcome-'+uuid.uuid4().hex,'record_type':'outcome',
        'issuer':profile['record_issuers']['outcome'],'nonce':'fixture:wp06-outcome-nonce',
        'issued_at':utc(datetime.now(timezone.utc)),
        'predecessor_record_id':exposure['record_id'],'predecessor_digest':exposure['integrity']['content_digest'],
        'payload':{'exposure_record_id':exposure['record_id'],'exposure_digest':exposure['integrity']['content_digest'],
            'attributed_condition':condition,'outcome_key':'fixture:metadata-only-outcome',
            'consent_state':'consented','consent_at':args['policy'].valid_from,
            'consent_authority_ref':profile['consent_authority_refs'][0],
            'consent_policy_version':profile['consent_policy_version'],
            'purpose':profile['permitted_purposes'][0],'eligible':True}}
    outcome=sign(outcome,outcome['issuer'],profile)
    chain={'contract_version':'2.0.1','profile_id':profile['profile_id'],'profile_version':profile['profile_version'],
        'case_id':'fixture:wp06-'+condition+'-'+config,'records':[assignment,resolution,exposure,outcome]}
    (args['root'].parent/'WP06_CHAIN.json').write_bytes(encode(chain))
    now=utc(datetime.now(timezone.utc))
    return chain,profile,KEYS,now,args


def re_sign_outcome(chain,profile,**changes):
    value=json.loads(encode(chain));old=value['records'][-1]
    old['payload'].update(changes)
    value['records'][-1]=sign({k:v for k,v in old.items() if k!='integrity'},old['issuer'],profile)
    return value

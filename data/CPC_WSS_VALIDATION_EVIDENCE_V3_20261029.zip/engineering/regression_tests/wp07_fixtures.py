"""Fresh synthetic WP03–07 flow; no native service, final rubric or learning.

The wrapper observes an actual WP05 call from the inherited WP06 fixture to
retain its writable controller. It does not replace its output or admission.
"""
from datetime import datetime, timezone
from pathlib import Path
import json
from collections.abc import Mapping
from unittest.mock import patch

from wss_bridge.producer import produce
from wss_bridge.outcomes import OutcomeRecipe,OutcomeStore,external_from_outcome
from wss_bridge.cpc_adapter import AdmissionContext,CPCAdapter
from wss_bridge.join import CoreEntry,entries_from_adapter
from wp03_fixtures import make_wire
from wp04_fixtures import digest
from wp05_fixtures import sign,utc,policy_data
import wp06_fixtures

RESPONSES={'no boundary evidence':0,'identifies one boundary':1,'separates input and instruction':2,
           'explains both boundaries':3,'explains and checks the rule':4}


def encode(value):
    # Test-only independent JSON transport, supporting immutable Mapping/tuples.
    # No production scoring/serialization helper used as a reconstruction oracle.
    def plain(item):
        if isinstance(item,Mapping):return {k:plain(v) for k,v in item.items()}
        if isinstance(item,(tuple,list)):return [plain(v) for v in item]
        return item
    return json.dumps(plain(value),ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')


def followup(controller,attempt,value,*,log_id=102,watermark=101):
    op=controller.begin_operation(controller.opportunity(note_ref='fixture:wp07-followup'),'FOLLOWUP',
        controlled_value_digest=digest(value),log_watermark=watermark,attempt_ref=attempt)
    controller.record_completion(op,known=True,evidence_ref='fixture:wp07-completion')
    ack=controller.observe(op,0,make_wire(operation_ref=op,kind='FOLLOWUP',log_id=log_id,
        watermark=watermark,value=value,completed_id=1001,value_id=2001))
    return ack,op


def make_recipe(controller,**changes):
    target=controller.context.followup_target
    data={'format':'wss-response-recipe-v1','rubric_id':'fixture:WP07-boundary-rubric','rubric_version':'fixture:1',
        'task_version_ref':controller.context.task_version_ref,'followup_item_digest':target.item_digest,
        'followup_presentation_digest':target.item_presentation_digest,
        'review_ref':'fixture:mechanical-review-declaration','rights_ref':'fixture:self-authored-QA-declaration',
        'responses':RESPONSES,**changes}
    return OutcomeRecipe(encode(data))


def flow(response=b'separates input and instruction',*,do_followup=True,extra=None,unicode_context=False):
    observed={}
    def actual(controller,attempt,**args):
        observed.update(controller=controller,attempt=attempt)
        return produce(controller,attempt,**args)
    actual_setup=wp06_fixtures.setup
    def configured_setup(*setup_args,**setup_kwargs):
        if not unicode_context:return actual_setup(*setup_args,**setup_kwargs)
        data=policy_data();data[0]['experiment_id']='fixture:experiment\u200dopaque'
        data[0]['permitted_purposes']=['fixture:purpose\u200dopaque']
        return actual_setup(*setup_args,data=data,**setup_kwargs)
    with patch.object(wp06_fixtures,'produce',side_effect=actual),patch.object(wp06_fixtures,'setup',side_effect=configured_setup):
        chain,profile,keys,_,args=wp06_fixtures.full_chain()
    controller,attempt=observed['controller'],observed['attempt']
    root=args['root'].parent
    exposure_raw=encode(chain['records'][2])
    if extra=='failed-retry':
        inv=controller.receive_help(attempt,logical_resource='WSS-U01-HINT',config_id='G_BASE')
        controller.finish_invocation(inv,publication='NONE',evidence_ref='fixture:known-failure')
    elif extra=='unknown-retry':
        inv=controller.receive_help(attempt,logical_resource='WSS-U01-HINT',config_id='G_BASE')
        controller.finish_invocation(inv,publication='UNRESOLVED',evidence_ref='fixture:unknown-publication')
    elif extra=='second-publication':
        more={**args,'root':root/'second-producer'}
        result=produce(controller,attempt,**more)
        if result.status!='COMPLETE':raise AssertionError('second synthetic publication failed')
    if do_followup:followup(controller,attempt,response)
    analysis=controller.analysis_snapshot(reason='WP07_SYNTHETIC_QA')
    recipe=make_recipe(controller);store=OutcomeStore.create(root/'wp07-outcomes','fixture:wp07-run')
    outcome=None
    if do_followup:
        outcome=store.derive(controller,analysis,exposure_raw,recipe,profile['permitted_purposes'][0])
        rawout={k:v for k,v in chain['records'][-1].items() if k!='integrity'}
        rawout['issued_at']=utc(datetime.now(timezone.utc))
        rawout['payload']['outcome_key']=outcome['composite']['outcome_key']
        chain['records'][-1]=sign(rawout,rawout['issuer'],profile)
    now=utc(datetime.now(timezone.utc));raw=encode(chain)
    (root/'WP07_CHAIN.json').write_bytes(raw)
    adapter=CPCAdapter.create(root/'wp07-admission',AdmissionContext(profile,keys,now),'fixture:wp07-core')
    result=adapter.evaluate(raw,input_ref='fixture:wp07-input')
    if result.result is None or result.result['disposition']!='ADMIT':
        raise AssertionError('new synthetic chain did not admit: '+str(result))
    entry=entries_from_adapter(adapter.view())[0]
    return {'controller':controller,'attempt':attempt,'analysis':analysis,'recipe':recipe,'store':store,
        'outcome':outcome,'external':None if outcome is None else external_from_outcome(outcome),
        'entry':entry,'exposure_raw':exposure_raw,'root':root,'adapter':adapter}


def entry_variant(entry,number,*,disposition='ADMIT',composite_changes=None):
    # Pure join unit fixture, not an additional actual core decision.
    result=json.loads(encode(entry.result));ref='fixture:unit-core-'+str(number)
    result.update(input_ref=ref,disposition=disposition)
    if disposition=='ADMIT':
        result['admitted_record']['input_ref']=ref
        result['admitted_record'].update(composite_changes or {})
    else:result['admitted_record']=None
    return CoreEntry('fixture:unit-receipt-'+str(number),ref,result)


def external_mapping(outcome,**changes):
    keys=['row_ref','composite','value','measure_state','rubric_id','rubric_version','recipe_digest','lineage_ref']
    return {**{key:outcome[key] for key in keys},**changes}

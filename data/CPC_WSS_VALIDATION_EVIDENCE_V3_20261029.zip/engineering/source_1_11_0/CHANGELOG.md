# Source1.9.0

Prospective append-only typed-reference index for producer snapshots, including
the former seven missing root references and consume/body/failure artifacts.
Exact owner-bound reporting reader; crash gaps/nonregular/corrupt data fail closed.
No existing artifact rewritten/backfilled/deleted and no CPC/schema/rule change.

## 1.10.0 — SC01, 2026-10-20
Explicit ordinary-course response scope0; source course.category gate (ninth table); strict float preservation; transport1.1/controller2/capture2; parent1.9.0 retained unchanged.

# Source1.11.0: complete supplied-evidence offline worked runner

See docs/worked_runner.md for the new executable orchestration API and safe CLI. Native connector/study execution, human content/rights/scientific approval and public release are not supplied. Parent1.10.0 mechanics remain except the explicit backwards-compatible producer reservation extension. Exact verification receipts are outside source in outputs/CPC_JLA_WSS_WORKED_RUNNER_OFFLINE_V1_20261025.

---

# WSS source 1.10.0 — SC01 response-scope repair

Separates positive context course IDs from explicit ordinary-course response scope 0.
Adds observed course category, source `course` table projection and site-route rejection.
Transport1.1/controller-v2/capture-v2 are incompatible with unreviewed legacy records.
No silent history migration, new source observations, native access or manuscript changes.

Normative repair contract: docs/sc01_response_scope.md. Final offline verification:
outputs/CPC_JLA_WSS_SC01_SEMANTIC_REPAIR_V1_20261020/.
Four D2 remain unmitigated. Native/JLA/G0 boundaries remain unchanged.

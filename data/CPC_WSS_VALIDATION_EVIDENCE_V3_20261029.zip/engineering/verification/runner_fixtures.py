"""SYNTHETIC_OFFLINE_ENGINEERING_TEST ports; no learner/native execution.

Only inherited SC01 synthetic wire/context and artificial padding are reused.
No setup/full_chain wrapper is called: the runner owns its single controller.
"""
from dataclasses import replace
from datetime import datetime, timedelta, timezone
import json

from wss_bridge.cpc_adapter import AdmissionContext
from wss_bridge.ledger import LedgerScope
from wss_bridge.outcomes import OutcomeRecipe
from wss_bridge.worked_runner import (EpisodePlan, HelpInputs, ObservationInput,
    OperationInput, RunnerConfig, RunnerPorts)
from wp03_fixtures import context, make_wire
from wp04_fixtures import inputs, digest, encode, RESOURCES
from wp05_fixtures import policy_data, policy_from, resolution, sign, utc, KEYS

SOURCE_LABEL = 'SYNTHETIC_OFFLINE_ENGINEERING_TEST'
TASK_VALUE = b'synthetic response'
FOLLOWUP_VALUE = b'separates input and instruction'


class SyntheticPorts:
    """Independent external byte/signing oracle with explicit fault injection."""
    def __init__(self, specs=(('hint', 'G_BASE', 1), ('answer', 'G_BASE', 1),
                              ('hint', 'G_BASE', 2)), *, operation_fault=None,
                 help_fault=None, outcome_fault=None, operation_probe=None):
        self.context = context()
        self.data = policy_data()
        self.profile = self.data[0]
        self.policy = policy_from(self.data, self.context)
        self.operation_fault = operation_fault
        self.help_fault = help_fault
        self.outcome_fault = outcome_fault
        self.operation_probe = operation_probe
        self.operations = []
        self.helps = []
        self.outcomes = []
        self.admissions = 0
        self.returned_raw = []
        episodes = tuple(EpisodePlan('synthetic:runner:E'+str(i), RESOURCES[condition], config,
            digest(TASK_VALUE), digest(FOLLOWUP_VALUE), publications, 1)
            for i, (condition, config, publications) in enumerate(specs, 1))
        self.config = RunnerConfig(LedgerScope('synthetic:runner-ledger', 'synthetic:runner-run',
            'SYNTHETIC_OFFLINE_FIXTURE', self.context.source.source_epoch_ref), self.context,
            episodes, self.profile['permitted_purposes'][0], max_operations=max(6, len(episodes)*2),
            max_observations=max(18, len(episodes)*6),
            max_publications=max(4, sum(e.publications for e in episodes)))
        target = self.context.followup_target
        self.recipe = OutcomeRecipe(encode({'format':'wss-response-recipe-v1',
            'rubric_id':'synthetic:runner-rubric','rubric_version':'synthetic:1',
            'task_version_ref':self.context.task_version_ref,
            'followup_item_digest':target.item_digest,
            'followup_presentation_digest':target.item_presentation_digest,
            'review_ref':'synthetic:engineering-review-declaration',
            'rights_ref':'synthetic:self-authored-padding-declaration',
            'responses':{'separates input and instruction':2}}))
        self.ports = RunnerPorts(self.operation, self.help_inputs, self.sign_outcome,
                                 self.admission_context, self.recipe)

    def operation(self, request):
        self.operations.append(request)
        if self.operation_probe:
            self.operation_probe(request)
        count = len(self.operations)
        raw = make_wire(request.operation_ref, 'synthetic:observation:'+str(count),
            log_id=100+count, kind=request.kind,
            value=TASK_VALUE if request.kind == 'TASK' else FOLLOWUP_VALUE,
            watermark=request.log_watermark, completed_id=1000+count, value_id=2000+count)
        fault = self.operation_fault if count == 1 else None
        if fault == 'accepted_then_wait':
            row = json.loads(raw)
            row['receipt'].update(status='NO_MATCH', occurrences=[], snapshots=[],
                                  cursor_end=request.log_watermark)
            waiting = encode(row)
            self.returned_raw.extend((raw, waiting))
            return OperationInput(True, 'synthetic:completion:'+str(count),
                (ObservationInput(0, raw), ObservationInput(1000, waiting)))
        if fault in ('duplicate_slots', 'accepted_then_malformed'):
            second = raw if fault == 'duplicate_slots' else b'{synthetic invalid later observation'
            self.returned_raw.extend((raw, second))
            return OperationInput(True, 'synthetic:completion:'+str(count),
                (ObservationInput(0, raw), ObservationInput(1000, second)))
        if fault == 'mismatched_operation':
            row = json.loads(raw)
            row['receipt']['operation_ref'] = 'synthetic:unrelated-reported-operation'
            raw = encode(row)
        if fault == 'malformed':
            raw = b'{synthetic invalid transport'
        elif fault in ('wait', 'wait_then_match'):
            row = json.loads(raw)
            row['receipt'].update(status='NO_MATCH', occurrences=[], snapshots=[],
                                  cursor_end=request.log_watermark)
            waiting = encode(row)
            if fault == 'wait_then_match':
                self.returned_raw.extend((waiting, raw))
                return OperationInput(True, 'synthetic:completion:'+str(count),
                    (ObservationInput(0, waiting), ObservationInput(1000, raw)))
            raw = waiting
        self.returned_raw.append(raw)
        return OperationInput(fault != 'unknown_completion', 'synthetic:completion:'+str(count),
            (ObservationInput(0, raw, 7 if fault == 'nonzero' else 0,
                              fault != 'close_uncertain'),))

    def help_inputs(self, request):
        self.helps.append(request)
        if self.help_fault == 'preparation_error':
            raise ValueError('synthetic external preparation failed')
        condition = {resource: name for name, resource in RESOURCES.items()}[request.episode.logical_resource]
        # The assignment is signed first. Resolution and launch bind that exact digest.
        unsigned_resolution = json.loads(resolution(self.policy, request.attempt_ref, condition))
        launch = unsigned_resolution['payload']['launch_attestation']['body']
        suffix = str(len(self.helps))
        launch.update(proof_id='synthetic:launch:'+suffix,
                      assignment_record_id='synthetic:assignment:'+suffix,
                      launch_nonce='synthetic:launch-nonce:'+suffix)
        common = {k:unsigned_resolution[k] for k in ('contract_version','profile_id','profile_version',
            'schema_version','experiment_id','experiment_version','unit_token','audience',
            'deployment_id','context_id','valid_from','expires_at')}
        assignment = {**common,'record_id':launch['assignment_record_id'], 'record_type':'assignment',
            'issuer':self.profile['record_issuers']['assignment'], 'nonce':'synthetic:assignment-nonce:'+suffix,
            'issued_at':utc(datetime.fromisoformat(launch['issued_at'])-timedelta(seconds=1)),
            'predecessor_record_id':None,'predecessor_digest':None,
            'payload':{'assigned_condition':condition,
                'assignment_policy_version':self.profile['assignment_policy_version'],
                'scope':self.profile['scope'],'resource_id':request.episode.logical_resource,
                'launch_nonce':launch['launch_nonce']}}
        assignment = sign(assignment, assignment['issuer'], self.profile)
        launch['assignment_digest'] = assignment['integrity']['content_digest']
        unsigned_resolution.update(record_id='synthetic:resolution:'+suffix,
            nonce='synthetic:resolution-nonce:'+suffix,
            predecessor_record_id=assignment['record_id'],
            predecessor_digest=assignment['integrity']['content_digest'])
        unsigned_resolution['payload'].update(launch_nonce=launch['launch_nonce'],
            launch_attestation=sign(launch, launch['issuer'], self.profile, proof=True))
        signed_resolution = sign({k:v for k,v in unsigned_resolution.items() if k != 'integrity'},
                                 unsigned_resolution['issuer'], self.profile)
        prompt, generation, catalog, binding = inputs(condition, request.episode.config_id)
        binding = replace(binding, resolution_ref=signed_resolution['record_id'])
        generation_raw = b'{}' if self.help_fault == 'producer_input_invalid' else generation.canonical_bytes
        assignment_raw = encode(assignment)
        if self.help_fault == 'nonbytes_assignment':
            assignment_raw = bytearray(assignment_raw)
        return HelpInputs(assignment_raw, encode(signed_resolution), self.policy,
                          prompt, generation_raw, catalog, binding)

    def sign_outcome(self, request):
        self.outcomes.append(request)
        assignment = json.loads(request.assignment_raw)
        exposure = json.loads(request.exposure_raw)
        condition = exposure['payload']['enacted_condition']
        common = {k:assignment[k] for k in ('contract_version','profile_id','profile_version',
            'schema_version','experiment_id','experiment_version','unit_token','audience',
            'deployment_id','context_id','valid_from','expires_at')}
        outcome = {**common,'record_id':'synthetic:outcome:'+str(len(self.outcomes)),
            'record_type':'outcome','issuer':self.profile['record_issuers']['outcome'],
            'nonce':'synthetic:outcome-nonce:'+str(len(self.outcomes)),
            'issued_at':utc(datetime.now(timezone.utc)),
            'predecessor_record_id':exposure['record_id'],
            'predecessor_digest':exposure['integrity']['content_digest'],
            'payload':{'exposure_record_id':exposure['record_id'],
                'exposure_digest':exposure['integrity']['content_digest'],
                'attributed_condition':condition,
                'outcome_key':request.outcome['composite']['outcome_key'],
                'consent_state':'consented','consent_at':self.policy.valid_from,
                'consent_authority_ref':self.profile['consent_authority_refs'][0],
                'consent_policy_version':self.profile['consent_policy_version'],
                'purpose':request.purpose,'eligible':True}}
        signed = sign(outcome, outcome['issuer'], self.profile)
        if self.outcome_fault == 'bad_mac':
            signed['integrity']['mac'] = 'hmac-sha256:'+'0'*64
        return encode(signed)

    def admission_context(self):
        self.admissions += 1
        return AdmissionContext(self.profile, KEYS, utc(datetime.now(timezone.utc)))

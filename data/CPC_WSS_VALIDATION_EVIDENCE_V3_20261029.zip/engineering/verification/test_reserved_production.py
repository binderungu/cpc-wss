"""Synthetic offline mechanical checks for caller-reserved producer receipt.

Uses only copied SC01-compatible padding/wire fixtures. These checks provide no
native, content, learner, or scientific qualification evidence.
"""
from dataclasses import replace
import os
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

CODE_ROOT = Path(os.environ["WSS_CODE_ROOT"]).resolve()
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "regression_tests"))
sys.path.insert(0, str(CODE_ROOT / "src"))

from wss_bridge.controller import OfflineController
from wss_bridge.primitives import plain_json
from wss_bridge.producer import produce
from wp05_fixtures import setup, objects


class ReservedProductionTests(unittest.TestCase):
    def reserve(self):
        ctl, attempt, args = setup()
        ref = ctl.receive_help(attempt, logical_resource=args["logical_resource"], config_id=args["config_id"])
        self.assertEqual(ctl.view()["invocations"][ref]["stage"], "RECEIVED")
        return ctl, attempt, args, ref

    def refused(self, ctl, attempt, args, ref, *, expected_ref=None):
        before = plain_json(ctl.view())
        with patch.object(OfflineController, "receive_help", side_effect=AssertionError("duplicate allocation")):
            result = produce(ctl, attempt, **args, preallocated_invocation_ref=ref)
        self.assertEqual(result.status, "PRECONDITION_REFUSED")
        self.assertEqual(result.publication, "NONE")
        self.assertTrue(result.controller_reconciled)
        self.assertEqual(result.error_code, "CONTROLLER_PRECONDITION_REFUSED")
        self.assertEqual(result.invocation_ref, expected_ref)
        self.assertIsNone(result.root)
        self.assertFalse(args["root"].exists())
        self.assertEqual(plain_json(ctl.view()), before)
        return result

    def test_source_is_requested_new_root(self):
        import wss_bridge.producer
        self.assertEqual(Path(wss_bridge.producer.__file__).resolve(), CODE_ROOT / "src/wss_bridge/producer.py")

    def test_reserved_success_uses_exactly_one_invocation_and_same_proof_index_identity(self):
        ctl, attempt, args, ref = self.reserve()
        with patch.object(OfflineController, "receive_help", side_effect=AssertionError("duplicate allocation")):
            result = produce(ctl, attempt, **args, preallocated_invocation_ref=ref)
        self.assertEqual((result.status, result.publication, result.invocation_ref), ("COMPLETE", "PUBLISHED", ref))
        state = ctl.view()
        self.assertEqual((state["counts"]["invocations"], state["counts"]["publications"]), (1, 1))
        self.assertTrue(state["invocations"][ref]["settled"])
        self.assertEqual(state["invocations"][ref]["history"],
                         ("RECEIVED", "CONSUME_STARTED", "CAPTURED", "COMMIT_DURABLE", "PUBLISHED", "PUBLISHED"))
        exposure = next(o for _, o in objects(args["root"]) if o.get("record_type") == "exposure")
        self.assertEqual(exposure["payload"]["invocation_id"], ref)
        from wss_bridge.producer_references import ProducerReferenceIndex
        index = ProducerReferenceIndex.open_readonly(args["root"],
                                                     invocation_ref=ref, call_ref=result.call_ref)
        self.assertIsNotNone(index)

    def test_wrong_attempt_preserves_known_ref_without_mutation(self):
        ctl, attempt, args, ref = self.reserve()
        self.refused(ctl, "fixture:other-attempt", args, ref, expected_ref=ref)

    def test_same_attempt_resource_or_config_mismatch_refuses_without_mutation(self):
        for name, value in (("logical_resource", "WSS-U01-ANSWER"), ("config_id", "G_CAP")):
            with self.subTest(field=name):
                ctl, attempt, args, ref = self.reserve()
                args[name] = value
                self.refused(ctl, attempt, args, ref, expected_ref=ref)

    def test_other_controller_ref_and_malformed_ref_are_not_adopted(self):
        _, _, _, other_ref = self.reserve()
        for supplied in (other_ref, "fixture:unknown-invocation", ["unhashable"]):
            with self.subTest(supplied_type=type(supplied).__name__):
                ctl, attempt, args, _ = self.reserve()
                self.refused(ctl, attempt, args, supplied)

    def test_consumed_or_later_stage_refuses_without_settlement_or_publication(self):
        for stage in ("CONSUME_STARTED", "CAPTURED", "COMMIT_DURABLE", "PUBLISHED"):
            with self.subTest(stage=stage):
                ctl, attempt, args, ref = self.reserve()
                for current in ("CONSUME_STARTED", "CAPTURED", "COMMIT_DURABLE", "PUBLISHED"):
                    ctl.advance_invocation(ref, current, evidence_ref="fixture:reserved-stage-test")
                    if current == stage:
                        break
                self.refused(ctl, attempt, args, ref, expected_ref=ref)

    def test_settled_refuses_without_new_invocation(self):
        ctl, attempt, args, ref = self.reserve()
        ctl.finish_invocation(ref, publication="NONE", evidence_ref="fixture:reserved-caller-failed")
        self.refused(ctl, attempt, args, ref, expected_ref=ref)

    def test_successful_reservation_cannot_be_reused(self):
        ctl, attempt, args, ref = self.reserve()
        result = produce(ctl, attempt, **args, preallocated_invocation_ref=ref)
        self.assertEqual(result.status, "COMPLETE")
        args["root"] = args["root"].with_name("forbidden-reuse")
        self.refused(ctl, attempt, args, ref, expected_ref=ref)

    def test_closed_attempt_refuses_reserved_received_invocation(self):
        ctl, attempt, args, ref = self.reserve()
        ctl.close_episode(attempt, reason="ABORT")
        self.refused(ctl, attempt, args, ref, expected_ref=ref)

    def test_policy_context_failure_keeps_reserved_identity_and_existing_failure_accounting(self):
        ctl, attempt, args, ref = self.reserve()
        args["policy"] = replace(args["policy"], controller_context_digest="sha256:" + "0" * 64)
        result = produce(ctl, attempt, **args, preallocated_invocation_ref=ref)
        self.assertEqual((result.status, result.publication, result.invocation_ref), ("INCOMPLETE", "NONE", ref))
        self.assertEqual(result.error_code, "CONTROLLER_TASK_CONTEXT_MISMATCH")
        self.assertTrue(result.controller_reconciled)
        self.assertEqual(ctl.view()["counts"]["invocations"], 1)
        self.assertEqual(ctl.view()["invocations"][ref]["stage"], "FAILED_BEFORE_PUBLICATION")
        self.assertFalse(args["root"].exists())

    def test_capture_failure_retains_same_identity_and_failure_receipt(self):
        ctl, attempt, args, ref = self.reserve()
        args["generation_raw"] = b"synthetic invalid generation"
        result = produce(ctl, attempt, **args, preallocated_invocation_ref=ref)
        self.assertEqual((result.status, result.publication, result.invocation_ref), ("INCOMPLETE", "NONE", ref))
        self.assertTrue(result.controller_reconciled)
        self.assertIsNotNone(result.failure_reference)
        state = ctl.view()
        self.assertEqual((state["counts"]["invocations"], state["counts"]["publications"]), (1, 0))
        self.assertEqual(state["invocations"][ref]["history"],
                         ("RECEIVED", "CONSUME_STARTED", "FAILED_BEFORE_PUBLICATION"))
        failure = next(o for _, o in objects(args["root"]) if o.get("format") == "wss-producer-failure-v1")
        self.assertEqual(failure["invocation_ref"], ref)
        self.assertEqual(failure["call_ref"], result.call_ref)
        self.assertEqual(failure["stage"], "CONSUME_STARTED")

    def test_default_legacy_call_allocates_then_publishes(self):
        ctl, attempt, args = setup()
        self.assertEqual(ctl.view()["counts"]["invocations"], 0)
        result = produce(ctl, attempt, **args)
        self.assertEqual((result.status, result.publication), ("COMPLETE", "PUBLISHED"))
        self.assertEqual(ctl.view()["counts"]["invocations"], 1)
        self.assertEqual(ctl.view()["counts"]["publications"], 1)


if __name__ == "__main__":
    unittest.main()

"""Boundary/preflight/bounded-reader regressions; synthetic files only."""
from pathlib import Path
from types import SimpleNamespace
from dataclasses import replace
from unittest.mock import patch
import sys,os,unittest,tempfile
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent.parent;CODE=Path(os.environ['WSS_CODE_ROOT']);sys.path[:0]=[str(CODE/'src'),str(OUT/'verification'),str(OUT/'regression_tests')]
from wss_bridge import worked_runner as r
from wss_bridge.primitives import ContractError,canonical_json_bytes
from wss_bridge.ledger import LedgerScope
from runner_fixtures import SyntheticPorts
class LimitsTests(unittest.TestCase):
 def test_episode_near_boundary_covers_longest_generated_followup_label(self):
  f=SyntheticPorts((('hint','G_BASE',1),));episode=f.config.episodes[0]
  with self.assertRaises(ContractError):replace(episode,episode_ref='a'*248)
  self.assertEqual(len(replace(episode,episode_ref='a'*247).episode_ref),247)
 def test_scope_near_boundary_covers_admission_and_snapshot_suffixes(self):
  f=SyntheticPorts((('hint','G_BASE',1),));scope=f.config.scope
  with self.assertRaises(ContractError):replace(f.config,scope=replace(scope,run_ref='a'*247))
  with self.assertRaises(ContractError):replace(f.config,scope=replace(scope,ledger_ref='a'*247))
  self.assertEqual(len(replace(f.config,scope=replace(scope,run_ref='a'*246,ledger_ref='b'*246)).scope.run_ref),246)
 def test_pending_facts_nonarray_not_normalized_to_ready_empty(self):
  f=SyntheticPorts((('hint','G_BASE',1),))
  for value in ['',{},None]:
   d=f.config.to_mapping();d['context']['pending_facts']=value
   with self.subTest(value=value),self.assertRaises(ContractError):r.RunnerConfig.from_bytes(canonical_json_bytes(d))
 def test_auxiliary_oversize_rejected_before_open_or_read(self):
  with tempfile.TemporaryDirectory(dir=os.environ['WSS_TEST_ARTIFACT_ROOT']) as temp:
   path=Path(temp)/'large.bin';path.write_bytes(b'xx')
   with patch.object(r,'_checked_fd',side_effect=AssertionError('must refuse before open')) as opened:
    with self.assertRaises(r.RunnerStopped):r._collect_auxiliary([SimpleNamespace(root=temp)],{},1)
    opened.assert_not_called()
 def test_auxiliary_cumulative_limit_reserves_prior_native_and_recipe_budget(self):
  with tempfile.TemporaryDirectory(dir=os.environ['WSS_TEST_ARTIFACT_ROOT']) as temp:
   (Path(temp)/'a.bin').write_bytes(b'abc');(Path(temp)/'b.bin').write_bytes(b'def');actual=r._checked_fd
   with patch.object(r,'_checked_fd',wraps=actual) as opened:
    with self.assertRaises(r.RunnerStopped):r._collect_auxiliary([SimpleNamespace(root=temp)],{'recipe':b'kept'},4)
    self.assertEqual(opened.call_count,1)
   collected=r._collect_auxiliary([SimpleNamespace(root=temp)],{'recipe':b'kept'},6)
   self.assertEqual(collected['recipe'],b'kept');self.assertEqual(sum(len(v) for k,v in collected.items() if k!='recipe'),6)
 def test_auxiliary_symlink_or_fifo_refused_without_read(self):
  for kind in ['link','fifo']:
   with self.subTest(kind=kind),tempfile.TemporaryDirectory(dir=os.environ['WSS_TEST_ARTIFACT_ROOT']) as temp:
    p=Path(temp)/'bad'
    if kind=='link':p.symlink_to(Path(temp)/'absent')
    else:os.mkfifo(p)
    with patch.object(r,'_checked_fd',side_effect=AssertionError('must refuse before open')):
     with self.assertRaises(r.RunnerStopped):r._collect_auxiliary([SimpleNamespace(root=temp)],{},100)
 def test_nested_manifest_name_not_silently_omitted_from_inventory(self):
  with tempfile.TemporaryDirectory(dir=os.environ['WSS_TEST_ARTIFACT_ROOT']) as temp:
   root=Path(temp);(root/'nested').mkdir();(root/'nested/RUNNER_MANIFEST.json').write_bytes(b'{}');r._seal_run(root)
   import json
   manifest=json.loads((root/'RUNNER_MANIFEST.json').read_bytes());self.assertIn('nested/RUNNER_MANIFEST.json',manifest['files'])
 def test_config_min_observation_capacity_refused_before_ports(self):
  f=SyntheticPorts()
  with self.assertRaises(ContractError):replace(f.config,max_observations=5)
if __name__=='__main__':unittest.main()

"""SYNTHETIC_OFFLINE_ENGINEERING_TEST: orchestration checks, never a worked demo.

All native-shaped bytes and artificial help materials are synthetic. These tests
make no empirical, scientific, rights, consent, or live-readiness claims.
"""
from collections import Counter
from dataclasses import replace
import hashlib
import json
import os
import shutil
from pathlib import Path
import socket
import sqlite3
import subprocess
import sys
import tempfile
from types import MappingProxyType
import unittest
from unittest.mock import Mock, patch

CODE_ROOT = Path(os.environ['WSS_CODE_ROOT']).resolve()
VERIFICATION = Path(__file__).resolve().parent
sys.path.insert(0, str(VERIFICATION.parent / 'regression_tests'))
sys.path.insert(0, str(CODE_ROOT / 'src'))
sys.path.insert(0, str(VERIFICATION))

from wss_bridge import worked_runner as runner
from wss_bridge import producer, cpc_adapter
from wss_bridge.controller import OfflineController
from wss_bridge.outcomes import OutcomeStore
from wss_bridge.ledger import LedgerError
from wss_bridge.primitives import ContractError, canonical_json_bytes, plain_json
from runner_fixtures import SyntheticPorts, SOURCE_LABEL
from wp04_fixtures import CONFIGS


class WorkedRunnerTests(unittest.TestCase):
    def setUp(self):
        self.parent = Path(tempfile.mkdtemp(prefix=self._testMethodName+'-',
                                          dir=os.environ['WSS_TEST_ARTIFACT_ROOT']))
        self.root = self.parent / 'run'

    def execute(self, fixture=None):
        f = SyntheticPorts() if fixture is None else fixture
        result = runner.run_offline(self.root, f.config, f.ports)
        return f, result

    def controller(self, f):
        roots = list(self.root.rglob('.controller.lock'))
        self.assertEqual(len(roots), 1, 'one runner controller must own all episodes')
        return OfflineController.open_readonly(roots[0].parent, f.config.scope, f.config.context)

    def documents(self):
        result = []
        for p in sorted(self.root.rglob('*.json')):
            try:
                row = json.loads(p.read_bytes())
            except (ValueError, UnicodeError):
                continue
            if isinstance(row, dict):
                result.append((p, row))
        return result

    def comparison(self):
        matches = [row for _, row in self.documents() if isinstance(row.get('arms'), dict)
                   and {'B0','B2','CPC_REFERENCE'} <= set(row['arms'])]
        self.assertEqual(len(matches), 1)
        return matches[0]

    def assert_no_help_or_outcomes(self, f):
        self.assertEqual((len(f.helps), len(f.outcomes), f.admissions), (0, 0, 0))
        self.assertEqual(len(f.operations), 1)
        retained = [p.read_bytes() for p in (self.root/'received').glob('*.bin')]
        self.assertTrue(all(raw in retained for raw in f.returned_raw))

    def test_source_and_fixture_labels_are_explicit(self):
        self.assertEqual(Path(runner.__file__).resolve(), CODE_ROOT/'src/wss_bridge/worked_runner.py')
        self.assertEqual(SOURCE_LABEL, 'SYNTHETIC_OFFLINE_ENGINEERING_TEST')

    def test_three_episode_cohort_single_controller_shared_store_and_no_clone(self):
        f, result = self.execute()
        self.assertEqual(result.status, 'COMPLETED', result.to_mapping())
        state = self.controller(f).view()
        self.assertEqual({k:state['counts'][k] for k in ('attempts','invocations','publications')},
                         {'attempts':3,'invocations':4,'publications':4})
        self.assertEqual((len(f.operations),len(f.helps),len(f.outcomes),f.admissions), (6,4,3,1))
        self.assertEqual(len({x.attempt_ref for x in f.outcomes}), 3)
        self.assertEqual(len({x.outcome['lineage_ref'] for x in f.outcomes}), 3)
        self.assertTrue(all(x.outcome['value'] == 2 for x in f.outcomes))
        stores = list(self.root.rglob('outcomes.meta.json'))
        self.assertEqual(len(stores), 1)
        outcomes = OutcomeStore.open_readonly(stores[0].parent, f.config.scope.run_ref).view()
        self.assertEqual(outcomes['counts']['received_derivations'], 3)
        self.assertEqual(outcomes['counts']['external_rows'], 3)
        comp = self.comparison()
        for arm in ('CPC_REFERENCE','B0','B2'):
            ledger = comp['arms'][arm]['join']['core_ledger']
            self.assertEqual(Counter(x['primary_reason'] for x in ledger),
                             Counter({'JOINED':2,'NATIVE_MAPPING_HOLD':1}))
        chain_raw = [p.read_bytes() for p in (self.root/'received').glob('*complete_chain.bin')]
        self.assertEqual(len(chain_raw), 3)
        chain_invocations = set()
        for raw in chain_raw:
            records = json.loads(raw)['records']
            self.assertEqual([r['record_type'] for r in records],
                             ['assignment','resolution','exposure','outcome'])
            chain_invocations.add(records[2]['payload']['invocation_id'])
            self.assertNotIn('value', records[3]['payload'])
            self.assertEqual(records[0]['unit_token'], records[2]['unit_token'])
            launch = records[1]['payload']['launch_attestation']['body']
            self.assertEqual(launch['assignment_digest'],records[0]['integrity']['content_digest'])
        self.assertEqual(len(chain_invocations), 3)
        self.assertEqual(len(set(state['invocations'])-chain_invocations), 1)
        episode_ledger = json.loads((self.root/'episode_ledger.json').read_bytes())
        self.assertEqual([len(e['unsubmitted_exposures']) for e in episode_ledger], [0,0,1])
        self.assertEqual(result.counts['source_only_publications'], 1)
        self.assertEqual(self.comparison()['B1']['format'], 'wss-b1-ablation-v1')
        self.assertEqual([json.loads(raw)['receipt']['occurrences'][0]['standard_log_record_id']
                          for raw in f.returned_raw], list(range(101,107)))
        self.assertEqual(runner.verify_worked_output(self.root)['status'], 'VERIFIED_LOCAL_BYTES')

    def test_all_ten_condition_configuration_mechanics(self):
        for condition in ('hint','answer'):
            for config in CONFIGS:
                with self.subTest(condition=condition, config=config):
                    self.root = self.parent / (condition+'-'+config)
                    f, result = self.execute(SyntheticPorts(((condition,config,1),)))
                    self.assertEqual(result.status, 'COMPLETED', result.to_mapping())
                    self.assertEqual(self.controller(f).view()['counts']['invocations'], 1)
                    self.assertEqual(self.comparison()['arms']['CPC_REFERENCE']['join']['core_ledger'][0]
                                     ['primary_reason'], 'JOINED')

    def test_source_operation_persisted_before_callback(self):
        def probe(request):
            matching = [row for _, row in self.documents()
                        if row.get('event') == 'PROSPECTIVE_OPERATION'
                        and row.get('data',{}).get('operation_ref') == request.operation_ref]
            self.assertEqual(len(matching), 1)
        f, result = self.execute(SyntheticPorts((('hint','G_BASE',1),), operation_probe=probe))
        self.assertEqual(result.status, 'COMPLETED', result.to_mapping())

    def test_raw_malformed_transport_is_retained_without_help(self):
        f, result = self.execute(SyntheticPorts(operation_fault='malformed'))
        self.assertIn(result.status, ('DIAGNOSTIC_INCOMPLETE','FAILED'))
        self.assert_no_help_or_outcomes(f)

    def test_wait_without_match_does_not_fabricate_anchor(self):
        f, result = self.execute(SyntheticPorts(operation_fault='wait'))
        self.assertIn(result.status, ('DIAGNOSTIC_INCOMPLETE','FAILED'))
        self.assert_no_help_or_outcomes(f)
        self.assertEqual(self.controller(f).view()['counts']['attempts'], 0)
        events = [r for _, r in self.documents() if r.get('event') == 'OBSERVATION']
        self.assertEqual(events[0]['data']['ack']['status'], 'WAIT')

    def test_wait_then_valid_supplied_slot_continues_without_native_retry(self):
        f, result = self.execute(SyntheticPorts((('hint','G_BASE',1),), operation_fault='wait_then_match'))
        self.assertEqual(result.status, 'COMPLETED', result.to_mapping())
        self.assertEqual(len(f.operations), 2)
        events = [r for _, r in self.documents() if r.get('event') == 'OBSERVATION']
        self.assertEqual([e['data']['slot_ms'] for e in events], [0,1000,0])

    def test_unknown_completion_nonzero_and_uncertain_close_stop(self):
        for fault in ('unknown_completion','nonzero','close_uncertain'):
            with self.subTest(fault=fault):
                self.root = self.parent/fault
                f, result = self.execute(SyntheticPorts(operation_fault=fault))
                self.assertIn(result.status, ('DIAGNOSTIC_INCOMPLETE','FAILED'))
                self.assert_no_help_or_outcomes(f)

    def test_help_preparation_error_retains_one_failed_invocation_zero_publications(self):
        f, result = self.execute(SyntheticPorts(help_fault='preparation_error'))
        self.assertIn(result.status, ('DIAGNOSTIC_INCOMPLETE','FAILED'))
        view = self.controller(f).view()
        self.assertEqual((view['counts']['invocations'],view['counts']['publications']), (1,0))
        inv = next(iter(view['invocations'].values()))
        self.assertTrue(inv['settled'])
        self.assertFalse(inv['ever_published'])
        self.assertEqual((len(f.helps),len(f.outcomes)), (1,0))

    def test_invalid_producer_input_retains_failed_call_and_does_not_derive(self):
        f, result = self.execute(SyntheticPorts(help_fault='producer_input_invalid'))
        self.assertIn(result.status, ('DIAGNOSTIC_INCOMPLETE','FAILED'))
        view = self.controller(f).view()
        self.assertEqual((view['counts']['invocations'],view['counts']['publications']), (1,0))
        self.assertEqual(len(f.outcomes), 0)
        self.assertEqual(len(f.operations), 1)
        production = [r['data'] for _, r in self.documents() if r.get('event') == 'PRODUCTION_RETURNED']
        self.assertEqual(len(production), 1)
        self.assertNotEqual(production[0]['status'], 'COMPLETE')

    def test_bad_external_outcome_reaches_actual_core_reject(self):
        f, result = self.execute(SyntheticPorts((('hint','G_BASE',1),), outcome_fault='bad_mac'))
        self.assertEqual(len(f.outcomes), 1)
        core = self.comparison()['arms']['CPC_REFERENCE']
        self.assertEqual(core['join']['core_ledger'][0]['core_disposition'], 'REJECT')
        self.assertEqual(len(f.operations), 2)

    def test_callback_network_attempt_is_blocked_and_prospective_operation_survives(self):
        def network(_):
            socket.socket()
        f, result = self.execute(SyntheticPorts(operation_probe=network))
        self.assertIn(result.status, ('DIAGNOSTIC_INCOMPLETE','FAILED'))
        self.assertEqual(result.error_type, 'PermissionError')
        self.assertEqual(self.controller(f).view()['counts']['operations'], 1)
        self.assertEqual((len(f.helps),len(f.outcomes)), (0,0))

    def test_report_write_failure_retains_complete_upstream_evidence(self):
        with patch.object(runner, 'write_handoff', side_effect=OSError('synthetic report write failure')):
            f, result = self.execute()
        self.assertIn(result.status, ('DIAGNOSTIC_INCOMPLETE','FAILED'))
        self.assertEqual((len(f.operations),len(f.helps),len(f.outcomes)), (6,4,3))
        self.assertEqual(self.controller(f).view()['counts']['publications'], 4)
        self.assertEqual(len(list((self.root/'received').glob('*complete_chain.bin'))), 3)
        self.assertTrue((self.root/'RUNNER_FAILURE.json').is_file())

    def test_existing_root_cannot_overwrite_or_resume(self):
        f, result = self.execute(SyntheticPorts((('hint','G_BASE',1),)))
        self.assertEqual(result.status, 'COMPLETED', result.to_mapping())
        before = {str(p.relative_to(self.root)):hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in self.root.rglob('*') if p.is_file()}
        try:
            again = runner.run_offline(self.root, f.config, f.ports)
        except (ContractError,FileExistsError,LedgerError):
            pass
        else:
            self.assertEqual(again.status, 'FAILED')
        after = {str(p.relative_to(self.root)):hashlib.sha256(p.read_bytes()).hexdigest()
                 for p in self.root.rglob('*') if p.is_file()}
        self.assertEqual(before, after)
        self.assertEqual(len(f.operations), 2)

    def test_duplicate_supplied_observation_preserves_first_anchor_without_extra_attempt(self):
        f, result = self.execute(SyntheticPorts((('hint','G_BASE',1),), operation_fault='duplicate_slots'))
        self.assertEqual(result.status, 'COMPLETED', result.to_mapping())
        state = self.controller(f).view()
        self.assertEqual((state['counts']['attempts'],state['counts']['publications']), (1,1))
        self.assertEqual(len(f.operations), 2)
        events = [r for _, r in self.documents() if r.get('event') == 'OBSERVATION']
        self.assertEqual([e['data']['ack']['status'] for e in events], ['ACCEPTED','DUPLICATE','ACCEPTED'])

    def test_unused_invalid_later_observation_is_retained_and_stops_help(self):
        f, result = self.execute(SyntheticPorts(operation_fault='accepted_then_malformed'))
        self.assertIn(result.status, ('DIAGNOSTIC_INCOMPLETE','FAILED'))
        self.assert_no_help_or_outcomes(f)
        self.assertEqual(len(f.returned_raw), 2)

    def test_reported_operation_mismatch_is_not_rewritten_to_expected_identity(self):
        f, result = self.execute(SyntheticPorts(operation_fault='mismatched_operation'))
        self.assertIn(result.status, ('DIAGNOSTIC_INCOMPLETE','FAILED'))
        self.assert_no_help_or_outcomes(f)
        retained = [p.read_bytes() for p in (self.root/'received').glob('*.bin')]
        self.assertEqual(json.loads(retained[0])['receipt']['operation_ref'],
                         'synthetic:unrelated-reported-operation')

    def assert_preparation_settled_without_producer(self, f, result):
        self.assertEqual(result.status, 'FAILED', result.to_mapping())
        self.assertEqual(result.phase, 'HELP_PREPARATION')
        view = self.controller(f).view()
        self.assertEqual((view['counts']['invocations'],view['counts']['publications']), (1,0))
        inv = next(iter(view['invocations'].values()))
        self.assertTrue(inv['settled'])
        self.assertFalse(inv['ever_published'])
        self.assertFalse(inv['publication_unresolved'])
        failed = [r['data'] for _,r in self.documents() if r.get('event') == 'HELP_PREPARATION_FAILED']
        self.assertEqual(len(failed), 1)
        self.assertEqual(failed[0]['publication'], 'NONE')
        self.assertEqual(result.counts['producer_calls_returned'], 0)
        self.assertEqual(list((self.root/'producers').iterdir()), [])
        self.assertEqual((len(f.operations),len(f.helps),len(f.outcomes)), (1,1,0))

    def test_nonbytes_assignment_retention_failure_settles_allocated_invocation(self):
        f, result = self.execute(SyntheticPorts(help_fault='nonbytes_assignment'))
        self.assert_preparation_settled_without_producer(f, result)
        self.assertEqual(result.counts['production_attempts'], 0)

    def test_help_retention_byte_budget_failure_settles_allocated_invocation(self):
        f = SyntheticPorts()
        original = f.ports.help_inputs
        tiny_budget = patch.object(runner, 'MAX_RECEIVED_BYTES', 1)
        self.addCleanup(tiny_budget.stop)
        def supplied(request):
            value = original(request)
            # Activate the real byte cap after the task capture and reservation.
            tiny_budget.start()
            return value
        f.ports = replace(f.ports, help_inputs=supplied)
        _, result = self.execute(f)
        self.assert_preparation_settled_without_producer(f, result)
        self.assertEqual(result.counts['production_attempts'], 0)
        self.assertEqual(runner.MAX_RECEIVED_BYTES, 1)

    def test_cli_plan_check_refuses_disposable_fifo_and_directory_before_read(self):
        fifo = self.parent/'disposable-plan-fifo'
        os.mkfifo(fifo, 0o600)
        directory = self.parent/'disposable-plan-directory'
        directory.mkdir()
        for path in (fifo,directory):
            with self.subTest(kind=path.name):
                # Nonblocking regular-file validation must refuse before reading.
                with patch.object(runner.os, 'fdopen', side_effect=AssertionError('nonregular read attempted')):
                    with self.assertRaises(LedgerError):
                        runner.main(['check-plan',str(path)])

    def test_output_verification_refuses_disposable_symlink_fifo_and_hardlink(self):
        f, result = self.execute(SyntheticPorts((('hint','G_BASE',1),)))
        self.assertEqual(result.status, 'COMPLETED', result.to_mapping())
        outside = self.parent/'disposable-empty-directory'
        outside.mkdir()
        added = self.root/'disposable-injected-entry'
        for kind in ('symlink_directory','fifo','hardlink'):
            with self.subTest(kind=kind):
                if kind == 'symlink_directory':
                    added.symlink_to(outside, target_is_directory=True)
                elif kind == 'fifo':
                    os.mkfifo(added, 0o600)
                else:
                    os.link(self.root/'STARTED.json', added)
                try:
                    with self.assertRaisesRegex(ContractError, 'nonregular/link refused'):
                        runner.verify_worked_output(self.root)
                finally:
                    # Only these explicit disposable test entries are removed.
                    added.unlink()
        self.assertEqual(runner.verify_worked_output(self.root)['status'], 'VERIFIED_LOCAL_BYTES')

    def test_explicit_source_scope_cannot_contradict_declared_evidence_class(self):
        f = SyntheticPorts()
        with self.assertRaisesRegex(ContractError, 'scope contradicts evidence class'):
            replace(f.config, evidence_class='REPORTED_NATIVE_READ')
        native_scope = replace(f.config.scope, purpose='REPORTED_NATIVE_READ')
        with self.assertRaisesRegex(ContractError, 'scope contradicts evidence class'):
            replace(f.config, scope=native_scope)

    def test_workflow_scope_label_preserves_separate_explicit_source_class(self):
        f = SyntheticPorts((('hint','G_BASE',1),))
        f.config = replace(f.config, scope=replace(f.config.scope, purpose='synthetic:generic-workflow'))
        _, result = self.execute(f)
        self.assertEqual(result.status, 'COMPLETED', result.to_mapping())
        started = json.loads((self.root/'STARTED.json').read_bytes())
        self.assertEqual(started['scope']['purpose'], 'synthetic:generic-workflow')
        self.assertEqual(started['evidence_class'], 'SYNTHETIC_OFFLINE_FIXTURE')
        self.assertEqual(started['scope_purpose_semantics'],
                         'bookkeeping workflow label, not proof of source truth')
        self.assertFalse(result.to_mapping()['scientific_or_release_approval'])

    def test_positive_then_wait_refuses_progress_and_retains_both_inputs(self):
        f, result = self.execute(SyntheticPorts(operation_fault='accepted_then_wait'))
        self.assertEqual(result.status, 'FAILED', result.to_mapping())
        self.assert_no_help_or_outcomes(f)
        self.assertEqual(len(f.returned_raw), 2)
        events = [r for _,r in self.documents() if r.get('event') == 'OBSERVATION']
        self.assertEqual([e['data']['ack']['status'] for e in events], ['ACCEPTED','WAIT'])
        refusals = [r['data'] for _,r in self.documents() if r.get('event') == 'SOURCE_PROGRESS_REFUSED']
        self.assertEqual(len(refusals), 1)
        self.assertEqual(refusals[0]['reason'], 'POST_CAPTURE_NO_MATCH')
        self.assertTrue(refusals[0]['retained_prior_positive'])

    def test_subprocess_guard_fires_before_mocked_fork_and_resets_after_failure(self):
        def launch(_):
            subprocess.Popen([sys.executable,'-c','raise RuntimeError("must never execute")'])
        # The genuine Popen audit event precedes this POSIX launch boundary.
        with patch.object(subprocess, '_fork_exec', side_effect=AssertionError('actual process launch reached')) as fork:
            f, result = self.execute(SyntheticPorts(operation_probe=launch))
            fork.assert_not_called()
        self.assertEqual((result.status,result.error_type), ('FAILED','PermissionError'))
        self.assertEqual((len(f.helps),len(f.outcomes)), (0,0))
        self.assertEqual(runner._ACTIVE, 0)
        # Audit lifecycle check only: this event cannot launch a process.
        sys.audit('subprocess.Popen', 'synthetic:no-launch', (), None, None)

    def test_system_and_sqlite_audit_events_block_before_mocked_effects_and_reset(self):
        # Python exposes these standard audit events before the C side effect.
        # Safe API-boundary shims emit that event, then a mock sentinel; neither
        # a real shell nor a real SQLite connection is ever called by this test.
        for api,event,args in ((os,'os.system',(b'synthetic:no-shell',)),
                               (sqlite3,'sqlite3.connect',('synthetic:no-database',))):
            with self.subTest(event=event):
                self.root = self.parent/event.replace('.','-')
                effect = Mock(side_effect=AssertionError('external effect reached'))
                def boundary(*call_args):
                    sys.audit(event,*call_args)
                    return effect(*call_args)
                attribute = 'system' if api is os else 'connect'
                with patch.object(api,attribute,side_effect=boundary):
                    def launch(_):
                        getattr(api,attribute)(*args)
                    f, result = self.execute(SyntheticPorts(operation_probe=launch))
                self.assertEqual((result.status,result.error_type), ('FAILED','PermissionError'))
                self.assertEqual((len(f.helps),len(f.outcomes)), (0,0))
                effect.assert_not_called()
                self.assertEqual(runner._ACTIVE, 0)
                # Inspect this hook directly: a containing verification harness
                # may retain its independent global no-database audit guard.
                runner._audit(event,args)

    def mutate_disposable_result_and_reseal(self, target, changes):
        result_path = target/'RUNNER_RESULT.json'
        result = json.loads(result_path.read_bytes())
        result.update(changes)
        raw = canonical_json_bytes(result)
        result_path.write_bytes(raw)
        manifest_path = target/'RUNNER_MANIFEST.json'
        manifest = json.loads(manifest_path.read_bytes())
        manifest['files']['RUNNER_RESULT.json'] = {
            'sha256':'sha256:'+hashlib.sha256(raw).hexdigest(), 'bytes':len(raw)}
        manifest_path.write_bytes(canonical_json_bytes(manifest))

    def test_resealed_result_corruption_is_rejected_by_semantics_after_checksums(self):
        f, result = self.execute(SyntheticPorts((('hint','G_BASE',1),)))
        self.assertEqual(result.status, 'COMPLETED', result.to_mapping())
        mutations = (
            ('unknown_field', {'unknown_field':True}, 'result schema invalid'),
            ('connector_flag', {'native_or_provider_connector_used':True}, 'boundary flags invalid'),
            ('approval_flag', {'scientific_or_release_approval':True}, 'boundary flags invalid'),
            ('mode', {'mode':'REPORTED_NATIVE_READ'}, 'boundary flags invalid'),
            ('phase', {'phase':'ADMISSION'}, 'success/result invariants invalid'),
            ('error_type', {'error_type':'RuntimeError'}, 'success/result invariants invalid'),
            ('report_status', {'report_status':'DIAGNOSTIC_INCOMPLETE'}, 'success/result invariants invalid'),
            ('diagnostic_status', {'status':'DIAGNOSTIC_INCOMPLETE'}, 'success/result invariants invalid'),
        )
        for label, changes, reason in mutations:
            with self.subTest(mutation=label):
                target = self.parent/('disposable-corruption-'+label)
                shutil.copytree(self.root, target)
                self.mutate_disposable_result_and_reseal(target, changes)
                with self.assertRaisesRegex(ContractError, reason):
                    runner.verify_worked_output(target)

    def test_resealed_failed_status_requires_real_matching_failure_receipt(self):
        _, result = self.execute(SyntheticPorts((('hint','G_BASE',1),)))
        self.assertEqual(result.status, 'COMPLETED', result.to_mapping())
        self.mutate_disposable_result_and_reseal(self.root,
            {'status':'FAILED','error_type':'RuntimeError','report_status':None})
        self.assertFalse((self.root/'RUNNER_FAILURE.json').exists())
        with self.assertRaises(FileNotFoundError):
            runner.verify_worked_output(self.root)

    def test_resealed_failed_result_must_match_failure_phase_type_counts_and_report(self):
        _, result = self.execute(SyntheticPorts(help_fault='preparation_error'))
        self.assertEqual(result.status, 'FAILED', result.to_mapping())
        self.assertEqual(runner.verify_worked_output(self.root)['runner_status'], 'FAILED')
        mutations = (('phase', {'phase':'INCORRECT'}), ('error', {'error_type':'IncorrectError'}),
                     ('counts', {'counts':{}}), ('report', {'report_status':'DIAGNOSTIC_INCOMPLETE'}))
        for label,changes in mutations:
            with self.subTest(mutation=label):
                target = self.parent/('disposable-failure-corruption-'+label)
                shutil.copytree(self.root,target)
                self.mutate_disposable_result_and_reseal(target,changes)
                with self.assertRaisesRegex(ContractError,'failure/result invariants invalid'):
                    runner.verify_worked_output(target)

    def test_manifest_fifo_or_symlink_leaf_is_refused_before_read(self):
        _, result = self.execute(SyntheticPorts((('hint','G_BASE',1),)))
        self.assertEqual(result.status, 'COMPLETED', result.to_mapping())
        manifest = self.root/'RUNNER_MANIFEST.json'
        original = manifest.read_bytes()
        backup = self.parent/'disposable-manifest-target.json'
        backup.write_bytes(original)
        for kind in ('fifo','symlink'):
            with self.subTest(kind=kind):
                manifest.unlink()
                if kind == 'fifo':
                    os.mkfifo(manifest,0o600)
                else:
                    manifest.symlink_to(backup)
                try:
                    with patch.object(runner.os,'fdopen',side_effect=AssertionError('nonregular manifest read')) as read:
                        with self.assertRaises((LedgerError,OSError)):
                            runner.verify_worked_output(self.root)
                        read.assert_not_called()
                finally:
                    manifest.unlink()
                    manifest.write_bytes(original)

    def test_signer_exception_retains_derived_outcome_without_core_input_or_submission(self):
        f = SyntheticPorts((('hint','G_BASE',1),))
        signer = Mock(side_effect=RuntimeError('synthetic signer unavailable'))
        f.ports = replace(f.ports,sign_outcome=signer)
        _, result = self.execute(f)
        self.assertEqual((result.status,result.phase), ('FAILED','OUTCOME_SIGNING'))
        self.assertEqual(result.counts['source_only_publications'],1)
        self.assertEqual(result.counts['outcome_derivations'],1)
        self.assertEqual(result.counts['external_rows'],1)
        self.assertEqual(result.counts['complete_core_inputs'],0)
        self.assertEqual(result.counts['core_inputs_submitted'],0)
        self.assertEqual(result.counts['completed_episodes'],0)
        signer.assert_called_once()
        stored = OutcomeStore.open_readonly(self.root/'outcomes',f.config.scope.run_ref).view()
        self.assertEqual(stored['counts']['external_rows'],1)
        self.assertEqual(stored['outcomes'][0]['value'],2)
        self.assertEqual(list((self.root/'received').glob('*complete_chain.bin')),[])

    def test_post_publication_producer_failure_preserves_published_count(self):
        original = producer._proof
        def fail_release(policy,resolution,kind,observed,**extra):
            if kind == 'release_attestation':
                raise RuntimeError('synthetic post-publication proof failure')
            return original(policy,resolution,kind,observed,**extra)
        with patch.object(producer,'_proof',side_effect=fail_release):
            f, result = self.execute(SyntheticPorts((('hint','G_BASE',1),)))
        self.assertEqual(result.status,'FAILED',result.to_mapping())
        self.assertEqual(result.counts['controller']['publications'],1)
        self.assertEqual(result.counts['controller']['invocations'],1)
        self.assertEqual(result.counts['source_only_publications'],1)
        self.assertEqual(result.counts['complete_core_inputs'],0)
        self.assertEqual(result.counts['core_inputs_submitted'],0)
        returns = [r['data'] for _,r in self.documents() if r.get('event') == 'PRODUCTION_RETURNED']
        self.assertEqual(len(returns),1)
        self.assertEqual(returns[0]['publication'],'PUBLISHED')
        self.assertNotEqual(returns[0]['status'],'COMPLETE')
        self.assertTrue((self.root/'producers/producer-0001/publications/response.txt').is_file())
        self.assertEqual((len(f.outcomes),result.counts['core_inputs_submitted']),(0,0))

    def test_nondefault_third_episode_owner_preserves_cardinality_and_hold(self):
        f = SyntheticPorts()
        f.config = replace(f.config,episodes=(*f.config.episodes[:2],
            replace(f.config.episodes[2],outcome_owner_ordinal=2)))
        _, result = self.execute(f)
        self.assertEqual(result.status,'COMPLETED',result.to_mapping())
        self.assertEqual((result.counts['controller']['publications'],result.counts['external_rows'],
                          result.counts['complete_core_inputs'],result.counts['core_inputs_submitted']), (4,3,3,3))
        ledger = json.loads((self.root/'episode_ledger.json').read_bytes())
        third = ledger[2]
        self.assertEqual(third['outcome_owner_invocation'],third['publication_invocations'][1])
        self.assertEqual(third['unsubmitted_exposures'],[third['publication_invocations'][0]])
        self.assertEqual(len({x.outcome['lineage_ref'] for x in f.outcomes}),3)
        self.assertEqual(Counter(row['primary_reason'] for row in
            self.comparison()['arms']['CPC_REFERENCE']['join']['core_ledger']),
            Counter({'JOINED':2,'NATIVE_MAPPING_HOLD':1}))

    def test_actual_core_api_exception_stays_unresolved_with_diagnostic_handoff(self):
        api = cpc_adapter._dependency('api')
        with patch.object(api,'validate_raw',side_effect=RuntimeError('synthetic API failure')):
            f, result = self.execute(SyntheticPorts((('hint','G_BASE',1),)))
        self.assertEqual(result.status,'DIAGNOSTIC_INCOMPLETE',result.to_mapping())
        self.assertEqual(result.counts['core_inputs_submitted'],1)
        adapter = json.loads((self.root/'adapter_view.json').read_bytes())
        self.assertEqual(adapter['received'],1)
        self.assertEqual(adapter['rows'][0]['failure_code'],'CORE_API_EXCEPTION')
        self.assertIsNone(adapter['rows'][0]['result'])
        self.assertEqual(adapter['results'],[])
        self.assertEqual((adapter['counts']['REJECT'],adapter['counts']['QUARANTINE']),(0,0))
        arm = self.comparison()['arms']['CPC_REFERENCE']
        self.assertIsNone(arm['results'][0]['result'])
        self.assertEqual(arm['join']['core_ledger'][0]['primary_reason'],'CORE_EVALUATION_UNRESOLVED')
        self.assertEqual(runner.verify_worked_output(self.root)['runner_status'],'DIAGNOSTIC_INCOMPLETE')

    def test_observation_budget_exhaustion_stops_before_followup_acceptance(self):
        f = SyntheticPorts((('hint','G_BASE',1),),operation_fault='wait_then_match')
        with self.assertRaises(ContractError):
            replace(f.config,max_observations=1)
        self.assertFalse(self.root.exists())
        f.config = replace(f.config,max_observations=2)
        _, result = self.execute(f)
        self.assertEqual((result.status,result.phase),('FAILED','FOLLOWUP_INPUT'))
        self.assertEqual(result.counts['observation_ingestions_attempted'],2)
        self.assertEqual(result.counts['supplied_operations'],2)
        self.assertEqual(result.counts['controller']['publications'],1)
        self.assertEqual(result.counts['external_rows'],0)
        self.assertEqual(result.counts['core_inputs_submitted'],0)
        retained = [p.read_bytes() for p in (self.root/'received').glob('*.bin')]
        self.assertTrue(all(raw in retained for raw in f.returned_raw))

    def test_complete_chain_retention_budget_failure_does_not_claim_core_or_episode_completion(self):
        original = runner._Run._retain
        def retain(state,label,raw):
            if label == 'complete_chain':
                # The genuine retention cap fails before any completed-chain append.
                with patch.object(runner,'MAX_RECEIVED_BYTES',state.received_bytes+len(raw)-1):
                    return original(state,label,raw)
            return original(state,label,raw)
        with patch.object(runner._Run,'_retain',retain):
            f, result = self.execute(SyntheticPorts((('hint','G_BASE',1),)))
        self.assertEqual(result.status,'FAILED',result.to_mapping())
        self.assertEqual((result.counts['external_rows'],result.counts['outcome_derivations']),(1,1))
        self.assertEqual((result.counts['complete_core_inputs'],result.counts['core_inputs_submitted'],
                          result.counts['completed_episodes']),(0,0,0))
        self.assertEqual(list((self.root/'received').glob('*complete_chain.bin')),[])
        self.assertFalse(any(r.get('event')=='EPISODE_COMPLETED' for _,r in self.documents()))

    def test_episode_completion_event_failure_does_not_increment_completed_episodes(self):
        original = runner._Run.event
        def event(state,name,data):
            if name == 'EPISODE_COMPLETED':
                raise OSError('synthetic episode event write failure')
            return original(state,name,data)
        with patch.object(runner._Run,'event',event):
            _, result = self.execute(SyntheticPorts((('hint','G_BASE',1),)))
        self.assertEqual(result.status,'FAILED',result.to_mapping())
        self.assertEqual((result.counts['complete_core_inputs'],result.counts['core_inputs_submitted'],
                          result.counts['completed_episodes']),(1,0,0))
        self.assertEqual(len(list((self.root/'received').glob('*complete_chain.bin'))),1)

    def test_episode_reference_suffix_capacity_rejected_before_runner_io(self):
        f = SyntheticPorts((('hint','G_BASE',1),))
        with self.assertRaises(ContractError):
            replace(f.config.episodes[0],episode_ref='a'*256)
        self.assertFalse(self.root.exists())
        self.assertEqual((len(f.operations),len(f.helps),len(f.outcomes)),(0,0,0))

    def test_configuration_and_nested_proxy_result_serialize(self):
        f = SyntheticPorts()
        self.assertEqual(runner.RunnerConfig.from_bytes(canonical_json_bytes(f.config.to_mapping())), f.config)
        result = runner.RunnerResult('synthetic:path','FAILED','TEST',None,
            MappingProxyType({'nested':MappingProxyType({'values':(1,2)})}),None)
        encoded = json.dumps(result.to_mapping())
        self.assertEqual(json.loads(encoded)['counts']['nested']['values'], [1,2])


if __name__ == '__main__':
    unittest.main()

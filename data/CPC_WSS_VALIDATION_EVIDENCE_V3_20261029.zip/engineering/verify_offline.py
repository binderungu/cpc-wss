"""Bounded offline mechanical checks, never a study runner or source repair."""
from __future__ import annotations
import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import platform
import py_compile
import subprocess
import sys
import time
import trace
import unittest

OUT = Path(__file__).resolve().parent
WORKSPACE = OUT.parent.parent
CODE = WORKSPACE / 'implementations/cpc_wss_u01_v1_11_0'
ROOTS = [CODE / 'src', CODE / 'references/cpc_release/implementation/src',
         CODE / 'references/comparator_release']


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def offline_guard():
    denied = []
    def guard(event, args):
        if event in {'socket.connect', 'socket.connect_ex', 'socket.bind', 'socket.getaddrinfo',
                     'sqlite3.connect', 'sqlite3.connect/handle'}:
            denied.append(event)
            raise PermissionError('Mechanical verification forbids network/database access')
    sys.addaudithook(guard)
    return denied


def environment():
    return {'executable':sys.executable, 'resolved_executable':str(Path(sys.executable).resolve()),
            'executable_sha256':sha(Path(sys.executable).resolve()), 'version':sys.version,
            'implementation':platform.python_implementation(), 'platform':platform.platform(),
            'sys_flags':str(sys.flags), 'dependencies':'standard library only; no installs',
            'source_root':str(CODE), 'evidence_class':'SYNTHETIC_OFFLINE_MECHANICAL_QA'}


def import_child():
    sys.dont_write_bytecode = True
    sys.path[:0] = [str(p) for p in ROOTS]+[str(OUT/'regression_tests'),str(OUT/'verification')]
    deny = offline_guard()
    # Import probe must have no writes, processes, or service interactions.
    def no_mutation(event, args):
        forbidden = {'os.mkdir','os.remove','os.rmdir','os.rename','os.link','os.symlink',
                     'os.chmod','os.chown','os.truncate','subprocess.Popen','os.system'}
        if event in forbidden:
            raise PermissionError('Import probe mutation forbidden: ' + event)
        if event == 'open':
            path, mode, flags = args
            if flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND):
                raise PermissionError('Import probe file write forbidden')
    sys.addaudithook(no_mutation)
    names = ['wss_bridge','wss_bridge.primitives','wss_bridge.configuration',
             'wss_bridge.native_contract','wss_bridge.ledger','wss_bridge.native_transport','wss_bridge.native_capture','wss_bridge.episode','wss_bridge.controller','wss_bridge.renderer','wss_bridge.capture','wss_bridge.producer','wss_bridge.cpc_adapter','wss_bridge.outcomes','wss_bridge.join','wss_bridge.baselines','wss_bridge.reporting','wss_bridge.producer_references','wss_bridge.worked_runner','cpc2','cpc2.api',
             'cpc2.profile','cpc2.export','comparator.independent_rules']
    imported = []
    for name in names:
        module = importlib.import_module(name)
        expected = ROOTS[0] if name.startswith('wss_bridge') else ROOTS[1] if name.startswith('cpc2') else ROOTS[2]
        file = Path(module.__file__).resolve()
        if not file.is_relative_to(expected.resolve()):
            raise RuntimeError('Unexpected import provenance: ' + name)
        imported.append({'module':name,'path':str(file),'sha256':sha(file)})
    from wp04_fixtures import inputs as make_inputs
    from wss_bridge.renderer import render
    prepared=[make_inputs(condition,config) for condition in ['hint','answer']
              for config in ['G_BASE','G_STYLE','G_CAP','G_RATIONALE','G_SEED']]
    def pure_boundary(event,args):
        if event == 'open' or event.startswith(('socket.','subprocess.','sqlite3.')) or event in {
                'os.listdir','os.scandir','os.system','os.getenv','os.putenv','os.unsetenv'}:
            raise PermissionError('Pure consume IO forbidden: '+event)
    sys.addaudithook(pure_boundary)
    pure_results=[render(*args) for args in prepared]
    if any(result.trace['status']!='BODY_PREPARED_NOT_PUBLISHED' for result in pure_results):
        raise RuntimeError('Invalid pure consume state')
    print(json.dumps({'pure_consume_cases':len(pure_results),'imports':imported,'mutation_guard':'enforced during imports',
                      'network_database_denials':deny,'admission_or_signing_calls':False}))


def compile_import():
    receipt={'environment':environment(),'compiled':[],'failures':[]}
    for file in sorted(CODE.rglob('*.py')):
        relative=file.relative_to(CODE)
        target=OUT/'compiled_final'/relative.with_suffix('.pyc')
        target.parent.mkdir(parents=True,exist_ok=True)
        try:
            py_compile.compile(str(file), cfile=str(target), doraise=True,
                invalidation_mode=py_compile.PycInvalidationMode.CHECKED_HASH)
            receipt['compiled'].append({'source':str(relative),'source_sha256':sha(file),
                                        'pyc':str(target.relative_to(OUT)),'pyc_sha256':sha(target)})
        except Exception as error:
            receipt['failures'].append({'source':str(relative),'error':repr(error)})
    child=subprocess.run([sys.executable,'-I','-B',str(Path(__file__).resolve()),'--import-child'],
                         cwd=OUT/'scratch',capture_output=True,text=True,timeout=30)
    (OUT/'logs/IMPORT_final.stdout.txt').write_text(child.stdout)
    (OUT/'logs/IMPORT_final.stderr.txt').write_text(child.stderr)
    receipt['import_exit_code']=child.returncode
    if child.returncode == 0:
        receipt['import_receipt']=json.loads(child.stdout)
    receipt['passed']=not receipt['failures'] and child.returncode==0
    write_json(OUT/'results/COMPILE_IMPORT_final.json',receipt)
    print(json.dumps({'phase':'compile_import','compiled':len(receipt['compiled']),
                      'import_exit_code':child.returncode,'passed':receipt['passed']}))
    return 0 if receipt['passed'] else 1


class DetailedResult(unittest.TextTestResult):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.rows=[]; self.subtests=[]; self.status={}; self.starts={}
    def startTest(self,test):
        self.starts[test.id()]=time.monotonic(); self.status[test.id()]='RUNNING'
        super().startTest(test)
    def addSuccess(self,test):
        self.status[test.id()]='PASS'; super().addSuccess(test)
    def addFailure(self,test,err):
        self.status[test.id()]='FAIL'; super().addFailure(test,err)
    def addError(self,test,err):
        self.status[test.id()]='ERROR'; super().addError(test,err)
    def addSkip(self,test,reason):
        self.status[test.id()]='SKIP'; super().addSkip(test,reason)
    def addExpectedFailure(self,test,err):
        self.status[test.id()]='EXPECTED_FAILURE'; super().addExpectedFailure(test,err)
    def addUnexpectedSuccess(self,test):
        self.status[test.id()]='UNEXPECTED_SUCCESS'; super().addUnexpectedSuccess(test)
    def addSubTest(self,test,subtest,err):
        state='PASS' if err is None else 'FAIL' if issubclass(err[0],test.failureException) else 'ERROR'
        self.subtests.append({'parent':test.id(),'id':subtest.id(),'status':state})
        if err is not None:self.status[test.id()]=state
        super().addSubTest(test,subtest,err)
    def stopTest(self,test):
        self.rows.append({'id':test.id(),'status':self.status[test.id()],
                          'seconds':round(time.monotonic()-self.starts[test.id()],6)})
        super().stopTest(test)


def run_tests(attempt,focus=False,targeted=False):
    sys.dont_write_bytecode=True
    os.environ['WSS_CODE_ROOT']=str(CODE)
    scratch=OUT/'scratch'/attempt; scratch.mkdir(exist_ok=False)
    os.environ['WSS_TEST_ARTIFACT_ROOT']=str(scratch)
    os.environ['TMPDIR']=str(scratch)
    sys.path[:0]=[str(p) for p in ROOTS]+[str(OUT/'regression_tests'),str(OUT/'verification')]
    denied=offline_guard()
    files=sorted((OUT/'regression_tests').glob('*.py'))+sorted((OUT/'verification').glob('*.py'))+[Path(__file__).resolve()]
    freeze={'attempt':attempt,'environment':environment(),'line_or_branch_coverage_measured':False,
            'test_files':[{'path':str(p.relative_to(OUT)),'sha256':sha(p)} for p in files],
            'source_manifest_sha256':sha(CODE/'SOURCE_MANIFEST.sha256'),'source_files':[{'path':str(p.relative_to(CODE)),'sha256':sha(p)} for p in sorted(CODE.rglob('*')) if p.is_file() and p.name!='SOURCE_MANIFEST.sha256']}
    write_json(OUT/'provenance'/f'{attempt}_SUITE_FREEZE.json',freeze)
    # Assertion-equivalent execution; line/branch coverage not measured in final gate.
    # Homebrew sys.base_prefix does not contain workspace source.
    with (OUT/'logs'/f'{attempt}_UNITTEST.txt').open('w') as stream:
        runner=unittest.TextTestRunner(stream=stream,verbosity=2,resultclass=DetailedResult)
        def discover_and_run():
            if targeted:
                suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name)
                    for name in ['test_producer.ProducerTests.test_ten_positive_bundles_real_clock_crypto_body_and_order_reconstructed',
                                 'test_producer.ProducerTests.test_future_configuration_time_cannot_consume_or_publish'])
            elif focus:
                suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name)
                    for name in ['test_contracts','test_native_transport','test_native_capture','test_controller_episode','test_wp03_integration','test_sc01_semantics'])
            else:
                suite=unittest.TestSuite([unittest.TestLoader().discover(str(OUT/'regression_tests'),pattern='test_*.py'),unittest.TestLoader().discover(str(OUT/'verification'),pattern='test_*.py')])
            return runner.run(suite)
        result=discover_and_run()
    receipt={'attempt':attempt,'test_methods_run':result.testsRun,'failures':len(result.failures),
             'errors':len(result.errors),'skipped':len(result.skipped),
             'expected_failures':len(result.expectedFailures),'unexpected_successes':len(result.unexpectedSuccesses),
             'passed':result.wasSuccessful() and not result.skipped and not result.expectedFailures,
             'test_methods':result.rows,'subtests':result.subtests,'network_database_denials':denied,
             'failure_details':[{'id':test.id(),'traceback':detail} for test,detail in result.failures+result.errors],
             'source_modified_by_harness':False,'scientific_experiment':False}
    write_json(OUT/'results'/f'{attempt}_UNITTEST.json',receipt)
    print(json.dumps({key:receipt[key] for key in ['attempt','test_methods_run','failures','errors','skipped','passed']}))
    return 0 if receipt['passed'] else 1


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--import-child',action='store_true')
    parser.add_argument('--compile-import',action='store_true')
    parser.add_argument('--tests',metavar='ATTEMPT')
    parser.add_argument('--focus',action='store_true')
    parser.add_argument('--targeted',action='store_true')
    args=parser.parse_args()
    if args.import_child:import_child()
    elif args.compile_import:sys.exit(compile_import())
    elif args.tests:sys.exit(run_tests(args.tests,args.focus,args.targeted))
    else:parser.error('Choose one explicit bounded phase')

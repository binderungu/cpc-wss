# CPC 2.0.1: klarifikasi kedalaman JSON dan verifikasi ulang D1

13 Oktober 2026. **PASS_FINITE_D1_CONTRACT201** untuk kontrak 2.0.1/schema cpc-2.0.1 dan source 2.0.2. Eksekusi pertama atas oracle baru serta satu clean replay masing-masing lulus 5.476/5.476 pemeriksaan, tanpa crash, admission keliru atau penolakan positive control. D2–D3 dan naskah tidak dikerjakan.

## Definisi normatif yang kini tunggal

Kontrak baru implementation/spec/CPC_NORMATIVE_CONTRACT_2.0.1.md §2.1 menetapkan root decoded JSON pada kedalaman 0. Setiap edge object→key, object→value atau array→item menambah 1. Key dan value adalah sibling, bukan path key→value. Scalar dan container kosong mempunyai kedalaman relatif 0; maximum mencakup keduanya. String panjang/Unicode/escaped JSON/whitespace encoding tidak menambah edge.

Contoh: {} dan [] bernilai 0; {"k":{}} bernilai 1; {"k":{"z":[]}} bernilai 2; [null] bernilai 1. Definisi berlaku pada seluruh decoded chain, termasuk integrity, nested proofs, extensions dan unknown subtrees; profile, key registry, waktu operator dan manifest uji terpisah tidak dihitung sebagai subtree.

Profil max_depth harus integer 1–32, bukan boolean. Nilai lebih kecil daripada chain lengkap tetap konfigurasi valid. D≤limit lulus guard kedalaman saja; aturan lain masih menentukan keputusan. D>limit mengembalikan I01/ERROR_INPUT sebelum struktur, semantik atau kriptografi dan tidak mengizinkan partial/truncated admission. Invalid external configuration C01 diperiksa lebih dahulu.

## Implementasi dan migrasi

common.iter_json_nodes dan common.json_depth memakai satu walker iterative; api._wire_scan menggunakannya agar diagnostic helper dan guard tidak berbeda definisi. Guard sekarang berlaku setelah strict decode dan shallow case_id accounting, sebelum pemeriksaan jenis root. Preflight menemukan root-kind mendahului guard; temuan R1 itu diperbaiki sebelum freeze dan dua decoded-array-root33 controls ditambahkan. Version constants di profile/API diselaraskan ke kontrak 2.0.1/schema cpc-2.0.1; source version2.0.2 terpisah dari contract version.

Lima dokumen spec baru, source/schema, dua profile utama dan key identities, registry, 32 file komponen, raw fixture dan oracle dibuat dalam release baru. Component bytes sengaja sama dengan aset sintetis sebelumnya; registry digests dihitung ulang dan cocok. Record/proof/context baru diterbitkan dan disegel dengan binding2.0.1. Delapan version controls menolak operator/chain/tag2.0.0; old bytes hanya dipakai sebagai negative reference. Tidak ada hasil lama yang dipindahkan labelnya ke2.0.1.

## Bukti yang dieksekusi

| Check | Hasil | Batas |
| --- | --- | --- |
| Syntax dan generic depth mechanics | 20 file Python compile; 6 tests lulus |Standalone literal examples, sibling edges, Unicode length, empty/scalar boundaries, iterative depth2000; bukan admission corpus. |
| Oracle/spec/source preflight |PASS sebelum freeze |R1 blocking finding dan R2 closure tetap tersimpan. |
| Controller D1 | 5.476/5.476 |130 ADMIT,766 REJECT,24 QUARANTINE,4.322 ERROR_INPUT,234 ERROR_CONFIG. |
| Record-order derivatives | 156/156 |Termasuk 5.476 rows, bukan tambahan independent mechanisms. |
| SDK/export boundaries | 5/5 |Unique operator refs, duplicate case_id INFO, duplicate ref/existing folder refusal. |
| Input accounting |130 admitted +5.346 excluded/not-evaluated =5.476 |Setiap ref/fingerprint tepat sekali; ERROR_CONFIG masuk NOT_EVALUATED_CONFIG. |
| Clean replay | 5.476/5.476 |Satu proses Codex terpisah, Python3.12.14 standard library; bukan field replication atau human/Pro gate. |
| Replay comparison |Raw decisions/checks/order/failures/exports byte-identik |SDKbatch UUIDrefs saja dinormalisasi. |
| Preservation |24.569 berkas lama dan 5.848 frozen files baru tidak berubah |Hash membuktikan konsistensi bytes saja. |

Cakupan mempertahankan 321 lokasi field per profile, absence/null/type/empty/unknown/domain/relationship dan applicability matrix. Depth controls mencakup baseline10 atlimit10, overflow10 under9, extraedge11 at11/under10, exact32/overflow33, profile-limit1 yang valid namun chain10 terlalu dalam, unknown subtree33, invalid config sebelum decode, serta decoded nonobject root33 sebelum jenis root. Reviewer merekonstruksi 5.386 targetdiagnostic obligations dan forbidden later-stage checks langsung dari raw.

Spec, source, profil, registry, input, expected diagnostics dan runner baru dibekukan sebelum admission baru. Tidak ada oracle edit setelah observasi pada release ini. Namun kasus berasal dari development corpus yang telah diketahui; freeze sebelum execution bukan independent new population atau konfirmasi probabilistik. Historical contract2.0.0 tetap memiliki initialFAIL42, repairFAIL2 dan PASS_CORRECTED_FINITE_D1 dengan post-observation depth correction. Keadaan lama tidak ditulis ulang.

Dua startup interruptions sebelum admission (nama key receipt salah dan parent run folder belum diinisialisasi) direkam terpisah di qa/; keduanya tidak menghasilkan input observations. Resolusinya initialization/bookkeeping, tanpa mengganti frozen source/oracle. Satu substantive run dan satu clean replay di atas merupakan seluruh conformance execution baru.

## Handoff dan batas lanjut

review/FINAL_VERIFICATION.md dan receipt memuat audit sumber/contract/inputs/diagnostics/accounting/replay. provenance/SOURCE_CONTRACT_FREEZE dan D1_EXECUTION_FREEZE mengikat versi; raw utama di runs/contract201_initial; raw replay yang dikemas di reproduction_evidence/independent201. Copy input/source workspace replay yang redundant tetap lokal, tidak digandakan di ZIP. State hanya bookkeeping, bukan scientific authority.

Klarifikasi depth kini normatif; caveat depth-counting tidak lagi diperlukan untuk kontrak 2.0.1. Hasil tetap finite synthetic conformance, bukan exhaustive correctness, kejujuran issuer, production security, consent/ethics nyata, actual artifact use/persistence/release, learning effects atau JLA readiness. Source menguji metadata proof yang diberikan; mode measured pada fixture tidak membuktikan actual consumed bytes. D2/D3/manuscript/public release/API berbayar tetap tidak dilakukan.

Untuk replay dari paket yang diekstrak, pakai nama folder run baru:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 execution/run_conformance.py --run new_replay201
```

Paket penuh sudah memiliki parent runs. Pada clean-copy subset yang hanya berisi frozen input/source, buat dahulu direktori kosong runs. Python≥3.11 diperlukan; hasil aktual menggunakan 3.12.14. Lanjut ke tahap berikutnya hanya setelah user memberikan scope baru.

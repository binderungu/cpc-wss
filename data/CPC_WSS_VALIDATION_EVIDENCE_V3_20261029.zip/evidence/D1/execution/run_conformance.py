"""Frozen finite D1 admission runner; no fixture producer or AI/model runtime."""
from __future__ import annotations
import argparse,collections,hashlib,hmac,json,os,re,sys,time,traceback
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path,value):path.write_text(json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
def jsonl(path):return [json.loads(line) for line in path.read_text().splitlines()]

def verify_bindings(manifest):
    errors=[rel for rel,hashed in manifest['files'].items() if not (ROOT/rel).is_file() or sha(ROOT/rel)!=hashed]
    if errors:raise RuntimeError('Frozen inputs/source changed: '+str(errors[:5]))

def independent_seals(raw,keys):
    value=json.loads(raw);errors=[]
    def check(obj,signed,path):
        try:
            content='sha256:'+hashlib.sha256(json.dumps(signed,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
            env=obj['integrity'];key=keys[env['key_id']].encode('ascii')
            mac='hmac-sha256:'+hmac.new(key,content.encode('ascii'),hashlib.sha256).hexdigest()
            if env['content_digest']!=content or not hmac.compare_digest(env['mac'],mac):errors.append(path)
        except (KeyError,ValueError,TypeError,UnicodeError):errors.append(path)
    for i,record in enumerate(value.get('records',[])):
        if not isinstance(record,dict):continue
        check(record,{k:v for k,v in record.items() if k!='integrity'},'record-'+str(i))
        payload=record.get('payload',{})
        if not isinstance(payload,dict):continue
        for kind in ('launch_attestation','commitment','release_attestation'):
            proof=payload.get(kind)
            if isinstance(proof,dict) and isinstance(proof.get('body'),dict):
                check(proof,proof['body'],kind)
                usage=proof['body'].get('usage_attestation')
                if isinstance(usage,dict) and isinstance(usage.get('body'),dict):check(usage,usage['body'],'usage')
    return errors

def diagset(result):return sorted(set((d['rule_id'],d['code'],d['disposition']) for d in result.get('diagnostics',[])))

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--run',required=True);parser.add_argument('--source',default='implementation');args=parser.parse_args()
    manifest=json.loads((ROOT/'provenance/D1_EXECUTION_FREEZE.json').read_text());verify_bindings(manifest)
    source=ROOT/args.source
    if args.source!='implementation':
        patch_manifest=json.loads((source/'SOURCE_FREEZE.json').read_text())
        if any(sha(source/r)!=h for r,h in patch_manifest['files'].items()):raise RuntimeError('Repair source freeze drift')
    sys.path.insert(0,str(source/'src'))
    from cpc2.api import validate_raw,validate_batch
    from cpc2.export import export_results,partition_results,EXPORT_FIELDS
    run=ROOT/'runs'/args.run;run.mkdir(exist_ok=False)
    source_hashes={str(p.relative_to(source)):sha(p) for sub in ('src','schemas') for p in (source/sub).rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    header={'run':args.run,'source':args.source,'source_files':source_hashes,'freeze_sha256':sha(ROOT/'provenance/D1_EXECUTION_FREEZE.json'),
            'oracle':'oracle/EXPECTED_FROZEN.jsonl','oracle_sha256':sha(ROOT/'oracle/EXPECTED_FROZEN.jsonl'),'runtime':sys.version,
            'D2':'NOT_RUN','D3':'NOT_RUN','manuscript_revision':'NOT_PERFORMED'}
    dump(run/'RUN_BINDING.json',header)
    rows=jsonl(ROOT/header['oracle']);results={};checks=[];exceptions=[];start=time.monotonic()
    with (run/'RAW_DECISIONS.jsonl').open('x') as raw_out,(run/'CASE_CHECKS.jsonl').open('x') as checks_out:
        for i,row in enumerate(rows):
            data=(ROOT/row['input_path']).read_bytes();context=json.loads((ROOT/row['context_path']).read_text())
            assert hashlib.sha256(data).hexdigest()==row['input_sha256']
            issues=[]
            if row['integrity_policy']=='ALL_AVAILABLE_SEALS_INDEPENDENTLY_VALID':
                seal_errors=independent_seals(data,context['key_registry'])
                if seal_errors:raise RuntimeError('Pre-execution semantic fixture seals failed: '+row['case_id'])
            try:
                result=validate_raw(data,context['profile'],context['key_registry'],context['validation_time'],input_ref=row['input_ref'])
            except Exception as exc:
                result={'disposition':'EXECUTION_ERROR','exception_type':type(exc).__name__,'exception':str(exc),'traceback':traceback.format_exc()}
                exceptions.append(row['case_id']);issues.append('UNCAUGHT_EXCEPTION')
            results[row['case_id']]=result
            if result['disposition']!=row['expected_disposition']:issues.append('DISPOSITION_MISMATCH')
            for expected in row['required_diagnostics']:
                if not any(d['rule_id']==expected['rule_id'] and d['disposition']==expected['disposition'] and
                           d.get('path','').startswith(expected.get('path_prefix','')) and
                           ('code' not in expected or d['code']==expected['code']) for d in result.get('diagnostics',[])):
                    issues.append('MISSING_REQUIRED_DIAGNOSTIC:'+json.dumps(expected,sort_keys=True))
            if any(d['rule_id'] in row.get('forbidden_diagnostic_rules',[]) for d in result.get('diagnostics',[])):
                issues.append('EVALUATION_AFTER_TERMINATING_BOUNDARY')
            if result['disposition']!='EXECUTION_ERROR':
                if result.get('input_ref')!=row['input_ref'] or result.get('input_sha256')!='sha256:'+row['input_sha256']:issues.append('INPUT_ACCOUNTING_IDENTITY')
                exported=result.get('admitted_record')
                if result['disposition']=='ADMIT':
                    if not isinstance(exported,dict) or set(exported)!=EXPORT_FIELDS:issues.append('INCOMPLETE_ADMITTED_EXPORT')
                    if any(d['disposition']!='INFO' for d in result['diagnostics']):issues.append('ADMIT_WITH_BLOCKING_DIAGNOSTIC')
                elif exported is not None:issues.append('REFUSAL_HAS_ADMITTED_RECORD')
                if row['family']=='required_field_dimension' and any(d['code'] in ('mac_mismatch','content_digest_mismatch') for d in result['diagnostics']):issues.append('INCIDENTAL_CRYPTO_MASK')
            check={'case_id':row['case_id'],'input_ref':row['input_ref'],'family':row['family'],'profile_name':row['profile_name'],
                   'expected':row['expected_disposition'],'observed':result['disposition'],'passed':not issues,'issues':issues}
            checks.append(check)
            raw_out.write(json.dumps({'scenario_id':row['case_id'],'input_path':row['input_path'],'context_path':row['context_path'],'result':result},sort_keys=True,ensure_ascii=False)+'\n')
            checks_out.write(json.dumps(check,sort_keys=True)+'\n')
            if (i+1)%100==0:
                raw_out.flush();checks_out.flush()
                dump(run/'PROGRESS.json',{'completed':i+1,'total':len(rows),'failed_so_far':sum(not c['passed'] for c in checks)})
                print('D1',i+1,'/',len(rows),'failed',sum(not c['passed'] for c in checks),flush=True)
        raw_out.flush();checks_out.flush();os.fsync(raw_out.fileno());os.fsync(checks_out.fileno())
    order_checks=[]
    for row in rows:
        if 'parent_case_id' not in row:continue
        parent=results[row['parent_case_id']];child=results[row['case_id']]
        pexport={k:v for k,v in (parent.get('admitted_record') or {}).items() if k!='input_ref'}
        cexport={k:v for k,v in (child.get('admitted_record') or {}).items() if k!='input_ref'}
        order_checks.append({'case_id':row['case_id'],'parent':row['parent_case_id'],
                             'passed':parent['disposition']==child['disposition'] and diagset(parent)==diagset(child) and pexport==cexport})
    dump(run/'ORDER_CHECKS.json',order_checks)
    export_status={};sdk_checks=[]
    supported=[r for r in results.values() if r['disposition']!='EXECUTION_ERROR']
    try:
        export_status=export_results(supported,run/'export')
        if exceptions:export_status['omitted_execution_errors']=exceptions
        before={p.name:sha(p) for p in (run/'export').iterdir()}
        try:export_results(supported,run/'export');existing_rejected=False
        except FileExistsError:existing_rejected=True
        sdk_checks.append({'test':'existing_output_refused_without_mutation','passed':existing_rejected and before=={p.name:sha(p) for p in (run/'export').iterdir()}})
    except Exception as exc:export_status={'error':type(exc).__name__,'message':str(exc),'accounting_complete':False}
    for profile_name in ('writing_feedback','quiz_tutor'):
        row=next(r for r in rows if r['profile_name']==profile_name and r['family']=='positive' and r['expected_disposition']=='ADMIT')
        context=json.loads((ROOT/row['context_path']).read_text());data=(ROOT/row['input_path']).read_bytes()
        try:
            batch=validate_batch([data,data],context['profile'],context['key_registry'],context['validation_time'])
            partition=partition_results(batch)
            good=(len(batch)==2 and all(r['disposition']=='ADMIT' for r in batch) and len({r['input_ref'] for r in batch})==2 and
                  any(d['code']=='duplicate_case_id_metadata' and d['disposition']=='INFO' for d in batch[1]['diagnostics']) and partition['received']==2)
            sdk_checks.append({'test':'duplicate_case_id_unique_operator_refs_'+profile_name,'passed':good})
            duplicate=[dict(batch[0]),dict(batch[0])]
            try:partition_results(duplicate);blocked=False
            except ValueError:blocked=True
            sdk_checks.append({'test':'duplicate_operator_ref_rejected_'+profile_name,'passed':blocked})
            dump(run/('BATCH_'+profile_name+'.json'),batch)
        except Exception as exc:sdk_checks.append({'test':'batch_'+profile_name,'passed':False,'exception':type(exc).__name__})
    dump(run/'SDK_EXPORT_CHECKS.json',sdk_checks)
    allpass=all(c['passed'] for c in checks) and all(c['passed'] for c in order_checks) and all(c['passed'] for c in sdk_checks) and not exceptions and export_status.get('accounting_complete',False) and export_status.get('received')==len(rows)
    summary={'run':args.run,'verdict':'PASS_FINITE_D1' if allpass else 'FAIL_D1','cases':len(rows),'passed_cases':sum(c['passed'] for c in checks),
             'failed_cases':sum(not c['passed'] for c in checks),'uncaught_exceptions':len(exceptions),
             'false_admits':sum(c['observed']=='ADMIT' and c['expected']!='ADMIT' for c in checks),
             'false_refusals':sum(c['observed']!='ADMIT' and c['expected']=='ADMIT' for c in checks),
             'observed_dispositions':dict(collections.Counter(r['disposition'] for r in results.values())),
             'order_derivatives':len(order_checks),'order_checks_passed':sum(c['passed'] for c in order_checks),'sdk_export_checks':sdk_checks,
             'export_accounting':export_status,'elapsed_seconds':round(time.monotonic()-start,3),'elapsed_interpretation':'run bookkeeping, not comparative performance evidence',
             'D2':'NOT_RUN','D3':'NOT_RUN','source':args.source,'oracle_sha256':header['oracle_sha256']}
    dump(run/'SUMMARY.json',summary);dump(run/'FAILURES.json',[c for c in checks if not c['passed']]);verify_bindings(manifest)
    print(json.dumps(summary,indent=2),flush=True)

if __name__=='__main__':main()

# Migration and evidence boundary — contract 2.0.1

Date: 13 October 2026. Normative contract: 2.0.1; required schema tag: `cpc-2.0.1`. This release clarifies decoded JSON depth and aligns a new implementation; D1 is pending at the prospective specification freeze.

| Version | Meaning | Evidence boundary |
|---|---|---|
| Historical reference 1.0.0 / protocol1.0.1 | Submitted IJTEL ecosystem | Historical reported evidence only |
| October technical candidate1.1.0 sourceR2 | Older finite synthetic tool validation | Original bounded results and residual defects preserved |
| Contract 2.0.0 / source 2.0.1 corrected D1 R5 | Original four-record/proof contract with previously unstated depth convention | Original failed oracle/run and corrected finite D1 retained; depth setup correction was post-observation |
| Contract 2.0.1 / schema cpc-2.0.1 | Explicit root-zero depth including keys, scalar leaves and empty containers; same other contract semantics | New profile/registry/corpus/oracle freeze before new D1; cases derived from existing development corpus, not a new confirmatory population |

## Normative delta

The depth of the complete decoded chain is its maximum root-zero descendant depth. Each object-to-key, object-to-value or array-to-item edge increments depth by 1. Keys and values are siblings. Scalars and empty containers have relative depth 0. Depth covers proofs, integrity, extensions and unsupported input subtrees, but excludes separately supplied operator profile/key registry/time/test manifest. String length and byte length do not add depth. See section 2.1 for recurrence and examples.

Frozen `input_limits.max_depth` is an integer 1..32, excluding booleans. A smaller limit remains valid even when a complete chain cannot fit. At/below limit passes only depth guard. Above limit is I01/ERROR_INPUT before structural, semantic or cryptographic evaluation, without partial/truncated admission. ERROR_CONFIG is still checked first. All other record classes, cryptographic/digest conventions, authority, artifact/consent/privacy policy and ordinary in-domain disposition precedence remain unchanged.

## Reissue; no historical retag

Create distinct new profile identities/versions bound to contract 2.0.1 and schema cpc-2.0.1. Reissue and freeze their registry instances and provenance even if component bytes/digests are unchanged. Generate separate 2.0.1 fixture files; update signed version/profile bindings and reseal nested proofs, commitments, records and predecessor links under the new frozen identities. Never relabel old files or results as 2.0.1. Old code retains its original accepted contract/schema versions and must not be modified to accept this release.

Before the new D1 run, freeze the new contract/source/profile/key registry/component metadata/corpus and independent expected decisions. Derived development cases remain finite synthetic conformance. A frozen new oracle is a prospective execution boundary; it does not erase knowledge obtained from old runs, make this a novel confirmatory population or guarantee completeness beyond the covered cases. Preserve old failed and corrected R5 runs under contract 2.0.0 with their original statuses and caveats.

## Authority

Authorized: specification clarification, aligned new implementation and D1 re-verification only. D2 actual-consumed-artifact capture, D3 comparison/LA analysis, manuscript changes, paid APIs, public release and submission are not authorized here. D1 signatures/registry equality and bytes-consistent hashes do not prove actual artifact use, learner effects, human usability or production security. The measured subset remains prompt/generation; other six components remain declared. Keep all original receipts and failures.

"""Prespecified wire/config/resource-boundary probes, not D2 performance tests."""
from copy import deepcopy
import json
from fixture_factory import load_context, make_chain, reseal, canonical_json
from structural_cases import descriptor

def _depth(value):
    if isinstance(value,dict):return max([0]+[1+_depth(v) for v in value.values()]+[1 for k in value])
    if isinstance(value,list):return max([0]+[1+_depth(v) for v in value])
    return 0

def _context_chain(chain,profile,name):
    old,_,_=load_context(name)
    def walk(value):
        if isinstance(value,dict):
            for key,item in list(value.items()):
                if key in ('profile_id','profile_version') and item==old[key]:value[key]=profile[key]
                else:walk(item)
        elif isinstance(value,list):
            for item in value:walk(item)
    walk(chain)
    return reseal(chain,name)

def build_cases():
    cases=[]
    for name in ('writing_feedback','quiz_tutor'):
        p,keys,stamp=load_context(name)
        seed=make_chain(name,case_id='boundary-control-'+name)
        def add(slug,chain=seed,expected='ERROR_INPUT',rule='I01',family='wire_boundary',**extra):
            cid=name+'-boundary-'+slug
            d=descriptor(cid,name,deepcopy(chain),expected,[] if expected=='ADMIT' else [{'rule_id':rule,'disposition':'ERROR_CONFIG' if expected=='ERROR_CONFIG' else 'ERROR_INPUT'}],family,slug,**extra)
            cases.append(d)
        for field in p:
            for mode in ('absent','null','wrong_type'):
                altered=deepcopy(p)
                if mode=='absent':del altered[field]
                elif mode=='null':altered[field]=None
                else:altered[field]=[] if isinstance(p[field],(str,dict)) else {}
                add('config-'+field+'-'+mode,expected='ERROR_CONFIG',rule='C01',family='external_config',profile_override=altered)
        changes={
          'not-frozen':('profile_state','draft'),
          'unsupported-contract':('contract_version','1.0.0'),
          'unsupported-schema':('schema_version','old-schema'),
          'duplicate-conditions':('conditions',[p['conditions'][0],p['conditions'][0]]),
          'no-measured-subset':('required_measured_components',[]),
          'unsupported-release':('release_boundary','network-receipt'),
          'authority-absent':('namespace_policy',{'ui.activity_title':{'role':'descriptive','required':False,'mapping':{}}}),
          'invalid-clock-reference':('observer_clock_id',' '),
          'oversize-byte-limit':('input_limits',dict(p['input_limits'],max_bytes=1048577)),
          'oversize-record-limit':('input_limits',dict(p['input_limits'],max_records=17)),
          'oversize-depth-limit':('input_limits',dict(p['input_limits'],max_depth=33)),
          'oversize-id-limit':('input_limits',dict(p['input_limits'],max_identifier_chars=257)),
          'freeze-after-validation':('freeze_timestamp','2026-10-14T00:00:00Z')}
        for slug,(field,value) in changes.items():
            altered=deepcopy(p);altered[field]=value
            add('config-'+slug,expected='ERROR_CONFIG',rule='C01',family='external_config',profile_override=altered)
        for mode,new in [('empty',{}),('nonascii',dict(keys,**{next(iter(keys)):'SYNTHETIC_ONLY_é'}))]:
            add('keys-'+mode,expected='ERROR_CONFIG',rule='C01',family='external_config',keys_override=new)
        add('validation-time-naive',expected='ERROR_CONFIG',rule='C01',family='external_config',validation_time_override='2026-10-13T02:00:00')
        # Unreadable wire retains raw bytes and never acquires an invented ID.
        for slug,raw in [('empty',b''),('nonutf8',b'\xff'),('duplicate-root',b'{"records":[],"records":[]}'),
                         ('nonfinite',b'{"value":NaN}'),('root-list',b'[]'),('root-null',b'null'),
                         ('root-scalar',b'42'),('huge-integer',b'{"value":'+b'1'*5000+b'}')]:
            add(slug,raw_bytes=raw)
        add('decode-deep-nesting',raw_bytes=b'['*2000+b'0'+b']'*2000)
        for slug,value in [('float',0.5),('negative',-1),('surrogate','\ud800')]:
            chain=deepcopy(seed);chain['wire_probe']=value
            add(slug,raw_bytes=json.dumps(chain,ensure_ascii=True,separators=(',',':')).encode())
        # Syntax-qualified RFC3339 boundary that parse_time may not truncate.
        for slug,value in [('naive','2026-10-13T01:00:00'),('overflow','9999-12-31T23:59:59-23:59')]:
            chain=deepcopy(seed);chain['records'][0]['issued_at']=value
            add(slug,chain=reseal(chain,name),rule='I02',family='timestamp_encoding')
        # A registered arbitrary metadata string reaches the exact raw-byte
        # bound without changing the allowed identifier language.
        ext=p['extension_keys'][0]
        for delta in (0,1):
            chain=deepcopy(seed);chain['records'][0]['extensions']={ext:{'padding':''}}
            chain=reseal(chain,name)
            padding=p['input_limits']['max_bytes']-len(canonical_json(chain))+delta
            chain['records'][0]['extensions'][ext]['padding']='x'*padding
            chain=reseal(chain,name);raw=canonical_json(chain)
            assert len(raw)==p['input_limits']['max_bytes']+delta
            add('raw-bytes-'+str(len(raw)),chain=chain,raw_bytes=raw,expected='ADMIT' if delta==0 else 'ERROR_INPUT')
        for target in (32,33):
            chain=deepcopy(seed);chain['records'][0]['extensions']={ext:0}
            while _depth(chain)<target:chain['records'][0]['extensions'][ext]={'ordinary':chain['records'][0]['extensions'][ext]}
            chain=reseal(chain,name);assert _depth(chain)==target
            add('depth-'+str(target),chain=chain,expected='ADMIT' if target==32 else 'ERROR_INPUT')
        for count in (16,17):
            chain=deepcopy(seed)
            chain['records'].extend(deepcopy(chain['records'][0]) for _ in range(count-4))
            d=descriptor(name+'-count-'+str(count),name,chain,'REJECT' if count==16 else 'ERROR_INPUT',
                         [{'rule_id':'R08' if count==16 else 'I01','disposition':'REJECT' if count==16 else 'ERROR_INPUT'}],
                         'record_bound','Maximum supported count allows cardinality evaluation; overflow stops input.')
            cases.append(d)
        for length in (256,257):
            chain=deepcopy(seed);chain['case_id']='x'*length
            add('id-'+str(length),chain=chain,expected='ADMIT' if length==256 else 'ERROR_INPUT',rule='I02')
        chain=deepcopy(seed);chain['case_id']='測'*256
        add('unicode-id-256',chain=chain,expected='ADMIT',rule='I02')
        strict=deepcopy(p);strict['profile_id']+='-strict128';strict['profile_version']+='-strict128'
        strict['input_limits']['max_identifier_chars']=128
        for length in (128,129):
            chain=_context_chain(deepcopy(seed),strict,name);chain['case_id']='x'*length
            add('strict-id-'+str(length),chain=chain,expected='ADMIT' if length==128 else 'ERROR_INPUT',rule='I02',profile_override=strict)
        chain=_context_chain(deepcopy(seed),strict,name)
        for mapping in (chain['records'][1]['payload']['claim_namespaces'],chain['records'][1]['payload']['launch_attestation']['body']['namespace_values']):
            mapping['x'*129]='ordinary'
        chain=reseal(chain,name)
        d=descriptor(name+'-strict-map-key129',name,chain,'REJECT',
             [{'rule_id':'I02','disposition':'ERROR_INPUT'},{'rule_id':'R03','disposition':'REJECT'}],
             'compound_identifier_namespace_bound','Oversize unknown identifier map key retains shape error and safe policy rejection.',profile_override=strict)
        cases.append(d)
        for slug,limits in [('stricter-record-limit',dict(p['input_limits'],max_records=3)),
                            ('stricter-depth-limit',dict(p['input_limits'],max_depth=9))]:
            narrower=deepcopy(p);narrower['profile_id']+='-'+slug;narrower['profile_version']+='-'+slug
            narrower['input_limits']=limits
            chain=_context_chain(deepcopy(seed),narrower,name)
            add(slug,chain=chain,expected='ERROR_INPUT',rule='I01',family='valid_stricter_config_overflow',profile_override=narrower)
        # CPC2.0.1 fixes depth before execution: independent _depth recurrence
        # includes scalar leaves/empty containers; no import of candidate helper.
        exact=deepcopy(p);exact['profile_id']+='-depth10';exact['profile_version']+='-depth10'
        exact['input_limits']['max_depth']=10
        chain=_context_chain(deepcopy(seed),exact,name);assert _depth(chain)==10
        add('exact-depth10',chain=chain,expected='ADMIT',family='normative_depth_boundary',profile_override=exact,
            integrity_policy='ALL_AVAILABLE_SEALS_INDEPENDENTLY_VALID',measured_fixture_depth=10)
        for target,limit in ((11,11),(11,10),(32,32),(33,32)):
            context=deepcopy(p);context['profile_id']+='-depth'+str(limit);context['profile_version']+='-depth'+str(limit)
            context['input_limits']['max_depth']=limit
            chain=_context_chain(deepcopy(seed),context,name);chain['records'][0]['extensions']={ext:0}
            while _depth(chain)<target:chain['records'][0]['extensions'][ext]={'ordinary':chain['records'][0]['extensions'][ext]}
            chain=reseal(chain,name);assert _depth(chain)==target
            add('normative-depth-'+str(target)+'-limit-'+str(limit),chain=chain,expected='ADMIT' if target<=limit else 'ERROR_INPUT',
                family='normative_depth_boundary',profile_override=context,integrity_policy='ALL_AVAILABLE_SEALS_INDEPENDENTLY_VALID',measured_fixture_depth=target)
        shallow=deepcopy(p);shallow['profile_id']+='-depth1';shallow['profile_version']+='-depth1';shallow['input_limits']['max_depth']=1
        chain=_context_chain(deepcopy(seed),shallow,name)
        add('valid-profile-depth1-chain10',chain=chain,expected='ERROR_INPUT',rule='I01',family='external_profile_depth_excluded',profile_override=shallow,
            measured_fixture_depth=10,integrity_policy='ALL_AVAILABLE_SEALS_INDEPENDENTLY_VALID')
        for i in range(4):
            for value,slug in [(None,'null'),([], 'list'),({},'empty-object'),(42,'scalar')]:
                chain=deepcopy(seed);chain['records'][i]=value
                add('record-member-'+str(i)+'-'+slug,chain=chain,rule='I02',family='record_member_type')
        chain=deepcopy(seed);chain['records']=[]
        cases.append(descriptor(name+'-empty-evidence-array',name,chain,'QUARANTINE',
            [{'rule_id':'Q01','disposition':'QUARANTINE'}],'incomplete_all_records','Well-formed empty records is evidence incompleteness.'))
        paths=[('records',2,'payload','commitment','body','usage_attestation','body','sequence'),
               ('records',2,'payload','commitment','body','sequence'),
               ('records',2,'payload','release_attestation','body','sequence')]
        for i,path in enumerate(paths):
            chain=deepcopy(seed);obj=chain
            for key in path[:-1]:obj=obj[key]
            obj[path[-1]]=-1
            add('sequence-negative-'+str(i),chain=chain,raw_bytes=json.dumps(chain,sort_keys=True,separators=(',',':')).encode(),
                family='unsupported_sequence_wire',integrity_policy='UNSUPPORTED_WIRE_INTENTIONAL')
        chain=deepcopy(seed)
        for path,number in zip(paths,(0,0,1)):
            obj=chain
            for key in path[:-1]:obj=obj[key]
            obj[path[-1]]=number
        add('sequence-zero-positive',chain=reseal(chain,name),expected='ADMIT',family='numeric_lower_bound_positive')
    return cases

"""Prespecified 2.0.1 full-tree and config-first termination controls."""
from copy import deepcopy
import hashlib,json
from pathlib import Path
from fixture_factory import make_chain,load_context,canonical_json
from boundary_cases import _depth

ROOT=Path(__file__).resolve().parents[1]

def main():
    rows=[json.loads(l) for l in (ROOT/'oracle/EXPECTED.jsonl').read_text().splitlines()]
    extra=[];(ROOT/'inputs_extra').mkdir(exist_ok=False);(ROOT/'contexts_extra').mkdir(exist_ok=False)
    for name in ('writing_feedback','quiz_tutor'):
        profile,keys,stamp=load_context(name)
        for mode in ('unknown_subtree','invalid_config_before_decode'):
            chain=make_chain(name,case_id=name+'-depth-priority')
            context={'profile':deepcopy(profile),'key_registry':keys,'validation_time':stamp}
            if mode=='unknown_subtree':
                chain['profile_id']='unapproved-root-profile'
                chain['unsupported_subtree']=0
                while _depth(chain)<33:chain['unsupported_subtree']=[chain['unsupported_subtree']]
                assert _depth(chain)==33
                raw=canonical_json(chain);expected='ERROR_INPUT';rule='I01'
            else:
                context['profile']['profile_state']='draft'
                raw=b'{unparseable';expected='ERROR_CONFIG';rule='C01'
            cid=name+'-'+mode;cp='contexts_extra/'+cid+'.json';ip='inputs_extra/'+cid+'.raw'
            (ROOT/cp).write_bytes(canonical_json(context));(ROOT/ip).write_bytes(raw)
            extra.append({'case_id':cid,'profile_name':name,'input_path':ip,'context_path':cp,'input_ref':'CPC201-'+cid,
                'input_sha256':hashlib.sha256(raw).hexdigest(),'raw_bytes':len(raw),'expected_disposition':expected,
                'required_diagnostics':[{'rule_id':rule,'disposition':expected}],
                'forbidden_diagnostic_rules':['I02','I03','R01','R02','R03','R04','R05','R06','R07','R08','Q01','Q02']+(['I01'] if rule=='C01' else []),
                'family':'depth_config_evaluation_priority','description':mode,
                'integrity_policy':'ALL_AVAILABLE_SEALS_INDEPENDENTLY_VALID' if rule=='I01' else 'INVALID_CONFIGURATION_AND_WIRE'})
    with (ROOT/'oracle/DEPTH_PRECEDENCE_SUPPLEMENT.jsonl').open('x') as f:
        for row in extra:f.write(json.dumps(row,sort_keys=True)+'\n')
    with (ROOT/'oracle/EXPECTED_FINAL.jsonl').open('x') as f:
        for row in rows+extra:f.write(json.dumps(row,sort_keys=True,ensure_ascii=False)+'\n')
    print('Final finite oracle rows:',len(rows+extra),'admission NOT_RUN.')

if __name__=='__main__':main()

"""Per-location semantic applicability, unknown values and relation boundaries.

Opaque IDs have valid unfamiliar alternatives, not an invented finite domain.
Container-domain obligations are tested on closed or authorized map keys.
"""
from copy import deepcopy
from structural_cases import targets,display,seal_mutated,mirrored,PROOFS,descriptor,ABSENT
from fixture_factory import load_context,make_chain

ZERO_DIGEST='sha256:'+'0'*64
CONTEXT={'contract_version','profile_id','profile_version','schema_version','experiment_id',
         'experiment_version','audience','deployment_id','context_id','issuer'}

def classify(path,value):
    key=path[-1]
    if isinstance(value,(dict,list)):
        return 'container_keys','NOT_APPLICABLE_SCALAR_DOMAIN',None,None
    if key=='record_type':return 'class_discriminator','ERROR_INPUT','I03','unsupported-class'
    if 'integrity' in path:
        new=ZERO_DIGEST if key=='content_digest' else ('hmac-sha256:'+'0'*64 if key=='mac' else 'unapproved-integrity-policy')
        return 'integrity_policy_or_digest','REJECT','R01',new
    if key in ('issued_at','valid_from','expires_at'):
        new='2026-10-13T00:00:00Z' if key=='expires_at' else '2026-10-15T00:00:00Z'
        return 'timestamp_relation','REJECT','R01',new
    if key=='consent_at':return 'consent_time_relation','REJECT','R06','2026-10-13T01:00:08Z'
    if 'claim_namespaces' in path or 'namespace_values' in path:
        return 'permitted_raw_mapping','REJECT','R03','UNAPPROVED_RAW_LABEL'
    if 'artifacts' in path:
        return 'registered_artifact_metadata','REJECT','R05',ZERO_DIGEST if key=='digest' else 'unapproved-artifact-metadata'
    if 'measured_components' in path:
        if key in ('capture_ref','use_ref'):return 'opaque_observation_reference','ADMIT',None,'other-opaque-observation'
        return 'measurement_metadata_binding','REJECT','R05',ZERO_DIGEST if key=='digest' else 'unapproved-measurement-metadata'
    if key in CONTEXT:return 'external_context_or_authority','REJECT','R01','unapproved-signed-context'
    if key in ('case_id','nonce','proof_id','outcome_key'):
        return 'opaque_unconstrained_identifier','ADMIT',None,'other-opaque-valid-identifier'
    if key=='record_id':
        return ('opaque_unconstrained_identifier','ADMIT',None,'other-outcome-record') if path[1]==3 else ('record_reference_binding','REJECT','R07','other-record-id')
    if key=='unit_token':return 'shared_unit_binding','REJECT','R07','other-opaque-unit'
    if key=='sequence':return 'local_sequence_relation','REJECT','R07',1000 if 'usage_attestation' in path else 0
    if key=='clock_id':return 'observer_clock_domain','REJECT','R07','unapproved-clock'
    if key.startswith('predecessor_'):return 'predecessor_binding','REJECT','R07',ZERO_DIGEST if key.endswith('digest') else 'other-predecessor'
    if key in ('assignment_record_id','assignment_digest','launch_nonce'):
        return 'assignment_launch_binding','REJECT','R04',ZERO_DIGEST if key.endswith('digest') else 'other-launch-reference'
    if key=='resource_id':return 'platform_resource_domain','REJECT','R04' if 'launch_attestation' in path else 'R02','unapproved-resource'
    if key in ('resolution_record_id','resolution_digest','exposure_record_id','exposure_digest','commitment_digest','release_boundary'):
        return 'proof_record_or_release_binding','REJECT','R07',ZERO_DIGEST if key.endswith('digest') else 'other-proof-record-reference'
    if key in ('artifact_version','invocation_id'):return 'bundle_or_invocation_binding','REJECT','R05','unapproved-invocation-or-bundle'
    if key in ('fallback_used','fallback_authorized','authorization_ref'):
        return 'conditional_fallback_policy','REJECT','R06',True if type(value)is bool else 'unapproved-fallback-reference'
    if key in ('eligible','consent_state','consent_authority_ref','consent_policy_version','purpose'):
        return 'consent_eligibility_policy','REJECT','R06',False if type(value)is bool else 'unapproved-governance-value'
    if key in ('assigned_condition','requested_condition','resolved_condition','enacted_condition','attributed_condition','assignment_policy_version','resolver_version','scope'):
        return 'condition_or_operational_policy','REJECT','R02','unapproved-condition-or-policy'
    raise AssertionError('Unclassified normative field: '+display(path))

def build_cases_and_applicability():
    cases=[];matrix=[]
    for name in ('writing_feedback','quiz_tutor'):
        profile,_,_=load_context(name);seed=make_chain(name,case_id='domain-control-'+name)
        for i,(path,value) in enumerate(targets(seed,name)):
            category,verdict,rule,new=classify(path,value)
            cid=name+'-domain-'+str(i).zfill(3)
            row={'profile':name,'target_path':display(path),'classification':category,'expected':verdict,'case_id':cid if new is not None else ''}
            if new is None:
                row['rationale']='No scalar unknown value of this type; closed/map/array item language and member keys covered by field/closed-container/boundary cases.'
                matrix.append(row);continue
            mutations=mirrored(path,new);chain=seal_mutated(seed,name,mutations)
            required=[] if rule is None else [{'rule_id':rule,'disposition':'ERROR_INPUT' if verdict=='ERROR_INPUT' else 'REJECT'}]
            if value is None and path[-1].startswith('predecessor_'):
                required.append({'rule_id':'I02','disposition':'ERROR_INPUT'})
            integrity_policy='EXPLICIT_INTEGRITY_ATTACK' if 'integrity' in path and path[-1] in ('key_id','content_digest','mac') else 'ALL_AVAILABLE_SEALS_INDEPENDENTLY_VALID'
            cases.append(descriptor(cid,name,chain,verdict,required,category,display(path)+' unknown/domain/relation alternative',
                target_path=list(path),dimension='domain_or_relation',integrity_policy=integrity_policy))
            row['rationale']='Unfamiliar opaque alternative is allowed.' if verdict=='ADMIT' else 'Contract-authorized domain or readable relation boundary.'
            matrix.append(row)
        # Optional extensions still obey location/type/allowlist, and arbitrary
        # metadata keys do not inherit contract-identifier restrictions.
        parents=[('records',i) for i in range(4)]+[p+('body',) for p in PROOFS.values()]
        for i,parent in enumerate(parents):
            for mode,ext,expected,rule in [('registered',{profile['extension_keys'][0]:{'':'ordinary',' descriptive ':True,'k'*300:[1,'x']}},'ADMIT',None),
                    ('unregistered',{'unregistered:metadata':'ordinary'},'ERROR_INPUT','I03'),
                    ('null',None,'ERROR_INPUT','I02'),('wrong_type',[],'ERROR_INPUT','I02')]:
                chain=seal_mutated(seed,name,[(parent+('extensions',),ext)])
                c=descriptor(name+'-extension-location-'+str(i)+'-'+mode,name,chain,expected,
                    [] if rule is None else [{'rule_id':rule,'disposition':'ERROR_INPUT','path_prefix':display(parent)}],
                    'extension_location',display(parent)+' '+mode)
                cases.append(c)
        # Unknown component keys differ from unknown attributes in a known entry.
        a=('records',2,'payload','artifacts')
        chain=seal_mutated(seed,name,mirrored(a+('unregistered_component',),deepcopy(profile['artifact_registry']['baseline-v1']['ui'])))
        cases.append(descriptor(name+'-unknown-artifact-component',name,chain,'ERROR_INPUT',[{'rule_id':'I03','disposition':'ERROR_INPUT'}],
                                'unknown_component_key','Unknown artifact component key, consistent in both vectors.'))
        m=PROOFS['usage_attestation']+('body','measured_components','unregistered_component')
        entry={'component_id':'unregistered_component','version':'opaque-v1','digest':ZERO_DIGEST,'capture_ref':'opaque-cap','use_ref':'opaque-use'}
        chain=seal_mutated(seed,name,[(m,entry)])
        cases.append(descriptor(name+'-unknown-measured-component',name,chain,'ERROR_INPUT',[{'rule_id':'I03','disposition':'ERROR_INPUT'}],
                                'unknown_component_key','Unknown measured-component key.'))
        np=('records',1,'payload','claim_namespaces','unregistered:condition')
        chain=seal_mutated(seed,name,mirrored(np,'ordinary'))
        cases.append(descriptor(name+'-unknown-namespace-key',name,chain,'REJECT',[{'rule_id':'R03','disposition':'REJECT'}],
                                'unknown_namespace_key','Unknown namespace, matching claim and attestation.'))
        from relational_cases import build_cases as relational
        fallback=next(c['chain'] for c in relational() if c['case_id']=='REL-'+name+'-valid-same-condition-fallback')
        refpath=('records',1,'payload','authorization_ref')
        for mode,value in [('absent',ABSENT),('null',None),('wrong_type',[]),('empty',''),
                           ('whitespace',' '),('control','bad\x01ref'),('oversize','x'*257)]:
            chain=seal_mutated(fallback,name,[(refpath,value)])
            required=[{'rule_id':'I02','disposition':'ERROR_INPUT'},
                      {'rule_id':'R06','disposition':'NOT_EVALUABLE','path_prefix':display(refpath)}]
            cases.append(descriptor(name+'-active-fallback-ref-'+mode,name,chain,'ERROR_INPUT',required,
                'active_fallback_required_reference','Active authorized fallback requires a nonempty typed reference; '+mode,
                target_path=list(refpath),dimension='active_fallback_'+mode))
    return cases,matrix

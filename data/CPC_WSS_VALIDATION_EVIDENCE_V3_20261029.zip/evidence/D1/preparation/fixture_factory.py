"""Independent synthetic D1 evidence builder; no validator or runtime imports.

All attestations are authored fixtures. They do not observe artifact use,
commitment persistence, response generation, release, or consent in a runtime.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import hmac
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROFILE_NAMES = ('writing_feedback', 'quiz_tutor')


def canonical_json(value):
    """CPC JSON v2 from stdlib, independently implemented for fixture sealing."""
    def check(obj):
        if obj is None or type(obj) is bool or isinstance(obj, str):
            return
        if type(obj) is int and obj >= 0:
            return
        if isinstance(obj, list):
            for item in obj:
                check(item)
            return
        if isinstance(obj, dict) and all(isinstance(key, str) for key in obj):
            for item in obj.values():
                check(item)
            return
        raise ValueError('fixture_unsupported_wire_type')
    check(value)
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf-8')


def digest(value):
    return 'sha256:' + hashlib.sha256(canonical_json(value)).hexdigest()


def raw_digest(value):
    return 'sha256:' + hashlib.sha256(value).hexdigest()


canonical = canonical_json


def sign(value, issuer, profile, keys):
    """Integrity envelope over given signed value using explicit role issuer."""
    key_id = profile['issuer_key_policy'][issuer]
    key = keys[key_id]
    key_bytes = key.encode('ascii') if isinstance(key, str) else key
    hashed = digest(value)
    return {'algorithm': 'HMAC-SHA256', 'key_id': key_id, 'content_digest': hashed,
            'mac': 'hmac-sha256:' + hmac.new(key_bytes, hashed.encode('ascii'), hashlib.sha256).hexdigest()}


def load_context(profile_name):
    if profile_name not in PROFILE_NAMES:
        raise ValueError('unknown_fixture_profile')
    profile = json.loads((ROOT / 'profiles' / (profile_name + '.json')).read_text())
    keys = json.loads((ROOT / 'registry' / (profile_name + '_keys.json')).read_text())
    time = json.loads((ROOT / 'profiles' / (profile_name + '_context.json')).read_text())['validation_time']
    return profile, keys, time


def _integrity(signed, profile, keys):
    return sign(signed, signed['issuer'], profile, keys)


def validate_fixture_integrity(chain, profile_name):
    """Independent envelope check only; no semantics or disposition decisions.

    Missing record classes are allowed. Every existing signed envelope must
    digest/MAC-bind its own content and match the separately supplied role key.
    """
    profile, keys, _ = load_context(profile_name)
    errors = []
    def verify(obj, signed, path):
        try:
            expected = sign(signed, signed['issuer'], profile, keys)
        except (KeyError, ValueError, TypeError, UnicodeError):
            errors.append(path + ': cannot seal provided signed object')
            return
        if obj.get('integrity') != expected:
            errors.append(path + ': envelope mismatch')
    for index, record in enumerate(chain.get('records', [])):
        if not isinstance(record, dict):
            continue
        path = 'records[' + str(index) + ']'
        verify(record, {key: value for key, value in record.items() if key != 'integrity'}, path)
        payload = record.get('payload')
        if not isinstance(payload, dict):
            continue
        for kind in ('launch_attestation', 'commitment', 'release_attestation'):
            item = payload.get(kind)
            if isinstance(item, dict) and isinstance(item.get('body'), dict):
                verify(item, item['body'], path + '.' + kind)
                nested = item['body'].get('usage_attestation')
                if isinstance(nested, dict) and isinstance(nested.get('body'), dict):
                    verify(nested, nested['body'], path + '.' + kind + '.usage_attestation')
    return errors


def seal_record(record, profile, keys):
    result = deepcopy(record)
    signed = {key: value for key, value in result.items() if key != 'integrity'}
    result['integrity'] = _integrity(signed, profile, keys)
    return result


def seal_proof(body, profile, keys):
    body = deepcopy(body)
    return {'body': body, 'integrity': _integrity(body, profile, keys)}


def reseal(chain, profile_name, repair_links=True):
    """Reseal copies; repair digest links only, never authored relation IDs/time.

    False preserves every digest link for explicit stale-digest mutations. True
    recomputes existing predecessor_digest, assignment_digest, resolution_digest,
    commitment_digest, and exposure_digest in dependency order when unambiguous.
    Missing fields are never inserted. Missing/duplicate record classes are not
    resolved through a first-record choice.
    """
    result = deepcopy(chain)
    profile, keys, _ = load_context(profile_name)
    records = result.get('records', [])
    groups = {kind: [r for r in records if isinstance(r, dict) and r.get('record_type') == kind]
              for kind in ('assignment', 'resolution', 'exposure', 'outcome')}
    known = {}
    def update_if_present(obj, field, value):
        if repair_links and isinstance(obj, dict) and field in obj and value is not None:
            obj[field] = value
    def proof(proof_obj):
        if isinstance(proof_obj, dict) and isinstance(proof_obj.get('body'), dict):
            proof_obj['integrity'] = _integrity(proof_obj['body'], profile, keys)
    for kind in ('assignment', 'resolution', 'exposure', 'outcome'):
        parent_kind = {'resolution': 'assignment', 'exposure': 'resolution', 'outcome': 'exposure'}.get(kind)
        parent_digest = known.get(parent_kind)
        for rec in groups[kind]:
            update_if_present(rec, 'predecessor_digest', parent_digest)
            payload = rec.get('payload', {})
            if not isinstance(payload, dict):
                payload = {}
            if kind == 'resolution':
                launch = payload.get('launch_attestation')
                if isinstance(launch, dict):
                    update_if_present(launch.get('body'), 'assignment_digest', known.get('assignment'))
                    proof(launch)
            if kind == 'exposure':
                commit = payload.get('commitment')
                release = payload.get('release_attestation')
                if isinstance(commit, dict) and isinstance(commit.get('body'), dict):
                    cb = commit['body']
                    usage = cb.get('usage_attestation')
                    update_if_present(cb, 'resolution_digest', known.get('resolution'))
                    if isinstance(usage, dict):
                        update_if_present(usage.get('body'), 'resolution_digest', known.get('resolution'))
                        proof(usage)
                    proof(commit)
                if isinstance(release, dict):
                    update_if_present(release.get('body'), 'commitment_digest',
                                      digest(commit) if isinstance(commit, dict) else None)
                    proof(release)
            if kind == 'outcome':
                update_if_present(payload, 'exposure_digest', known.get('exposure'))
            rec['integrity'] = _integrity({k: v for k, v in rec.items() if k != 'integrity'}, profile, keys)
        if len(groups[kind]) == 1:
            known[kind] = groups[kind][0]['integrity']['content_digest']
    return result


def make_chain(profile_name, condition=None, case_id='base'):
    profile, keys, _ = load_context(profile_name)
    condition = condition or profile['conditions'][0]
    if condition not in profile['conditions']:
        raise ValueError('fixture_condition_not_permitted')
    resource = next(resource for resource, mapped in profile['resource_condition_map'].items() if mapped == condition)
    namespaces = {name: next(raw for raw, mapped in policy['mapping'].items() if mapped == condition)
                  for name, policy in profile['namespace_policy'].items() if policy['required']}
    common = {field: profile[field] for field in ('contract_version', 'profile_id', 'profile_version',
              'experiment_id', 'experiment_version', 'deployment_id', 'context_id')}
    common.update(unit_token='synthetic-unit-' + case_id, audience=profile['expected_audience'],
                  valid_from='2026-10-13T00:00:00Z', expires_at='2026-10-14T00:00:00Z')
    def record(kind, stamp, payload, predecessor=None):
        obj = dict(common, record_id=case_id + '-' + kind, record_type=kind,
                   schema_version=profile['schema_version'], issuer=profile['record_issuers'][kind],
                   issued_at=stamp, nonce=case_id + '-nonce-' + kind,
                   predecessor_record_id=predecessor['record_id'] if predecessor else None,
                   predecessor_digest=predecessor['integrity']['content_digest'] if predecessor else None,
                   payload=payload)
        return seal_record(obj, profile, keys)
    def body(kind, stamp, **fields):
        return dict(common, proof_id=case_id + '-proof-' + kind,
                    issuer=profile['proof_issuers'][kind], issued_at=stamp, **fields)
    assignment = record('assignment', '2026-10-13T01:00:00Z', {
        'assigned_condition': condition, 'assignment_policy_version': profile['assignment_policy_version'],
        'scope': profile['scope'], 'resource_id': resource, 'launch_nonce': case_id + '-launch'})
    launch = seal_proof(body('launch_attestation', '2026-10-13T01:00:01Z',
        assignment_record_id=assignment['record_id'], assignment_digest=assignment['integrity']['content_digest'],
        resource_id=resource, launch_nonce=case_id + '-launch', namespace_values=namespaces), profile, keys)
    resolution = record('resolution', '2026-10-13T01:00:02Z', {
        'requested_condition': condition, 'resolved_condition': condition, 'claim_namespaces': namespaces,
        'resolver_version': profile['resolver_version'], 'fallback_used': False, 'fallback_authorized': False,
        'authorization_ref': None, 'launch_nonce': case_id + '-launch', 'launch_attestation': launch}, assignment)
    bundle = 'baseline-v1'
    vector = deepcopy(profile['artifact_registry'][bundle])
    invocation = case_id + '-invocation'
    measured = {component: {'component_id': component, 'version': vector[component]['version'],
                'digest': vector[component]['digest'], 'capture_ref': 'synthetic-capture-' + component,
                'use_ref': 'synthetic-use-' + component} for component in profile['required_measured_components']}
    usage = seal_proof(body('usage_attestation', '2026-10-13T01:00:03Z',
        clock_id=profile['observer_clock_id'], sequence=10, invocation_id=invocation,
        resolution_record_id=resolution['record_id'], resolution_digest=resolution['integrity']['content_digest'],
        measured_components=measured), profile, keys)
    commitment = seal_proof(body('commitment', '2026-10-13T01:00:04Z',
        clock_id=profile['observer_clock_id'], sequence=11, resolution_record_id=resolution['record_id'],
        resolution_digest=resolution['integrity']['content_digest'], invocation_id=invocation,
        enacted_condition=condition, artifact_version=bundle, artifacts=vector, usage_attestation=usage), profile, keys)
    release = seal_proof(body('release_attestation', '2026-10-13T01:00:05Z',
        clock_id=profile['observer_clock_id'], sequence=12, invocation_id=invocation,
        commitment_digest=digest(commitment), exposure_record_id=case_id + '-exposure',
        release_boundary=profile['release_boundary']), profile, keys)
    exposure = record('exposure', '2026-10-13T01:00:06Z', {
        'enacted_condition': condition, 'artifact_version': bundle, 'artifacts': vector,
        'invocation_id': invocation, 'commitment': commitment, 'release_attestation': release}, resolution)
    outcome = record('outcome', '2026-10-13T01:00:07Z', {
        'exposure_record_id': exposure['record_id'], 'exposure_digest': exposure['integrity']['content_digest'],
        'attributed_condition': condition, 'outcome_key': 'synthetic-outcome-' + case_id,
        'consent_state': 'consented', 'consent_at': '2026-10-13T00:59:00Z',
        'consent_authority_ref': profile['consent_authority_refs'][0],
        'consent_policy_version': profile['consent_policy_version'],
        'purpose': profile['permitted_purposes'][0], 'eligible': True}, exposure)
    return {'contract_version': '2.0.1', 'profile_id': profile['profile_id'],
            'profile_version': profile['profile_version'], 'case_id': case_id,
            'records': [assignment, resolution, exposure, outcome]}

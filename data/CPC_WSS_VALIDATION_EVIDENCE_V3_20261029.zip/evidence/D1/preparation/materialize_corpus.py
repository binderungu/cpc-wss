"""Write candidate-independent oracle and actual wire bytes, never admission."""
from copy import deepcopy
from collections import Counter
import csv,hashlib,itertools,json
from pathlib import Path
import structural_cases,boundary_cases,relational_cases,domain_cases,version_cases
from fixture_factory import load_context,canonical_json

ROOT=Path(__file__).resolve().parents[1]

def build_all():
    domain,matrix=domain_cases.build_cases_and_applicability()
    cases=structural_cases.build_cases()+boundary_cases.build_cases()+relational_cases.build_cases()+domain+version_cases.build_cases()
    relational=relational_cases.build_cases()
    selected=[]
    for name in ('writing_feedback','quiz_tutor'):
        for wanted in ('ADMIT','REJECT','QUARANTINE','ERROR_INPUT'):
            available=[c for c in relational if c['profile_name']==name and c['expected_disposition']==wanted and len(c['chain']['records'])<=4]
            if wanted=='REJECT':available=[c for c in available if any(d['rule_id']=='R03' for d in c['required_diagnostics'])]
            selected.append(available[0])
    for source in selected:
        for i,order in enumerate(itertools.permutations(range(len(source['chain']['records'])))):
            c=deepcopy(source);c['chain']['records']=[c['chain']['records'][j] for j in order]
            c['case_id']=source['case_id']+'-perm-'+str(i).zfill(2)
            c['family']='order_derivative';c['parent_case_id']=source['case_id'];c['record_order']=list(order)
            cases.append(c)
    assert len(cases)<=6000
    assert len({c['case_id'] for c in cases})==len(cases)
    return cases

def main():
    oracle=ROOT/'oracle';oracle.mkdir(exist_ok=True)
    inputs=ROOT/'inputs_r2';inputs.mkdir(exist_ok=True)
    contexts=ROOT/'contexts_r2';contexts.mkdir(exist_ok=True)
    if (oracle/'EXPECTED.jsonl').exists():raise RuntimeError('Refuse replacing prepared corpus')
    rows=[];coverage=[]
    for i,c in enumerate(build_all()):
        profile,keys,stamp=load_context(c['profile_name'])
        context={'profile':c.get('profile_override',profile),'key_registry':c.get('keys_override',keys),
                 'validation_time':c.get('validation_time_override',stamp)}
        cb=canonical_json(context);context_rel='contexts_r2/'+hashlib.sha256(cb).hexdigest()+'.json'
        if not (ROOT/context_rel).exists():(ROOT/context_rel).write_bytes(cb)
        raw=c['raw_bytes'] if 'raw_bytes' in c else canonical_json(c['chain'])
        rel='inputs_r2/case-'+str(i).zfill(5)+'.raw'
        (ROOT/rel).write_bytes(raw)
        row={k:v for k,v in c.items() if k not in ('chain','raw_bytes','profile_override','keys_override','validation_time_override')}
        ref='CPC201-D1-'+str(i).zfill(6)
        row.update(input_path=rel,input_sha256=hashlib.sha256(raw).hexdigest(),raw_bytes=len(raw),context_path=context_rel,input_ref=ref)
        rows.append(row)
        if 'target_path' in c:coverage.append({'case_id':c['case_id'],'profile':c['profile_name'],
             'target_path':structural_cases.display(c['target_path']),'dimension':c['dimension'],'expected':c['expected_disposition']})
    with (oracle/'EXPECTED.jsonl').open('x') as f:
        for row in rows:f.write(json.dumps(row,sort_keys=True,ensure_ascii=False)+'\n')
    with (oracle/'FIELD_DIMENSION_COVERAGE.csv').open('x',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['case_id','profile','target_path','dimension','expected']);writer.writeheader();writer.writerows(coverage)
    receipt={'admission_invoked':False,'cases':len(rows),'families':dict(Counter(r['family'] for r in rows)),
             'expected_dispositions':dict(Counter(r['expected_disposition'] for r in rows)),
             'contexts_including_invalid_negative_config_fixtures':len({r['context_path'] for r in rows}),
             'field_locations_per_primary_profile':len(structural_cases.targets(structural_cases.make_chain('writing_feedback'),'writing_feedback')),
             'rng':'NONE_DETERMINISTIC','D2':'NOT_RUN','D3':'NOT_RUN'}
    _,matrix=domain_cases.build_cases_and_applicability()
    with (oracle/'DOMAIN_APPLICABILITY.csv').open('x',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['profile','target_path','classification','expected','case_id','rationale']);writer.writeheader();writer.writerows(matrix)
    (oracle/'PREPARATION_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()

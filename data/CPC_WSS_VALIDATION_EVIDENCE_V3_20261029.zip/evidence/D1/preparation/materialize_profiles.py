"""Create new synthetic D1 trust roots once; never run chain admission."""
from __future__ import annotations
import json
from pathlib import Path
from fixture_factory import ROOT, canonical_json, raw_digest

FREEZE = '2026-10-13T00:00:00Z'
VALIDATION_TIME = '2026-10-13T02:00:00Z'
DECLARED = ('ui', 'corpus', 'retriever', 'index', 'model', 'policy')


def _write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError('Materialized artifacts are append-only: ' + str(path))
    path.write_bytes(data)


def _json(path, value):
    _write(path, (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False) + '\n').encode())


def materialize():
    manifest = []
    for name, conditions, raws, resources in (
        ('writing_feedback', ('guided', 'plain'), ('guided', 'plain'),
         ('resource-writing-guided', 'resource-writing-plain')),
        ('quiz_tutor', ('hint', 'answer'), ('Q_HINT', 'Q_ANSWER'),
         ('resource-quiz-hint', 'resource-quiz-answer'))):
        prefix = 'd1-contract201-20261013-' + name
        roles = {role: prefix + '-issuer-' + role for role in ('assignment', 'resolver', 'runtime', 'outcome', 'observer')}
        key_policy = {issuer: prefix + '-key-' + role for role, issuer in roles.items()}
        keys = {key_policy[issuer]: 'SYNTHETIC_ONLY_CPC201_D1_20261013_' + name.upper() + '_' + role.upper()
                for role, issuer in roles.items()}
        artifact_registry = {}
        for bundle in ('baseline-v1', 'alternate-v1'):
            component_dir = ROOT / 'components' / name / bundle
            prompt = ('Synthetic CPC D1 fixture configuration.\nProfile: ' + name + '\nBundle: ' + bundle +
                      '\nNo runtime, learner text, or AI response exists.\n').encode()
            generation = {'fixture_profile': name, 'fixture_bundle': bundle,
                          'max_output_tokens': 128 if bundle == 'baseline-v1' else 192,
                          'sampling': 'deterministic', 'configuration_only': True}
            generation_bytes = canonical_json(generation)
            entries = {'prompt': (prompt, 'prompt.txt', 'measured', 'raw-bytes consumed'),
                       'generation': (generation_bytes, 'generation.json', 'measured', 'cpc-json-v2 object consumed')}
            for component in DECLARED:
                descriptor = {'component_id': component, 'profile': name, 'bundle': bundle,
                              'fixture_version': component + '-' + bundle,
                              'evidence_mode': 'declared', 'configuration_only': True}
                entries[component] = (canonical_json(descriptor), component + '.json', 'declared', 'canonical declared descriptor bytes')
            vector = {}
            for component, (component_bytes, filename, mode, canonicalization) in entries.items():
                path = component_dir / filename
                _write(path, component_bytes)
                entry = {'version': name + '-' + component + '-' + bundle,
                         'digest': raw_digest(component_bytes), 'evidence_mode': mode}
                vector[component] = entry
                manifest.append({'profile': name, 'bundle': bundle, 'component_id': component,
                                 'path': str(path.relative_to(ROOT)), 'bytes': len(component_bytes),
                                 'digest': entry['digest'], 'version': entry['version'], 'evidence_mode': mode,
                                 'digest_basis': canonicalization,
                                 'runtime_consumption_observed': False})
            artifact_registry[bundle] = vector
        mapping = dict(zip(raws, conditions))
        profile = {
            'profile_id': prefix, 'profile_version': '2.0.1-D1-20261013-v1',
            'contract_version': '2.0.1', 'schema_version': 'cpc-2.0.1',
            'experiment_id': 'synthetic-' + name + '-D1-contract201', 'experiment_version': '20261013-contract201-v1',
            'expected_audience': 'cpc-d1-local-validator', 'deployment_id': 'synthetic-d1-local',
            'context_id': 'synthetic-context-' + name, 'scope': 'synthetic-tool-conformance',
            'assignment_policy_version': 'assignment-synthetic-v1', 'resolver_version': 'resolver-synthetic-v1',
            'mapping_version': name + '-mapping-v1', 'consent_policy_version': 'synthetic-consent-v1',
            'observer_clock_id': 'synthetic-local-clock-v1', 'release_boundary': 'durable_local_response_file',
            'profile_state': 'frozen', 'freeze_timestamp': FREEZE, 'conditions': list(conditions),
            'resource_condition_map': dict(zip(resources, conditions)),
            'namespace_policy': {
                'lti.resource_condition': {'role': 'authoritative', 'required': True, 'mapping': mapping},
                'lti.delivery_condition': {'role': 'consistency', 'required': True, 'mapping': mapping},
                'ui.activity_title': {'role': 'descriptive', 'required': False, 'mapping': {}}},
            'record_issuers': {'assignment': roles['assignment'], 'resolution': roles['resolver'],
                              'exposure': roles['runtime'], 'outcome': roles['outcome']},
            'proof_issuers': {'launch_attestation': roles['assignment'], 'commitment': roles['runtime'],
                             'usage_attestation': roles['observer'], 'release_attestation': roles['observer']},
            'issuer_key_policy': key_policy,
            'permitted_purposes': ['synthetic-tool-evaluation'],
            'consent_authority_refs': ['synthetic-consent-authority'],
            'artifact_registry': artifact_registry,
            'required_measured_components': ['prompt', 'generation'],
            'component_canonicalizations': {'prompt': 'raw-bytes consumed', 'generation': 'cpc-json-v2 object consumed'},
            'fallback_permissions': {'fallback-' + condition + '-v1': {'condition': condition,
                                    'artifact_versions': ['alternate-v1']} for condition in conditions},
            'extension_keys': ['cpc.fixture_note', 'cpc.audit_metadata'],
            'privacy_denylist': ['email', 'learnerid', 'studentname', 'rawprompt', 'rawresponse', 'rawtext', 'content'],
            'input_limits': {'max_bytes': 1048576, 'max_records': 16, 'max_depth': 32, 'max_identifier_chars': 256}}
        _json(ROOT / 'profiles' / (name + '.json'), profile)
        _json(ROOT / 'registry' / (name + '_keys.json'), keys)
        _json(ROOT / 'registry' / (name + '_artifacts.json'), artifact_registry)
        _json(ROOT / 'profiles' / (name + '_context.json'), {'profile_file': 'profiles/' + name + '.json',
              'key_registry_file': 'registry/' + name + '_keys.json', 'validation_time': VALIDATION_TIME,
              'profile_freeze_timestamp': FREEZE, 'time_basis': 'fixed synthetic D1 timeline',
              'actual_runtime_observation': False})
    _json(ROOT / 'registry' / 'COMPONENT_MANIFEST.json', {
        'evidence_class': 'synthetic_D1_configuration_materialization', 'entries': manifest,
        'D2_status': 'NOT_RUN', 'D3_status': 'NOT_RUN',
        'limitation': 'File-byte digests establish registry materialization only; signed usage fixtures are not runtime observations.'})


if __name__ == '__main__':
    materialize()

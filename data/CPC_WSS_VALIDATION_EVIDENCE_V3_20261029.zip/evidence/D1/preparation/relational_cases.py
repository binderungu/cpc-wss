"""Contract-led relational fixtures; never import or call the CPC evaluator.

Expected decisions were specified before admission execution. Signing helpers
only create/verify synthetic assertions, without demonstrating capture truth.
"""
from __future__ import annotations
from copy import deepcopy
import hashlib
import hmac
import json
from fixture_factory import make_chain, load_context, reseal, digest


def _objects(chain):
    for record in chain['records']:
        if not isinstance(record, dict):
            continue
        yield record, {k: v for k, v in record.items() if k != 'integrity'}
        payload = record.get('payload', {})
        for key in ('launch_attestation', 'commitment', 'release_attestation'):
            proof = payload.get(key)
            if isinstance(proof, dict) and isinstance(proof.get('body'), dict):
                yield proof, proof['body']
                usage = proof['body'].get('usage_attestation')
                if isinstance(usage, dict) and isinstance(usage.get('body'), dict):
                    yield usage, usage['body']


def _verify_seals(chain, keys):
    """Independent stdlib byte/HMAC check; no candidate code or role policy."""
    for container, signed in _objects(chain):
        integrity = container['integrity']
        raw = json.dumps(signed, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')
        expected = 'sha256:' + hashlib.sha256(raw).hexdigest()
        assert integrity['content_digest'] == expected, 'Semantic fixture digest was not resealed'
        key = keys[integrity['key_id']]
        if isinstance(key, str):
            key = key.encode('ascii')
        mac = 'hmac-sha256:' + hmac.new(key, expected.encode('ascii'), hashlib.sha256).hexdigest()
        assert hmac.compare_digest(mac, integrity['mac']), 'Semantic fixture MAC was not resealed'


def _parts(chain):
    a, r, e, o = chain['records']
    l = r['payload']['launch_attestation']['body']
    c = e['payload']['commitment']['body']
    u = c['usage_attestation']['body']
    x = e['payload']['release_attestation']['body']
    return a, r, e, o, l, c, u, x


def _set(path, value):
    def mutate(chain, profile):
        current = chain
        for key in path[:-1]:
            current = current[key]
        current[path[-1]] = deepcopy(value)
    return mutate


def build_cases():
    cases = []
    for profile_name in ('writing_feedback', 'quiz_tutor'):
        profile, keys, _ = load_context(profile_name)
        condition, other = profile['conditions'][:2]
        def add(slug, family, description, mutate=None, verdict='REJECT', rules=(), integrity=True, repair_links=True, post=None):
            cid = 'REL-' + profile_name + '-' + slug
            chain = make_chain(profile_name, condition, cid)
            if mutate:
                mutate(chain, profile)
            chain = reseal(chain, profile_name, repair_links=repair_links)
            if post:
                post(chain, profile)
                if integrity:
                    chain = reseal(chain, profile_name, repair_links=False)
            if integrity:
                _verify_seals(chain, keys)
            cases.append({'case_id':cid, 'profile_name':profile_name, 'chain':chain,
                          'expected_disposition':verdict,
                          'required_diagnostics':[{'rule_id':rid, 'disposition':disp} for rid,disp in rules],
                          'family':family, 'description':description,
                          'integrity_policy':'ALL_AVAILABLE_SEALS_INDEPENDENTLY_VALID' if integrity else 'EXPLICIT_INTEGRITY_ATTACK'})

        # Positive controls derive directly from sections 2--6 and example 1/4.
        for cond in profile['conditions']:
            def valid_condition(chain, p, selected=cond):
                replacement = make_chain(profile_name, selected, chain['case_id'])
                chain.clear(); chain.update(replacement)
            add('positive-'+cond, 'positive', 'Complete chain for approved condition '+cond, valid_condition, 'ADMIT')
        def reverse(chain,p): chain['records'].reverse()
        add('record-order', 'positive', 'Record array order is irrelevant to signed relation evaluation', reverse, 'ADMIT')
        def descriptive(chain,p):
            _,r,_,_,l,_,_,_ = _parts(chain)
            r['payload']['claim_namespaces']['ui.activity_title'] = 'Changed descriptive metadata'
            l['namespace_values']['ui.activity_title'] = 'Changed descriptive metadata'
        add('descriptive-title', 'positive', 'Allowed descriptive namespace changes no condition authority', descriptive, 'ADMIT')
        def extension(chain,p):
            a,_,_,_,l,_,_,_ = _parts(chain)
            key = p['extension_keys'][0]
            a['extensions'] = {key:{'ordinary_metadata':'observer fixture'}}
            l['extensions'] = {key:{'ordinary_metadata':'observer fixture'}}
        add('registered-extension', 'positive', 'Registered signed metadata extension does not redefine eligibility', extension, 'ADMIT')
        def equal_boundaries(chain,p):
            a,r,e,o,l,c,u,x = _parts(chain)
            u['issued_at'] = c['issued_at']
            u['sequence'] = c['sequence']
            o['payload']['consent_at'] = u['issued_at']
            e['issued_at'] = x['issued_at']
            o['issued_at'] = e['issued_at']
        add('nonstrict-equality', 'positive', 'Consent/use and use/commit and release/exposure/outcome equality permitted', equal_boundaries, 'ADMIT')
        def utc_offsets(chain,p):
            from datetime import datetime, timezone, timedelta
            for container,signed in _objects(chain):
                for key in ('issued_at','valid_from','expires_at','consent_at'):
                    if key in signed:
                        instant = datetime.fromisoformat(signed[key].replace('Z','+00:00'))
                        replacement = instant.astimezone(timezone(timedelta(hours=7))).isoformat()
                        if 'body' in container:
                            container['body'][key] = replacement
                        else:
                            container[key] = replacement
                if 'payload' in container and 'consent_at' in container['payload']:
                    t = datetime.fromisoformat(container['payload']['consent_at'].replace('Z','+00:00'))
                    container['payload']['consent_at'] = t.astimezone(timezone(timedelta(hours=7))).isoformat()
        add('utc-equivalent-offsets', 'positive', 'Explicit-zone timestamps representing identical UTC instants admit', utc_offsets, 'ADMIT')
        def fallback(chain,p):
            _,r,e,_,_,c,u,_ = _parts(chain)
            ref,permission = next((k,v) for k,v in p['fallback_permissions'].items() if v['condition']==condition)
            bundle = permission['artifact_versions'][0]
            r['payload'].update(fallback_used=True, fallback_authorized=True, authorization_ref=ref)
            vector = deepcopy(p['artifact_registry'][bundle])
            e['payload'].update(artifact_version=bundle, artifacts=vector)
            c.update(artifact_version=bundle, artifacts=deepcopy(vector))
            for component in p['required_measured_components']:
                u['measured_components'][component].update(version=vector[component]['version'], digest=vector[component]['digest'])
        add('valid-same-condition-fallback', 'positive', 'Externally registered fallback remains in assigned condition', fallback, 'ADMIT')

        # Required classes absent; contradicting available assertions still win.
        for index,kind in enumerate(('assignment','resolution','exposure','outcome')):
            def missing(chain,p,i=index): chain['records'].pop(i)
            add('missing-'+kind,'incomplete','Entire '+kind+' class absent',missing,'QUARANTINE',(('Q01','QUARANTINE'),))
        def missing_wrong_context(chain,p):
            chain['records'][0]['context_id']='unauthorized-context'
            chain['records'].pop(3)
        add('missing-outcome-context','compound','Missing outcome plus independently signed wrong assignment context',missing_wrong_context,rules=(('R01','REJECT'),('Q01','QUARANTINE')))
        def malformed_wrong_context(chain,p):
            chain['records'][0]['context_id']='unauthorized-context'
            chain['records'][2]['payload']['release_attestation']['body'].pop('sequence')
        add('malformed-context','compound','Malformed observation plus unrelated signed assignment context conflict',malformed_wrong_context,rules=(('R01','REJECT'),('I02','ERROR_INPUT')))
        def namespaces(chain,p,mode):
            _,r,_,_,l,_,_,_ = _parts(chain)
            maps = r['payload']['claim_namespaces']
            required = [k for k,v in p['namespace_policy'].items() if v['required']]
            if mode=='coherent-wrong':
                for k in required:
                    maps[k] = next(raw for raw,v in p['namespace_policy'][k]['mapping'].items() if v==other)
            elif mode=='conflict':
                k=required[-1]; maps[k]=next(raw for raw,v in p['namespace_policy'][k]['mapping'].items() if v==other)
            elif mode=='missing': maps.pop(required[0])
            elif mode=='unknown': maps['unauthorized.condition']='irrelevant'
            elif mode=='unmapped': maps[required[0]]='UNKNOWN_RAW_CONDITION'
            elif mode=='descriptive-only':
                maps.clear(); maps['ui.activity_title']='guided display label'
            l['namespace_values']=deepcopy(maps)
        for mode,verdict,rule in [('coherent-wrong','REJECT','R03'),('conflict','REJECT','R03'),('missing','ERROR_INPUT','I02'),('unknown','REJECT','R03'),('unmapped','REJECT','R03'),('descriptive-only','ERROR_INPUT','I02')]:
            add('namespace-'+mode,'namespace','Namespace '+mode+' with equally signed resolver/platform claims',lambda c,p,m=mode:namespaces(c,p,m),verdict,((rule,verdict),))
        def missing_ns_conflict(chain,p):
            namespaces(chain,p,'conflict'); chain['records'].pop(3)
        add('missing-outcome-namespaces','compound','Missing outcome retains independently conflicting mapped namespaces',missing_ns_conflict,rules=(('R03','REJECT'),('Q01','QUARANTINE')))
        def claim_only(chain,p):
            _,r,_,_,_,_,_,_= _parts(chain)
            k=next(k for k,v in p['namespace_policy'].items() if v['required'])
            r['payload']['claim_namespaces'][k]=next(raw for raw,v in p['namespace_policy'][k]['mapping'].items() if v==other)
        add('resolver-v-platform-namespace','namespace','Resolver claim differs from platform attestation',claim_only,rules=(('R03','REJECT'),))
        def wrong_resource(chain,p):
            _,_,_,_,l,_,_,_=_parts(chain)
            l['resource_id']=next(k for k,v in p['resource_condition_map'].items() if v==other)
        add('platform-resource-authority','authority','Signed launch resource maps to other condition despite nominal matching fields',wrong_resource,rules=(('R02','REJECT'),('R04','REJECT')))
        for field in ('assignment_policy_version','scope','resource_id','assigned_condition'):
            add('assignment-'+field,'authority','Assignment '+field+' outside operator policy',lambda c,p,f=field:c['records'][0]['payload'].__setitem__(f,'unauthorized-value'),rules=(('R02','REJECT'),))
        add('resolver-version','authority','Resolver version outside frozen operator policy',lambda c,p:c['records'][1]['payload'].__setitem__('resolver_version','unauthorized-version'),rules=(('R02','REJECT'),))

        # External context applies even where records mutually agree.
        for field in ('profile_id','profile_version','experiment_id','experiment_version','audience','deployment_id','context_id'):
            add('signed-context-'+field,'context','Signed assignment '+field+' differs from operator profile',lambda c,p,f=field:c['records'][0].__setitem__(f,'unauthorized-context'),rules=(('R01','REJECT'),))
        def proof_context(chain,p): _parts(chain)[6]['context_id']='unauthorized-observer-context'
        add('proof-context','context','Nested usage context conflicts with operator and record',proof_context,rules=(('R01','REJECT'),))
        def proof_issuer(chain,p): _parts(chain)[4]['issuer']=p['record_issuers']['resolution']
        add('launch-authority-role','authority','Resolver cannot stand in for platform launch authority',proof_issuer,rules=(('R01','REJECT'),))
        for field in ('profile_id','profile_version','contract_version'):
            def root_empty(chain,p,f=field):
                chain[f]='unapproved-routing';chain['records']=[]
            add('routing-empty-'+field,'compound','Root policy mismatch remains rejection with no records',root_empty,rules=(('R01','REJECT'),('Q01','QUARANTINE')))
        add('unit-binding','binding','Signed outcome opaque unit differs from other available records',lambda c,p:c['records'][3].__setitem__('unit_token','opaque-other-unit'),rules=(('R07','REJECT'),))
        for slug,index,field,rule in [('launch-assignment-id',4,'assignment_record_id','R04'),('launch-nonce',4,'launch_nonce','R04'),('resolution-nonce',1,'launch_nonce','R04'),('commit-resolution-id',5,'resolution_record_id','R07'),('usage-resolution-id',6,'resolution_record_id','R07'),('release-exposure-id',7,'exposure_record_id','R07'),('release-boundary',7,'release_boundary','R07'),('outcome-exposure-id',3,'exposure_record_id','R07'),('invocation-usage',6,'invocation_id','R05')]:
            def bind(chain,p,i=index,f=field):
                obj=_parts(chain)[i]
                if i in (1,3):obj=obj['payload']
                obj[f]='different-binding'
            add(slug,'binding',field+' mismatches signed bound evidence',bind,rules=((rule,'REJECT'),))
        for slug,index,field,rule in [('launch-assignment-digest',4,'assignment_digest','R04'),('commit-resolution-digest',5,'resolution_digest','R07'),('usage-resolution-digest',6,'resolution_digest','R07'),('release-commitment-digest',7,'commitment_digest','R07'),('outcome-exposure-digest',3,'exposure_digest','R07')]:
            def bad_digest(chain,p,i=index,f=field):
                obj=_parts(chain)[i]
                if i==3:obj=obj['payload']
                obj[f]='sha256:'+'a'*64
            add(slug,'binding',field+' deliberately differs after ordinary digest-link reseal',rules=((rule,'REJECT'),),post=bad_digest)
        def predecessor(chain,p): chain['records'][2]['predecessor_record_id']='other-resolution'
        add('predecessor-id','binding','Exposure predecessor ID differs independently from nested proof links',predecessor,rules=(('R07','REJECT'),))
        add('predecessor-digest','binding','Exposure predecessor content digest differs',rules=(('R07','REJECT'),),post=lambda c,p:c['records'][2].__setitem__('predecessor_digest','sha256:'+'a'*64))

        # Same-condition-only fallback and explicit authorization.
        for slug,mutation in [('used-not-authorized',lambda r,p:r.update(fallback_used=True,fallback_authorized=False,authorization_ref=next(iter(p['fallback_permissions'])))),('unused-authorized',lambda r,p:r.update(fallback_used=False,fallback_authorized=True)),('unused-ref',lambda r,p:r.update(authorization_ref=next(iter(p['fallback_permissions'])))),('unknown-permission',lambda r,p:r.update(fallback_used=True,fallback_authorized=True,authorization_ref='unregistered-permission')),('other-condition-permission',lambda r,p:r.update(fallback_used=True,fallback_authorized=True,authorization_ref=next(k for k,v in p['fallback_permissions'].items() if v['condition']==other)))]:
            add('fallback-'+slug,'fallback','Fallback '+slug,lambda c,p,m=mutation:m(c['records'][1]['payload'],p),rules=(('R06','REJECT'),))
        def cross_condition(chain,p):
            fallback(chain,p)
            chain['records'][1]['payload']['resolved_condition']=other
            chain['records'][2]['payload']['enacted_condition']=other
            _parts(chain)[5]['enacted_condition']=other
            chain['records'][3]['payload']['attributed_condition']=other
        add('fallback-cross-condition','fallback','Authorized fallback cannot silently reassign condition',cross_condition,rules=(('R02','REJECT'),('R06','REJECT')))

        def fallback_unapproved_bundle(chain,p):
            fallback(chain,p)
            _,_,e,_,_,c,u,_=_parts(chain)
            vector=deepcopy(p['artifact_registry']['baseline-v1'])
            e['payload'].update(artifact_version='baseline-v1',artifacts=vector)
            c.update(artifact_version='baseline-v1',artifacts=deepcopy(vector))
            for component in p['required_measured_components']:
                u['measured_components'][component].update(version=vector[component]['version'],digest=vector[component]['digest'])
        add('fallback-bundle-outside-permission','fallback','Registered baseline bundle does not satisfy alternate-only fallback permission',fallback_unapproved_bundle,rules=(('R06','REJECT'),))

        # Usage metadata tests do not claim an actual capture path or truth.
        for component in ('prompt','generation'):
            for field,value in (('digest','sha256:'+'b'*64),('version','changed-version'),('component_id','different-component')):
                def measured(chain,p,comp=component,f=field,v=value):_parts(chain)[6]['measured_components'][comp][f]=v
                add('usage-'+component+'-'+field,'measured-metadata','Signed '+component+' measurement '+field+' conflicts',measured,rules=(('R05','REJECT'),))
        def all_declared(chain,p):
            _,_,e,_,_,c,_,_=_parts(chain)
            for vector in (e['payload']['artifacts'],c['artifacts']):
                for entry in vector.values():entry['evidence_mode']='declared'
        add('all-artifacts-declared','measured-metadata','Declared-only vector cannot satisfy strong measured profile',all_declared,rules=(('R05','REJECT'),))
        def registry_changed(chain,p):
            _,_,e,_,_,c,u,_=_parts(chain)
            for vector in (e['payload']['artifacts'],c['artifacts']):vector['prompt']['digest']='sha256:'+'b'*64
            u['measured_components']['prompt']['digest']='sha256:'+'b'*64
        add('coherent-unapproved-digest','measured-metadata','All supplied prompt digests agree but frozen registry differs',registry_changed,rules=(('R05','REJECT'),))
        add('commit-vector-conflict','measured-metadata','Commitment vector differs from exposure vector',lambda c,p:_parts(c)[5]['artifacts']['prompt'].__setitem__('digest','sha256:'+'b'*64),rules=(('R05','REJECT'),))

        # Trusted replay instant and prospective local event ordering.
        for slug,left,right,rule in [('use-after-commit',6,5,'R07'),('commit-equal-release',5,7,'R07'),('commit-after-release',5,7,'R07'),('release-after-exposure',7,2,'R07'),('resolution-after-use',1,6,'R07'),('launch-after-resolution',4,1,'R04'),('assignment-after-launch',0,4,'R04')]:
            def time_conflict(chain,p,s=slug,i=left,j=right):
                from datetime import datetime,timedelta
                parts=_parts(chain);rhs=parts[j]['issued_at'];t=datetime.fromisoformat(rhs.replace('Z','+00:00'))
                parts[i]['issued_at']=(t if s=='commit-equal-release' else t+timedelta(seconds=1)).isoformat()
            add(slug,'time',slug+' violates UTC boundary',time_conflict,rules=((rule,'REJECT'),))
        def consent_late(chain,p):
            from datetime import datetime,timedelta
            parts=_parts(chain);t=datetime.fromisoformat(parts[6]['issued_at'].replace('Z','+00:00'))
            parts[3]['payload']['consent_at']=(t+timedelta(seconds=1)).isoformat()
        add('consent-after-use','time','Prospective consent cannot occur after usage',consent_late,rules=(('R06','REJECT'),))
        for slug,i,j in [('use-sequence-after-commit',6,5),('commit-sequence-equal-release',5,7),('commit-sequence-after-release',5,7)]:
            def sequence(chain,p,s=slug,left=i,right=j):
                parts=_parts(chain);parts[left]['sequence']=parts[right]['sequence']+(0 if 'equal' in s else 1)
            add(slug,'time',slug+' violates observer ordering',sequence,rules=(('R07','REJECT'),))
        add('observer-clock','time','Clock differs from frozen observer clock context',lambda c,p:_parts(c)[6].__setitem__('clock_id','untrusted-clock'),rules=(('R07','REJECT'),))
        for slug,field in [('expired-at-validation','expires_at'),('not-yet-valid','valid_from'),('issued-in-future','issued_at')]:
            def fresh(chain,p,s=slug,f=field):
                from datetime import datetime,timedelta
                _,_,now=load_context(profile_name);t=datetime.fromisoformat(now.replace('Z','+00:00'))
                chain['records'][0][f]=(t+timedelta(seconds=1) if s!='expired-at-validation' else t).isoformat()
            add(slug,'freshness',slug+' violates trusted replay instant',fresh,rules=(('R01','REJECT'),))
        for state in ('declined','withdrawn','unknown'):
            add('consent-'+state,'governance','Typed '+state+' consent assertion cannot admit',lambda c,p,s=state:c['records'][3]['payload'].__setitem__('consent_state',s),rules=(('R06','REJECT'),))
        for field,value in [('eligible',False),('purpose','unpermitted-purpose'),('consent_authority_ref','unapproved-authority'),('consent_policy_version','unapproved-policy')]:
            add('governance-'+field,'governance',field+' outside approved consent eligibility policy',lambda c,p,f=field,v=value:c['records'][3]['payload'].__setitem__(f,v),rules=(('R06','REJECT'),))

        def usage_expired(chain,p):
            _,_,now=load_context(profile_name)
            _parts(chain)[6]['expires_at']=now
        add('proof-expired-at-validation','freshness','Usage proof expires exactly at trusted validation time',usage_expired,rules=(('R01','REJECT'),))
        def valid_from_after_issue(chain,p):
            from datetime import datetime,timedelta
            usage=_parts(chain)[6]
            usage['valid_from']=(datetime.fromisoformat(usage['issued_at'].replace('Z','+00:00'))+timedelta(seconds=1)).isoformat()
        add('proof-valid-after-issuance','freshness','Proof issuance before valid_from is invalid',valid_from_after_issue,rules=(('R01','REJECT'),))
        # Chain-local reuse/cardinality, including ambiguous outcomes.
        for i,kind in enumerate(('assignment','resolution','exposure')):
            def duplicate_class(chain,p,index=i):
                record=deepcopy(chain['records'][index]);record['record_id']+='-second';record['nonce']+='-second'
                chain['records'].append(record)
            add('multiple-'+kind,'cardinality','Multiple '+kind+' records are contradictory',duplicate_class,rules=(('R08','REJECT'),))
        def ambiguous_outcome(chain,p):
            record=deepcopy(chain['records'][3]);record['record_id']+='-second';record['nonce']+='-second'
            chain['records'].append(record)
        add('ambiguous-outcome','cardinality','Distinct otherwise matching outcome records cannot be selected',ambiguous_outcome,'QUARANTINE',(('Q02','QUARANTINE'),))
        def ambiguity_unit(chain,p):
            ambiguous_outcome(chain,p)
            chain['records'][-1]['unit_token']='other-opaque-unit'
        add('outcome-ambiguity-unit-conflict','compound','Ambiguous outcomes retain independently signed unit contradiction',ambiguity_unit,rules=(('R07','REJECT'),('Q02','QUARANTINE')))
        def outcome_duplicate_nonce(chain,p):
            record=deepcopy(chain['records'][3]);record['record_id']+='-second'
            chain['records'].append(record)
        add('outcome-ambiguity-duplicate-nonce','compound','Ambiguous outcome plus duplicate envelope nonce retains stronger rejection',outcome_duplicate_nonce,rules=(('R08','REJECT'),('Q02','QUARANTINE')))
        add('duplicate-record-id','cardinality','Record IDs must be chain-locally unique',lambda c,p:c['records'][3].__setitem__('record_id',c['records'][0]['record_id']),rules=(('R08','REJECT'),))
        add('duplicate-envelope-nonce','cardinality','Envelope nonces must be chain-locally unique',lambda c,p:c['records'][3].__setitem__('nonce',c['records'][0]['nonce']),rules=(('R08','REJECT'),))
        add('duplicate-nested-proof-id','cardinality','Nested proof IDs must be chain-locally unique',lambda c,p:_parts(c)[7].__setitem__('proof_id',_parts(c)[6]['proof_id']),rules=(('R08','REJECT'),))

        def private_extension(chain,p):
            key=p['extension_keys'][0];chain['records'][0]['extensions']={key:{'email':'synthetic@example.invalid'}}
        add('privacy-nested-extension','privacy','Detectable forbidden direct-identity field rejects even in registered metadata',private_extension,rules=(('R01','REJECT'),))
        add('unregistered-extension','extension','Unregistered signed extension is structural refusal',lambda c,p:c['records'][0].__setitem__('extensions',{'unregistered:metadata':'ordinary'}),'ERROR_INPUT',(('I03','ERROR_INPUT'),))
        add('root-extension','extension','Unsigned root does not support even registered metadata extensions',lambda c,p:c.__setitem__('extensions',{p['extension_keys'][0]:'ordinary'}),'ERROR_INPUT',(('I03','ERROR_INPUT'),))
        def wrong_commitment_digest_kind(chain,p):
            parts=_parts(chain)
            parts[7]['commitment_digest']=digest(parts[5])
        add('release-body-only-commitment-digest','binding','Release must bind complete signed commitment, not only its body',rules=(('R07','REJECT'),),post=wrong_commitment_digest_kind)
        # Explicit integrity attacks are not pooled with properly resealed semantic tests.
        def corrupt_mac(chain,p):chain['records'][0]['integrity']['mac']='hmac-sha256:'+'0'*64
        add('invalid-wellformed-mac','integrity','Well-formed incorrect record MAC rejects',integrity=False,rules=(('R01','REJECT'),),post=corrupt_mac)
        def wrong_role_key(chain,p):
            envelope=chain['records'][0]['integrity']
            key_id=p['issuer_key_policy'][p['record_issuers']['resolution']]
            key=keys[key_id]
            if isinstance(key,str):key=key.encode('ascii')
            envelope['key_id']=key_id
            envelope['mac']='hmac-sha256:'+hmac.new(key,envelope['content_digest'].encode('ascii'),hashlib.sha256).hexdigest()
        add('valid-mac-wrong-role-key','integrity','Cryptographically matching MAC under another registered role key is unauthorized',integrity=False,rules=(('R01','REJECT'),),post=wrong_role_key)
    return cases

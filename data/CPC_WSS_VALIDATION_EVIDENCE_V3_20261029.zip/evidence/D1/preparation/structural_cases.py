"""Contract-catalogue field sweep; expected outcomes precede admission execution."""
from copy import deepcopy
import json
from pathlib import Path
from fixture_factory import load_context, make_chain, canonical_json, digest, sign

ROOT=Path(__file__).resolve().parents[1]
FIELDS=json.loads((ROOT/'implementation/spec/FIELD_REQUIREMENTS.json').read_text())
KINDS=('assignment','resolution','exposure','outcome')
PROOFS={
 'launch_attestation':('records',1,'payload','launch_attestation'),
 'commitment':('records',2,'payload','commitment'),
 'usage_attestation':('records',2,'payload','commitment','body','usage_attestation'),
 'release_attestation':('records',2,'payload','release_attestation')}
ABSENT=object()

def get(obj,path):
    for key in path:obj=obj[key]
    return obj

def set_value(obj,path,value):
    try:parent=get(obj,path[:-1])
    except (KeyError,IndexError,TypeError):return
    if value is ABSENT:
        if isinstance(parent,dict):parent.pop(path[-1],None)
    else:parent[path[-1]]=deepcopy(value)

def display(path):
    return '$'+''.join('['+str(k)+']' if isinstance(k,int) else '.'+k for k in path)

def seal_mutated(chain,name,mutations):
    """Reseal supported malformed structures without repairing the tested field.

    Parent digests are repaired; target integrity faults are reapplied before
    signing containing ancestors. Authored IDs/conditions/times are never healed.
    """
    value=deepcopy(chain);profile,keys,_=load_context(name)
    for path,new in mutations:set_value(value,path,new)
    def targeted(path):return any(path[:len(p)]==p for p,_ in mutations)
    def fix(path,new):
        if not targeted(path):
            try:get(value,path)
            except (KeyError,IndexError,TypeError):return
            set_value(value,path,new)
    def proof(path,kind):
        try:item=get(value,path)
        except (KeyError,IndexError,TypeError):return
        if not isinstance(item,dict) or not isinstance(item.get('body'),dict):return
        item['integrity']=sign(item['body'],profile['proof_issuers'][kind],profile,keys)
        for p,new in mutations:
            if p[:len(path)+1]==path+('integrity',):set_value(value,p,new)
    known={}
    records=value.get('records')
    if not isinstance(records,list):return value
    for i,kind in enumerate(KINDS):
        if i>=len(records) or not isinstance(records[i],dict):continue
        rec=records[i];rp=('records',i)
        previous={'resolution':'assignment','exposure':'resolution','outcome':'exposure'}.get(kind)
        if previous in known:fix(rp+('predecessor_digest',),known[previous])
        if kind=='resolution':
            lp=PROOFS['launch_attestation']
            if 'assignment' in known:fix(lp+('body','assignment_digest'),known['assignment'])
            proof(lp,'launch_attestation')
        if kind=='exposure':
            cp,up,xp=(PROOFS[n] for n in ('commitment','usage_attestation','release_attestation'))
            if 'resolution' in known:
                for p in (cp,up):fix(p+('body','resolution_digest'),known['resolution'])
            proof(up,'usage_attestation');proof(cp,'commitment')
            try:commit=get(value,cp)
            except (KeyError,TypeError,IndexError):commit=None
            if isinstance(commit,dict):fix(xp+('body','commitment_digest'),digest(commit))
            proof(xp,'release_attestation')
        if kind=='outcome' and 'exposure' in known:fix(rp+('payload','exposure_digest'),known['exposure'])
        rec['integrity']=sign({k:v for k,v in rec.items() if k!='integrity'},profile['record_issuers'][kind],profile,keys)
        for p,new in mutations:
            if p[:3]==rp+('integrity',):set_value(value,p,new)
        env=rec.get('integrity')
        h=env.get('content_digest') if isinstance(env,dict) else None
        if isinstance(h,str) and len(h)==71 and h.startswith('sha256:'):known[kind]=h
    return value

def targets(chain,name):
    result=[]
    def add(parent,keys):
        for key in keys:result.append((parent+(key,),get(chain,parent+(key,))))
    add((),FIELDS['chain_required'])
    for i,kind in enumerate(KINDS):
        add(('records',i),FIELDS['record_required'])
        add(('records',i,'payload'),FIELDS['payload_required'][kind])
        add(('records',i,'integrity'),FIELDS['integrity_required'])
    for kind,path in PROOFS.items():
        add(path,FIELDS['proof_shape']['required'])
        add(path+('body',),FIELDS['proof_body_required'][kind])
        add(path+('integrity',),FIELDS['integrity_required'])
    for vp in (('records',2,'payload','artifacts'),PROOFS['commitment']+('body','artifacts')):
        add(vp,sorted(get(chain,vp)))
        for component in sorted(get(chain,vp)):add(vp+(component,),FIELDS['artifact_entry_required'])
    mp=PROOFS['usage_attestation']+('body','measured_components')
    add(mp,sorted(get(chain,mp)))
    for component in sorted(get(chain,mp)):add(mp+(component,),FIELDS['measured_component_required'])
    for np in (('records',1,'payload','claim_namespaces'),PROOFS['launch_attestation']+('body','namespace_values')):
        add(np,sorted(get(chain,np)))
    return result

def mirrored(path,new):
    # Synchronize the two required vectors to avoid an incidental readable
    # vector contradiction masking the isolated structural defect.
    a=('records',2,'payload','artifacts');b=PROOFS['commitment']+('body','artifacts')
    if path[:len(a)]==a:return [(path,new),(b+path[len(a):],new)]
    if path[:len(b)]==b:return [(path,new),(a+path[len(b):],new)]
    a=('records',1,'payload','claim_namespaces');b=PROOFS['launch_attestation']+('body','namespace_values')
    if path[:len(a)]==a:return [(path,new),(b+path[len(a):],new)]
    if path[:len(b)]==b:return [(path,new),(a+path[len(b):],new)]
    return [(path,new)]

def variants(path,value):
    yield 'absent',ABSENT
    if value is not None:yield 'null',None
    if value is None:
        yield 'wrong_container',[]
    elif type(value) is bool:yield 'wrong_type',0
    elif type(value) is int:yield 'wrong_type',True
    elif isinstance(value,str):
        yield 'wrong_type',[]
        yield 'empty',''
        yield 'surrounding_whitespace',' '+value+' '
        yield 'control_character','bad\x01identifier'
        # Digest/MAC and date encodings are tested malformed separately; they
        # are not subject to the configurable identifier-character bound.
        if not (path[-1] in ('issued_at','valid_from','expires_at','consent_at') or
                value.startswith(('sha256:','hmac-sha256:'))):yield 'oversize_identifier','x'*257
    elif isinstance(value,dict):
        yield 'wrong_type',[]
        yield 'empty',{}
    elif isinstance(value,list):yield 'wrong_type',{}

def descriptor(cid,name,chain,expected,required,family,description,**extra):
    result=dict(case_id=cid,profile_name=name,chain=chain,expected_disposition=expected,
                required_diagnostics=required,family=family,description=description,
                integrity_policy='structural_resealed_targets_preserved')
    result.update(extra)
    return result

def build_cases():
    cases=[]
    for name in ('writing_feedback','quiz_tutor'):
        seed=make_chain(name,case_id='field-control-'+name)
        for index,(path,value) in enumerate(targets(seed,name)):
            for mode,new in variants(path,value):
                cid=name+'-field-'+str(index).zfill(3)+'-'+mode
                chain=seal_mutated(seed,name,mirrored(path,new))
                cases.append(descriptor(cid,name,chain,'ERROR_INPUT',[{'rule_id':'I02','disposition':'ERROR_INPUT','path_prefix':display(path[:-1] if path[-1].startswith('lti.') else path)}],
                    'required_field_dimension',display(path)+' '+mode,target_path=list(path),dimension=mode))
        # Exact required null exceptions are positive, not malformed cases.
        cases.append(descriptor(name+'-null-exceptions',name,seed,'ADMIT',[],
            'conditional_null_positive','Assignment predecessors and unused fallback reference are explicitly null.'))
        # Unknown fields only in closed objects. Artifact entry unknown fields
        # are mirrored as above so the structural rule is the tested defect.
        containers=[(),*[('records',i) for i in range(4)],*[('records',i,'payload') for i in range(4)],
                    *PROOFS.values(),*[p+('body',) for p in PROOFS.values()],
                    *[('records',i,'integrity') for i in range(4)],*[p+('integrity',) for p in PROOFS.values()]]
        for vp in (('records',2,'payload','artifacts'),PROOFS['commitment']+('body','artifacts')):
            containers.extend(vp+(key,) for key in sorted(get(seed,vp)))
        mp=PROOFS['usage_attestation']+('body','measured_components')
        containers.extend(mp+(key,) for key in sorted(get(seed,mp)))
        for i,path in enumerate(containers):
            cid=name+'-unknown-'+str(i).zfill(3)
            chain=seal_mutated(seed,name,mirrored(path+('unrecognized_field',),'opaque-fixture'))
            cases.append(descriptor(cid,name,chain,'ERROR_INPUT',[{'rule_id':'I03','disposition':'ERROR_INPUT','path_prefix':display(path)}],
                                    'closed_field',display(path)+' unknown field'))
    return cases

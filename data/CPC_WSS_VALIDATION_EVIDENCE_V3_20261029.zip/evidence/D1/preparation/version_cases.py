"""Version reissuance controls, authored before new conformance execution."""
from copy import deepcopy
import json
from pathlib import Path
from fixture_factory import make_chain,load_context,reseal
from structural_cases import descriptor

ROOT=Path(__file__).resolve().parents[1]

def build_cases():
    cases=[]
    for name in ('writing_feedback','quiz_tutor'):
        p,keys,stamp=load_context(name)
        old=json.loads((ROOT/'reference'/('legacy_'+name+'_context.json')).read_text())
        chain=json.loads((ROOT/'reference'/('legacy_'+name+'_chain.raw')).read_bytes())
        cases.append(descriptor(name+'-old-operator-config',name,make_chain(name),'ERROR_CONFIG',
            [{'rule_id':'C01','disposition':'ERROR_CONFIG'}],'version_reissuance','Contract2.0.0 operator profile is unsupported by new implementation.',
            profile_override=old['profile'],keys_override=old['key_registry'],validation_time_override=old['validation_time']))
        merged=dict(keys,**old['key_registry'])
        cases.append(descriptor(name+'-old-chain-new-operator',name,chain,'REJECT',
            [{'rule_id':'R01','disposition':'REJECT'}],'version_reissuance','Old chain cannot self-assert new contract/profile. Old math seals remain checkable.',
            keys_override=merged,integrity_policy='ALL_AVAILABLE_SEALS_INDEPENDENTLY_VALID'))
        chain=make_chain(name)
        for record in chain['records']:record['schema_version']='cpc-2.0.0'
        cases.append(descriptor(name+'-old-schema-tag-resealed',name,reseal(chain,name),'REJECT',
            [{'rule_id':'R01','disposition':'REJECT'}],'version_reissuance','New authorized seals cannot excuse old schema version.',
            integrity_policy='ALL_AVAILABLE_SEALS_INDEPENDENTLY_VALID'))
        chain=make_chain(name)
        def walk(v):
            if isinstance(v,dict):
                for k,x in v.items():
                    if k=='contract_version':v[k]='2.0.0'
                    else:walk(x)
            elif isinstance(v,list):
                for x in v:walk(x)
        walk(chain)
        cases.append(descriptor(name+'-old-contract-tag-resealed',name,reseal(chain,name),'REJECT',
            [{'rule_id':'R01','disposition':'REJECT'}],'version_reissuance','Matching old signed contract tags are still incompatible with operator2.0.1.',
            integrity_policy='ALL_AVAILABLE_SEALS_INDEPENDENTLY_VALID'))
    return cases

"""Mechanics checks against literal normative examples, not full admission."""
import unittest
from cpc2.common import json_depth,iter_json_nodes
from cpc2.api import _wire_scan

class DepthDefinitionTests(unittest.TestCase):
    def test_literal_examples(self):
        cases=[(None,0),(True,0),(42,0),('x',0),({},0),([],0),
               ({'k':None},1),([None],1),({'k':{}},1),({'k':{'z':[]}},2),
               ([{'k':[None]}],3),({'':[[]]},2)]
        for value,expected in cases:
            with self.subTest(value=value):self.assertEqual(json_depth(value),expected)
    def test_object_key_and_value_are_siblings(self):
        self.assertEqual(list(iter_json_nodes({'k':{'z':None}})),[({'k':{'z':None}},0),('k',1),({'z':None},1),('z',2),(None,2)])
    def test_long_unicode_scalar_and_key_add_no_edges(self):
        self.assertEqual(json_depth({'測'*10000:'界'*10000}),1)
    def test_empty_container_at_boundary_is_counted(self):
        self.assertEqual(json_depth({'outer':[{}]}),2)
        self.assertFalse(_wire_scan({'outer':[{}]},2))
        self.assertEqual(_wire_scan({'outer':[{}]},1),[{'rule_id':'I01','code':'input_depth_limit','path':'$','disposition':'ERROR_INPUT'}])
    def test_scalar_leaf_above_container_count_is_not_ignored(self):
        self.assertEqual(json_depth({'outer':[{'leaf':0}]}),3)
        self.assertTrue(_wire_scan({'outer':[{'leaf':0}]},2))
    def test_iterative_deep_tree_no_python_recursion(self):
        value=0
        for _ in range(2000):value=[value]
        self.assertEqual(json_depth(value),2000)
        self.assertEqual(_wire_scan(value,32)[0]['code'],'input_depth_limit')

if __name__=='__main__':unittest.main()

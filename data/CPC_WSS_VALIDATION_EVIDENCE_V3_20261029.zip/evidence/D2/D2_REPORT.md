# CPC2.0.1 D2: actual-use prompt dan generation, V1

13 Oktober 2026. Verdict **PASS_LOCAL_MOCK_D2_WITH_EXPLICIT_TRUST_BOUNDARY** untuk 60 skenario sintetis pada runtime mock lokal. Eksekusi utama dan satu clean replay masing-masing 60/60 sesuai oracle; tidak ada exception tak tertangani atau kehilangan baris. **16 admission normal** mempunyai binding actual-use yang cocok. **Empat counterexample observer tidak jujur tetap mendapat ADMIT offline meskipun audit fisik menemukan MISMATCH.** Kasus ini bukan keberhasilan mitigasi CPC dan tidak boleh disembunyikan. D3 dan naskah tidak dikerjakan; API berbayar 0.

## Apa yang kini diamati secara aktual

Provider menerima immutable prompt bytes dan frozen GenerationConfig dengan 4 field: response_style, max_output_chars, include_rationale, seed. Di dalam pemanggilan consume, receiver menyimpan tepat bytes/objek argumen yang kemudian dipakai model_response. Digest prompt berasal dari raw bytes tersebut; digest generation berasal dari canonical JSON objek yang benar-benar dikonsumsi. Measurement tidak membuka kembali pathname untuk menebak apa yang dipakai.

Mock deterministik memakai MODE prompt, fingerprint seluruh prompt/konfigurasi, seed, style, rationale dan batas karakter. Pemeriksa terpisah merekonstruksi response dari snapshot tanpa mengimpor fungsi mock atau physical auditor implementer. Ini menunjukkan pemakaian argumen pada jalur instrumented mock; bukan kemampuan LLM atau kualitas pembelajaran.

Commitment ditandatangani pada event create/sign aktual, lalu ditulis exclusive, file-fsync dan directory-fsync. Completion durability dicatat terpisah: issued_at commitment adalah logical create/sign time, bukan klaim waktu fsync selesai. Setelah staging response fsync, observer mengambil keberadaan/hash commitment tepat sebelum atomic hard-link ke response_released.bin dan directory-fsync. Release timestamp/sequence direkam sesudah boundary itu; exposure/outcome diterbitkan kemudian. Full signed commitment bytes tetap sama dan digest-nya mengikat release proof.

Boundary release adalah **file output lokal yang ditetapkan**, bukan semua file staging/capture yang disimpan untuk audit, bukan browser/network/learner receipt. Trace filesystem/UTC/monotonic/sequence dan code path fsync merupakan bukti protokol OS lokal di bawah asumsi instrument/receiver jujur; tidak ada independent kernel trace, power-loss test atau trusted hardware. Observer, runtime dan role keys berbeda secara logis tetapi berada dalam satu proses, dengan public SYNTHETIC_ONLY keys.

## Skenario dan hasil

| Kelompok | Yang diuji | Hasil/batas |
| --- | --- | --- |
| Baseline dan fallback same-condition | Dua profile, empat kondisi, bundle approved/alternate |8 admission normal, actual capture sesuai registry. |
| Path berubah setelah load | Mutable pathname diganti, immutable snapshot approved tetap dipakai |8 admission normal; capture cocok bytes/objek yang digunakan, bukan pathname akhir. |
| Disk berubah sebelum load / argumen disubstitusi sebelum use | Actual consumed bytes/objek berubah meskipun loader/registry semula benar |16 REJECT R05, truthful physical binding tetapi actual registry mismatch. |
| Stale usage invocation/digest dan declared-only | Signature tetap benar, evidence salah atau tidak memenuhi measured policy |12 REJECT R05; tidak disamarkan accidental MAC/content-digest failure. |
| Release sebelum commit | Deliberately unsafe publication lebih dahulu, actual earlier UTC/sequence dipertahankan pada forensic negative proof |4 REJECT R07; tidak mengarang waktu release prospektif. |
| Commit persistence/release failure | Controlled EIO, no publication dan no final exposure/outcome |8 QUARANTINE Q01; assignment/resolution-only, candidate commit/capture diaudit terpisah. |
| Forged registry-only report | Provider benar-benar memakai input berubah, observer/runtime melaporkan registry baik secara konsisten |4 offline ADMIT, physical MISMATCH, actual-registry False/reported-registry True. Explicit trust-boundary counterexamples. |

Total offline:20 ADMIT,32 REJECT,8 QUARANTINE. Hanya16 dari20 ADMIT memiliki honest actual-use eligible evidence; empat lainnya counterexample di luar asumsi observer jujur.48 physical MATCH dan12 MISMATCH juga bukan sensitivity populasi: mismatch terdiri dari stale invocation/digest dan observer forgery yang sengaja dibangun.

Terdapat52 designated response publications dan56 official persistent commitments. Semua32 REJECT adalah exclusion setelah mock response dipublikasikan; ini bukan pencegahan delivery. Hanya8 controlled I/O failures yang menahan publikasi. Export metadata core20admitted +40excluded =60refs tepat sekali. Tidak ada outcome-value merge, tabel learning analytics atau baseline SQL/D3. File HONEST_ACTUAL_USE_ELIGIBLE_IDS hanya daftar audit16ID, bukan analisis manfaat.

## Freeze, independensi dan versi

Core source 2.0.2, schema/contract 2.0.1 disalin identik. Runtime baru 1.0.0, dua profile D2 baru, selection map dan registry dibekukan bersama 64 real component files (8bundles×8components), oracle 60 case, auditor dan runner sebelum trial pertama. Prompt/generation16file adalah subset measured;48descriptor lainnya tetap declared. Digests registry cocok actual file bytes, tetapi materialisasi file saja tidak disebut actual use. D2 baru mengamati pemakaiannya pada mock.

Preflight terpisah memperbaiki tiga gap auditor sebelum freeze: bundle kini diturunkan dari frozen operator selection, receiver dikaitkan ke invocation/capture/use event secara langsung, dan native digest/HMAC serta hubungan candidate commitment pada I/O faults diperiksa secara independen. R1blocking evidence dan R2closure disimpan. Tidak ada oracle edit atau source repair setelah60trial pertama.

Final verifier merekonstruksi setiap case dari snapshots/receiver/events/physical files dan memeriksa 456signedobjects per run. Satu clean workspace memuat 131freezeentries +manifest, kemudian menghasilkan 60observasi runtime baru. Keputusan/target diagnostic triples/physical relations/actual input digests/responsebytes sama antarrun. Timestamp, monotonic_ns dan signed-chain digests berubah secara sah karena observasinya baru; tidak diklaim byte-identik seperti D1.

Semua 42.053 berkas historis yang dilindungi, 44 copied+parent corefiles, 64 components dan 131 frozen inputs/source tetap cocok byte-nya. Hash hanya konsistensi bytes, bukan scientific correctness. Laporan final terpisah di review/FINAL_VERIFICATION.md; primary independent math/evidence reconstruction dan replay comparison di review/reproduction/. Raw replay dikemas sebagai reproduction_evidence/independent_d2; input/source workspace redundan tetap lokal.

## Batas klaim dan langkah berikutnya

D2 menutup gap capture registry-only pada jalur **honest, instrumented local mock**: measured digests berasal dari actual immutable provider arguments dan prospective commit/release ditelusuri secara fisik. Ia tidak membuat offline signature menjadi bukti kejujuran observer. Empat forged controls justru menunjukkan metadata yang konsisten dapat lolos walau physical inputs berbeda. Semua pernyataan pass harus menyertakan batas ini.

Belum ada remote AI/provider, real LTI, live learner delivery, secure custody/independent hardware observer, entire-stack measurement, production security, learning effects, full-information comparator/practical LA benefit, atau verdict JLA-ready. D3 NOT_RUN, manuscript NOT_REVISED, no public release/no paid API. Selanjutnya perlu D3 dan adjudikasi kontribusi sebelum perbaikan naskah; tidak diotorisasi otomatis oleh hasil ini.

## Reproduksi dan waktu

Dalam direktori paket yang diekstrak, jalankan frozen runner dengan nama baru:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 execution/run_d2.py --run new_d2_replay
```

Python>=3.11 diperlukan; run aktual memakai 3.12.14 standard library. Profile context ini memiliki batas aktual sampai **2026-10-15T04:07:20.922556+00:00 UTC**. Fresh physical replay setelah expiry memerlukan context/profile release baru yang sah dan dipertahankan sebagai versi baru; jangan memundurkan atau mengarang timestamp observasi. Archived chain dapat diaudit ulang dengan validation_time yang benar-benar tercatat pada run asal sebagai historical replay, bukan live admission.

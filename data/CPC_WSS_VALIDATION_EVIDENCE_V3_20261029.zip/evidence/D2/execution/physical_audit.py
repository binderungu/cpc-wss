"""Independent filesystem/receiver evidence reconstruction, not D3 comparison.

Does not import producer/mock/core decision functions. Same local trust model:
trace and immutable capture receiver are honest except explicit fault controls.
"""
import hashlib,hmac,json
from datetime import datetime
from pathlib import Path

def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def hash_bytes(data):return 'sha256:'+hashlib.sha256(data).hexdigest()
def when(v):return datetime.fromisoformat(v.replace('Z','+00:00'))

def independent_response(prompt,cfg):
    # Reconstruct the specified mock without importing its implementation.
    lines=prompt.decode().splitlines();tags=[s[len('MODE='):] for s in lines if s.startswith('MODE=')]
    mode=tags[0] if tags else 'UNSPECIFIED'
    fp=hash_bytes(prompt+b'\x00'+canon(cfg))[len('sha256:'):]
    word=['alpha','beta','gamma','delta'][cfg['seed']%4]
    sep={'bulleted':'\n- ','multiline':'\n'}.get(cfg['response_style'],' | ')
    parts=['fingerprint='+fp,'mode='+mode,'style='+cfg['response_style'],'example='+word]
    if cfg['include_rationale']:parts+=['rationale=synthetic deterministic mock explanation']
    return sep.join(parts)[:cfg['max_output_chars']].encode()

def inspect_trial(root,trial,row):
    root=Path(root);trial=Path(trial);issues=[]
    profile=json.loads((root/'profiles'/(row['profile_name']+'.json')).read_text())
    keys=json.loads((root/'registry'/(row['profile_name']+'_keys.json')).read_text())
    selected=json.loads((root/'registry/RUNTIME_SELECTION.json').read_text())[row['profile_name']][row['condition']]
    expected_bundle=selected['alternate' if row['mode']=='approved_fallback' else 'baseline']
    result=json.loads((trial/'runtime_result.json').read_text());chain=json.loads((trial/'final_chain.json').read_text())
    receiver=json.loads((trial/'receiver.json').read_text());events=[json.loads(l) for l in (trial/'events.jsonl').read_text().splitlines()]
    def need(ok,label):
        if not ok:issues.append(label)
    def event(action):
        found=[e for e in events if e['action']==action]
        return found[0] if len(found)==1 else None
    sealed_objects=0
    def verify_seal(obj,kind,is_proof=True):
        nonlocal sealed_objects
        signed=obj['body'] if is_proof else {k:v for k,v in obj.items() if k!='integrity'}
        issuer=profile['proof_issuers' if is_proof else 'record_issuers'][kind]
        key_id=profile['issuer_key_policy'][issuer];hashed=hash_bytes(canon(signed))
        expected={'algorithm':'HMAC-SHA256','key_id':key_id,'content_digest':hashed,
                  'mac':'hmac-sha256:'+hmac.new(keys[key_id].encode('ascii'),hashed.encode('ascii'),hashlib.sha256).hexdigest()}
        need(signed['issuer']==issuer and obj['integrity']==expected,'INDEPENDENT_SEAL:'+kind)
        sealed_objects+=1
    def verify_commit(obj):
        verify_seal(obj,'commitment');verify_seal(obj['body']['usage_attestation'],'usage_attestation')
    for record in chain['records']:
        verify_seal(record,record['record_type'],False)
        if record['record_type']=='resolution':verify_seal(record['payload']['launch_attestation'],'launch_attestation')
        if record['record_type']=='exposure':
            verify_commit(record['payload']['commitment']);verify_seal(record['payload']['release_attestation'],'release_attestation')
    need(result['bundle']==expected_bundle,'SUMMARY_BUNDLE_NE_OPERATOR_SELECTION')
    prompt=(trial/'actual_consumed_prompt.bin').read_bytes();config_raw=(trial/'actual_consumed_generation.json').read_bytes();cfg=json.loads(config_raw)
    need(set(cfg)=={'response_style','max_output_chars','include_rationale','seed'},'CONFIG_EXACT_FIELDS')
    need(type(cfg['max_output_chars']) is int and type(cfg['seed']) is int and type(cfg['include_rationale']) is bool,'CONFIG_TYPES')
    need(canon(cfg)==config_raw,'CONFIG_CANONICAL_ACTUAL_OBJECT')
    actual={'prompt':hash_bytes(prompt),'generation':hash_bytes(canon(cfg))}
    need(actual==result['actual_input_digests'],'RUNTIME_ACTUAL_DIGEST_SUMMARY')
    need(receiver['prompt_sha256']==actual['prompt'] and receiver['generation_sha256']==actual['generation'],'RECEIVER_DIGESTS')
    need(receiver['config_exact_fields']==cfg,'RECEIVER_ACTUAL_PARAMETERS')
    observed=event('provider_consumed')
    need(observed is not None and observed==receiver['event'],'RECEIVER_EVENT_SOURCE')
    need(observed is not None and observed['input_digests']==actual,'USE_BOUNDARY_DIGESTS')
    need(observed is not None and observed['invocation_id']==receiver['invocation_id'] and
         observed['capture_refs']==receiver['capture_refs'] and observed['use_refs']==receiver['use_refs'],'USE_EVENT_RELATION_IDS')
    need(receiver['source_paths_reopened_for_measurement'] is False,'PATH_REREAD_MEASUREMENT')
    response=(trial/'response_staged.bin').read_bytes()
    need(response==independent_response(prompt,cfg),'OUTPUT_NOT_FROM_CAPTURED_PARAMETERS')
    need(result['response_sha256']==hash_bytes(response),'RESPONSE_DIGEST')
    need([e['sequence'] for e in events]==list(range(1,len(events)+1)),'EVENT_SEQUENCE')
    need(all(a['monotonic_ns']<b['monotonic_ns'] for a,b in zip(events,events[1:])),'MONOTONIC_EVENT_ORDER')
    need(all(when(a['utc'])<=when(b['utc']) for a,b in zip(events,events[1:])),'REAL_WALLCLOCK_REGRESSION')
    approved=profile['artifact_registry'][expected_bundle]
    actual_registry=all(actual[c]==approved[c]['digest'] for c in actual)
    released=(trial/'response_released.bin').is_file();persisted=(trial/'signed_commitment.json').is_file()
    need(released==result['released'],'RELEASE_STATUS_FILE')
    need(persisted==result['commitment_persisted'],'COMMIT_STATUS_FILE')
    if released:need((trial/'response_released.bin').read_bytes()==response,'PHYSICAL_RESPONSE_CONTENT')
    records={r['record_type']:r for r in chain['records']}
    exposure=records.get('exposure');reported_registry=None;temporal=None;mode_policy=True
    if exposure:
        vector=exposure['payload']['artifacts'];commit=exposure['payload']['commitment'];usage=commit['body']['usage_attestation']['body'];release=exposure['payload']['release_attestation']['body']
        need(exposure['payload']['artifact_version']==commit['body']['artifact_version']==expected_bundle,'FINAL_BUNDLE_NE_OPERATOR_SELECTION')
        measured=usage['measured_components']
        binding=(all(measured[c]['digest']==actual[c] and vector[c]['digest']==actual[c] for c in actual)
                 and usage['invocation_id']==receiver['invocation_id']==exposure['payload']['invocation_id']
                 and all(measured[c]['capture_ref']==receiver['capture_refs'][c] and measured[c]['use_ref']==receiver['use_refs'][c] for c in actual))
        reported_registry=all(vector[c]==approved[c] and measured[c]['digest']==approved[c]['digest'] and measured[c]['version']==approved[c]['version'] for c in actual)
        mode_policy=all(vector[c]['evidence_mode']=='measured' for c in actual)
        need(all(vector[c]==approved[c] for c in set(approved)-set(actual)),'DECLARED_SIX_CHANGED')
        need(persisted and json.loads((trial/'signed_commitment.json').read_bytes())==commit,'PERSISTED_COMMITMENT_NE_FINAL_OBJECT')
        need(persisted and (trial/'signed_commitment.json').read_bytes()==canon(commit),'COMMIT_BYTES_CANONICAL_UNMODIFIED')
        need(release['commitment_digest']==hash_bytes(canon(commit)),'FULL_SIGNED_COMMITMENT_BINDING')
        ce=event('commitment_created_for_signing');de=event('commitment_durable');pe=event('prepublication_commitment_observation');re=event('release_observed')
        need(all(e is not None for e in (ce,de,pe,re)),'PHYSICAL_TIMELINE_EVENTS')
        if all(e is not None for e in (ce,de,pe,re)):
            need(commit['body']['issued_at']==ce['utc'] and commit['body']['sequence']==ce['sequence'],'COMMIT_LOGICAL_TIME_NOT_ACTUAL')
            need(usage['issued_at']==observed['utc'] and usage['sequence']==observed['sequence'],'USE_TIME_NOT_ACTUAL')
            need(release['issued_at']==re['utc'] and release['sequence']==re['sequence'],'RELEASE_TIME_NOT_ACTUAL')
            need(de['commitment_file_sha256']==hash_bytes(canon(commit)),'DURABILITY_OBJECT_DIGEST')
            temporal=(observed['monotonic_ns']<=ce['monotonic_ns']<de['monotonic_ns']<pe['monotonic_ns']<re['monotonic_ns']
                      and when(usage['issued_at'])<=when(commit['body']['issued_at'])<when(release['issued_at'])
                      and usage['sequence']<=commit['body']['sequence']<release['sequence']
                      and pe['commitment_present'] is True and pe['commitment_file_sha256']==hash_bytes(canon(commit)))
            if row['mode']!='release_before_commit':need(temporal,'PROSPECTIVE_DURABILITY_BEFORE_RELEASE')
        need('outcome' in records and when(release['issued_at'])<=when(exposure['issued_at'])<=when(records['outcome']['issued_at'])<=when(result['validation_time']),'FINAL_RECORDS_AFTER_OBSERVED_RELEASE')
        need(not any('release' in k for k in commit['body']),'PROSPECTIVE_COMMIT_HAS_FUTURE_RELEASE_FIELD')
    else:
        # I/O controls have actual capture but deliberately no finalized proof.
        candidate_path=trial/('signed_commitment.json' if persisted else 'commitment_unpersisted_candidate.json')
        candidate=json.loads(candidate_path.read_bytes());cv=candidate['body']['artifacts'];cu=candidate['body']['usage_attestation']['body']
        verify_commit(candidate)
        ce=event('commitment_created_for_signing');de=event('commitment_durable')
        need(ce is not None and candidate['body']['issued_at']==ce['utc'] and candidate['body']['sequence']==ce['sequence'],'IO_CANDIDATE_CREATE_EVENT')
        need(cu['issued_at']==observed['utc'] and cu['sequence']==observed['sequence'],'IO_CANDIDATE_USE_EVENT')
        need(candidate['body']['clock_id']==cu['clock_id']==profile['observer_clock_id'],'IO_CANDIDATE_CLOCK')
        need(candidate['body']['artifact_version']==expected_bundle,'IO_CANDIDATE_BUNDLE')
        need(candidate['body']['resolution_record_id']==cu['resolution_record_id']==records['resolution']['record_id'] and
             candidate['body']['resolution_digest']==cu['resolution_digest']==records['resolution']['integrity']['content_digest'],'IO_CANDIDATE_RESOLUTION')
        need(candidate['body']['invocation_id']==cu['invocation_id']==receiver['invocation_id'],'IO_CANDIDATE_INVOCATION')
        need(when(cu['issued_at'])<=when(candidate['body']['issued_at']),'IO_CANDIDATE_USE_CREATE_ORDER')
        binding=(all(cv[c]['digest']==actual[c] and cu['measured_components'][c]['digest']==actual[c] and
                     cu['measured_components'][c]['capture_ref']==receiver['capture_refs'][c] and
                     cu['measured_components'][c]['use_ref']==receiver['use_refs'][c] for c in actual)
                 and cu['invocation_id']==receiver['invocation_id']==observed['invocation_id'])
        mode_policy=all(cv[c]['evidence_mode']=='measured' for c in actual)
        need(set(records)=={'assignment','resolution'},'BLOCKED_IO_FINAL_RECORD_FORGED')
        need(not released and event('release_observed') is None,'BLOCKED_IO_RELEASE_OBSERVED')
        if persisted:
            need(de is not None and de['commitment_file_sha256']==hash_bytes(candidate_path.read_bytes()) and
                 de['commitment_object_digest']==hash_bytes(canon(candidate)),'IO_DURABLE_EVENT_FILE')
            need(candidate_path.read_bytes()==canon(candidate),'IO_DURABLE_CANONICAL_BYTES')
        else:need(de is None,'IO_FALSE_DURABLE_EVENT')
    # Path-substitution controls must distinguish used snapshot from path now.
    for c in ('prompt','generation'):
        loaded=(trial/('loaded_prompt.bin' if c=='prompt' else 'loaded_generation.json')).read_bytes()
        path_now=(trial/'mutable_sources'/('prompt.txt' if c=='prompt' else 'generation.json')).read_bytes()
        if row['mode']==c+'_path_changed_after_load':
            need(hash_bytes(loaded)==actual[c] and hash_bytes(path_now)!=actual[c],'PATH_CHANGE_AFTER_LOAD_NOT_ISOLATED')
        if row['mode']==c+'_substitution_before_use':
            need(hash_bytes(loaded)!=actual[c] and hash_bytes(path_now)==approved[c]['digest'],'IN_MEMORY_SUBSTITUTION_NOT_ISOLATED')
    physical='MATCH' if binding else 'MISMATCH'
    facts={'physical_binding':physical,'actual_registry_match':actual_registry,'reported_registry_match':reported_registry,
           'measured_mode_policy':mode_policy,'temporal_order':temporal,'released':released,'commitment_persisted':persisted,
           'response_sha256':hash_bytes(response),'actual_input_digests':actual,'binding_basis':'finalized_chain_and_receiver' if exposure else 'capture_only_no_finalized_proof',
           'trusted_actual_admit_eligible':physical=='MATCH' and actual_registry and mode_policy and temporal is True,
           'independent_sealed_objects_checked':sealed_objects,'issues':issues,'mechanical_evidence_valid':not issues}
    return facts

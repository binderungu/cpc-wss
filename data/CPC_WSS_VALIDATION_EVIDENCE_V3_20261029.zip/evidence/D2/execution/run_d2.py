"""Frozen D2 actual-use mock trials and admission/accounting, never D3."""
import argparse,collections,hashlib,json,os,sys,traceback
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
def verify(freeze):
    errors=[r for r,h in freeze['files'].items() if not (ROOT/r).is_file() or sha(ROOT/r)!=h]
    if errors:raise RuntimeError('Frozen source/input drift '+str(errors[:3]))

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--run',required=True);args=parser.parse_args()
    freeze=json.loads((ROOT/'provenance/D2_EXECUTION_FREEZE.json').read_text());verify(freeze)
    sys.path[:0]=[str(ROOT/'implementation/src'),str(ROOT)]
    from runtime.producer import run_trial
    from cpc2.api import validate_raw
    from cpc2.export import export_results
    from physical_audit import inspect_trial
    scenarios=json.loads((ROOT/'oracle/SCENARIOS.json').read_text())['cases']
    run=ROOT/'runs'/args.run;run.mkdir(parents=True,exist_ok=False);(run/'trials').mkdir()
    save(run/'RUN_BINDING.json',{'run':args.run,'freeze_sha256':sha(ROOT/'provenance/D2_EXECUTION_FREEZE.json'),
        'source_core':'2.0.2','contract':'2.0.1','runtime_version':'1.0.0','oracle_sha256':sha(ROOT/'oracle/SCENARIOS.json'),
        'runtime':sys.version,'D3':'NOT_RUN','manuscript':'NOT_REVISED','timeline':'ActualUTC/monotonic/seq observations; fresh perreplay'})
    decisions=[];checks=[];all_facts=[];exceptions=[]
    metrics={'expected_release':'released','expected_commitment_persisted':'commitment_persisted',
             'expected_physical_binding':'physical_binding','expected_actual_registry_match':'actual_registry_match',
             'expected_reported_registry_match':'reported_registry_match','expected_measured_mode_policy':'measured_mode_policy',
             'expected_temporal_order':'temporal_order'}
    with (run/'RAW_ADMISSION.jsonl').open('x') as rf,(run/'CASE_CHECKS.jsonl').open('x') as cf,(run/'PHYSICAL_AUDIT.jsonl').open('x') as af:
        for i,row in enumerate(scenarios):
            trial=run/'trials'/row['case_id'];issues=[]
            try:
                result=run_trial(row,trial)
                profile=json.loads((ROOT/'profiles'/(row['profile_name']+'.json')).read_text())
                keys=json.loads((ROOT/'registry'/(row['profile_name']+'_keys.json')).read_text())
                raw=(trial/'final_chain.json').read_bytes()
                decision=validate_raw(raw,profile,keys,result['validation_time'],input_ref='D2-'+str(i).zfill(5))
                facts=inspect_trial(ROOT,trial,row);all_facts.append({'case_id':row['case_id'],**facts})
                if decision['disposition']!=row['expected_admission']:issues.append('ADMISSION_MISMATCH')
                for d in row['required_diagnostics']:
                    if not any(x['rule_id']==d['rule_id'] and x['disposition']==d['disposition'] for x in decision['diagnostics']):issues.append('MISSING_TARGET_DIAGNOSTIC:'+d['rule_id'])
                if any(d['code'] in ('content_digest_mismatch','mac_mismatch') for d in decision['diagnostics']):issues.append('UNINTENDED_CRYPTO_MASK')
                for expected,fact in metrics.items():
                    if facts[fact]!=row[expected]:issues.append('PHYSICAL_EXPECTATION:'+fact)
                issues.extend(facts['issues'])
                if decision['disposition']!='ADMIT' and decision['admitted_record'] is not None:issues.append('REFUSED_EXPORT')
                if decision['input_sha256']!='sha256:'+hashlib.sha256(raw).hexdigest():issues.append('INPUT_FINGERPRINT')
                decisions.append(decision)
                rf.write(json.dumps({'case_id':row['case_id'],'trial_path':str(trial.relative_to(ROOT)),
                                     'validation_time':result['validation_time'],'decision':decision},sort_keys=True)+'\n')
                af.write(json.dumps({'case_id':row['case_id'],**facts},sort_keys=True)+'\n')
            except Exception as exc:
                issues.append('UNCAUGHT_RUNTIME_OR_AUDIT_EXCEPTION');exceptions.append(row['case_id'])
                rf.write(json.dumps({'case_id':row['case_id'],'exception_type':type(exc).__name__,'exception':str(exc),'traceback':traceback.format_exc()},sort_keys=True)+'\n')
            check={'case_id':row['case_id'],'mode':row['mode'],'profile_name':row['profile_name'],'condition':row['condition'],
                   'claim_class':row['claim_class'],'passed':not issues,'issues':issues}
            checks.append(check);cf.write(json.dumps(check,sort_keys=True)+'\n')
            for h in (rf,cf,af):h.flush()
            save(run/'PROGRESS.json',{'completed':i+1,'total':len(scenarios),'failed_so_far':sum(not c['passed'] for c in checks)})
            print('D2',i+1,'/',len(scenarios),'failed',sum(not c['passed'] for c in checks),flush=True)
        for h in (rf,cf,af):h.flush();os.fsync(h.fileno())
    try:
        accounting=export_results(decisions,run/'core_metadata_export')
        if exceptions:accounting['execution_errors_excluded_from_SDK_export']=exceptions
    except Exception as exc:accounting={'error':type(exc).__name__,'message':str(exc),'accounting_complete':False}
    counters=[r['case_id'] for r in scenarios if r['claim_class']=='trust_boundary_counterexample']
    decision_by={s['case_id']:d for s,d in zip([r for r in scenarios if r['case_id'] not in exceptions],decisions)}
    admitted_verified=[f['case_id'] for f in all_facts if f['trusted_actual_admit_eligible'] and decision_by[f['case_id']]['disposition']=='ADMIT'
                       and f['case_id'] not in counters and f['mechanical_evidence_valid']]
    save(run/'HONEST_ACTUAL_USE_ELIGIBLE_IDS.json',admitted_verified)
    allpass=(all(c['passed'] for c in checks) and not exceptions and accounting.get('accounting_complete') and accounting.get('received')==len(scenarios))
    summary={'status':'PASS_LOCAL_MOCK_D2_WITH_EXPLICIT_TRUST_BOUNDARY' if allpass else 'FAIL_D2','cases':len(scenarios),
       'passed_cases':sum(c['passed'] for c in checks),'failed_cases':sum(not c['passed'] for c in checks),'uncaught_exceptions':len(exceptions),
       'offline_counts':dict(collections.Counter(d['disposition'] for d in decisions)),
       'physically_verified_honest_ADMIT':len(admitted_verified),'trust_boundary_counterexamples':counters,
       'counterexample_note':'These four offlineADMIT despitephysicalMISMATCH; NOT successfulCPC mitigation and excludedhonestobserverclaim.',
       'actual_registry_match_counts':dict(collections.Counter(str(f['actual_registry_match']) for f in all_facts)),
       'physical_binding_counts':dict(collections.Counter(f['physical_binding'] for f in all_facts)),
       'released':sum(f['released'] for f in all_facts),'official_commitment_persisted':sum(f['commitment_persisted'] for f in all_facts),
       'core_export_accounting':accounting,'zero_paid_API_calls':True,'D3':'NOT_RUN','manuscript':'NOT_REVISED',
       'evidence_class':'Real local mock provider/file events withsyntheticinputs; sameprocess honestobserverassumption',
       'replay_criterion':'Same scenario outcomes/physicalrelations/inputdigests/responsebytes, freshobservedtimestamps notbyteidentical signedchains'}
    save(run/'SUMMARY.json',summary);save(run/'FAILURES.json',[c for c in checks if not c['passed']]);verify(freeze)
    print(json.dumps(summary,indent=2),flush=True)

if __name__=='__main__':main()

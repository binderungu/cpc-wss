# CPC D2 prospective oracle 1.0.0

Contract 2.0.1; copied admission source 2.0.2; design date 13 October 2026. Status: **EXPECTED_BEFORE_EXECUTION**. This file and `SCENARIOS.json` prescribe expected checks; they contain no executed D2 result. The oracle, runtime source, external profiles, registry and source binding must be frozen before the first trial. Historical D1 results are not D2 evidence.

## Boundary and independence

The authorized task is a finite synthetic, local deterministic AI mock with no paid API. It tests whether prompt and generation actual-use measurements reflect the immutable arguments consumed inside the mock provider, and whether observed local release follows durable commitment persistence. D3 comparisons/LA joins, manuscript work, actual learners, real LTI transport, network/browser delivery and production keys are excluded.

The frozen CPC contract is authoritative. Expected decisions were derived by reading contract sections 3–6 and 8, the rule matrix, and the copied validator predicates; no trial or admission function was executed while constructing this oracle. The runtime is a producer: it must not obtain expected decisions and then synthesize a matching result. The independent auditor must reconstruct actual-use truth from saved consumed prompt bytes, saved consumed generation object, provider response, receiver capture and observed event/file evidence rather than accepting `runtime_result.json` booleans or reported registry digests as truth.

The mock is one instrumented process with distinct fixture key IDs, not a secure independent observer. Local provider argument capture establishes a traceable path under its disclosed honest observer assumption. A signature alone cannot establish that an observer told the truth. The deliberately forged-registry cases expose that boundary and must remain in the report even if all oracle checks match.

## Sixty prescribed cases

Fifteen modes run once in each of four profile/condition combinations: writing feedback `guided`/`plain`, with identity namespace mapping, and quiz tutoring `hint`/`answer`, with raw `Q_HINT`/`Q_ANSWER` translation. A condition name or activity title must not select an expected decision; the separately supplied profile, resource map and signed authority evidence control attribution.

| Modes | Expected offline decision | Required targeted diagnostic | Physical binding | Actual inputs match registry | Reported proof/vector match registry |
|---|---|---|---|---|---|
| `baseline`, `approved_fallback` | ADMIT | None | MATCH | Yes | Yes |
| Prompt/generation disk changed before load | REJECT | R05/REJECT | MATCH | No | No |
| Prompt/generation argument substituted before use | REJECT | R05/REJECT | MATCH | No | No |
| Prompt/generation pathname changed after snapshot loading | ADMIT | None | MATCH | Yes | Yes |
| `stale_usage_invocation` | REJECT | R05/REJECT | MISMATCH | Yes | Yes |
| `stale_usage_digest` | REJECT | R05/REJECT | MISMATCH | No | No |
| `declared_only` | REJECT | R05/REJECT | MATCH | Yes | No |
| `commit_persist_failure`, `release_failure` | QUARANTINE | Q01/QUARANTINE | MATCH in candidate capture | Yes | No final proof; null |
| `release_before_commit` | REJECT | R07/REJECT | MATCH | Yes | Yes |
| `forged_registry_only` | ADMIT | None | **MISMATCH** | **No** | **Yes** |

Each row represents four cases except paired mode rows, which represent eight. The prospective totals are 20 offline ADMIT, 32 REJECT and 8 QUARANTINE. Only **16** ADMIT cases are complete within the honest producer/observer assumption; four ADMIT cases are explicit trust-boundary counterexamples. The expected release count is 52 and expected official durable commitment count is 56. These are accounting checks, not empirical results or rates of deployment detection.

## Required semantics of faults

1. Disk-change controls modify isolated mutable copies, never frozen registry/component originals. Truthful capture reports changed consumed bytes/objects in usage and vector; R05 must detect disagreement with frozen approved registry. A checksum failure caused merely by unresealed evidence is not the intended test.
2. Argument substitution occurs between load and provider call. The actual provider receives a new immutable `bytes` object or frozen generation dataclass. Capture must see that same argument, not the loaded original or a later pathname read. Prompt substitution and generation substitution are separate cases.
3. Pathname-change controls mutate a source path after the approved immutable arguments were loaded. They remain ADMIT only because the provider actually consumes the approved snapshot. An auditor that reopens the changed pathname would misclassify these controls and does not measure actual use.
4. `stale_usage_invocation` changes the sealed usage body's `invocation_id`, while the current provider call, commitment, release and exposure retain current invocation identity. A changed opaque `use_ref` alone is insufficient to create the offline targeted R05 predicate; the source does not derive invocation identity from an opaque reference spelling.
5. `stale_usage_digest` consumes changed prompt and generation, reports truthful changed digests in the complete vector, but seals stale approved digests in usage. Its reported-registry metric is false because **both** vector and usage must match; a stale usage digest alone matching the registry cannot make the metric true. R05 must identify usage/vector contradiction.
6. `declared_only` retains structurally complete, truthful usage proof and approved arguments, but sets vector evidence modes to `declared`. The minimum targeted decision is R05/REJECT. Removing proof fields would test malformed evidence (I02), and does not substitute for this policy test.
7. I/O-blocked cases compute the response, then refuse publication when commitment persistence or release fails. Their final chain contains assignment and resolution only, so the actual offline oracle is Q01/QUARANTINE for missing exposure/outcome, not a fabricated runtime-specific rejection. A candidate usage/commitment file is kept for physical inspection and must not be counted as finalized exposure. No `response_released.bin` may exist. Commitment persistence failure additionally forbids the official durable commitment file; release failure preserves the previously durable commitment.
8. `release_before_commit` is an intentionally unsafe negative control. The local response file is physically published before the signed commitment is created/persisted. The later proof must preserve real observed earlier release UTC and sequence, and bind the later immutable signed commitment. It must yield targeted R07/REJECT; rewriting the earlier observation to a future timestamp would destroy the control.
9. `forged_registry_only` changes actually consumed prompt and generation, but the authorized observer/runtime report approved registry digests consistently in both vector and usage proof. Correctly signed, structurally complete evidence can consequently pass the offline validator. The expected independent physical verdict is MISMATCH and actual-registry match is false. This is **not successful CPC mitigation**, not false-positive success, not an honest-observer experiment and not evidence of protection against colluding authorities. An unexpected offline reject must not be forced into the oracle by inserting an unrelated flaw.

## Physical, registry, policy and temporal metrics

`expected_physical_binding` compares actual provider arguments, invocation and capture/use relation to reported usage; it is separate from registry approval. Truthfully consumed unapproved arguments produce MATCH physical binding and REJECT registry conformance. `expected_actual_registry_match` compares actual prompt raw-byte digest and canonicalized consumed generation object digest to approved selected frozen bundle. `expected_reported_registry_match` compares both reported vector and usage metadata to that bundle, including evidence mode; it is null if the final chain has no exposure. `expected_measured_mode_policy` inspects the candidate/final vector and is false only for declared-only. All of these definitions are repeated in machine-readable form in `SCENARIOS.json`.

`expected_temporal_order` requires observed UTC order and local sequence order plus durable file existence before publication. It is false for release-before-commit and null when publication never completes. A later commitment checksum, a planned timestamp or final exposure issued after release cannot prove pre-release persistence. Signed commitment bytes must remain unchanged after persistence and its complete-object digest must bind the release proof. The actual release boundary is `durable_local_response_file`, with no claim of human/browser/network receipt.

Only prompt and generation are measured. Prompt uses actual immutable raw bytes. Generation uses `cpc-json-v2` canonicalization of exactly the consumed frozen object with four fields: `response_style`, `max_output_chars`, `include_rationale`, `seed`. The deterministic mock must consume all four fields, allowing independent response reconstruction; it supplies no evidence of LLM capability, response quality, learning or utility. The other six components (`ui`, `corpus`, `retriever`, `index`, `model`, `policy`) remain declared. Testing changed generation settings does not measure an entire AI stack.

## Acceptance and evidence interpretation

Every prescribed case requires exact final decision, the targeted diagnostic pairs, physical binding, registry metrics, measured policy, persistence/publication gates and temporal checks. An unrelated REJECT is a failure of the intended control. Every received input must have one admission/exclusion accounting row and no refused input may have an admitted export. ADMIT counterexamples must still receive accounting rows, but must be reported separately from the 16 honest complete admissions. Export contains metadata only; synthetic raw prompt/generation/response snapshots are local experiment audit artifacts outside the CPC contract/normalized export.

Keep crashes, mismatches, failed trials, runtime repairs and oracle changes visible as new revisions; do not overwrite a run or silently recode expected results after observing them. A freeze/hash supplies byte consistency and temporal provenance, not scientific correctness. A finite pass, if later observed, supports this synthetic mock path and fault set only. It does not establish production truth of capture, observer independence, population sensitivity, secure durability under power loss, paid/remote provider equivalence, D3 usefulness or JLA readiness.

# Local D2 producer

`run_trial(spec, trial_dir)` in `producer.py` consumes an operator-frozen profile,
separate synthetic role keys, runtime selection and existing component files.
It runs only when explicitly invoked. Import has no experiment side effects.
The caller must put `implementation/src` and this package root on `sys.path`.
The returned dictionary contains the final chain, actual post-issuance validation
time, runtime disposition, physical release/persistence facts and audit paths.
It never validates/adjudicates its own chain. Existing trial directories fail.

The mock receives immutable `bytes` and a frozen `GenerationConfig` with exactly
`response_style`, `max_output_chars`, `include_rationale`, `seed`. Inside the
provider call, the receiver snapshots those exact arguments and hashes prompt
raw bytes and canonical JSON of the consumed configuration. It never reopens a
source path for the measurement. Mutable source files and immutable loaded/use
snapshots are separate evidence. `receiver.json` records invocation/capture/use
references matching the observed consumption event. Raw prompt, configuration,
and response content stay outside the CPC chain and normalized export.

`model_response` in `mock_provider.py` permits independent reconstruction. It
reads the first `MODE=` prompt line as a mode branch; full prompt bytes and all
configuration fields determine a visible SHA256 fingerprint. Seed selects an
example, style changes layout, rationale controls explanatory text, and maximum
characters truncates output. This deterministic mock uses no external AI/API.
It supplies synthetic output, not educational or learner-effect evidence.

Each event records actual UTC, `monotonic_ns`, and a chain-local counter. Usage
records the receiver boundary timestamp. Commitment `issued_at` is the actual
logical create-for-signing event; later `commitment_durable` records completion
of exclusive file write, file fsync and directory fsync. Complete signed
commitment canonical bytes are retained, never edited after persistence.
Immediately before publication, file presence and file digest are observed.
Response publication uses an exclusive atomic hard link after staging-file
fsync, then directory fsync. `release_observed` follows that completion; final
exposure and synthetic outcome metadata are issued afterward. No timestamps
are moved forward to hide clock/order failures; tests must detect those.

Fault modes replace source bytes before load or immutable arguments before use,
change paths after snapshots, report a stale invocation/digest, mark measured
components declared, or inject controlled `EIO` before commitment fsync or
atomic publication. Those I/O faults produce assignment/resolution-only chains;
no successful release or final exposure is asserted. The premature-release
negative deliberately publishes before commitment exists. A later forensic
attestation retains the actual earlier release UTC and sequence and should
fail CPC order checks. This deliberately unsafe negative is labeled in traces.

`forged_registry_only` is a trust-boundary control: the actual provider consumes
substituted prompt/configuration but the observer signs registry digests in
both usage and artifacts. Valid HMACs do not prove an honest observer. Offline
admission may therefore be expected while independent physical audit detects
the mismatch. It is excluded from the honest-observer validation claim.

Physical mock release occurs before final offline validation. An offline
`REJECT` excludes analytical admission; it does not undo mock delivery or claim
a pre-delivery prevention mechanism. Only prompt and generation are measured;
the other six component metadata entries retain declared registry evidence.
Fsync results demonstrate the local OS durability protocol, not power-loss
survival or production distributed durability. Public `SYNTHETIC_ONLY` keys
support transparent fixtures only and supply no production authentication.

No D3 SQL/comparator, learning analytics analysis, manuscript edit, network call,
paid inference, deployment, or public release belongs to this producer.

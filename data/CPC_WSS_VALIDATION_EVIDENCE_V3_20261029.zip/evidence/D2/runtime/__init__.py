"""Local synthetic D2 producer; no paid or remote inference."""

"""Deterministic provider with immutable arguments and in-call use capture."""
from dataclasses import asdict, dataclass
import hashlib
import json


@dataclass(frozen=True)
class GenerationConfig:
    response_style: str
    max_output_chars: int
    include_rationale: bool
    seed: int

    @classmethod
    def from_mapping(cls, value):
        fields = {'response_style', 'max_output_chars', 'include_rationale', 'seed'}
        if not isinstance(value, dict) or set(value) != fields:
            raise ValueError('generation_config_exact_fields_required')
        if not isinstance(value['response_style'], str) or not value['response_style']:
            raise ValueError('response_style_required')
        if type(value['max_output_chars']) is not int or value['max_output_chars'] < 1:
            raise ValueError('max_output_chars_positive_integer_required')
        if type(value['seed']) is not int or value['seed'] < 0:
            raise ValueError('seed_nonnegative_integer_required')
        if type(value['include_rationale']) is not bool:
            raise ValueError('include_rationale_boolean_required')
        return cls(**value)


def canonical_config(config):
    return json.dumps(asdict(config), sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf-8')


def model_response(prompt_bytes, config):
    """Reconstructible mock algorithm; input is already the actual-use snapshot.

    The first MODE= line controls a branch label. Full prompt bytes and all four
    generation fields control the visible fingerprint. Seed selects an example;
    style controls separators; rationale controls explanatory text; maximum
    limits Unicode output characters. No learner response or network is used.
    """
    if type(prompt_bytes) is not bytes or type(config) is not GenerationConfig:
        raise TypeError('immutable_provider_arguments_required')
    text = prompt_bytes.decode('utf-8')
    modes = [line[5:] for line in text.splitlines() if line.startswith('MODE=')]
    mode = modes[0] if modes else 'UNSPECIFIED'
    signature = hashlib.sha256(prompt_bytes + b'\0' + canonical_config(config)).hexdigest()
    example = ('alpha', 'beta', 'gamma', 'delta')[config.seed % 4]
    separator = '\n- ' if config.response_style == 'bulleted' else ('\n' if config.response_style == 'multiline' else ' | ')
    parts = ['fingerprint=' + signature, 'mode=' + mode,
             'style=' + config.response_style, 'example=' + example]
    if config.include_rationale:
        parts.append('rationale=synthetic deterministic mock explanation')
    return separator.join(parts)[:config.max_output_chars].encode('utf-8')


def consume(prompt_bytes, config, capture):
    """Capture exact immutable arguments at provider consumption, inside call.

    capture receives the same bytes/object used by model_response. It must save
    snapshots before returning; it never reopens source paths to measure use.
    """
    if type(prompt_bytes) is not bytes or type(config) is not GenerationConfig:
        raise TypeError('immutable_provider_arguments_required')
    observed = capture(prompt_bytes, config)
    return model_response(prompt_bytes, config), observed

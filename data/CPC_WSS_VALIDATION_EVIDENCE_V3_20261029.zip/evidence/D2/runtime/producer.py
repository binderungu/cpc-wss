"""Observed local D2 events and signed CPC records; never calls the validator.

Only run_trial starts a real synthetic trial. Import has no trial side effects.
All timestamps are actual UTC observations, never fabricated D1 fixture times.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
from datetime import datetime, timezone
import errno
import hashlib
import hmac
import json
import os
from pathlib import Path
import time

from cpc2.common import canonical_json, digest, proof_object_digest
from .mock_provider import GenerationConfig, canonical_config, consume

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
MODES = (
    'baseline', 'approved_fallback', 'prompt_disk_changed_before_load',
    'generation_disk_changed_before_load', 'prompt_substitution_before_use',
    'generation_substitution_before_use', 'prompt_path_changed_after_load',
    'generation_path_changed_after_load', 'stale_usage_invocation',
    'stale_usage_digest', 'declared_only', 'commit_persist_failure',
    'release_failure', 'release_before_commit', 'forged_registry_only',
)


def _utc():
    return datetime.now(timezone.utc).isoformat(timespec='microseconds').replace('+00:00', 'Z')


def _hash_bytes(value):
    return 'sha256:' + hashlib.sha256(value).hexdigest()


def _save_json(path, value):
    path.write_bytes(canonical_json(value))


def _fsync_dir(path):
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


class EventLog:
    def __init__(self, directory):
        self.path = directory / 'events.jsonl'
        self.sequence = 0
        self.rows = []

    def event(self, action, **details):
        self.sequence += 1
        row = {'sequence': self.sequence, 'utc': _utc(),
               'monotonic_ns': time.monotonic_ns(), 'action': action, **details}
        with self.path.open('ab') as handle:
            handle.write(canonical_json(row) + b'\n')
            handle.flush()
            os.fsync(handle.fileno())
        self.rows.append(row)
        return row


def _signed(value, issuer, profile, keys, proof=False):
    unsigned = value['body'] if proof else value
    key_id = profile['issuer_key_policy'][issuer]
    content = digest(unsigned)
    secret = keys[key_id]
    key_bytes = secret.encode('ascii') if isinstance(secret, str) else secret
    seal = {'algorithm': 'HMAC-SHA256', 'key_id': key_id,
            'content_digest': content,
            'mac': 'hmac-sha256:' + hmac.new(key_bytes, content.encode('ascii'), hashlib.sha256).hexdigest()}
    return {**value, 'integrity': seal}


def _changed_prompt(prompt):
    return b'MODE=SUBSTITUTED_SYNTHETIC\n' + prompt + b'\nD2_LOCAL_SUBSTITUTION=1\n'


def _changed_config(config):
    values = asdict(config)
    values.update(response_style='substituted_style', seed=config.seed + 17,
                  include_rationale=not config.include_rationale,
                  max_output_chars=config.max_output_chars + 13)
    return GenerationConfig.from_mapping(values)


def run_trial(spec: dict, trial_dir: Path) -> dict:
    """Run one isolated real-time synthetic/mock trial, returning audit metadata.

    Requires pre-frozen external profiles/registry/selection. trial_dir must not
    exist. No validation, export, SQL, comparator, manuscript or network calls.
    """
    if not isinstance(spec, dict) or spec.get('mode') not in MODES:
        raise ValueError('unsupported_trial_mode')
    root = Path(spec.get('package_root', PACKAGE_ROOT)).resolve()
    profile_name, condition, mode, case_id = (spec[k] for k in ('profile_name', 'condition', 'mode', 'case_id'))
    profile = json.loads((root / 'profiles' / (profile_name + '.json')).read_text())
    keys = json.loads((root / 'registry' / (profile_name + '_keys.json')).read_text())
    context_config = json.loads((root / 'profiles' / (profile_name + '_context.json')).read_text())
    selection = json.loads((root / 'registry' / 'RUNTIME_SELECTION.json').read_text())
    # A wrapper with per-profile selections is optional; authority remains in profile.
    if 'profiles' in selection:
        selection = selection['profiles'][profile_name]
    elif profile_name in selection:
        selection = selection[profile_name]
    picked = selection[condition]
    bundle = picked['alternate' if mode == 'approved_fallback' else 'baseline']
    if bundle not in profile['artifact_registry'] or condition not in profile['conditions']:
        raise ValueError('operator_selection_outside_profile')
    permissions = [ref for ref, permission in profile['fallback_permissions'].items()
                   if permission['condition'] == condition and bundle in permission['artifact_versions']]
    if mode == 'approved_fallback' and not permissions:
        raise ValueError('alternate_bundle_not_authorized')
    resources = [rid for rid, mapped in profile['resource_condition_map'].items() if mapped == condition]
    if not resources:
        raise ValueError('resource_mapping_unavailable')
    namespace_values = {}
    for namespace, policy in profile['namespace_policy'].items():
        candidates = [raw for raw, mapped in policy['mapping'].items() if mapped == condition]
        if candidates:
            namespace_values[namespace] = sorted(candidates)[0]
        elif policy['required']:
            raise ValueError('required_namespace_mapping_unavailable')
    trial_dir = Path(trial_dir).resolve()
    trial_dir.mkdir(parents=True, exist_ok=False)
    source_dir = trial_dir / 'mutable_sources'
    source_dir.mkdir()
    source = root / 'components' / profile_name / bundle
    prompt_path, generation_path = source_dir / 'prompt.txt', source_dir / 'generation.json'
    prompt_path.write_bytes((source / 'prompt.txt').read_bytes())
    generation_path.write_bytes((source / 'generation.json').read_bytes())
    log = EventLog(trial_dir)
    log.event('trial_start', case_id=case_id, mode=mode, profile_id=profile['profile_id'])
    unit, invocation = 'unit:' + case_id, 'invocation:' + case_id
    exposure_id = 'exposure:' + case_id
    shared = {k: profile[k] for k in ('contract_version', 'profile_id', 'profile_version',
              'experiment_id', 'experiment_version', 'deployment_id', 'context_id')}
    shared.update(unit_token=unit, audience=profile['expected_audience'],
                  valid_from=profile['freeze_timestamp'], expires_at=context_config['valid_until'])

    def proof(kind, extra, observed):
        issuer = profile['proof_issuers'][kind]
        body = {**shared, 'proof_id': kind + ':' + case_id, 'issuer': issuer,
                'issued_at': observed['utc'], **extra}
        return _signed({'body': body}, issuer, profile, keys, proof=True)

    def record(kind, payload, predecessor, observed):
        issuer = profile['record_issuers'][kind]
        body = {**shared, 'record_id': kind + ':' + case_id, 'record_type': kind,
                'schema_version': profile['schema_version'], 'issuer': issuer,
                'issued_at': observed['utc'], 'nonce': 'nonce:' + kind + ':' + case_id,
                'predecessor_record_id': predecessor['record_id'] if predecessor else None,
                'predecessor_digest': predecessor['integrity']['content_digest'] if predecessor else None,
                'payload': payload}
        return _signed(body, issuer, profile, keys)

    assignment_event = log.event('assignment_issued')
    assignment = record('assignment', {'assigned_condition': condition,
                        'assignment_policy_version': profile['assignment_policy_version'],
                        'scope': profile['scope'], 'resource_id': resources[0],
                        'launch_nonce': 'launch:' + case_id}, None, assignment_event)
    launch_event = log.event('launch_observed')
    launch = proof('launch_attestation', {'assignment_record_id': assignment['record_id'],
                   'assignment_digest': assignment['integrity']['content_digest'],
                   'resource_id': resources[0], 'launch_nonce': 'launch:' + case_id,
                   'namespace_values': namespace_values}, launch_event)
    fallback = mode == 'approved_fallback'
    resolution_event = log.event('resolution_issued')
    resolution = record('resolution', {'requested_condition': condition, 'resolved_condition': condition,
                        'claim_namespaces': namespace_values, 'resolver_version': profile['resolver_version'],
                        'fallback_used': fallback, 'fallback_authorized': fallback,
                        'authorization_ref': sorted(permissions)[0] if fallback else None,
                        'launch_nonce': 'launch:' + case_id, 'launch_attestation': launch},
                        assignment, resolution_event)
    consent_event = log.event('synthetic_consent_metadata_observed')
    if mode == 'prompt_disk_changed_before_load':
        prompt_path.write_bytes(_changed_prompt(prompt_path.read_bytes()))
        log.event('prompt_source_changed_before_load')
    if mode == 'generation_disk_changed_before_load':
        original = GenerationConfig.from_mapping(json.loads(generation_path.read_bytes()))
        generation_path.write_bytes(canonical_config(_changed_config(original)))
        log.event('generation_source_changed_before_load')
    loaded_prompt = prompt_path.read_bytes()
    loaded_config = GenerationConfig.from_mapping(json.loads(generation_path.read_bytes()))
    (trial_dir / 'loaded_prompt.bin').write_bytes(loaded_prompt)
    (trial_dir / 'loaded_generation.json').write_bytes(canonical_config(loaded_config))
    log.event('immutable_arguments_loaded', prompt_sha256=_hash_bytes(loaded_prompt),
              generation_sha256=_hash_bytes(canonical_config(loaded_config)))
    actual_prompt, actual_config = loaded_prompt, loaded_config
    if mode in ('prompt_substitution_before_use', 'stale_usage_digest', 'forged_registry_only'):
        actual_prompt = _changed_prompt(loaded_prompt)
        log.event('prompt_argument_substituted_before_use')
    if mode in ('generation_substitution_before_use', 'stale_usage_digest', 'forged_registry_only'):
        actual_config = _changed_config(loaded_config)
        log.event('generation_argument_substituted_before_use')
    if mode == 'prompt_path_changed_after_load':
        prompt_path.write_bytes(_changed_prompt(loaded_prompt))
        log.event('prompt_source_changed_after_snapshot')
    if mode == 'generation_path_changed_after_load':
        generation_path.write_bytes(canonical_config(_changed_config(loaded_config)))
        log.event('generation_source_changed_after_snapshot')
    vector = deepcopy(profile['artifact_registry'][bundle])
    capture_refs = {component: 'capture:' + component + ':' + case_id for component in ('prompt', 'generation')}
    use_refs = {component: 'use:' + component + ':' + case_id for component in ('prompt', 'generation')}

    def capture(prompt, config):
        # These are exactly the arguments consumed by the provider call below.
        captured_config = canonical_config(config)
        actual_digests = {'prompt': _hash_bytes(prompt), 'generation': _hash_bytes(captured_config)}
        event = log.event('provider_consumed', invocation_id=invocation,
                          input_digests=actual_digests, capture_refs=capture_refs, use_refs=use_refs)
        (trial_dir / 'actual_consumed_prompt.bin').write_bytes(prompt)
        (trial_dir / 'actual_consumed_generation.json').write_bytes(captured_config)
        receiver = {'invocation_id': invocation, 'event': event,
                    'config_exact_fields': asdict(config), 'prompt_sha256': actual_digests['prompt'],
                    'generation_sha256': actual_digests['generation'],
                    'capture_refs': capture_refs, 'use_refs': use_refs,
                    'capture_boundary': 'inside_mock_provider.consume_before_response',
                    'source_paths_reopened_for_measurement': False}
        _save_json(trial_dir / 'receiver.json', receiver)
        return {'event': event, 'actual_input_digests': actual_digests}

    response, observed_use = consume(actual_prompt, actual_config, capture)
    actual_digests = observed_use['actual_input_digests']
    use_event = observed_use['event']
    (trial_dir / 'response_staged.bin').write_bytes(response)
    log.event('mock_response_computed', response_sha256=_hash_bytes(response), response_bytes=len(response))
    reported_digests = dict(actual_digests)
    if mode in ('stale_usage_digest', 'forged_registry_only'):
        reported_digests = {component: vector[component]['digest'] for component in ('prompt', 'generation')}
        log.event('observer_reports_stale_registry_digests', dishonest=(mode == 'forged_registry_only'))
    for component in ('prompt', 'generation'):
        vector[component]['digest'] = reported_digests[component] if mode == 'forged_registry_only' else actual_digests[component]
    if mode == 'declared_only':
        for entry in vector.values():
            entry['evidence_mode'] = 'declared'
    measured = {component: {'component_id': component, 'version': vector[component]['version'],
                'digest': reported_digests[component], 'capture_ref': capture_refs[component],
                'use_ref': use_refs[component]} for component in ('prompt', 'generation')}
    usage = proof('usage_attestation', {'clock_id': profile['observer_clock_id'],
                  'sequence': use_event['sequence'],
                  'invocation_id': 'stale:' + case_id if mode == 'stale_usage_invocation' else invocation,
                  'resolution_record_id': resolution['record_id'],
                  'resolution_digest': resolution['integrity']['content_digest'],
                  'measured_components': measured}, use_event)
    commit_path = trial_dir / 'signed_commitment.json'
    release_path = trial_dir / 'response_released.bin'
    released = persisted = False
    release_event = None

    def publish(unsafe=False):
        staging = trial_dir / 'response_publish_pending.bin'
        with staging.open('xb') as handle:
            handle.write(response)
            handle.flush()
            os.fsync(handle.fileno())
        # Observe the commitment after staging is durable, immediately before
        # the atomic publication action; do not measure it from a later path.
        present = commit_path.is_file()
        before = {'commitment_present': present,
                  'commitment_file_sha256': _hash_bytes(commit_path.read_bytes()) if present else None,
                  'unsafe_negative_control': unsafe}
        log.event('prepublication_commitment_observation', **before)
        if not unsafe and not present:
            raise RuntimeError('commitment_not_persisted')
        # Atomic, exclusive hard-link publication followed by directory fsync.
        # Staging remains an audit artifact; no prior output can be overwritten.
        os.link(staging, release_path)
        _fsync_dir(trial_dir)
        return log.event('release_observed', response_sha256=_hash_bytes(release_path.read_bytes()),
                         release_boundary=profile['release_boundary'], **before)

    if mode == 'release_before_commit':
        release_event = publish(unsafe=True)
        released = True
    commit_event = log.event('commitment_created_for_signing')
    commitment = proof('commitment', {'clock_id': profile['observer_clock_id'],
                       'sequence': commit_event['sequence'], 'resolution_record_id': resolution['record_id'],
                       'resolution_digest': resolution['integrity']['content_digest'],
                       'invocation_id': invocation, 'enacted_condition': condition,
                       'artifact_version': bundle, 'artifacts': vector, 'usage_attestation': usage}, commit_event)
    commitment_bytes = canonical_json(commitment)
    runtime_status = 'COMPLETED'
    if mode == 'commit_persist_failure':
        # Controlled persistence fault before the official exclusive durable file.
        try:
            with (trial_dir / 'commitment_unpersisted_candidate.json').open('xb') as handle:
                handle.write(commitment_bytes)
                handle.flush()
                raise OSError(errno.EIO, 'controlled fault before commitment fsync')
        except OSError as failure:
            if failure.errno != errno.EIO:
                raise
            log.event('injected_commitment_persistence_failure', controlled_errno='EIO', publication_attempted=False)
        runtime_status = 'CONTROLLED_COMMIT_PERSISTENCE_FAILURE'
    else:
        with commit_path.open('xb') as handle:
            handle.write(commitment_bytes)
            handle.flush()
            os.fsync(handle.fileno())
        _fsync_dir(trial_dir)
        persisted = True
        log.event('commitment_durable', commitment_file_sha256=_hash_bytes(commit_path.read_bytes()),
                  commitment_object_digest=proof_object_digest(commitment))
        if mode == 'release_failure':
            try:
                raise OSError(errno.EIO, 'controlled fault before atomic publication')
            except OSError as failure:
                if failure.errno != errno.EIO:
                    raise
                log.event('injected_release_failure', controlled_errno='EIO', publication_attempted=False)
            runtime_status = 'CONTROLLED_RELEASE_FAILURE'
        elif not released:
            release_event = publish()
            released = True
    records = [assignment, resolution]
    if released and persisted:
        release = proof('release_attestation', {'clock_id': profile['observer_clock_id'],
                        'sequence': release_event['sequence'], 'invocation_id': invocation,
                        'commitment_digest': proof_object_digest(commitment),
                        'exposure_record_id': exposure_id,
                        'release_boundary': profile['release_boundary']}, release_event)
        # Negative-order control binds later-created commitment to real earlier
        # release; timestamp is retained, not rewritten. It should fail R07.
        if mode == 'release_before_commit':
            log.event('forensic_negative_release_attestation_created_after_commitment',
                      retained_observed_release_utc=release_event['utc'])
        exposure_event = log.event('final_exposure_record_issued_after_release')
        exposure = record('exposure', {'enacted_condition': condition, 'artifact_version': bundle,
                          'artifacts': vector, 'invocation_id': invocation,
                          'commitment': commitment, 'release_attestation': release}, resolution, exposure_event)
        outcome_event = log.event('synthetic_outcome_metadata_issued')
        outcome = record('outcome', {'exposure_record_id': exposure['record_id'],
                         'exposure_digest': exposure['integrity']['content_digest'],
                         'attributed_condition': condition, 'outcome_key': 'outcome:' + case_id,
                         'consent_state': 'consented', 'consent_at': consent_event['utc'],
                         'consent_authority_ref': profile['consent_authority_refs'][0],
                         'consent_policy_version': profile['consent_policy_version'],
                         'purpose': profile['permitted_purposes'][0], 'eligible': True}, exposure, outcome_event)
        records.extend([exposure, outcome])
    chain = {k: profile[k] for k in ('contract_version', 'profile_id', 'profile_version')}
    chain.update(case_id=case_id, records=records)
    _save_json(trial_dir / 'final_chain.json', chain)
    complete_event = log.event('final_chain_materialized', record_count=len(records),
                              chain_sha256=_hash_bytes((trial_dir / 'final_chain.json').read_bytes()))
    validation_time = _utc()  # independent runner validates after final issuance.
    result = {'case_id': case_id, 'mode': mode, 'profile_name': profile_name,
              'condition': condition, 'bundle': bundle, 'chain': chain,
              'validation_time': validation_time, 'runtime_status': runtime_status,
              'released': released, 'commitment_persisted': persisted,
              'actual_input_digests': actual_digests, 'reported_input_digests': reported_digests,
              'response_sha256': _hash_bytes(response), 'final_event_sequence': complete_event['sequence'],
              'audit_paths': {'events': 'events.jsonl', 'receiver': 'receiver.json',
                'actual_prompt': 'actual_consumed_prompt.bin', 'actual_generation': 'actual_consumed_generation.json',
                'loaded_prompt': 'loaded_prompt.bin', 'loaded_generation': 'loaded_generation.json',
                'response_staged': 'response_staged.bin',
                'response_released': 'response_released.bin' if released else None,
                'commitment': 'signed_commitment.json' if persisted else None,
                'chain': 'final_chain.json'}}
    _save_json(trial_dir / 'runtime_result.json', {k: v for k, v in result.items() if k != 'chain'})
    return result

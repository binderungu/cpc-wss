# D3 CPC 2.0.1: pembanding full-information dan walkthrough LA, V2

13 Oktober 2026. **Verdict final: PASS_BOUNDED_SYNTHETIC_D3_INDEPENDENT_VERIFICATION.** Kedua implementasi memberikan keputusan dan export admitted yang sama pada 64 input; 24 pemeriksaan analitik sesuai oracle, enam mechanical guards lulus, tanpa exception. Audit matematika independen dan satu reproduksi bersih juga lulus, tanpa temuan material dalam batas protokol. Ini validasi teknis pada data sintetis dan rekaman mock lokal, bukan bukti efektivitas pembelajaran, superioritas deteksi, production security atau JLA-ready.

## Hasil pembanding dan batas informasi

Core CPC source 2.0.2 / contract-schema 2.0.1 disalin identik. Pembanding adalah **rules suite Python independen dengan informasi setara**, sesuai opsi SQL/equivalent pada rencana; ia bukan implementasi SQL. Canonical JSON, digest, HMAC, timestamp, profile/authority, proof, linkage dan rule predicates dijalankan sendiri tanpa mengimpor atau menyalin validator CPC. SQL dipakai pada adapter join analitik bersama di tahap downstream. Independent computation tidak berarti independent specification: keduanya memakai kontrak dan field catalogue yang sama.

Kedua validator menerima raw chain yang sama, profil/key registry operator yang sama, serta validation_time historis yang benar-benar tercatat pada D2. Tidak ada physical capture, label fault atau expected verdict yang diberikan untuk menentukan admission. Source pembanding dibuat sebelum perbandingan pertama. Terdapat 60 chain D2 dan empat penerimaan ulang raw baseline yang persis sama, masing-masing diberi input_ref operator baru. Empat salinan itu adalah uji ingestion, bukan learner atau observasi actual-use baru.

V2 menghasilkan **24 ADMIT / 32 REJECT / 8 QUARANTINE pada masing-masing implementasi**, 0 perbedaan verdict, 0 perbedaan normalized admitted export, dan 0 exception. Minimum target R05/R07/Q01 tetap diperiksa; fault semantik tidak disamarkan oleh MAC/content-digest failure. Keputusan setara mendukung portabilitas semantics pada katalog ini. Ia tidak menunjukkan CPC lebih kuat dari SQL/GX/equivalent rules, dan tidak membuktikan seluruh domain atau 5.476 kasus D1 ekuivalen.

## Walkthrough outcome dan denominator

External outcome store dibuat baru dari metadata 52 chain lengkap. Scalar adalah SHA-256 canonical governed composite modulo 101; nilainya tidak ditentukan oleh kondisi, fault, verdict atau flag physical audit. Semua nilai adalah fixture buatan, bukan estimasi hasil belajar atau efek treatment. CPC sendiri tetap mengekspor metadata whitelisted tanpa outcome value.

Adapter melakukan exact SQLite join pada tujuh field: experiment_id, experiment_version, unit_token, exposure_record_id, exposure_digest, outcome_key, purpose. Kardinalitas harus tepat satu di sisi metadata admitted **dan** external outcome store. Satu outcome opaque yang dirujuk dua admitted input_ref tidak dipilih atau di-deduplicate diam-diam. Duplikat external dengan nilai identik tetap ambigu. Nilai hilang, NaN, bool, string dan scalar di luar [0,100] tidak diimputasi atau dikoersi.

| Store sintetis | Original60: joined / physical-qualified | Full64: joined / physical-qualified | Alasan perubahan |
| --- | --- | --- | --- |
| Lengkap | 20 / 16 | 16 / 12 | Full64 memuat 8 admission yang ambigu karena empat raw chain diterima ulang. |
| Empat outcome unik hilang | 16 / 12 | 12 / 8 | Satu outcome approved fallback per kondisi tidak tersedia. |
| Empat key memiliki duplikat nilai berbeda | 16 / 12 | 12 / 8 | External cardinality bukan satu; tidak di-average. |
| Empat key memiliki duplikat nilai identik | 16 / 12 | 12 / 8 | Nilai yang sama tidak menghapus ambiguity. |
| Empat orphan dengan opaque key sama, composite scope salah | 20 / 16 | 16 / 12 | Wrong-scope rows tidak bergabung dan tetap dicatat di external ledger. |
| Empat scalar invalid | 16 / 12 | 12 / 8 | NaN/bool/string/101 ditolak dari tabel analitik. |

Original60 adalah cohort terpisah yang ditetapkan lewat inventory sebelum eksekusi, bukan hasil memilih atau menghapus duplikat pada Full64. Denominator received tetap 60 atau 64. Core refusal tetap 40 pada keduanya. Semua input_ref berada tepat sekali dalam joined rows atau reasoned exclusion ledger; semua external store rows juga mempunyai ordinal/status ledger. Perbedaan core admission dan analytical join exclusion dicatat eksplisit. Rata-rata scalar tersedia pada CSV/JSON hanya untuk membuktikan transformasi bisa diselesaikan; tidak dipakai untuk membandingkan kualitas kondisi.

Contoh nyata konfigurasi: writing menggunakan raw guided/plain dengan identity mapping; quiz menggunakan authoritative Q_HINT/Q_ANSWER yang diterjemahkan menjadi hint/answer serta resource-bound condition. Source admission yang sama memproses kedua profil. Hasil condition table pada store lengkap adalah 15 received, 5 core ADMIT, 8 REJECT, 2 QUARANTINE, 5 joined dan 4 physical-qualified per kondisi pada Original60. Full64 mempunyai 16 received, 6 ADMIT, 8 REJECT, 2 QUARANTINE, 4 joined dan 3 physical-qualified per kondisi.

## Empat counterexample D2 tetap terlihat

Semua store variant mempertahankan empat forged-observer cases pada primary joined table jika join-nya unik. Mereka tetap **ADMIT pada kedua validator**, tetapi independent physical audit D2 menemukan actual inputs yang berbeda dari laporan observer. View physical-qualified menggunakan qualifier eksternal dari audit D2 dan mencatat keempat removal beserta alasan/denominator. Ini sensitivity filter downstream, bukan mitigasi CPC atau bukti actual-use baru.

Semua original 32 REJECT D2 terjadi setelah response mock dipublikasikan. D3 menunjukkan exclusion dari analisis, bukan pencegahan delivery. Prompt/generation adalah measured subset; enam komponen lain declared. Receiver/observer tetap local instrumented single-process dengan public SYNTHETIC_ONLY role keys. Tidak ada real AI/provider, live LTI, learner, trusted hardware, kernel/power-loss qualification atau production security.

## Kegagalan V1 dan lineage perbaikan

Eksekusi pertama V1 gagal: pembanding mengembalikan 64 ERROR_CONFIG karena loop positional scalar fields memasukkan conditions list ke pemeriksaan identifier. CPC pada run itu tetap 24/32/8. Ini bug implementasi pembanding, bukan hasil yang boleh dipakai sebagai superiority CPC. Preflight R1 source review juga melewatkannya.

Seluruh V1 source, freeze, oracle, preflight dan raw failed run dipertahankan, termasuk byte copy lengkap dalam evidence/prior_failed_D3_V1. V2 comparator 1.0.1 memakai daftar scalar field eksplisit; mechanical config checks independen menerima dua profil dan menolak kontrol tipe salah sebelum freeze baru. Ini **repair 1 setelah observasi**, bukan prospective original-run success atau dataset baru. Oracle, core, raw input, outcome fixtures dan adapter analitik tetap identik. Freeze V2 memuat 1.847 files sebelum eksekusi; raw hasil awal V2 dibekukan sebagai 169 files sebelum audit akhir.

Verifier terpisah merekonstruksi 472 record/proof seals, 52 scalar fixtures, seluruh composite/cardinality, joined/exclusion/external ledgers, metrics, mean dan CSV pada kedua implementasi menggunakan Python stdlib sendiri, tanpa mengimpor validator, adapter atau oracle derivation helper. Satu workspace bersih menyalin tepat 1.847 frozen files + manifest, lalu menjalankan frozen runner satu kali. Audit hasil replay lulus; 168 artefak deterministik byte-identik dengan run V2 awal. Hanya RUN_BINDING mempunyai nama run/UTC analisis baru. Ini analisis ulang data historis yang sama, bukan observasi actual-use baru. Semua 45.786 berkas historis, 1.847 frozen files, 169 hasil awal, 44 core/spec/schema, 837 salinan input D2 dan 927 salinan kegagalan V1 terverifikasi utuh sebelum/sesudah replay. Review ini adalah proses Codex independen, bukan Pro/Claude/human editorial gate.

## Kontribusi residual yang benar-benar ditunjukkan

Hasil ini mendukung nilai guna terbatas sebagai reference workflow: profil identity/translation yang bisa dipakai melalui konfigurasi, signed-evidence admission dengan rule-addressed refusal ledger, whitelist attribution export, serta outcome join yang menjaga cardinality dan denominator hingga condition table. README/commands dan raw output membuat jalur itu bisa diperiksa dan dipakai ulang secara lokal. Pembanding setara juga dapat menerapkan semantics ini.

Belum ada pengukuran waktu setup operator, penghematan human effort, usability, institutional adoption, learning benefit atau kontribusi ilmiah yang diputuskan reviewer. D3 menutup tugas teknis yang direncanakan; signifikansi residual untuk JLA masih perlu adjudikasi Pro dan red team bersama bukti lengkap. Access/reuse licensing dan public release juga belum diputuskan. Tidak ada perubahan naskah atau klaim otomatis submission-ready.

## Berkas utama dan reproduksi

- protocol/D3_PROTOCOL.md dan protocol/CLAIM_BOUNDARIES.md: rencana, gate dan allowed/bounded/forbidden claims.
- oracle/D3_EXPECTED.json: expected counts, per-input classifications, external ledger counts, condition tables dan scalar sums/means, diturunkan independen sebelum D3.
- runs/initial_d3_v2/PAIRED_DECISIONS.jsonl: keputusan mentah kedua implementations.
- runs/initial_d3_v2/analytics/: dua implementations × enam stores × dua cohorts; joined rows, exclusion/input/external ledgers, metrics dan CSV condition tables.
- provenance/REPAIR_LEDGER.json dan evidence/prior_failed_D3_V1/: kegagalan serta satu repair terdokumentasi.
- review/: preflight dan audit/reproduksi teknis independen; bukan Pro/Claude/human editorial review.

Dari root paket yang diekstrak: `PYTHONDONTWRITEBYTECODE=1 python3 execution/run_d3.py --run new_d3_replay`. Python>=3.11 stdlib; run aktual menggunakan 3.12.14. Historical replay memakai waktu validasi D2 asal, tidak membuat timestamp observasi baru atau menghindari expiry context untuk live admission. New actual-use trials tetap memerlukan legitimate new context/version. API berbayar dan provider calls baru: **0**. Naskah: **NOT_REVISED**.

# CPC 2.0.1 D3 technical packet V2

This new packet preserves the previous D1/D2 releases and manuscript. It evaluates independent full-information admission and a complete synthetic outcome-attribution task. It uses archived D2 AI-mock observations unchanged; there are no new provider or paid API calls.

V1's first comparison failed because its independent comparator mistakenly treated the profile's conditions list as a scalar identifier. V1 source, preflight, freeze and 64-row failed run remain unchanged. V2 repairs only that comparator configuration typing defect, uses the identical oracle/inputs/CPC core/analytical adapter, and retains the original failure in its evidence annex. This is a documented technical repair after observation, not a new confirmatory population or outcome-directed oracle change.

## Reproduce after the packet has been frozen

From the extracted package root, use Python 3.11 or newer with its standard library:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 execution/run_d3.py --run new_d3_replay
```

The runner refuses an existing run directory and verifies frozen source/input hashes before importing implementations. It analyzes the recorded original validation instant of each archived chain. This does not create new actual-use observations or evade context expiry for live admission. Historical data analysis remains reproducible after the original D2 contexts expire; fresh runtime trials would require new legitimate contexts.

1. `inputs/COMPARISON_INPUTS.json` selects 60 original D2 chains and four exact-chain reingestions with distinct operator input_refs. Profiles and synthetic role keys are separately supplied.
2. `implementation/src/cpc2/` is the unchanged CPC core source 2.0.2. `comparator/independent_rules.py` is a separately authored full-information Python rules suite. Admission predicates in the comparator are Python, not SQL. Their shared normative specification is disclosed.
3. Both implementations receive exactly the same raw chain, profile, keys and historical validation_time. Physical audit/fault labels are not admission inputs. Paired raw decisions and admitted metadata are written before analysis.
4. `analytics/data/SCENARIOS.json` defines six external store variants. Synthetic values derive only from the governed composite key. `analytics/adapter.py` uses SQLite exact composite joins with uniqueness required on both sides. It is shared downstream analysis code; independent numerical/accounting verification is separate.
5. `runs/<name>/analytics/<scenario>/<implementation>/` contains complete analysis JSON, per-input and per-external-row ledgers, synthetic joined rows and condition tables for the explicit full64 and original60 cohorts. Excluded chains never carry scalar values in the refusal ledger.
6. The primary offline table preserves four D2 forged-observer admissions. The separately labeled physical-audit-qualified sensitivity view supplies explicit removals and denominators. It does not repair CPC's offline trust boundary.

Profile adaptation already present in the frozen input configurations is meaningful: writing uses authoritative guided/plain identity mapping; quiz maps raw Q_HINT/Q_ANSWER to hint/answer and resource-bound conditions. The same two implementations and analytical adapter process both without profile-name branches in admission. This is a demonstrated configuration path, not a timed onboarding or usability result.

See `protocol/D3_PROTOCOL.md`, `protocol/CLAIM_BOUNDARIES.md`, `oracle/D3_EXPECTED.json`, the source-readiness/preflight receipts and, after execution, `D3_REPORT.md`. Raw failures, if any, must remain in their original run/version. Hash/checkpoint PASS only proves bookkeeping consistency; it is not scientific novelty, effectiveness, production qualification or JLA submission readiness.

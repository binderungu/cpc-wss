"""Strict opaque composite join over offline admitted CPC metadata and external scalars.

No CPC admission logic is implemented here. SQL counts physical rows, including
identical duplicates. Physical qualification is a separate archived sensitivity view.
"""
import json
import math
from pathlib import Path
import sqlite3

FIELDS = ('experiment_id', 'experiment_version', 'unit_token', 'exposure_record_id',
          'exposure_digest', 'outcome_key', 'purpose')

def key(record):
    vals = tuple(record.get(f) for f in FIELDS)
    if any(not isinstance(v,str) or not v for v in vals):
        raise ValueError('Seven nonempty governed composite strings required')
    return vals

def scalar_valid(value):
    # Exact tagged JSON transport for the prospective NaN fixture. This does not
    # coerce strings or bools; its decoded value fails the finite-scalar contract.
    if type(value) is dict and value == {'nonfinite':'NaN'}:
        value = float('nan')
    return type(value) in (int,float) and 0 <= value <= 100 and math.isfinite(value)

def _decisions(results):
    return [r['decision'] if 'decision' in r else r for r in results]

def _audit_map(physical_audit):
    if isinstance(physical_audit,dict):
        return physical_audit
    mapping = {r['case_id']:r for r in physical_audit}
    if len(mapping) != len(physical_audit):
        raise ValueError('Duplicate physical-audit case_id')
    return mapping

def _cohort(refs, decisions, external_rows, metadata, physical):
    db = sqlite3.connect(':memory:')
    columns = ','.join(f+' TEXT NOT NULL COLLATE BINARY' for f in FIELDS)
    db.execute('CREATE TABLE admissions (input_ref TEXT NOT NULL, '+columns+')')
    db.execute('CREATE TABLE external (ordinal INTEGER NOT NULL, '+columns+')')
    valid_keys, invalid_keys = {}, {}
    for ordinal,row in enumerate(external_rows):
        try:
            composite = key(row)
        except ValueError as exc:
            invalid_keys[ordinal] = str(exc)
            continue
        valid_keys[ordinal] = composite
        db.execute('INSERT INTO external VALUES ('+','.join('?' for _ in range(8))+')',(ordinal,*composite))
    for ref in refs:
        decision = decisions[ref]
        if decision['disposition'] == 'ADMIT':
            admitted = decision.get('admitted_record')
            if not isinstance(admitted,dict) or admitted.get('input_ref') != ref:
                raise ValueError('ADMIT must carry admitted_record with exact input_ref')
            db.execute('INSERT INTO admissions VALUES ('+','.join('?' for _ in range(8))+')',(ref,*key(admitted)))
        elif decision['disposition'] not in ('REJECT','QUARANTINE'):
            raise ValueError('Unknown core disposition')
        elif decision.get('admitted_record') is not None:
            raise ValueError('Core refusal must have null admitted_record')
    clause = ' AND '.join(f+'=?' for f in FIELDS)
    accounting, joined, excluded = [], [], []
    sensitivity_excluded, sensitivity = [], []
    for ref in refs:
        decision, meta = decisions[ref], metadata[ref]
        result = {'input_ref':ref,'case_id':meta['case_id'],
                  'core_disposition':decision['disposition'],
                  'profile_name':meta['profile_name'],
                  'planned_condition':meta['condition'],
                  'archived_physical_audit_ref':meta['physical_audit_ref']}
        if decision['disposition'] != 'ADMIT':
            result.update(status='EXCLUDED', reason='CORE_'+decision['disposition'],
                          reasons=['CORE_'+decision['disposition']],
                          diagnostics=decision.get('diagnostics',[]),
                          admission_cardinality=None, external_cardinality=None)
            # Deliberately never inspect the raw rejected outcome or external scalar.
        else:
            admitted = decision['admitted_record']
            composite = key(admitted)
            acount = db.execute('SELECT COUNT(*) FROM admissions WHERE '+clause,composite).fetchone()[0]
            matches = [r[0] for r in db.execute('SELECT ordinal FROM external WHERE '+clause,composite)]
            result.update(admission_cardinality=acount,external_cardinality=len(matches),
                          attributed_condition=admitted['attributed_condition'])
            reasons = []
            if acount != 1:
                reasons.append('ADMISSION_COMPOSITE_AMBIGUOUS')
            if not matches:
                reasons.append('EXTERNAL_MISSING')
            elif len(matches) != 1:
                reasons.append('EXTERNAL_COMPOSITE_AMBIGUOUS')
            if len(matches) == 1 and not scalar_valid(external_rows[matches[0]].get('scalar')):
                reasons.append('EXTERNAL_SCALAR_INVALID')
            if reasons:
                result.update(status='EXCLUDED',reason=';'.join(reasons),reasons=reasons)
            else:
                ordinal = matches[0]
                row = external_rows[ordinal]
                result.update(status='JOINED',reason=None,reasons=[])
                entry = dict(admitted, input_ref=ref, profile_name=meta['profile_name'],
                             external_row_ordinal=ordinal, external_row_id=row.get('row_id'),
                             scalar=row['scalar'])
                audit = physical.get(meta['physical_audit_ref'])
                qualified = isinstance(audit,dict) and audit.get('trusted_actual_admit_eligible') is True
                entry['archived_physical_qualified'] = qualified
                entry['physical_qualifier_basis'] = 'External archived D2 audit; not inferred CPC guarantee'
                joined.append(entry)
                if qualified:
                    sensitivity.append(dict(entry))
                else:
                    sensitivity_excluded.append({'input_ref':ref,'case_id':meta['case_id'],
                        'reason':'ARCHIVED_PHYSICAL_AUDIT_NOT_QUALIFIED',
                        'audit_ref':meta['physical_audit_ref'],
                        'physical_binding':audit.get('physical_binding') if audit else 'UNAVAILABLE',
                        'qualification_is_not_CPC_mitigation':True})
        accounting.append(result)
        if result['status'] == 'EXCLUDED':
            excluded.append(dict(result))
    ledger = []
    joined_ordinals = {r['external_row_ordinal'] for r in joined}
    for ordinal,row in enumerate(external_rows):
        rec = {'external_row_ordinal':ordinal,'external_row_id':row.get('row_id'),
               'scalar_valid':scalar_valid(row.get('scalar'))}
        if ordinal in invalid_keys:
            rec.update(status='INVALID_COMPOSITE',reason=invalid_keys[ordinal],
                       matching_admitted_input_refs=[],external_cardinality=None)
        else:
            composite = valid_keys[ordinal]
            matched_refs = [r[0] for r in db.execute('SELECT input_ref FROM admissions WHERE '+clause,composite)]
            ecount = db.execute('SELECT COUNT(*) FROM external WHERE '+clause,composite).fetchone()[0]
            rec.update(matching_admitted_input_refs=matched_refs, external_cardinality=ecount)
            if not matched_refs:
                rec.update(status='UNUSED_NO_ADMITTED_COMPOSITE',reason='No admitted metadata at this full composite')
            elif len(matched_refs) != 1 or ecount != 1:
                rec.update(status='AMBIGUOUS',reason='Admission or external cardinality differs from one')
            elif not rec['scalar_valid']:
                rec.update(status='INVALID_SCALAR',reason='Finite number excluding bool within inclusive [0,100] required')
            elif ordinal in joined_ordinals:
                rec.update(status='MATCHED',reason=None)
            else:
                raise AssertionError('Valid uniquely matching row unaccounted')
        ledger.append(rec)
    table = []
    groups = sorted({(metadata[r]['profile_name'], metadata[r]['condition']) for r in refs})
    for profile,condition in groups:
        received = [r for r in refs if (metadata[r]['profile_name'],metadata[r]['condition']) == (profile,condition)]
        admits = [r for r in received if decisions[r]['disposition'] == 'ADMIT']
        jrows = [r for r in joined if r['input_ref'] in received]
        prows = [r for r in sensitivity if r['input_ref'] in received]
        p_admits = [r for r in admits if physical.get(metadata[r]['physical_audit_ref'],{}).get('trusted_actual_admit_eligible') is True]
        table.append({'profile_name':profile,'planned_condition':condition,
                      'summary_condition_basis':'Frozen operator cohort labels; join uses no condition label',
                      'received':len(received),'core_admit':len(admits),
                      'core_reject':sum(decisions[r]['disposition']=='REJECT' for r in received),
                      'core_quarantine':sum(decisions[r]['disposition']=='QUARANTINE' for r in received),
                      'join_eligible':len(jrows),'physical_qualified_core_admit':len(p_admits),
                      'physical_qualified_join_eligible':len(prows),
                      'core_admit_pct_of_received':100*len(admits)/len(received),
                      'join_pct_of_core_admit':100*len(jrows)/len(admits) if admits else None,
                      'physical_qualified_pct_of_join_eligible':100*len(prows)/len(jrows) if jrows else None,
                      'synthetic_scalar_mean_primary':sum(r['scalar'] for r in jrows)/len(jrows) if jrows else None,
                      'synthetic_scalar_mean_physical_sensitivity':sum(r['scalar'] for r in prows)/len(prows) if prows else None})
    if len(accounting)!=len(refs) or len(joined)+len(excluded)!=len(refs):
        raise AssertionError('Input accounting failure')
    if len(ledger)!=len(external_rows):
        raise AssertionError('External row accounting failure')
    db.close()
    return {'received':len(refs),'core_admit':sum(decisions[r]['disposition']=='ADMIT' for r in refs),
            'core_reject':sum(decisions[r]['disposition']=='REJECT' for r in refs),
            'core_quarantine':sum(decisions[r]['disposition']=='QUARANTINE' for r in refs),
            'join_eligible':len(joined),'physical_qualified_join_eligible':len(sensitivity),
            'physical_qualified_core_admit':sum(decisions[r]['disposition']=='ADMIT' and
                physical.get(metadata[r]['physical_audit_ref'],{}).get('trusted_actual_admit_eligible') is True for r in refs),
            'per_ref':accounting,'joined_rows':joined,'exclusion_ledger':excluded,
            'external_row_ledger':ledger,'condition_table':table,
            'physical_qualified_sensitivity':{'basis':'Archived D2 physical audit, distinct from CPC admission',
                'primary_join_denominator':len(joined),'included':len(sensitivity),
                'rows':sensitivity,'exclusion_ledger':sensitivity_excluded},
            'claim_boundary':'Synthetic descriptive bookkeeping, no learning-effect or population inference'}

def analyze(results, external_rows, case_metadata, physical_audit):
    """All 64 decisions required; reject duplicate input refs; analyze explicit 64/60 scopes.

    Results: list of core decisions, or wrappers with decision field. External
    rows: list dictionaries with seven governed strings, row_id, scalar. Metadata:
    COMPARISON_INPUTS list. Physical audit: list or case_id mapping. Scalars are
    neither coerced nor imputed; the exact NaN transport tag decodes to invalid NaN.
    """
    decisions_list = _decisions(results)
    refs = [d['input_ref'] for d in decisions_list]
    if len(set(refs)) != len(refs):
        raise ValueError('DUPLICATE_INPUT_REF in results; distinct reingestions need distinct refs')
    metadata_refs = [r['input_ref'] for r in case_metadata]
    if len(set(metadata_refs)) != len(metadata_refs):
        raise ValueError('DUPLICATE_INPUT_REF in metadata')
    if set(refs) != set(metadata_refs):
        raise ValueError('Results must account for exactly every received metadata input_ref')
    config = json.loads((Path(__file__).parent/'data/SCENARIOS.json').read_text())
    if set(config['cohorts']['full64']) != set(refs):
        raise ValueError('Full64 scope differs from frozen cohort inventory')
    decisions = {d['input_ref']:d for d in decisions_list}
    metadata = {d['input_ref']:d for d in case_metadata}
    physical = _audit_map(physical_audit)
    cohorts = {name:_cohort(cohort_refs, decisions, external_rows, metadata, physical)
               for name,cohort_refs in config['cohorts'].items()}
    return {'adapter_version':'d3-opaque-sqlite-join-1.0.0','join_fields':list(FIELDS),
            'comparison_input_refs_received':len(refs),'external_rows_received':len(external_rows),
            'cohorts':cohorts,'original60_scope':'Prespecified original D2 inputs; separate analysis, not deduplicated full64',
            'cardinality_rule':'Both admission and external composite cardinality equal one',
            'duplicate_policy':'All received rows counted; never choose, average, erase, or impute duplicates'}

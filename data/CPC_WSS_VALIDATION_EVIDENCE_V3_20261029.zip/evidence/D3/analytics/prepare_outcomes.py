"""Materialize synthetic external scalars and prespecified cohorts; never admit or join."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FIELDS = ('experiment_id', 'experiment_version', 'unit_token', 'exposure_record_id',
          'exposure_digest', 'outcome_key', 'purpose')

def dump(path, value):
    with path.open('x', encoding='utf8') as f:
        json.dump(value, f, indent=2, sort_keys=True, allow_nan=False)
        f.write('\n')

def main():
    inputs = json.loads((ROOT/'inputs/COMPARISON_INPUTS.json').read_text())
    originals = [x for x in inputs if x['mode'] != 'duplicate_ingestion']
    if len(originals) != 60 or len(inputs) != 64:
        raise ValueError('Explicit cohort inventory must be original60/full64')
    rows, lineage, targets = [], [], []
    for item in originals:
        path = ROOT/item['raw_path']
        chain = json.loads(path.read_text())
        outcomes = [r for r in chain['records'] if r['record_type'] == 'outcome']
        if len(outcomes) > 1:
            raise ValueError('Source chain must contain at most one outcome record')
        if not outcomes:
            continue
        out = outcomes[0]
        key = {f: (out[f] if f in ('experiment_id','experiment_version','unit_token')
                   else out['payload'][f]) for f in FIELDS}
        canonical = json.dumps(key, sort_keys=True, separators=(',',':'), ensure_ascii=False).encode()
        digest = hashlib.sha256(canonical).hexdigest()
        row = dict(key, row_id='scalar:'+digest, scalar=int(digest,16)%101)
        rows.append(row)
        lineage.append({'row_id': row['row_id'], 'source_input_ref': item['input_ref'],
                        'source_raw_path': item['raw_path'],
                        'source_raw_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                        'source_outcome_record_id': out['record_id'],
                        'source_outcome_digest': out['integrity']['content_digest'],
                        'governed_composite_sha256': digest,
                        'generation': 'int(sha256(canonical governed composite),16) % 101'})
        if item['mode'] == 'approved_fallback':
            targets.append({'input_ref':item['input_ref'], 'case_id':item['case_id'],
                            'profile_name':item['profile_name'], 'condition':item['condition'],
                            'row_id':row['row_id']})
    if len(rows) != 52 or len(targets) != 4:
        raise ValueError('Expected 52 complete outcome records and four explicitly targeted fallbacks')
    by_id = {r['row_id']: r for r in rows}
    if len(by_id) != len(rows):
        raise ValueError('Source outcome identity unexpectedly repeated')
    target_ids = {t['row_id'] for t in targets}
    variants = {'complete':rows,
                'missing_unique': [r for r in rows if r['row_id'] not in target_ids]}
    variants['duplicate_conflicting'] = [dict(r) for r in rows]
    variants['duplicate_identical'] = [dict(r) for r in rows]
    variants['wrong_composite_orphans'] = [dict(r) for r in rows]
    variants['invalid_scalar'] = [dict(r) for r in rows]
    # JSON stores NaN as a tagged transport object; adapter decodes only this exact tag.
    invalid_transport = [{'nonfinite':'NaN'}, True, '50', 101]
    for i,t in enumerate(targets):
        source = by_id[t['row_id']]
        variants['duplicate_conflicting'].append(dict(source, row_id=source['row_id']+':conflict',
                                                        scalar=(source['scalar']+1)%101))
        variants['duplicate_identical'].append(dict(source, row_id=source['row_id']+':same'))
        bad = dict(source, row_id=source['row_id']+':wrong-composite')
        bad['unit_token'] += ':wrong-unit'
        bad['purpose'] += ':wrong-purpose'
        variants['wrong_composite_orphans'].append(bad)
        for r in variants['invalid_scalar']:
            if r['row_id'] == source['row_id']:
                r['scalar'] = invalid_transport[i]
    config = {'schema':'d3-external-scalar-scenarios-v1', 'join_fields':list(FIELDS),
              'scalar_contract':{'type':'finite numeric scalar excluding bool', 'minimum':0,
                                 'maximum':100,'unit':'synthetic score, no learning meaning',
                                 'transport_nan':{'nonfinite':'NaN'}},
              'generator':'sha256(canonical governed composite) modulo 101; no decision, condition parsing, physical-audit flag, or counterexample flag inputs',
              'selector':{'mode':'approved_fallback', 'reason':'Unique honest nonbaseline outcome per condition; baseline duplicates must remain independently tested', 'targets':targets},
              'cohorts':{'full64':[x['input_ref'] for x in inputs],
                         'original60':[x['input_ref'] for x in originals]},
              'scenarios':{name:{'path':'analytics/data/'+name+'.json','external_rows':len(value)} for name,value in variants.items()},
              'invalid_scalar_assignments':[{**t,'invalid_kind':k} for t,k in zip(targets,['NaN','bool','string','out_of_range'])],
              'cardinality_policy':'Both admission-side and external-store-side composite cardinality must equal one; duplicates of identical values remain ambiguous',
              'physical_sensitivity_policy':'Separate archived D2 physical-audit qualifier, never CPC mitigation; primary offline cohort preserves four forged observers'}
    data = ROOT/'analytics/data'
    for name, value in variants.items():
        dump(data/(name+'.json'), value)
    dump(data/'OUTCOME_LINEAGE.json',lineage)
    dump(data/'SCENARIOS.json',config)

if __name__ == '__main__':
    main()

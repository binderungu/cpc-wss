# Independent full-information rules comparator 1.0.0

This is an independently authored **Python rules suite equivalent in information access** to the CPC admission interface for the bounded D3 catalogue. It is not a SQL implementation, and it does not claim conformance equivalence across the entire CPC domain or the exhaustive D1 corpus. All validation predicates here execute in Python. No portions execute in SQLite. Standard-library SHA-256, HMAC, UTF-8 JSON and aware datetime operations are helpers for the rule predicates.

## Interface and evidence parity

```python
from independent_rules import validate_raw
result = validate_raw(raw_bytes, operator_profile, synthetic_key_registry,
                      recorded_validation_time, input_ref='D3-00000')
```

`raw_bytes` contains the entire archived chain, including launch, commitment, usage and release proof bodies/integrities. Both comparators receive the same external frozen profile/key registry and the historical D2 validation instant. `input_ref` is operator accounting; no decision depends on a scenario name, nominal profile label, manifest mode, expected result, saved CPC decision or physical audit. This module neither loads the comparison manifest nor accesses physical captures. It cannot recover independent physical truth hidden by a consistently lying authorized observer. The four such D2 counterexamples must remain offline admissions when their full signed chain satisfies the contract; they are not claimed to be detected by this comparator.

The implementation does not import, inspect or copy the CPC validator, wrapper, crypto helpers, exporter, historical validator, saved decision ledgers, D2 oracle outcomes, or PHYSICAL_AUDIT. Source derivation used the normative contract 2.0.1, FIELD_REQUIREMENTS.json, RULE_DECISION_MATRIX.csv, supplied JSON wire/profile/export schemas, external two-profile registries, synthetic key registries and one raw complete chain to establish concrete nesting/representation. Locator fields in COMPARISON_INPUTS.json establish only the runtime inputs. Expected-disposition and mode fields are ignored. Diagnostic codes/paths are independently written implementation details and need not match CPC; rule IDs/dispositions and final admission/export outcomes can be compared prospectively.

## Implemented rule inventory

- C01: external profile required fields/frozen identities, strict input-limit configuration, approved condition/resource/namespace domains, role/key registry, distinct commitment/observer key IDs and frozen artifact-vector policies; historical validation timestamp parsing.
- I01: raw-byte budget; strict UTF-8 JSON; duplicate keys, floats/nonfinite values and invalid root rejection; root-zero full JSON depth including key edges, scalar leaves and empty containers; record-count bounds and nonobject records.
- I02/I03: field-catalogue required strings/containers/booleans/nonnegative integer sequences; closed record/proof/payload/entry shapes; integrity encodings; timestamps; registered signed metadata extensions; root and record types; exact component and measurement sets.
- R01: root/record/proof external identity/audience/deployment/context/issuer policies; canonical signed-content digest; native HMAC verification using digest string; key-role policy. Signature-invalid dependencies are not trusted for cross-record predicates.
- R02/R03/R04: approved assignment resource/policy/scope, dynamic condition domains, resolver policy; profile-derived authoritative/consistency raw namespace translations excluding descriptive labels; launch-authority proof and nonce/resource/assignment/digest/namespace relationships.
- R05: exact registry vector/evidence modes; measured-required prompt/generation; usage map component-ID/version/digest relationships; invocation, resolution and commitment/exposure bindings. This validates observer assertions, not external actual use.
- R06: same-condition authorized fallback permission/bundle; freshness; consent state/eligibility/policy/reference/purpose; consent before observed use; parsed privacy-denylist field detection.
- R07: all available predecessor/unit/outcome links, full signed commitment-object release digest, release boundary/clock, envelope order, launch bounds, use/commit/release/final exposure/outcome UTC order and local sequence order.
- R08/Q01/Q02: chain-local duplicate record IDs/nonces/proof IDs, record cardinality, missing whole classes, ambiguous outcome cardinality, and REJECT > ERROR_INPUT > QUARANTINE > ADMIT precedence.
- Admission: exact normalized metadata whitelist with null admitted_record on every refusal; no learner text, response content or outcome values enter export.

This inventory describes implemented predicates, not measured exhaustive robustness. The evaluated claim is agreement on the separately frozen **60 archived D2 chains plus four exact-chain reingestions**, including complete honest chains, same-condition fallback, after-load path changes, changed/substituted inputs, stale usage, declared-only policy, premature release, incomplete A/R-only I/O-failure evidence and authorized-observer counterexamples. Reingestions are independent input_ref rows: global replay/outcome uniqueness is out of chain scope and must be handled by D3 analysis joins/denominators.

## Setup and practical limits

No install or network step is needed: put `comparator/` on Python's import path, retain `implementation/spec/FIELD_REQUIREMENTS.json`, load the four declared interface inputs, and invoke `validate_raw`. Python stdlib only; fixture keys are public SYNTHETIC_ONLY strings. This is a concrete integration procedure, not a measured engineer-onboarding or usability result. The full D3 runner and analytical join task are separate artifacts owned outside this module.

Bounded agreement does not establish real LTI transport, adversarial-observer honesty, secure custody, durable hardware persistence, global exactly-once delivery, streaming/network delivery, learning effects, broad security qualification or submission readiness. No new mock-provider trial or paid API call is needed for this historical-time D3 comparison.

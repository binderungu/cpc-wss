"""Frozen D3 historical-data comparison and synthetic join; no provider calls."""
from __future__ import annotations
import argparse
import collections
import csv
import datetime
import hashlib
import json
import sys
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + '\n')

def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]

def verify_freeze():
    freeze = json.loads((ROOT/'provenance/D3_EXECUTION_FREEZE.json').read_text())
    errors = [name for name,digest in freeze['files'].items()
              if not (ROOT/name).is_file() or sha(ROOT/name) != digest]
    if errors:
        raise RuntimeError('Frozen source/input drift: ' + repr(errors[:5]))
    return freeze

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--run',required=True)
    args=parser.parse_args()
    if not args.run or Path(args.run).name != args.run or args.run in {'.','..'}:
        raise ValueError('A new single-component run name is required')
    verify_freeze()
    sys.path[:0] = [str(ROOT/'implementation/src'),str(ROOT)]
    from cpc2.api import validate_raw as core_validate
    from cpc2.export import export_results
    from comparator.independent_rules import validate_raw as alternative_validate
    from analytics.adapter import analyze
    manifest=json.loads((ROOT/'inputs/COMPARISON_INPUTS.json').read_text())
    oracle=json.loads((ROOT/'oracle/D3_EXPECTED.json').read_text())
    expected_by={e['input_ref']:e for e in oracle['comparison']['case_expectations']}
    if set(expected_by)!={s['input_ref'] for s in manifest}:
        raise RuntimeError('Oracle/input-ref inventory differs')
    for spec in manifest:
        if spec['expected_disposition']!=expected_by[spec['input_ref']]['expected_disposition']:
            raise RuntimeError('Oracle/manifest expected disposition differs')
    run=ROOT/'runs'/args.run
    run.mkdir(parents=True,exist_ok=False)
    save(run/'RUN_BINDING.json',{'run':args.run,'observed_run_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'freeze_sha256':sha(ROOT/'provenance/D3_EXECUTION_FREEZE.json'),'python':sys.version,
         'evidence_class':'Historical D2 mock chain replay with recorded original validation times, new synthetic D3 analysis',
         'core_version':'2.0.2','contract_version':'2.0.1','provider_calls':0,'paid_API_calls':0,'manuscript':'NOT_REVISED'})
    paired=[];decisions={'cpc':[],'independent':[]};exceptions=[];failures=[]
    for spec in manifest:
        raw=(ROOT/spec['raw_path']).read_bytes()
        profile=json.loads((ROOT/spec['profile_path']).read_text())
        keys=json.loads((ROOT/spec['keys_path']).read_text())
        pair={'input_ref':spec['input_ref'],'case_id':spec['case_id'],'raw_sha256':hashlib.sha256(raw).hexdigest(),
              'profile_sha256':sha(ROOT/spec['profile_path']),'keys_sha256':sha(ROOT/spec['keys_path']),
              'validation_time':spec['validation_time']}
        for name,validate in [('cpc',core_validate),('independent',alternative_validate)]:
            try:
                result=validate(raw,profile,keys,spec['validation_time'],input_ref=spec['input_ref'])
                pair[name]=result;decisions[name].append(result)
                if result['input_ref']!=spec['input_ref']:
                    failures.append({'input_ref':spec['input_ref'],'implementation':name,'reason':'input_ref mismatch'})
                if result['disposition']!=spec['expected_disposition']:
                    failures.append({'input_ref':spec['input_ref'],'implementation':name,'reason':'oracle disposition mismatch',
                                     'expected':spec['expected_disposition'],'actual':result['disposition']})
                for expected in spec['required_diagnostics']:
                    if not any(d['rule_id']==expected['rule_id'] and d['disposition']==expected['disposition'] for d in result['diagnostics']):
                        failures.append({'input_ref':spec['input_ref'],'implementation':name,'reason':'missing targeted diagnostic','expected':expected})
                if any(d['rule_id']=='R01' and d['disposition']=='REJECT' for d in result['diagnostics']):
                    failures.append({'input_ref':spec['input_ref'],'implementation':name,'reason':'unexpected integrity/context masking on validly sealed D2 inputs'})
                if result['disposition']!='ADMIT' and result.get('admitted_record') is not None:
                    failures.append({'input_ref':spec['input_ref'],'implementation':name,'reason':'refusal carried admitted export'})
            except Exception as exc:
                error={'input_ref':spec['input_ref'],'implementation':name,'exception':type(exc).__name__,
                       'message':str(exc),'traceback':traceback.format_exc()}
                exceptions.append(error);pair[name]={'exception':error}
        if all('disposition' in pair.get(n,{}) for n in decisions):
            pair['same_disposition']=pair['cpc']['disposition']==pair['independent']['disposition']
            pair['same_admitted_export']=pair['cpc'].get('admitted_record')==pair['independent'].get('admitted_record')
            if not pair['same_disposition'] or not pair['same_admitted_export']:
                failures.append({'input_ref':spec['input_ref'],'reason':'paired decision/export difference'})
        paired.append(pair)
    (run/'PAIRED_DECISIONS.jsonl').write_text(''.join(json.dumps(p,sort_keys=True,ensure_ascii=False)+'\n' for p in paired))
    save(run/'EXCEPTIONS.json',exceptions)
    for name in decisions:
        (run/(name.upper()+'_DECISIONS.jsonl')).write_text(''.join(json.dumps(p,sort_keys=True)+'\n' for p in decisions[name]))
    if len(decisions['cpc'])==len(manifest):
        export_results(decisions['cpc'],run/'cpc_metadata_export')
    summary={'status':'FAIL_D3' if failures or exceptions else 'COMPARISON_PASS_ANALYTICS_PENDING',
             'received':len(manifest),'paired_rows':len(paired),'counts':{k:dict(collections.Counter(p['disposition'] for p in v)) for k,v in decisions.items()},
             'decision_differences':sum(p.get('same_disposition') is False for p in paired),
             'admitted_export_differences':sum(p.get('same_admitted_export') is False for p in paired),
             'exceptions':len(exceptions),'failures':len(failures),'paid_API_calls':0,'manuscript':'NOT_REVISED'}
    for name,counts in summary['counts'].items():
        if counts!=oracle['comparison']['expected_counts']:
            failures.append({'implementation':name,'reason':'aggregate decision count differs from oracle'})
    summary['failures']=len(failures)
    if failures:summary['status']='FAIL_D3'
    save(run/'FAILURES.json',failures)
    save(run/'SUMMARY.json',summary)
    if exceptions or failures:
        print(json.dumps(summary));return 1
    return run_analytics(run,manifest,decisions,analyze,oracle,summary)

def run_analytics(run,manifest,decisions,analyze,oracle,summary):
    from analytics.adapter import scalar_valid
    config=json.loads((ROOT/'analytics/data/SCENARIOS.json').read_text())
    physical=rows(ROOT/'inputs/PHYSICAL_AUDIT.jsonl')
    forged={r['case_id'] for r in json.loads((ROOT/'oracle/D2_SCENARIOS_UNCHANGED.json').read_text())['cases']
            if r['claim_class']=='trust_boundary_counterexample'}
    checks=[];analyses={};failures=[]
    for scenario,setting in config['scenarios'].items():
        store=json.loads((ROOT/setting['path']).read_text())
        analyses[scenario]={}
        for implementation,result in decisions.items():
            output=analyze(result,store,manifest,physical)
            analyses[scenario][implementation]=output
            directory=run/'analytics'/scenario/implementation
            directory.mkdir(parents=True,exist_ok=False)
            save(directory/'ANALYSIS.json',output)
            for cohort,view in output['cohorts'].items():
                expected=oracle['analytical'][scenario][cohort]
                metrics=analysis_metrics(view,len(store),forged)
                issues=[]
                if metrics!=expected['metrics']:issues.append('METRICS_DIFFER')
                classification={r['input_ref']:('JOINED' if r['status']=='JOINED' else r['reason']) for r in view['per_ref']}
                if classification!=expected['expected_input_classifications']:issues.append('INPUT_CLASSIFICATIONS_DIFFER')
                ledger_counts=dict(collections.Counter(r['status'] for r in view['external_row_ledger']))
                if ledger_counts!=expected['expected_external_ledger_counts']:issues.append('EXTERNAL_LEDGER_COUNTS_DIFFER')
                projected=[{key:r.get(key) for key in exp} for r,exp in zip(view['condition_table'],expected['condition_table'])]
                if len(view['condition_table'])!=len(expected['condition_table']) or projected!=expected['condition_table']:
                    issues.append('CONDITION_TABLE_DIFFER')
                refs=[r['input_ref'] for r in view['per_ref']]
                if len(set(refs))!=len(refs) or len(refs)!=view['received']:issues.append('INPUT_ROW_LOSS_OR_DUPLICATION')
                ordinals=[r['external_row_ordinal'] for r in view['external_row_ledger']]
                if sorted(ordinals)!=list(range(len(store))):issues.append('EXTERNAL_ROW_LOSS_OR_DUPLICATION')
                if len(view['joined_rows'])+len(view['exclusion_ledger'])!=view['received']:issues.append('PARTITION_ACCOUNTING')
                if any('scalar' in r for r in view['exclusion_ledger']):issues.append('SCALAR_IN_REFUSAL_LEDGER')
                checks.append({'scenario':scenario,'implementation':implementation,'cohort':cohort,
                               'passed':not issues,'issues':issues,'metrics':metrics})
                for issue in issues:failures.append({'scenario':scenario,'implementation':implementation,'cohort':cohort,'reason':issue})
                save(directory/(cohort+'_METRICS.json'),metrics)
                for name in ['per_ref','joined_rows','exclusion_ledger','external_row_ledger']:
                    (directory/(cohort+'_'+name+'.jsonl')).write_text(''.join(json.dumps(r,sort_keys=True,allow_nan=False)+'\n' for r in view[name]))
                with (directory/(cohort+'_condition_table.csv')).open('w',newline='') as f:
                    writer=csv.DictWriter(f,fieldnames=list(view['condition_table'][0]))
                    writer.writeheader();writer.writerows(view['condition_table'])
        if semantic_analysis(analyses[scenario]['cpc'])!=semantic_analysis(analyses[scenario]['independent']):
            failures.append({'scenario':scenario,'reason':'ANALYTICAL_SEMANTIC_DIFFERENCE'})
    # Prespecified mechanical guards; no scenario/source repair based on results.
    guards=[]
    for name,value in [('NaN',float('nan')),('bool',True),('string','50'),('out_of_range',101)]:
        guards.append({'guard':'invalid_scalar_'+name,'passed':scalar_valid(value) is False})
    base_store=json.loads((ROOT/config['scenarios']['complete']['path']).read_text())
    for name,bad in [('duplicate_input_ref',decisions['cpc']+[decisions['cpc'][0]]),('missing_decision',decisions['cpc'][1:])]:
        try:analyze(bad,base_store,manifest,physical)
        except ValueError:guards.append({'guard':name,'passed':True})
        else:guards.append({'guard':name,'passed':False})
    for g in guards:
        if not g['passed']:failures.append({'reason':'MECHANICAL_GUARD_FAILED','guard':g['guard']})
    save(run/'ANALYTICAL_CHECKS.json',checks)
    save(run/'MECHANICAL_GUARDS.json',guards)
    save(run/'ANALYTICAL_FAILURES.json',failures)
    summary.update(status='FAIL_D3' if failures else 'PASS_BOUNDED_SYNTHETIC_D3',
         analytical_checks=len(checks),analytical_checks_passed=sum(c['passed'] for c in checks),
         analytical_failures=len(failures),mechanical_guards_passed=sum(g['passed'] for g in guards),
         trust_boundary_counterexamples=sorted(forged),
         comparator='Independent Python equivalent rules suite; analytics uses shared SQLite join adapter',
         boundary='Finite archived D2 catalogue and synthetic outcome task; no detection superiority, learning effect, production or JLA-ready claim')
    save(run/'SUMMARY.json',summary)
    print(json.dumps(summary,sort_keys=True))
    return 1 if failures else 0

def analysis_metrics(view,store_count,forged):
    reason_rows=view['exclusion_ledger'];joined=view['joined_rows'];physical=view['physical_qualified_sensitivity']
    primary_sum=sum(r['scalar'] for r in joined);physical_sum=sum(r['scalar'] for r in physical['rows'])
    return {'received':view['received'],'core_admitted':view['core_admit'],
            'core_rejected':view['core_reject'],'core_quarantined':view['core_quarantine'],
            'core_refused':view['core_reject']+view['core_quarantine'],'joined':view['join_eligible'],
            'physical_qualified':view['physical_qualified_join_eligible'],
            'physical_qualified_core_admitted':view['physical_qualified_core_admit'],
            'external_rows_received':store_count,
            'admission_duplicate_exclusions':sum('ADMISSION_COMPOSITE_AMBIGUOUS' in r['reasons'] for r in reason_rows),
            'missing_external_exclusions':sum('EXTERNAL_MISSING' in r['reasons'] for r in reason_rows),
            'ambiguous_external_exclusions':sum('EXTERNAL_COMPOSITE_AMBIGUOUS' in r['reasons'] for r in reason_rows),
            'invalid_scalar_exclusions':sum('EXTERNAL_SCALAR_INVALID' in r['reasons'] for r in reason_rows),
            'forged_in_primary':sum(r['case_id'] in forged for r in joined),
            'forged_excluded_physical':sum(r['case_id'] in forged for r in physical['exclusion_ledger']),
            'primary_scalar_sum':primary_sum,'physical_scalar_sum':physical_sum,
            'synthetic_scalar_mean_primary':primary_sum/len(joined) if joined else None,
            'synthetic_scalar_mean_physical_sensitivity':physical_sum/len(physical['rows']) if physical['rows'] else None}

def semantic_analysis(output):
    # Different implementation-addressed diagnostics remain in raw ledgers.
    # Their wording is not the analytical equivalence target.
    value=json.loads(json.dumps(output))
    for view in value['cohorts'].values():
        for name in ['per_ref','exclusion_ledger']:
            for row in view[name]:row.pop('diagnostics',None)
    return value

if __name__=='__main__':
    raise SystemExit(main())

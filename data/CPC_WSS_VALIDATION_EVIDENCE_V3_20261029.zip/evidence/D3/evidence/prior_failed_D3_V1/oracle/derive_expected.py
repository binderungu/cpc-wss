import json,hashlib,math
from pathlib import Path
from collections import Counter,defaultdict
R=Path(__file__).resolve().parents[1]
load=lambda p:json.loads((R/p).read_text())
manifest=load('inputs/COMPARISON_INPUTS.json'); hist={x['case_id']:x for x in load('oracle/D2_SCENARIOS_UNCHANGED.json')['cases']}
cfg=load('analytics/data/SCENARIOS.json'); honest=set(load('inputs/HONEST_ACTUAL_USE_ELIGIBLE_IDS.json'))
fields=('experiment_id','experiment_version','unit_token','exposure_record_id','exposure_digest','outcome_key','purpose')
meta={x['input_ref']:x for x in manifest}; keys={}; scalar_by_key={}
for m in manifest:
    assert m['expected_disposition']==hist[m['case_id']]['expected_admission']
    assert m['required_diagnostics']==hist[m['case_id']]['required_diagnostics']
    records=load(m['raw_path'])['records']; outs=[x for x in records if x['record_type']=='outcome']
    if m['expected_disposition']=='ADMIT':
        assert len(outs)==1
        o=outs[0]; keys[m['input_ref']]=tuple(o[f] if f in ('experiment_id','experiment_version','unit_token') else o['payload'][f] for f in fields)
for row in load('analytics/data/complete.json'):
    k=tuple(row[f] for f in fields)
    d=hashlib.sha256(json.dumps(dict(zip(fields,k)),sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
    assert row['row_id']=='scalar:'+d and row['scalar']==int(d,16)%101
    scalar_by_key[k]=row['scalar']
assert len(scalar_by_key)==52
expected={'oracle_version':'D3-PROSPECTIVE-ORACLE-1.0.0','design_status':'EXPECTED_BEFORE_D3_EXECUTION','method':'Independent direct composite-key multiset mathematics from raw metadata, unchanged historical D2 oracle, frozen scalar stores and explicit cohorts. No CPC, comparator, analyzer imports or calls; no D3 run read.','historical_development_expectations':'D2 labels are existing development expectations, not novel confirmatory outcomes; reingestion raw chains identical.','join_fields':list(fields),'comparison':{'expected_counts':dict(Counter(x['expected_disposition'] for x in manifest)),'case_expectations':[{k:x[k] for k in ('input_ref','expected_disposition','required_diagnostics')} for x in manifest]},'analytical':{}}
valid=lambda x:type(x) in (int,float) and math.isfinite(x) and 0<=x<=100
for scenario,spec in cfg['scenarios'].items():
    store=load(spec['path']); grouped=defaultdict(list)
    for ordinal,row in enumerate(store):grouped[tuple(row[f] for f in fields)].append((ordinal,row))
    scenarios={}
    for cohort,refs in cfg['cohorts'].items():
        admits=[r for r in refs if meta[r]['expected_disposition']=='ADMIT']; mult=Counter(keys[r] for r in admits)
        joined=[]; exclusions=Counter(); classifications={}
        for r in refs:
            d=meta[r]['expected_disposition']; reason=[]
            if d!='ADMIT':reason=['CORE_'+d]
            else:
                matches=grouped[keys[r]]
                if mult[keys[r]]!=1:reason.append('ADMISSION_COMPOSITE_AMBIGUOUS')
                if len(matches)==0:reason.append('EXTERNAL_MISSING')
                elif len(matches)!=1:reason.append('EXTERNAL_COMPOSITE_AMBIGUOUS')
                if len(matches)==1 and not valid(matches[0][1]['scalar']):reason.append('EXTERNAL_SCALAR_INVALID')
                if not reason:joined.append((r,matches[0][1]['scalar']))
            classifications[r]=';'.join(reason) if reason else 'JOINED'
            exclusions.update(reason)
        phy=[(r,v) for r,v in joined if meta[r]['case_id'] in honest]
        forged=[r for r,v in joined if hist[meta[r]['case_id']]['mode']=='forged_registry_only']
        metrics={'received':len(refs),'core_admitted':len(admits),'core_refused':len(refs)-len(admits),'core_rejected':sum(meta[r]['expected_disposition']=='REJECT' for r in refs),'core_quarantined':sum(meta[r]['expected_disposition']=='QUARANTINE' for r in refs),'joined':len(joined),'physical_qualified':len(phy),'physical_qualified_core_admitted':sum(meta[r]['case_id'] in honest for r in admits),'admission_duplicate_exclusions':exclusions['ADMISSION_COMPOSITE_AMBIGUOUS'],'missing_external_exclusions':exclusions['EXTERNAL_MISSING'],'ambiguous_external_exclusions':exclusions['EXTERNAL_COMPOSITE_AMBIGUOUS'],'invalid_scalar_exclusions':exclusions['EXTERNAL_SCALAR_INVALID'],'forged_in_primary':len(forged),'forged_excluded_physical':len(forged),'external_rows_received':len(store),'primary_scalar_sum':sum(v for r,v in joined),'physical_scalar_sum':sum(v for r,v in phy),'synthetic_scalar_mean_primary':sum(v for r,v in joined)/len(joined) if joined else None,'synthetic_scalar_mean_physical_sensitivity':sum(v for r,v in phy)/len(phy) if phy else None}
        table=[]
        for profile,condition in sorted({(meta[r]['profile_name'],meta[r]['condition']) for r in refs}):
            rr=[r for r in refs if (meta[r]['profile_name'],meta[r]['condition'])==(profile,condition)]; aa=[r for r in rr if r in admits]; jj=[(r,v) for r,v in joined if r in rr]; pp=[(r,v) for r,v in phy if r in rr]
            table.append({'profile_name':profile,'planned_condition':condition,'received':len(rr),'core_admit':len(aa),'core_reject':sum(meta[r]['expected_disposition']=='REJECT' for r in rr),'core_quarantine':sum(meta[r]['expected_disposition']=='QUARANTINE' for r in rr),'join_eligible':len(jj),'physical_qualified_core_admit':sum(meta[r]['case_id'] in honest for r in aa),'physical_qualified_join_eligible':len(pp),'core_admit_pct_of_received':100*len(aa)/len(rr),'join_pct_of_core_admit':100*len(jj)/len(aa) if aa else None,'physical_qualified_pct_of_join_eligible':100*len(pp)/len(jj) if jj else None,'synthetic_scalar_mean_primary':sum(v for r,v in jj)/len(jj) if jj else None,'synthetic_scalar_mean_physical_sensitivity':sum(v for r,v in pp)/len(pp) if pp else None})
        extern=Counter()
        for row in store:
            k=tuple(row[f] for f in fields); a=mult[k]; e=len(grouped[k])
            category='UNUSED_NO_ADMITTED_COMPOSITE' if a==0 else 'AMBIGUOUS' if a!=1 or e!=1 else 'INVALID_SCALAR' if not valid(row['scalar']) else 'MATCHED'
            extern[category]+=1
        scenarios[cohort]={'metrics':metrics,'condition_table':table,'expected_input_classifications':classifications,'expected_external_ledger_counts':dict(extern)}
    expected['analytical'][scenario]=scenarios
with (R/'oracle/D3_EXPECTED.json').open('x') as f:json.dump(expected,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
print(json.dumps({'comparison':expected['comparison']['expected_counts'],'scenarios':{s:{c:v['metrics'] for c,v in cs.items()} for s,cs in expected['analytical'].items()}},indent=2))

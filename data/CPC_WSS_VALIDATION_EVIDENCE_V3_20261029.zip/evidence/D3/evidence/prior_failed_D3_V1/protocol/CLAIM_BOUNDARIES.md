# D3 claim adjudication boundaries, set before execution

This packet addresses a bounded technical comparison and complete synthetic outcome-attribution workflow. Final evidence locations and observed results will be recorded separately after execution.

| Claim | Required evidence | Intended classification |
| --- | --- | --- |
| Same-input admission semantics on the 64 archived chain inputs | Independent comparator source; same raw/profile/keys/time hashes; paired decisions and oracle targets | BOUNDED to this finite catalogue; no full-domain equivalence |
| Existing CPC core/schema/spec preserved | Parent/copy byte checks and source binding | ALLOWED integrity observation; no scientific correctness implication |
| Concrete opaque-key outcome attribution with complete accounting | Synthetic external store, per-input and per-store-row ledger, condition table, cardinality fault controls | BOUNDED technical walkthrough; not learner study |
| Profile portability across identity and authoritative raw-condition translation | Same source processes writing guided/plain and quiz Q_HINT/Q_ANSWER→hint/answer via frozen profiles | BOUNDED demonstrated configuration reuse; not measured adoption or authoring effort |
| A reference workflow combines signed admission, refusal diagnostics, whitelist exports and join-safe analysis | Source/commands and raw end-to-end outputs, equal comparator access | BOUNDED artifact engineering usefulness; novelty/JLA significance remains for adjudication |
| Four forged-observer cases establish offline authentication does not prove actual use | Unchanged D2 raw inputs/physical audits plus both D3 implementations' admissions, explicit analytical sensitivity exclusions | ALLOWED negative evidence; never called CPC mitigation |
| Greater error detection than full-information SQL/equivalent rules | No prospective superiority hypothesis, population or diverse validated benchmark supplied | FORBIDDEN |
| Faster setup, lower human burden, usability, adoption, production performance | No independent timed user/operator study or valid benchmark supplied | FORBIDDEN |
| Real consent/ethics approval, learning effect, live LTI/full-stack measurement, production security | No corresponding field/production evidence supplied | FORBIDDEN |
| Submission readiness or guaranteed acceptance | No final manuscript or independent external editor/reviewer adjudication | FORBIDDEN |

Single-chain admission does not establish globally unique outcome keys. A separate cardinality-safe analytical adapter may refuse a join without relabeling the chain's ADMIT verdict. A physical-audit-qualified view is a separate downstream sensitivity filter, and it does not repair the core's trust in a colluding observer. Primary tables must expose this distinction.

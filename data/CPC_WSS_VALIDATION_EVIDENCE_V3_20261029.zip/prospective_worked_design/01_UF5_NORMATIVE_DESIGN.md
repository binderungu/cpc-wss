# Kontrak normatif UF5

Design ID CPC-WSS-WORKED-UF5-DENOMINATOR-V1-20261025. MUST berarti wajib dalam scope metode prospektif ini. Istilah hasil pada dokumen ini adalah hasil audit artefak, bukan enum core CPC atau perubahan schema program.

## Pertanyaan dan unit evaluasi

Untuk batch WSS tiga episode yang diprospektifkan, apakah handoff CPC memberikan kemampuan representation/reuse/inspectability yang konkret di atas counterpart B0 dan B2 yang memadai, untuk menelusuri positive lineage, reasoned hold, dan denominator dari delivered evidence yang sama?

Unit evaluasi adalah **artefak handoff pada scope/cohort/snapshot yang sama**, bukan mahasiswa, learning effect, preference, kecepatan manusia, jumlah fields atau jumlah file. Hasil dibatasi pada kasus dan paket yang diperiksa. T1–T4 bukan studi usability atau user trial.

## Persyaratan

- **U01 Common evidence:** ketiga arm MUST menerima seluruh common envelope dan policy yang sama. Per-arm receipt, digest, daftar object scope dan akses nyata MUST dapat dicocokkan. B0/B2 boleh memakai auxiliary sidecars, registry dan shared trace/report machinery. Common capture bukan kredit eksklusif CPC.
- **U02 Counterpart adequacy:** CPC reference, B0 native-centered dan B2 rules-centered masing-masing MUST memenuhi field crosswalk02–03. Format boleh berbeda; shared schema/machinery MUST diungkap. CPC tidak boleh dibandingkan dengan counterpart yang sengaja dipersempit atau belum selesai agar memperoleh keuntungan.
- **U03 Original results:** per-arm core/rules/native/terminal states MUST berasal dari output arm itu sendiri, dengan original locators. Meminjam trace projection diperbolehkan; menyalin verdict CPC menjadi B2 tidak diperbolehkan. B0/B2 berbagi rules engine/capture/catalogue/downstream machinery dan bukan dua replikasi independen.
- **U04 Fixed selection:** E1/E2 untuk T1 dan E3 untuk T2 dipilih sebelum run. Jangan mengganti objek karena tidak JOINED, failed, missing atau ambiguous. Satu item yang tidak tersedia tetap mempunyai record dan alasan. T3/T4 mencakup semua received/source-only/failed/partial objects dalam scope.
- **U05 Fixed tasks:** semua arm MUST dinilai dengan T1–T4 dan view netral yang sama. Record jawaban, per-link locators, expected relationships, contradictions, unresolved dependencies, shared components dan visibility/access state. UNKNOWN bukan bukti manfaat atau bukti no-added-value.
- **U06 Single source owner:** E3 memakai outcome_owner_ordinal=1 untuk serialisasi saja. Dua publikasi aktual tetap tercatat; nonowner tidak memperoleh cloned outcome/chain. Semua interpretasi actual two-publication attempt tetap HOLD_MULTI_INVOCATION, terpisah dari actual core disposition. Tidak mengganti owner bila ordinal1 gagal/uncertain.
- **U07 Full denominator:** hitung entire declared admitted/external scope sebelum filter scalar/validity/eligibility. Jangan dedup untuk mendapatkan singleton atau menjumlahkan grain/snapshot yang overlap. Source-only/no-chain tidak mendapat fake core verdict.
- **U08 Delivered access:** inspeksi MUST menggunakan delivered package/documentation yang diotorisasi, dengan capability dan auxiliary yang setara. Working directory penulis tidak boleh menjadi dependency diam-diam. Raw sessions/private keys tidak perlu didistribusikan; field/access crosswalk MUST menjelaskan authorized verifier atau evidence yang tersedia. Bila akses yang diperlukan tidak cukup, catat NOT_ASSESSABLE.
- **U09 Decision parity:** disagreement keputusan CPC/B0/B2 MUST diurai sebagai bug/spec/access mismatch sebelum UF5 diputuskan. Equality diterima dan tidak memutuskan UF5 sendirian. B1 tetap information ablation, boleh UNKNOWN/ABSTAIN, dan bukan counterpart superioritas.
- **U10 Residual claim:** setiap fitur yang diklaim MUST mempunyai locator CPC dan B0/B2, konsekuensi konkret pada tugas tetap, serta alasan bahwa residual bukan kosmetik, nama field, common capture, shared machinery atau implementation handicap yang dibuat-buat.
- **U11 Results integrity:** no-added-value, failure, hold, partial state dan missingness MUST dipertahankan. Tidak ada post-hoc threshold, retry, tambahan kasus atau perubahan policy untuk menghasilkan verdict yang disukai.
- **U12 Separation:** metode diputuskan sekarang; actual inputs/authority/freeze dan inspection evidence belum ada. UF5 tidak dinyatakan lulus dan technical QA tidak menjadi sample N atau scientific result.

## Aturan putusan berurutan

1. **NOT_ADJUDICATED / INSUFFICIENT_EVIDENCE:** common scope/akses tidak memadai; counterpart unfinished/unfair; object yang diperlukan tidak tersedia; T1–T4 belum dapat dijawab; atau mismatch penting belum terselesaikan. Missing evidence tidak menjadi residual benefit dan tidak otomatis menjadi no-added-value.
2. **NO_ADDED_LA_HANDOFF_VALUE:** counterpart yang sah/setara telah menyediakan kemampuan T1–T4 yang sama dan tidak ada residual nonkosmetik yang didukung. Ini hasil negatif yang sah untuk kasus ini; route/stop/retarget dengan genealogy tetap. Jangan berasumsi ada siklus repair tersisa.
3. **BOUNDED_HANDOFF_VALUE_SUPPORTED:** setelah seluruh prasyarat kecukupan dipenuhi, reviewer menunjukkan residual spesifik dengan locator, akibat konkret pada T1–T4, serta penjelasan terhadap kedua counterpart yang memadai. Reviewer harus menolak keuntungan yang berasal dari shared machinery atau akses tak adil. Tidak ada skor agregat, field-count threshold atau mayoritas vote yang otomatis menghasilkan status ini.

Fitur yang seluruhnya shared tidak boleh dikreditkan eksklusif kepada CPC. Jika hanya label atau format berbeda, itu tidak memenuhi residual. Kesimpulan bounded tidak membuktikan novelty terhadap seluruh prior art, utility pada populasi lain, efficiency, learning/causal effect atau kelayakan JLA; adjudikasi kontribusi tetap tahap berikutnya.

## Keputusan dan review

Inspector merekam bukti; Codex memverifikasi identity/counts/locators; Pro melakukan adjudikasi ilmiah sesuai scope yang kelak diotorisasi. Penulis menetapkan rights dan keputusan kelanjutan. Bila review lain telah disepakati, simpan actual reviewer/version/scope/date/verdict; jangan menggantikannya dengan self-review atau subtugas audit sebelumnya. Tidak ada kontak/review baru pada paket ini.

# Common envelope dan counterpart

## Inventory bersama yang wajib

Satu envelope immutable kelak mengikat scope/cohort/snapshot, source epoch, exact raw input/core chains, native event/value/item/presentation snapshots, operation/close/freshness/ACK receipts, actor/context, assignment dan approved bundle/config, actual consumed prompt/generation/output references, semua publication statuses, first selected follow-up, approved recipe/domain/rubric, seluruh external rows, profile/registry/key-role policy/validation time dan complete denominator/store inventory.

Daftar inventory MUST memberi relative path, bytes, digest, evidence class, allowed audience, role dan relationship ke original typed reference. Directory path/hash sendiri bukan bukti hak atau source truth. Raw source/session/key yang tidak boleh didistribusikan dipetakan ke jalur verifikasi/access yang sah; jangan mengklaim inspeksi selesai bila missing/withheld link menentukan jawabannya. Tidak memasukkan private signing keys ke paket pembaca.

Common envelope hanya satu salinan fisik bila diacu dari tiga manifests. Salinan per arm boleh dibuat hanya jika digest/bytes/scope identik. Digest actual belum dibuat pada desain ini. Root inventory/selection scope MUST ditetapkan sebelum hasil; semua actual added/failure/partial records di scope dicatat, tidak disaring agar cocok dengan rencana.

## Tiga counterpart

| Arm | Representasi pokok | Output keputusan | Bukti dan auxiliary |
|---|---|---|---|
| CPC_REFERENCE | Profile/reference workflow handoff | Actual CPC receipt + downstream native/join | Common envelope penuh |
| B0 | Native-centered handoff/SOP dengan sidecars | Output proper-use rules arm sendiri | Common envelope penuh; boleh memakai trace projection/report schema yang sama |
| B2 | Rules-centered handoff | Output rules tanpa keputusan CPC sebagai oracle | Common envelope penuh; shared specification/catalogue/adapter/capture diungkap |

B0/B2 bukan dua replikasi independen; current implementation memakai shared rules machinery. Ketiganya MUST dapat menjawab seluruh T1–T4. B1 tidak masuk tiga counterpart UF5 karena merupakan explicit information ablation; hasilnya tetap dilaporkan terpisah bila tersedia.

## Manifest counterpart yang kelak diisi

Wajib ada arm, counterpart_ref, common_evidence_digest, common_inventory_ref, source/version/digest engine, original result locator(s), field_crosswalk_ref, neutral_view_ref, all_dependencies, shared_components, access_receipt_ref dan field_access_crosswalk. Identitas run/cohort/snapshot dan prefix/terminal relationship MUST eksplisit. Null pada template berarti belum dimaterialisasi, bukan nilai runtime yang sah.

Current reporting.py:382–423 mempertahankan seluruh comparison/native/outcome ledgers, sementara source_map/examples diambil dari CPC_REFERENCE. Itu tidak membuktikan withholding. Implementasi berikut boleh memanfaatkan ledgers tersebut untuk counterpart yang adil, tetapi per-arm projection/crosswalk belum dikualifikasikan. Dokumen ini menetapkan requirements; tidak menambahkan writer/projection code.

## Adequacy checklist sebelum penilaian residual

1. Cocokkan common digest, object ID scope dan policy/validation time untuk tiga arm.
2. Cocokkan actual access, termasuk auxiliary dan verifier routes. Akses parsial yang mempengaruhi jawaban menjadi blocker.
3. Buka original output arm. Identitas rujukan dan hasil tidak boleh berasal dari relabel CPC output.
4. Pastikan seluruh field03 mempunyai binding, state dan provenance; format berbeda bukan kekurangan.
5. Cocokkan counts dengan kamus05 pada snapshot yang sama. Simpan failures, no-chain, missing/invalid dan uncertain states.
6. Jika counterpart belum selesai/masih sengaja dipersempit, tandai UF5 NOT_ADJUDICATED; jangan mencatat kemenangan CPC.

Semua enam langkah belum dijalankan atas actual worked evidence. Daftar ini bukan grant atau reader-access approval.

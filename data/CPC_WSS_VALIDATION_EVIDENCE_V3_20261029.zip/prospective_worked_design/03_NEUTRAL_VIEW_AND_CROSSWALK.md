# View netral dan field crosswalk

`design/NEUTRAL_VIEW_FIELDS.json` menetapkan nama, grain dan kewajiban field untuk deliverable mendatang. Ini spesifikasi serialisasi artefak audit, bukan perubahan schema CPC/validator/export program.

## Bentuk paket netral

- `scope.json`: satu scope descriptor per arm/cohort/snapshot, dengan common envelope identity, captured prefix head/sequence, current analysis reference dan relasi terminal view.
- `core_rows.jsonl`: satu row per **received raw core input occurrence** dalam scope per arm, termasuk unresolved evaluation. Input_ref yang sama pada snapshot/arm berbeda adalah grain berbeda; digest bytes yang sama tidak mengizinkan dedup. Bila duplicate input occurrence sungguh diterima, ordinal receipt tetap membedakannya.
- `source_only_rows.jsonl`: satu row per nonowner publication/no-complete-chain, failed/uncertain invocation atau native/source branch tanpa received core. Jenis record MUST eksplisit; baris yang bukan publication tidak diberi publication ID fiktif. Core disposition null; tidak dimasukkan REJECT/QUARANTINE.
- `denominator.jsonl`: satu record per grain/scope/arm basis yang didefinisikan05. Lists/member-locators dan predicate diperlukan, bukan scalar count tanpa dasar.
- `field_crosswalk.json`: setiap field canonical ke original path/JSON pointer/record ID serta aturan transformasi deklaratif dan dependencies. Ketiadaan mapping dicatat; tidak mengarang ID.

`core_rows` adalah normalisasi data tersimpan, tidak menjalankan ulang core untuk mengganti verdict lama. View terpisah menyimpan hasil asli masing-masing arm. Semua raw external received rows dipertahankan dalam common inventory: unmatched/invalid/missing/duplicate rows tidak hilang karena tidak JOINED.

## Semantik field

Scope meliputi run_ref, cohort_ref, snapshot_ref, arm dan common_evidence_digest. Core row mengikat input occurrence ordinal, input_ref, raw digest/ref, actual disposition atau unresolved API; actual native mapping/reasons; actual eligible terminal atau ketidaktersediaannya; key/source/item/version/presentation refs; source ownership; actual consumption/publications; recipe/external refs dan missingness. Ke-enam komponen declared tetap declared. Raw source-only records mempertahankan status nyata dan alasan tanpa fake core result.

Reference descriptor berbentuk `{state, locators, reason}`. State AVAILABLE memerlukan relative path + exact pointer/record ID dan bytes/digest bila objek file. MISSING, WITHHELD, UNRESOLVED dan NOT_APPLICABLE tidak saling menggantikan; selain AVAILABLE harus mempunyai alasan. Tidak ada empty string atau null yang ditafsirkan sebagai bukti. Actual values tidak diisi pada desain ini.

HOLD E3 tidak menjadi REJECT CPC. Untuk actual two-publication attempt, view menunjukkan owner1, semua publications, nonowner no-chain, actual core disposition dan native hold/reasons; terminal tidak JOINED dan joined scalar null. Jika input belum diterima, tempatnya source-only dengan `core_disposition=null`, bukan core_rows palsu.

## Scope snapshot

`captured_prefix_head` dan basis_sequence mengikat immutable view yang dievaluasi. Current analysis reference dapat berada di luar riwayat yang termuat pada prefix-nya sendiri. Terminal controller view diberi digest/sequence sendiri dan daftar event delta. Jangan mengubah prefix count agar sama dengan terminal atau menjumlahkan keduanya. Hubungan prefix/terminal dibuktikan dengan event/identity lineage; bila tidak ada, status UNRESOLVED, bukan asumsi bahwa delta selalu satu.

## Crosswalk yang adil

Tiap arm wajib mengisi field yang sama dengan output/provenance arm sendiri. Shared trace projections diperbolehkan dan diungkap. Transformasi hanya mengganti representasi/menautkan references yang sudah ada; tidak memilih latest valid response, menebak approved IDs, mengisi missing score0, mengubah verdict, atau menghasilkan outcome clone.

Untuk T4, delivered inventory dan dokumentasi harus cukup untuk menautkan/membaca view netral. Bila pembentukan view memerlukan utility baru, utility dan instruksi harus kelak disertakan, diotorisasi dan dikualifikasikan sebelum pemakaian; desain ini tidak menganggapnya sudah tersedia. Inspection tidak boleh memakai absolute author working paths sebagai dependency tersembunyi.

Access crosswalk mencatat required field, audience, supplied locator/verifier route dan apakah kebutuhan T1–T4 terpenuhi. Restricted request route boleh, tetapi harus sungguh tersedia dan sah pada evaluasi. Public aggregate-only reader_candidate tidak dianggap memenuhi seluruh linkage UF6.

Metadata crosswalk (canonical field, transform, dependencies dan sebagainya) merujuk versi desain ini dan tidak membutuhkan mapping rekursif ke dirinya sendiri. Source-binding requirements berlaku pada field scope/core/source-only/denominator. Konstanta label/desain harus ditandai sebagai transformasi deklaratif, bukan observed native facts.

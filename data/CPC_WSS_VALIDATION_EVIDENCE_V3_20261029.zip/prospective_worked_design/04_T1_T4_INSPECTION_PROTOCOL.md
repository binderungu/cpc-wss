# Prosedur inspeksi T1–T4

Status: metode prospektif diadopsi; seluruh record aktual NOT_PERFORMED. Tidak ada inspeksi worked evidence, replay, view-building execution atau studi manusia dijalankan pada penutupan dokumen ini.

## Persiapan yang wajib

Sebelum result-producing run, tetapkan versi/hash metode ini, common-envelope requirements, counterpart manifest/crosswalk, view netral, exact material/domain/presentation, E3 owner1, kamus denominator dan rute inspector/reviewer. Actual hashes/rights/authority/runtime/window menunggu gate tersendiri. Bila perubahan metode material diperlukan, versi baru dan review/route yang nyata harus mendahului dependent run; pertahankan versi ini, jangan menyebut keputusan post-hoc sebagai prospektif.

Sesudah run yang kelak sah, inspector terlebih dahulu memeriksa scope/access/identity/adequacy02. Inspector melihat nama arm untuk menelusuri provenance; ini informed artifact inspection, bukan blinded usability trial. Auditor tidak mengklaim independence dari hasil buatan sendiri. Pro melakukan adjudikasi ilmiah menurut otorisasi berikutnya; review lain yang disepakati tetap terpisah.

Gunakan seluruh tiga arm dan urutan tetap CPC_REFERENCE, B0, B2 pada setiap task untuk keperluan pencatatan. Urutan itu tidak menjadi kontrol efek urutan manusia; tidak ada klaim waktu/preference. Untuk setiap task catat evidence state secara terpisah per object/subquestion, lalu simpulan task tanpa skor gabungan. Template berisi 12 slot arm×task; T1 memuat E1 dan E2 sebagai objek terpisah.

## T1: positive lineage, objek E1 dan E2

Mulai dari row E1/E2 yang **aktual** diklaim JOINED oleh arm. Jika tidak ada row JOINED, pertahankan actual disposition/terminal/failure dan catat objek tidak dapat mendemonstrasikan positive path; jangan memilih episode pengganti.

Wajib telusuri:

1. Raw input occurrence dan original arm result ke exact source epoch/native task event/value/item/context dan version/presentation.
2. Attempt dan fixed assignment ke actual invocation serta approved prompt/generation bundle.
3. Actual consumed prompt/generation dan final exposure/publication references; pisahkan declared components dan asserted source truth.
4. First selected native follow-up dengan exact occurrence/value/item/version/presentation; selected tidak diganti karena missing/invalid/score.
5. Single source owner ke exact recipe/rubric/domain dan external row; score lookup dari actual retained bytes, bukan condition/admission/keyhash.
6. Original core/native/join receipts dan entire multiplicity basis yang menghasilkan JOINED.

Simpan setiap link sebagai required relationship + locator/value + supported/contradicted/unavailable reason. Score0 valid berbeda dari MISSING/INVALID/null. Tidak ada learning gain conclusion. Bila sebagian link hilang, jawaban tidak otomatis SUPPORTED meskipun core ADMIT.

## T2: E3 ambiguity hold, objek E3

Cari semua invocation/publication attempts, successful/failed/uncertain, sebelum first selected follow-up. Untuk E3 yang aktual menyelesaikan **dua publikasi**, tunjukkan kedua IDs, settled chronology, source key tunggal, serialization owner ordinal1 dan nonowner NO_OUTCOME_CHAIN/NOT_SUBMITTED. Periksa satu outcome derivation/source ownership, actual core disposition yang tidak dimodifikasi, native HOLD_MULTI_INVOCATION serta terminal NATIVE_MAPPING_HOLD tanpa JOINED scalar.

Owner1 bukan scientific attribution ke bantuan pertama. Nonowner tidak diberi fake REJECT/QUARANTINE dan tidak dimasukkan denominator received core jika raw input belum diterima. Bila salah satu publikasi gagal/uncertain, simpan actual failure/partial state; planned two-publication demonstration menjadi NOT_ASSESSABLE atau NOT_EXERCISED sesuai objeknya. Jangan memaksakan HOLD_MULTI_INVOCATION, memilih later successful owner, mengulang atau menambah kasus untuk memperoleh pola ideal.

## T3: rekonstruksi seluruh denominator

Gunakan daftar grain05 dan seluruh manifest scope. Rekonstruksi dari member identities dan actual statuses:

- Episodes/planned opportunities versus controller opportunity, operation attempts, actual finalization attempts dan known/unknown completion.
- Actual helper launches/calls versus supplied transport observations, canonical occurrences versus ingestions/duplicates, selected versus other follow-up/revisions.
- All invocations termasuk pre-publication failure, successful/uncertain publication dan source-only/no-chain branches.
- Derivations, external received rows, complete/partial chains versus received core inputs/unresolved evaluations.
- Untuk tiap arm: received core partition; ADMIT mapping partition; eligible terminal partition. Cardinality dihitung sebelum filtering validity/scalar/eligibility.
- Scope prefix/terminal dan orphan/partial/missing inventories; tidak menjumlahkan overlapping snapshots.

Simpan formula, count dan member IDs/locators. Bila equality aritmetis terjadi tetapi member identities salah/overlap, hasil tetap CONTRADICTED. Unknown counts tetap null dengan alasan; bukan0. Project QA methods/subtests dan D1–D3historical refs tidak menjadi native N.

## T4: reuse terbatas dari delivered artefacts

Satu target view netral03 dan field dictionary dipakai pada semua arm. Berikan hanya delivered package/documentation dan rute akses yang sah. Catat inventory/version/hash yang tersedia bagi inspector. Rekonstruksi jawaban T1–T3 melalui crosswalk dan transformasi deklaratif yang ditetapkan sebelum hasil. Setiap transformasi/utilitas/dependency dicatat; tidak boleh menggunakan hidden author working directory, ad-hoc selection/policy, assumed IDs atau extra native reads.

Periksa nilai/identity/kelengkapan view, bukan kecepatan, kemudahan, banyaknya klik, jumlah file/field atau preferensi pengguna. Jika utility belum tersedia atau data withheld menentukan jawaban, catat NOT_ASSESSABLE dan dependency yang hilang. Jangan memberi counterpart yang unfinished label kalah. Utility yang kelak dieksekusi memerlukan scope terpisah; paket ini tidak menjalankannya.

## Evidence state dan prosedur keputusan

Untuk setiap subquestion dan task/object:

- **SUPPORTED:** required relationships benar-benar ditunjukkan oleh locators yang tersedia dalam declared scope; tidak bergantung pada inference yang tidak diungkap.
- **CONTRADICTED:** evidence aktual bertentangan dengan required relationship; simpan kedua locator dan dampaknya.
- **NOT_ASSESSABLE:** data, akses, object atau dependency yang diperlukan tidak tersedia/uncertain. Tidak sama dengan CONTRADICTED atau0.

`NOT_PERFORMED` hanya workflow state template sebelum penilaian, bukan hasil keempat. Simpulan task memuat seluruh subquestions; satu contradiction relevan harus terlihat, dan gap kritis mencegah klaim task lengkap. Tidak ada pass-rate agregat yang mengganti penilaian ilmiah.

Sesudah semua counterpart memadai dan task records tersedia, isi residual-feature crosswalk. Untuk setiap claimed feature: locator CPC dan masing-masing B0/B2, shared component, concrete consequence pada task, cosmetic/access/implementation confounds dan alasan keputusan. Gunakan urutan putusan01. Simpan disagreement, unsupported claims dan negative findings. Pro/adjudicator harus memberi alasan exact feature/task/locator, bukan kesan bahwa CPC tampak lebih rapi.

Jika counterparty menyediakan kemampuan T1–T4 setara dan tidak ada residual nonkosmetik yang didukung, NO_ADDED_LA_HANDOFF_VALUE sah. Jika T1–T4 tidak lengkap, verdict INSUFFICIENT_EVIDENCE; jangan mengubah ketiadaan bukti menjadi manfaat atau no-added-value. Tidak ada task/answer/putusannya yang diisi sebagai actual pada paket ini.

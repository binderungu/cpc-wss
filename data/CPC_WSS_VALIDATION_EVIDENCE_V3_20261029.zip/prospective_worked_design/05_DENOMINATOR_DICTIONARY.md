# Kamus denominator dan oracle bersyarat

Desain prospektif; semua actual counts belum dikumpulkan. Rincian machine-readable: design/DENOMINATOR_ORACLE.json. Nilai bersyarat adalah ilustrasi rencana, bukan target yang harus dipenuhi dengan retry atau penggantian kasus.

## Grain dan basis

| Grain | Definisi dan identitas hitung | Ideal bersyarat | Batas |
|---|---|---:|---|
| episode_opportunities_planned | Entry E1/E2/E3 dalam frozen prospective plan |3| Bukan controller emission dan bukan3learner |
| episode_task_opportunities_reached | Episode yang mencapai TASK opportunity, dibuktikan mapping E→opportunity ID |3| Turunan subset TASK, jangan ditambah ke opportunity total |
| controller_operation_opportunities | Distinct opportunity IDs yang benar-benar dipersist; TASK dan FOLLOWUP terpisah |6| Source worked_runner.py:216; orphan opportunity sebelum begin_operation dapat tetap dihitung |
| controller_operations | Distinct durable operation_ref, kind TASK/FOLLOWUP |6 (3+3)| Bukan ordinary finalization success count; tiap op merujuk opportunity-nya |
| native_finalization_attempts | Actual ordinary form-finalization attempt receipt, charged sebelum submit |6 (3+3)| Operation yang dibuat belum membuktikan submit dikirim; no blind resubmit |
| known/unknown completion | Partition attempt receipts menurut evidence completion |Conditional known6| HTTP200/helper match saja tidak membuktikan known; unresolved tetapunknown |
| protocol_helper_calls | Actual helper launches/requests, termasuk failed/timeout |≤18| Ceiling candidate, bukan requirement18; max3slot/op; butuh grant baru |
| supplied_observations | Immutable wire envelopes yang diberikan kepada controller |Tidak dipatok| Tidak membuktikan jumlah actual helper calls; extra unused envelopes tetap retained |
| canonical_native_occurrences | Distinct native finalization event identity dalam source epoch |6 jika route lengkap tepat| Same completed_id dapat dipakai ulang; values/versions/snapshots tetapdibedakan |
| ingestions | Distinct ingestion receipts, termasuk duplicate/failed observations |Tidak dipatok| Duplicate ingestion bukan native occurrence baru |
| attempts | Distinct controller task attempt_ref dari canonical TASK occurrence |3| Bukan operation attempt, invocation atau learner N |
| invocations | Invocation_ref sebelum preprocessing/generation dapat gagal |4| Semua failed/uncertain tetap masuk |
| publication_attempts | Actual designated publication attempt receipts |4| Budget candidate4, bukan bukti4success |
| successful_publications | Distinct final publication IDs berstatus successful |4| Uncertain/failed dihitung terpisah; tidak diberi successful ID buatan |
| selected_followups | First selected native follow-up/source per task attempt |3| Tidak memilih latest/firstvalid/score-terbaik |
| other_followups_or_revisions | Follow-up/revision receipts selain selected, termasuk post-close |Tidak dipatok| Tidak dihapus untuk menyelamatkan join |
| outcome_derivations | Distinct derivation request refs dan terminal status |3 successful ideal| Failed/pending termasuk received derivations, bukan default score0 |
| external_received_rows | Seluruh row occurrences diterima downstream dalam declared scope |3 ideal| Duplicate/invalid/unmatched semua retained, cardinality sebelumfilter |
| complete_chain_assemblies | Chain selesai dirakit; distinct assembly/output identity |3 ideal| Belum tentu disubmit/diterima core |
| received_core_inputs per arm | Raw input receipt occurrence yang diterima evaluator |3 ideal| Complete/not-submitted/partial/source-only tidak dicampur |
| source_only_no_chain_publications | Successful publication tanpa complete outcome chain |1 ideal (E3 nonowner)| Tidak mempunyai core verdict dan bukan fake reject bucket |
| core/native/terminal partitions | Member lists per input/arm/snapshot |Lihat di bawah| Actual result dipertahankan; tidak dipaksa3ADMIT |
| captured_prefix_analyses | Distinct historical analysis events dalam basis prefix handoff |Tidak dipatok| Current analysis diidentifikasi terpisah, tidak otomatis masuk prefix sendiri |
| terminal_controller_analyses | Analysis event set pada terminal controller view |Tidak dipatok| Snapshot/sequence/digest terpisah; bukan koreksi prefixcount |

Outcome/source-only grain dapat overlap dengan publication/invocation melalui relasi yang eksplisit; jangan menjumlahkannya menjadi total sample. Begitu pula raw external rows versus derivations: satu derivation gagal dapat menghasilkan no row, duplicate delivery dapat menghasilkan lebih dari satu row occurrence. Jangan berasumsi one-to-one tanpa receipts.

Preflight/configuration/cleanup reads, local file inspections T1–T4, protocol helper calls dan native finalization attempts berada pada access/action ledgers yang berbeda. Max18 khusus protocol helper calls yang direncanakan; tidak menyelundupkan preflight/cleanup akses ke budget ini atau mengotorisasikannya lewat desain. Actual launch tanpa usable envelope tetap charged. File-envelope count tidak dipakai sebagai pengganti launch receipt.

## Relasi dan rekonsiliasi

Setiap record count MUST mempunyai `{grain, scope_ref, arm_or_shared, snapshot_basis, predicate, member_refs, count_state, actual_count, reason}`. AVAILABLE exact count mempunyai complete member identity basis; UNKNOWN/PARTIAL count tidak diganti0. Observed lower bound disimpan sebagai lower_bound terpisah jika scope tidak lengkap. Plan count tetap field planned, tidak dipindah ke actual_count.

Untuk semua identities dalam satu declared scope:

- controller_operations merujuk subset valid controller opportunities; satu operation per opportunity pada route ini. Opportunity yang dipersist lalu begin_operation gagal tetap ada dan perlu alasan tanpa operation fiktif.
- operation creation, native finalization attempt, completion knowledge dan observed canonical event adalah tahap berbeda. Tidak ada equality wajib di antaranya pada failures.
- received_core = ADMIT + REJECT + QUARANTINE + ERROR_INPUT + NOT_EVALUATED_CONFIG + unresolved_API, dengan member sets disjoint/covering. unresolved_API adalah accounting state untuk result belum tersedia, bukan core disposition baru.
- ADMIT = PENDING + HOLD + ELIGIBLE pada actual native mapping. Mapping evaluation unresolved dipertahankan sebagai PENDING dengan alasan asli bila memang itu hasil arm.
- ELIGIBLE = JOINED + ADMISSION_COMPOSITE_AMBIGUOUS + EXTERNAL_COMPOSITE_AMBIGUOUS + EXTERNAL_MISSING + EXTERNAL_MEASURE_INVALID. Gunakan original terminal states, termasuk scalar missingness. Baca entire admitted/external scope sebelum filter.
- received derivations dipartisi actual DERIVED/FAILED/PENDING sesuai receipt; tidak menyamakan failed/pending dengan score0 atau external row valid.
- received/no-chain/partial/not-submitted/as-yet-unresolved inventory MUST mencakup semua declared branches tanpa menciptakan fabricated raw inputs/verdicts.

## Oracle rencana lengkap (semua syarat terpenuhi)

| Episode | TASK/FOLLOWUP operations | Invocations/successful publications | Single-owner outcome/complete received chain | Source-only nonowner |
|---|---:|---:|---:|---:|
| E1 hint/G_BASE |1+1|1|1|0|
| E2 answer/G_BASE |1+1|1|1|0|
| E3 hint/G_BASE |1+1|2|1|1|
| Total |3+3|4|3|1|

Tiga episode opportunities terencana ≠ enam controller operation opportunities. Jika semua tiga complete inputs benar-benar ADMIT dan native/source/authority/singleton syarat terpenuhi, conditional result adalah2ELIGIBLE→JOINED dan1HOLD(E3). Tidak ada received fourth core row untuk E3 nonowner. Actual R/Q/ERROR/unresolved/missing results tetapmengubah rekonsiliasi; coreADMIT tidak diwajibkan agar demo dianggap terlaksana.

Planned follow-up fixture responses sama4 untuk E1/E2/E3 bila actual retained response dan approved exact recipe mendukungnya. Historical representative QA memakai2,2,2 dan tidak menjadi worked score. Label education/outcome tidak menambah N manusia atau validitas learning measure.

## Scope analyses prefix/terminal

Analysis disimpan dari immutable prefix sebelum event analisis itu sendiri ditambahkan. Catat basis_sequence, captured_head, analysis_ref dan terminal_view_ref. Historical QA memberi prefix3 dan terminal4; itu satu contoh lineage, bukan fixed oracle bagi run baru. Jika terminal berisi current analysis dan tidak ada event analysis lain, terminal_count = prefix_count+1 **hanya bila** hubungan tersebut dibuktikan. Jika perbedaan lain muncul, simpan event delta aktual, jangan menambah/mengurangi counter tanpa sumber.

## Contoh penalaran dokumenter parsial (bukan run)

- **P01 Stop sebelum E2:** hanya E1 selesai dan runner berhenti sebelum E2 opportunity. Planned episodes tetap3; reached TASK opportunities1; controller opportunities2/operations2 bila kedua operasi E1 dibuat. Tidak mengklaim6ops atau threeattempts. Jumlah actual reads/ingestions tetap dari receipts, tidak diasumsikan2 atau6.
- **P02 Opportunity tersimpan, begin_operation gagal:** satu opportunity dapat ada tanpa operation. Catat orphan/failed transition dan scope stop. Jangan memaksakan equal count opportunity=operation.
- **P03 Publikasi kedua E3 gagal/uncertain:** dua invocation/publication attempts dapat ada tetapi hanya satu successful publication. Satu outcome/chain mungkin belum dibuat karena runnerstop. Jangan memaksakan two-publication HOLD atau mempromosikan owner2 untuk menyelesaikan ilustrasi.
- **P04 Duplicate ingestion:** dua ingestion receipts dapat menunjuk satu canonical occurrence. Pertahankan keduanya; canonical occurrence tidak ditambah untuk mengejaringestionN.
- **P05 Driver exit1 sesudah durable outputs:** counts adalah yang tersimpan beserta completeness scope; exit1 tetap dilaporkan, tanpa retry demi stdoutbersih. Historical21Oct tetap histori tersendiri.

Contoh-contoh ini adalah pemeriksaan logika kamus, bukan behavioral test atau observasi baru. Actual receipt IDs, counts dan event deltas tetap belumada.
